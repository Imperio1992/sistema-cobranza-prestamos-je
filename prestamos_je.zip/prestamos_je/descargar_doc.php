<?php
session_start();
include("conexion.php");

// Solo usuarios autenticados
if (!isset($_SESSION['rol'])) {
    header("HTTP/1.0 403 Forbidden");
    exit('Acceso denegado.');
}

$id_doc = intval($_GET['id'] ?? 0);
if (!$id_doc) {
    header("HTTP/1.0 400 Bad Request");
    exit('ID inválido.');
}

// Obtener registro del documento
$stmt = $conexion->prepare("SELECT * FROM documentos_cliente WHERE id_doc = ? LIMIT 1");
$stmt->bind_param("i", $id_doc);
$stmt->execute();
$doc = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doc) {
    header("HTTP/1.0 404 Not Found");
    exit('Documento no encontrado.');
}

$ruta_fisica = __DIR__ . '/' . $doc['ruta_archivo'];

if (!file_exists($ruta_fisica)) {
    header("HTTP/1.0 404 Not Found");
    exit('Archivo no encontrado en el servidor.');
}

// Detectar MIME
$ext  = strtolower(pathinfo($doc['nombre_archivo'], PATHINFO_EXTENSION));
$mime_map = [
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png'  => 'image/png',
    'webp' => 'image/webp',
    'pdf'  => 'application/pdf',
];
$mime = $mime_map[$ext] ?? 'application/octet-stream';

// Nombre de descarga amigable: TIPO_apellido_nombre.ext
$nombre_descarga = $doc['tipo'] . '.' . $ext;

// Enviar archivo como descarga forzada
header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . $nombre_descarga . '"');
header('Content-Length: ' . filesize($ruta_fisica));
header('Cache-Control: private, no-cache');
header('Pragma: no-cache');

readfile($ruta_fisica);
exit;

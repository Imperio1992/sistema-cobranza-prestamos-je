<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$id_cliente = intval($_GET['id'] ?? 0);
if (!$id_cliente) { header("Location: clientes.php"); exit; }

$stmt = $conexion->prepare("
    SELECT id_cliente, nombre, apellido, estatus, fecha_desbloqueo
    FROM clientes WHERE id_cliente = ? LIMIT 1
");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();

if (!$c || $c['estatus'] !== 'BLOQUEADO') {
    header("Location: clientes.php"); exit;
}

$hoy = date('Y-m-d');
if (!empty($c['fecha_desbloqueo']) && $hoy < $c['fecha_desbloqueo']) {
    header("Location: clientes.php?error=fecha"); exit;
}

$upd = $conexion->prepare("
    UPDATE clientes SET estatus='ACTIVO', motivo_bloqueo=NULL, fecha_desbloqueo=NULL WHERE id_cliente=?
");
$upd->bind_param("i", $id_cliente);
$upd->execute();

header("Location: clientes.php?desbloqueado=1");
exit;

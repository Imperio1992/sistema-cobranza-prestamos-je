<?php
/*
 * guardar_visita.php
 * Registra una visita en historial_visitas y actualiza score_crediticio.
 *
 * SQL requerido (ejecutar en phpMyAdmin si la tabla no existe):
 *
 * CREATE TABLE IF NOT EXISTS historial_visitas (
 *   id            INT AUTO_INCREMENT PRIMARY KEY,
 *   id_cliente    INT NOT NULL,
 *   id_prestamo   INT DEFAULT NULL,
 *   id_empleado   INT DEFAULT NULL,
 *   fecha_visita  DATE NOT NULL,
 *   resultado     ENUM('PAGO','NO_PAGO','PAGO_PARCIAL','PROMESA_PAGO','NO_ENCONTRADO') NOT NULL,
 *   comentario    TEXT DEFAULT NULL,
 *   creado_en     DATETIME DEFAULT CURRENT_TIMESTAMP,
 *   FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
 * ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 */

date_default_timezone_set('America/Hermosillo');

$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR'];
include("seguridad.php");
include("conexion.php");

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'msg' => 'Método no permitido']);
    exit;
}

/* ── ENTRADAS ── */
$id_prestamo = intval($_POST['id_prestamo'] ?? 0);
$id_cliente  = intval($_POST['id_cliente']  ?? 0);
$resultado   = trim($_POST['resultado']     ?? '');
$comentario  = trim($_POST['comentario']    ?? '');
$fecha       = trim($_POST['fecha']         ?? date('Y-m-d'));
$id_empleado = intval($_SESSION['id_empleado'] ?? 0);

/* ── VALIDACIONES ── */
$resultados_validos = ['PAGO', 'NO_PAGO', 'PAGO_PARCIAL', 'PROMESA_PAGO', 'NO_ENCONTRADO'];

if ($id_cliente <= 0) {
    echo json_encode(['ok' => false, 'msg' => 'Cliente inválido']);
    exit;
}
if (!in_array($resultado, $resultados_validos)) {
    echo json_encode(['ok' => false, 'msg' => 'Resultado inválido']);
    exit;
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) {
    $fecha = date('Y-m-d');
}

/* ── VERIFICAR QUE LA TABLA EXISTE ── */
$check = $conexion->query("SHOW TABLES LIKE 'historial_visitas'");
if (!$check || $check->num_rows === 0) {
    $conexion->query("
        CREATE TABLE IF NOT EXISTS historial_visitas (
            id           INT AUTO_INCREMENT PRIMARY KEY,
            id_cliente   INT NOT NULL,
            id_prestamo  INT DEFAULT NULL,
            id_empleado  INT DEFAULT NULL,
            fecha_visita DATE NOT NULL,
            resultado    ENUM('PAGO','NO_PAGO','PAGO_PARCIAL','PROMESA_PAGO','NO_ENCONTRADO') NOT NULL,
            comentario   TEXT DEFAULT NULL,
            creado_en    DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

/* ── DELTA DE SCORE ── */
$deltas = [
    'PAGO'          =>  2,
    'PAGO_PARCIAL'  => -1,
    'NO_PAGO'       => -3,
    'PROMESA_PAGO'  => -1,
    'NO_ENCONTRADO' => -1,
];
$delta = $deltas[$resultado] ?? 0;

/* ── ESCAPE ── */
$res_esc = $conexion->real_escape_string($resultado);
$com_esc = $conexion->real_escape_string($comentario);
$fec_esc = $conexion->real_escape_string($fecha);
$pre_val = $id_prestamo > 0 ? $id_prestamo : 'NULL';
$emp_val = $id_empleado > 0 ? $id_empleado : 'NULL';

/* ── INSERTAR VISITA ── */
$ok = $conexion->query("
    INSERT INTO historial_visitas
        (id_cliente, id_prestamo, id_empleado, fecha_visita, resultado, comentario)
    VALUES
        ($id_cliente, $pre_val, $emp_val, '$fec_esc', '$res_esc', '$com_esc')
");

if (!$ok) {
    echo json_encode(['ok' => false, 'msg' => 'Error al guardar visita: ' . $conexion->error]);
    exit;
}

/* ── ACTUALIZAR SCORE (límite 0–200) ── */
$conexion->query("
    UPDATE clientes
    SET score_crediticio = GREATEST(0, LEAST(200, COALESCE(score_crediticio, 100) + ($delta)))
    WHERE id_cliente = $id_cliente
");

/* ── LEER SCORE ACTUALIZADO ── */
$row   = $conexion->query("SELECT score_crediticio FROM clientes WHERE id_cliente = $id_cliente")->fetch_assoc();
$score = intval($row['score_crediticio'] ?? 100);

echo json_encode([
    'ok'    => true,
    'msg'   => 'Visita registrada correctamente',
    'delta' => $delta,
    'score' => $score,
]);

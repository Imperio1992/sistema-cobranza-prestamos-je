<?php
require_once 'config.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json');

// Verificar sesion
if (!isset($_SESSION['id_usuario']) || !isset($_SESSION['rol'])) {
    echo json_encode(['ok' => false, 'error' => 'Sesion no activa']);
    exit;
}

// Solo metodo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'error' => 'Metodo no permitido']);
    exit;
}

$id_prestamo = intval($_POST['id_prestamo'] ?? 0);
$monto       = floatval($_POST['monto'] ?? 0);
$tipo        = trim($_POST['tipo'] ?? 'EFECTIVO');
$id_empleado = intval($_POST['id_empleado'] ?? 0);

if (!$id_prestamo) {
    echo json_encode(['ok' => false, 'error' => 'ID de prestamo invalido']);
    exit;
}

// Tipos de pago permitidos
$tipos_validos = ['EFECTIVO', 'TRANSFERENCIA', 'ATRASO'];
if (!in_array($tipo, $tipos_validos)) {
    $tipo = 'EFECTIVO';
}

// Si el monto es 0, es un atraso
if ($monto == 0) {
    $tipo = 'ATRASO';
}

$conn = getDB();

// Usar la misma hora que MySQL para que coincida con cobranza_diaria.php
// Obtenemos NOW() y CURDATE() directo desde MySQL (evita diferencias de zona horaria con PHP)
$resTime = $conn->query("SELECT NOW() as ahora, CURDATE() as hoy");
$timeRow = $resTime->fetch_assoc();
$ahora_mysql = $timeRow['ahora'];   // datetime exacto de MySQL
$hoy_mysql   = $timeRow['hoy'];     // date exacta de MySQL

// Verificar que el prestamo existe y esta activo/atrasado
$stmt = $conn->prepare("
    SELECT p.id_prestamo, p.saldo_actual, p.estado, p.pago_diario, p.total_pagar, p.total_pagado,
           c.id_asesor, p.id_cliente
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    WHERE p.id_prestamo = ?
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$prestamo = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$prestamo) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'Prestamo no encontrado']);
    exit;
}

if (!in_array($prestamo['estado'], ['ACTIVO', 'ATRASADO'])) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'El prestamo no esta activo']);
    exit;
}

// Si es ASESOR, verificar que el cliente es suyo
if ($_SESSION['rol'] === 'ASESOR') {
    $stmt = $conn->prepare("SELECT id_empleado FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $_SESSION['id_usuario']);
    $stmt->execute();
    $resUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($resUser['id_empleado'] != $prestamo['id_asesor']) {
        $conn->close();
        echo json_encode(['ok' => false, 'error' => 'Sin permiso para cobrar este cliente']);
        exit;
    }
}

// Validar monto: no puede superar el saldo actual (salvo que sea 0 para atraso)
if ($monto > 0 && floatval($prestamo['saldo_actual']) > 0 && $monto > floatval($prestamo['saldo_actual'])) {
    $monto = floatval($prestamo['saldo_actual']);
}

// Iniciar transaccion
$conn->begin_transaction();

try {
    // Insertar en tabla pagos usando la hora de MySQL directamente
    // (igual que lo hace cobranza_diaria.php con NOW())
    $stmt = $conn->prepare("
        INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado, cuota_numero, tipo_pago, interes)
        VALUES (?, ?, ?, 0, ?, 0.00)
    ");
    $stmt->bind_param("isds", $id_prestamo, $ahora_mysql, $monto, $tipo);
    $stmt->execute();
    $id_pago = $conn->insert_id;
    $stmt->close();

    // Actualizar saldo_actual y total_pagado en prestamos
    if ($monto > 0) {
        $nuevo_saldo = max(0, floatval($prestamo['saldo_actual']) - $monto);
        $nuevo_total_pagado = floatval($prestamo['total_pagado']) + $monto;

        // Si el saldo llega a 0, marcar como PAGADO usando CURDATE() de MySQL
        $nuevo_estado = $nuevo_saldo <= 0 ? 'PAGADO' : $prestamo['estado'];

        if ($nuevo_saldo <= 0) {
            // Liquidado: guarda fecha_liquidacion con la fecha de MySQL
            $stmt = $conn->prepare("
                UPDATE prestamos
                SET saldo_actual = ?, total_pagado = ?, estado = ?, fecha_liquidacion = ?
                WHERE id_prestamo = ?
            ");
            $stmt->bind_param("dsssi", $nuevo_saldo, $nuevo_total_pagado, $nuevo_estado, $hoy_mysql, $id_prestamo);
        } else {
            $stmt = $conn->prepare("
                UPDATE prestamos
                SET saldo_actual = ?, total_pagado = ?, estado = ?
                WHERE id_prestamo = ?
            ");
            $stmt->bind_param("dssi", $nuevo_saldo, $nuevo_total_pagado, $nuevo_estado, $id_prestamo);
        }
        $stmt->execute();
        $stmt->close();

        // Registrar en caja (igual que cobranza_diaria.php usa NOW() de MySQL)
        if ($tipo !== 'ATRASO' && $monto > 0) {
            $concepto  = "Cobro diario - Prestamo #$id_prestamo";
            // EFECTIVO -> medio=EFECTIVO (aparece en caja efectivo)
            // TRANSFERENCIA -> medio=BANCO (aparece en caja banco/banca)
            $medio     = ($tipo === 'TRANSFERENCIA') ? 'BANCO' : 'EFECTIVO';
            $tipo_caja = 'ENTRADA';
            $stmt = $conn->prepare("
                INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, id_prestamo, tipo_movimiento, fecha)
                VALUES (?, ?, ?, ?, ?, ?, 'COBRO', NOW())
            ");
            $stmt->bind_param("sssdii", $tipo_caja, $concepto, $medio, $monto, $id_empleado, $id_prestamo);
            $stmt->execute();
            $stmt->close();
        }
    }

;

    $conn->commit();

    $mensaje = $monto > 0
        ? "Pago de $" . number_format($monto, 2) . " registrado correctamente"
        : "Atraso registrado para hoy";

    echo json_encode([
        'ok'          => true,
        'mensaje'     => $mensaje,
        'id_pago'     => $id_pago,
        'monto'       => $monto,
        'nuevo_saldo' => isset($nuevo_saldo) ? $nuevo_saldo : $prestamo['saldo_actual'],
        'fecha'       => $ahora_mysql,
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['ok' => false, 'error' => 'Error al guardar: ' . $e->getMessage()]);
} finally {
    $conn->close();
}

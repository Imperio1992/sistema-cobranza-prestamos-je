<?php
include("../seguridad.php");
include("../conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']      ?? 'ASESOR';
$user = $_SESSION['usuario']  ?? 'Usuario';
$id_empleado_logueado = intval($_SESSION['id_empleado'] ?? 0);

/* Si es ASESOR, redirigir directo a su lista de cobros */
if ($rol === 'ASESOR' && $id_empleado_logueado) {
    header("Location: cobro_lista.php?id_empleado=" . $id_empleado_logueado);
    exit;
}

function esDiaHabil(): bool { return (int)date('N') < 7; }

function fechaEs(?DateTime $dt = null, string $tipo = 'corta'): string {
    if (!$dt) $dt = new DateTime();
    $meses = [1=>'enero',2=>'febrero',3=>'marzo',4=>'abril',5=>'mayo',6=>'junio',
              7=>'julio',8=>'agosto',9=>'septiembre',10=>'octubre',11=>'noviembre',12=>'diciembre'];
    $dias  = [1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes',6=>'Sábado',7=>'Domingo'];
    if ($tipo === 'dia')   return $dias[(int)$dt->format('N')];
    if ($tipo === 'larga') return $dias[(int)$dt->format('N')] . ', ' . $dt->format('j') . ' de '
                                  . $meses[(int)$dt->format('n')] . ' de ' . $dt->format('Y');
    return $dt->format('j') . ' de ' . $meses[(int)$dt->format('n')] . ' de ' . $dt->format('Y');
}

$hoy = date('Y-m-d');

/* ── ASESORES CON COBROS ──
   Usamos prestamos.id_empleado para agrupar los préstamos por asesor
   asignado al préstamo, no por el asesor del cliente.
   Esto permite que un cliente tenga préstamos con distintos asesores. */
$asesores = [];
$result = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido, e.rol, e.ruta_tipo,
           COUNT(DISTINCT p.id_prestamo) AS total_activos,
           COUNT(DISTINCT CASE WHEN p.pago_diario > 0                        THEN p.id_prestamo END) AS total_diarios,
           COUNT(DISTINCT CASE WHEN p.pago_diario = 0 AND p.plazo_semanas > 0 THEN p.id_prestamo END) AS total_semanales
    FROM empleados e
    LEFT JOIN prestamos p ON p.id_empleado = e.id_empleado
          AND p.estado IN ('ACTIVO','ATRASADO')
    WHERE e.estatus = 'ACTIVO' AND e.rol IN ('ASESOR','GERENTE')
    GROUP BY e.id_empleado
    HAVING total_activos > 0 OR e.rol = 'ASESOR'
    ORDER BY e.rol ASC, e.nombre, e.apellido
");
if ($result) while ($row = $result->fetch_assoc()) $asesores[] = $row;

/* ── RESUMEN GLOBAL DIARIO ── */
$resumenDiario = $conexion->query("
    SELECT COUNT(DISTINCT p.id_prestamo)  AS total_cobros,
           SUM(p.pago_diario)             AS monto_esperado,
           COUNT(DISTINCT pg.id_prestamo) AS cobrados_hoy,
           COALESCE(SUM(CASE WHEN pg.id_pago IS NOT NULL THEN pg.monto_pagado END), 0) AS monto_cobrado
    FROM prestamos p
    LEFT JOIN pagos pg ON pg.id_prestamo = p.id_prestamo
                       AND DATE(pg.fecha_pago) = '$hoy'
    WHERE p.estado IN ('ACTIVO','ATRASADO') AND p.pago_diario > 0
")->fetch_assoc();

/* ── RESUMEN GLOBAL SEMANAL ── */
$resumenSemanal = $conexion->query("
    SELECT COUNT(DISTINCT p.id_prestamo)  AS total_cobros,
           SUM(p.total_pagar / p.plazo_semanas) AS monto_esperado,
           COUNT(DISTINCT pg.id_prestamo) AS cobrados_hoy,
           COALESCE(SUM(CASE WHEN pg.id_pago IS NOT NULL THEN pg.monto_pagado END), 0) AS monto_cobrado
    FROM prestamos p
    LEFT JOIN pagos pg ON pg.id_prestamo = p.id_prestamo
                       AND DATE(pg.fecha_pago) = '$hoy'
    WHERE p.estado IN ('ACTIVO','ATRASADO') AND p.pago_diario = 0 AND p.plazo_semanas > 0
")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Cobro Diario — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>
/* Aplicar tema ANTES de renderizar para evitar flash */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 48px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-icon { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; text-decoration:none; }
.btn-icon:hover { color:#0f172a; border-color:#2563eb; }

/* ── FECHA ── */
.fecha-banner { font-size:.88rem; color:#64748b; margin-bottom:22px; display:flex; align-items:center; gap:8px; padding:11px 16px; background:white; border-radius:10px; border:1px solid #f1f5f9; box-shadow:0 1px 4px rgba(0,0,0,.04); }
.fecha-banner strong { color:#0f172a; }

/* ── RESUMEN BLOQUES ── */
.resumen-bloque { margin-bottom:24px; }
.resumen-label { font-size:.78rem; font-weight:700; text-transform:uppercase; letter-spacing:1px; padding:5px 14px; border-radius:20px; display:inline-flex; align-items:center; gap:6px; margin-bottom:12px; }
.resumen-label.diario  { background:#dbeafe; color:#1e40af; }
.resumen-label.semanal { background:#fef3c7; color:#92400e; }
.resumen-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; }
.resumen-card { background:white; border-radius:12px; padding:16px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,.06); border-top:4px solid #e2e8f0; }
.resumen-card.verde   { border-top-color:#22c55e; }
.resumen-card.azul    { border-top-color:#3b82f6; }
.resumen-card.naranja { border-top-color:#f59e0b; }
.resumen-card.morado  { border-top-color:#8b5cf6; }
.resumen-card .valor    { font-size:1.6rem; font-weight:800; color:#1e293b; line-height:1.1; }
.resumen-card .etiqueta { font-size:.75rem; color:#64748b; margin-top:5px; }

/* ── ASESORES ── */
.seccion-titulo { font-size:1rem; font-weight:700; color:#0f172a; margin-bottom:14px; padding-bottom:8px; border-bottom:2px solid #2563eb; display:flex; align-items:center; gap:8px; }
.busqueda-bar { background:white; border-radius:10px; padding:10px 14px; margin-bottom:14px; display:flex; gap:10px; align-items:center; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; }
.busqueda-bar input { flex:1; border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 14px; font-size:.88rem; font-family:'Inter',sans-serif; outline:none; background:#f8fafc; color:#1e293b; }
.busqueda-bar input:focus { border-color:#2563eb; background:white; }
.asesores-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px; }
.asesor-card { background:white; border-radius:14px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,.06); border:1.5px solid #f1f5f9; cursor:pointer; transition:all .2s; text-decoration:none; display:block; color:inherit; }
.asesor-card:hover { border-color:#2563eb; box-shadow:0 6px 20px rgba(37,99,235,.12); transform:translateY(-2px); }
.asesor-card.es-gerente { border-left:4px solid #8b5cf6; }
.asesor-header { display:flex; align-items:center; gap:14px; margin-bottom:14px; }
.asesor-avatar { width:48px; height:48px; border-radius:50%; background:linear-gradient(135deg,#2563eb,#1d4ed8); color:white; font-size:1.1rem; font-weight:700; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.asesor-avatar.gerente { background:linear-gradient(135deg,#8b5cf6,#6d28d9); }
.asesor-nombre { font-size:.95rem; font-weight:700; color:#0f172a; }
.asesor-ruta   { font-size:.78rem; color:#64748b; margin-top:2px; display:flex; align-items:center; gap:4px; }
.badge-gerente { display:inline-block; background:#ede9fe; color:#5b21b6; border-radius:8px; padding:1px 8px; font-size:.68rem; font-weight:700; margin-left:6px; vertical-align:middle; }
.asesor-stats { display:flex; gap:10px; margin-bottom:14px; }
.stat-item { flex:1; background:#f8fafc; border-radius:9px; padding:10px; text-align:center; }
.stat-item .num { font-size:1.25rem; font-weight:700; color:#1e293b; }
.stat-item .lbl { font-size:.68rem; color:#64748b; margin-top:2px; }
.stat-item.total-box   { border-top:3px solid #2563eb; }
.stat-item.diario-box  { border-top:3px solid #3b82f6; }
.stat-item.semanal-box { border-top:3px solid #f59e0b; }
.btn-cobrar { display:flex; align-items:center; justify-content:center; gap:8px; background:#2563eb; color:white; border:none; border-radius:9px; padding:10px; font-size:.88rem; font-weight:600; width:100%; cursor:pointer; transition:background .15s; font-family:'Inter',sans-serif; }
.btn-cobrar:hover { background:#1d4ed8; }
.btn-cobrar.gerente-btn { background:#7c3aed; }
.btn-cobrar.gerente-btn:hover { background:#6d28d9; }

/* ── DARK MODE ── */
[data-theme="dark"] body          { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#e2e8f0; }
[data-theme="dark"] .btn-icon     { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-icon:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .fecha-banner { background:#111827; border-color:#1e293b; color:#64748b; }
[data-theme="dark"] .fecha-banner strong { color:#e2e8f0; }
[data-theme="dark"] .resumen-card { background:#111827; }
[data-theme="dark"] .resumen-card .valor { color:#e2e8f0; }
[data-theme="dark"] .resumen-card .etiqueta { color:#64748b; }
[data-theme="dark"] .seccion-titulo { color:#e2e8f0; }
[data-theme="dark"] .busqueda-bar { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .busqueda-bar input { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .asesor-card  { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .asesor-card:hover { border-color:#3b82f6; }
[data-theme="dark"] .asesor-nombre { color:#e2e8f0; }
[data-theme="dark"] .stat-item    { background:#1e293b; }
[data-theme="dark"] .stat-item .num { color:#e2e8f0; }

/* ── RESPONSIVE ── */
@media(max-width:900px) {
    .sidebar { display:none; }
    .main { margin-left:0; padding:16px 14px 40px; }
    .resumen-grid { grid-template-columns:1fr 1fr; }
    .asesores-grid { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="../index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="../dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="../caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="../historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="../registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="../nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="../cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario.php" class="danger active"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="../clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="../clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="../empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="../programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="../reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="../buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="../nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <a href="../index.php" class="btn-icon" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-calendar-check" style="color:#2563eb;"></i> Cobranza del Día</h1>
                <p style="font-size:.82rem;color:#64748b;margin-top:3px;">Selecciona un asesor para ver su lista de cobros</p>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- FECHA BANNER -->
    <div class="fecha-banner">
        <i class="bi bi-calendar3" style="color:#2563eb;"></i>
        Hoy: <strong><?= fechaEs(null, 'larga') ?></strong>
        <?php if (!esDiaHabil()): ?>
        &nbsp;<span style="background:#fee2e2;color:#991b1b;border-radius:6px;padding:3px 8px;font-size:.75rem;font-weight:600;">
            <i class="bi bi-slash-circle"></i> Día no laborable
        </span>
        <?php endif; ?>
    </div>

    <!-- RESUMEN DIARIO -->
    <div class="resumen-bloque">
        <div class="resumen-label diario"><i class="bi bi-calendar-day"></i> Cobro Diario</div>
        <div class="resumen-grid">
            <div class="resumen-card azul">
                <div class="valor"><?= number_format($resumenDiario['total_cobros'] ?? 0) ?></div>
                <div class="etiqueta">Préstamos diarios activos</div>
            </div>
            <div class="resumen-card naranja">
                <div class="valor">$<?= number_format($resumenDiario['monto_esperado'] ?? 0, 2) ?></div>
                <div class="etiqueta">Meta diaria total</div>
            </div>
            <div class="resumen-card verde">
                <div class="valor"><?= number_format($resumenDiario['cobrados_hoy'] ?? 0) ?></div>
                <div class="etiqueta">Cobrados hoy</div>
            </div>
            <div class="resumen-card">
                <div class="valor">$<?= number_format($resumenDiario['monto_cobrado'] ?? 0, 2) ?></div>
                <div class="etiqueta">Monto cobrado hoy</div>
            </div>
        </div>
    </div>

    <!-- RESUMEN SEMANAL -->
    <div class="resumen-bloque">
        <div class="resumen-label semanal"><i class="bi bi-calendar-week"></i> Cobro Semanal</div>
        <div class="resumen-grid">
            <div class="resumen-card morado">
                <div class="valor"><?= number_format($resumenSemanal['total_cobros'] ?? 0) ?></div>
                <div class="etiqueta">Préstamos semanales activos</div>
            </div>
            <div class="resumen-card naranja">
                <div class="valor">$<?= number_format($resumenSemanal['monto_esperado'] ?? 0, 2) ?></div>
                <div class="etiqueta">Cuota semanal total</div>
            </div>
            <div class="resumen-card verde">
                <div class="valor"><?= number_format($resumenSemanal['cobrados_hoy'] ?? 0) ?></div>
                <div class="etiqueta">Cobrados esta semana</div>
            </div>
            <div class="resumen-card">
                <div class="valor">$<?= number_format($resumenSemanal['monto_cobrado'] ?? 0, 2) ?></div>
                <div class="etiqueta">Monto cobrado</div>
            </div>
        </div>
    </div>

    <!-- LISTA DE ASESORES -->
    <div class="seccion-titulo">
        <i class="bi bi-people-fill" style="color:#2563eb;"></i>
        Asesores y Gerentes con Cobros
    </div>

    <div class="busqueda-bar">
        <i class="bi bi-search" style="color:#94a3b8;"></i>
        <input type="text" id="buscar-asesor" placeholder="Buscar por nombre del asesor..."
               oninput="filtrarAsesores(this.value)" autocomplete="off">
    </div>

    <div class="asesores-grid" id="lista-asesores">
        <?php foreach ($asesores as $a):
            $es_gerente_card = ($a['rol'] === 'GERENTE');
        ?>
        <a class="asesor-card <?= $es_gerente_card ? 'es-gerente' : '' ?>"
           href="cobro_lista.php?id_empleado=<?= $a['id_empleado'] ?>">
            <div class="asesor-header">
                <div class="asesor-avatar <?= $es_gerente_card ? 'gerente' : '' ?>">
                    <?= strtoupper(substr($a['nombre'], 0, 1)) ?>
                </div>
                <div>
                    <div class="asesor-nombre">
                        <?= htmlspecialchars($a['nombre'] . ' ' . $a['apellido']) ?>
                        <?php if ($es_gerente_card): ?>
                        <span class="badge-gerente">GERENTE</span>
                        <?php endif; ?>
                    </div>
                    <div class="asesor-ruta">
                        <?php if (!empty($a['ruta_tipo'])): ?>
                        <i class="bi bi-geo-alt"></i> <?= htmlspecialchars($a['ruta_tipo']) ?>
                        <?php else: ?>
                        <i class="bi bi-geo-alt" style="opacity:.4;"></i> Sin ruta asignada
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="asesor-stats">
                <div class="stat-item total-box">
                    <div class="num"><?= number_format($a['total_activos']) ?></div>
                    <div class="lbl">Total activos</div>
                </div>
                <div class="stat-item diario-box">
                    <div class="num" style="color:#2563eb;"><?= number_format($a['total_diarios']) ?></div>
                    <div class="lbl">Diarios</div>
                </div>
                <div class="stat-item semanal-box">
                    <div class="num" style="color:#d97706;"><?= number_format($a['total_semanales']) ?></div>
                    <div class="lbl">Semanales</div>
                </div>
            </div>
            <div class="btn-cobrar <?= $es_gerente_card ? 'gerente-btn' : '' ?>">
                <i class="bi bi-calendar-check"></i> Ir a Cobros del Día
            </div>
        </a>
        <?php endforeach; ?>

        <?php if (empty($asesores)): ?>
        <div style="grid-column:1/-1;text-align:center;padding:48px;color:#94a3b8;">
            <i class="bi bi-people" style="font-size:2.5rem;display:block;margin-bottom:10px;opacity:.4;"></i>
            No hay asesores activos con cobros pendientes.
        </div>
        <?php endif; ?>
    </div>

</main>
</div>

<script>
/* ── TEMA ── */
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
/* Sincronizar ícono del botón al cargar */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), p = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── FILTRO DE ASESORES ── */
function filtrarAsesores(texto) {
    texto = texto.toLowerCase().trim();
    document.querySelectorAll('.asesor-card').forEach(function(card) {
        var nombre = card.querySelector('.asesor-nombre').textContent.toLowerCase();
        card.style.display = nombre.includes(texto) ? '' : 'none';
    });
}
</script>
</body>
</html>

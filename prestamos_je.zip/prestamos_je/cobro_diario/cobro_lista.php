<?php
include("../seguridad.php");
include("../conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';

$id_empleado_logueado = intval($_SESSION['id_empleado'] ?? 0);
$id_empleado = isset($_GET['id_empleado']) ? intval($_GET['id_empleado']) : 0;

if ($rol === 'ASESOR') {
    $id_empleado = $id_empleado_logueado;
}

if (!$id_empleado) {
    header('Location: cobro_diario.php');
    exit;
}

$asesor_q = $conexion->query("SELECT id_empleado, nombre, apellido, rol, ruta_tipo, telefono FROM empleados WHERE id_empleado = $id_empleado");
$asesor   = $asesor_q ? $asesor_q->fetch_assoc() : null;

if (!$asesor) {
    header('Location: cobro_diario.php');
    exit;
}

$hoy      = date('Y-m-d');
$busqueda = trim($_GET['buscar'] ?? '');
$bs       = $conexion->real_escape_string($busqueda);

// Día hábil anterior (si hoy es lunes, ayer=viernes; domingo no es hábil)
$ayer_dt = new DateTime($hoy);
$ayer_dt->modify('-1 day');
if ((int)$ayer_dt->format('N') === 7) { $ayer_dt->modify('-1 day'); } // skip domingo
$ayer = $ayer_dt->format('Y-m-d');
$ayer_fue_habil = true; // si llegamos aquí, $ayer siempre es lun-sáb

function diasHabiles(string $fecha_inicio, string $fecha_fin): int {
    $inicio = new DateTime($fecha_inicio);
    $fin    = new DateTime($fecha_fin);
    $fin->modify('+1 day');
    $dias = 0;
    foreach (new DatePeriod($inicio, new DateInterval('P1D'), $fin) as $dia) {
        if ($dia->format('N') < 7) $dias++;
    }
    return $dias;
}

function esDiaHabil(): bool { return (int)date('N') < 7; }

function fechaEs(?DateTime $dt = null, string $tipo = 'corta'): string {
    if (!$dt) $dt = new DateTime();
    $meses = [1=>'enero',2=>'febrero',3=>'marzo',4=>'abril',5=>'mayo',6=>'junio',
              7=>'julio',8=>'agosto',9=>'septiembre',10=>'octubre',11=>'noviembre',12=>'diciembre'];
    $dias  = [1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes',6=>'Sábado',7=>'Domingo'];
    if ($tipo === 'dia')   return $dias[(int)$dt->format('N')];
    if ($tipo === 'larga') return $dias[(int)$dt->format('N')] . ', ' . $dt->format('j') . ' de '
                                  . $meses[(int)$dt->format('n')] . ' de ' . $dt->format('Y');
    return $dt->format('j') . ' de ' . $meses[(int)$dt->format('n')] . ' de ' . $dt->format('Y');
}

$busqueda_sql = '';
if ($bs !== '') {
    $busqueda_sql = " AND (c.nombre LIKE '%$bs%' OR c.apellido LIKE '%$bs%' OR c.telefono LIKE '%$bs%')";
}

/* ── QUERY PRINCIPAL ────────────────────────────────────────────────────────
   CAMBIO CLAVE: filtramos por p.id_empleado (asesor asignado AL PRÉSTAMO)
   en lugar de c.id_asesor (asesor asignado AL CLIENTE).
   Esto permite que un mismo cliente comparta préstamos con distintos asesores:
   cada asesor solo ve sus propios préstamos, sin importar quién sea el asesor
   principal del cliente.
   ────────────────────────────────────────────────────────────────────────── */
$sql = "
    SELECT
        p.id_prestamo, p.pago_diario, p.plazo_semanas,
        p.saldo_actual, p.total_pagar, p.total_pagado,
        p.estado, p.fecha_inicio, p.mora_acumulada,
        c.id_cliente,
        c.nombre   AS cliente_nombre,
        c.apellido AS cliente_apellido,
        c.telefono AS cliente_tel,
        c.direccion AS cliente_dir,
        COALESCE(pago_hoy.monto_pagado, 0)  AS pagado_hoy,
        pago_hoy.id_pago                    AS id_pago_hoy,
        COALESCE(pago_ayer.monto_pagado, 0) AS pagado_ayer,
        DATEDIFF(CURDATE(), p.fecha_inicio) + 1 AS dia_numero,
        (
            SELECT COALESCE(SUM(pg2.monto_pagado), 0)
            FROM pagos pg2
            WHERE pg2.id_prestamo = p.id_prestamo
              AND DATE(pg2.fecha_pago) < CURDATE()
        ) AS pagado_hasta_ayer
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    LEFT JOIN (
        SELECT id_prestamo,
               SUM(monto_pagado) AS monto_pagado,
               MAX(id_pago)      AS id_pago
        FROM pagos
        WHERE DATE(fecha_pago) = '$hoy'
        GROUP BY id_prestamo
    ) pago_hoy ON pago_hoy.id_prestamo = p.id_prestamo
    LEFT JOIN (
        SELECT id_prestamo,
               SUM(monto_pagado) AS monto_pagado
        FROM pagos
        WHERE DATE(fecha_pago) = '$ayer'
        GROUP BY id_prestamo
    ) pago_ayer ON pago_ayer.id_prestamo = p.id_prestamo
    WHERE p.id_empleado = $id_empleado
      AND (
            p.estado IN ('ACTIVO','ATRASADO')
            OR (
                p.estado IN ('PAGADO','RENOVADO')
                AND pago_hoy.id_pago IS NOT NULL
            )
          )
    $busqueda_sql
    ORDER BY p.estado DESC, c.nombre, c.apellido
";

$result = $conexion->query($sql);

$cobros         = [];
$total_esperado = 0;
$total_cobrado  = 0;
$cobrados       = 0;
$pendientes     = 0;
$atrasados      = 0;
$no_abonaron    = 0;

while ($row = $result->fetch_assoc()) {
    $es_semanal = (floatval($row['pago_diario']) == 0 && intval($row['plazo_semanas']) > 0);

    if ($es_semanal) {
        $cuota = floatval($row['plazo_semanas']) > 0
            ? floatval($row['total_pagar']) / floatval($row['plazo_semanas'])
            : 0;
        $dias_desde_inicio     = (new DateTime($hoy))->diff(new DateTime($row['fecha_inicio']))->days;
        $semanas_transcurridas = floor($dias_desde_inicio / 7);
        $ya_pago_total_row     = floatval($row['pagado_hasta_ayer']) + floatval($row['pagado_hoy']);
        $semanas_pagadas       = ($cuota > 0) ? (int)floor($ya_pago_total_row / $cuota) : 0;
        $semana_vigente        = (int)$semanas_transcurridas;
        $fecha_inicio_dt       = new DateTime($row['fecha_inicio']);
        $prox_semana_num       = ($semanas_pagadas > $semana_vigente) ? $semanas_pagadas + 1 : $semana_vigente;
        $proximo_pago_dt       = clone $fecha_inicio_dt;
        $proximo_pago_dt->modify('+' . ($prox_semana_num * 7) . ' days');
        $row['proximo_pago_dt']      = $proximo_pago_dt;
        $row['proximo_pago_vencido'] = (new DateTime($hoy) > $proximo_pago_dt);
        $debio_pagar = $semanas_transcurridas * $cuota;
    } else {
        $cuota = floatval($row['pago_diario']);
        // El primer día (fecha_inicio) NO genera cobro — se empieza a contar desde el día siguiente
        $inicio_conteo_dt = new DateTime($row['fecha_inicio']);
        $inicio_conteo_dt->modify('+1 day');
        $inicio_conteo = $inicio_conteo_dt->format('Y-m-d');
        $dias_transcurridos = ($inicio_conteo <= $hoy) ? diasHabiles($inicio_conteo, $hoy) : 0;
        $debio_pagar = $dias_transcurridos * $cuota;
        $row['proximo_pago_dt']      = null;
        $row['proximo_pago_vencido'] = false;
    }

    $row['cuota']      = $cuota;
    $row['es_semanal'] = $es_semanal;
    $row['es_nuevo']   = ($row['fecha_inicio'] === $hoy); // préstamo iniciado hoy

    $ya_pago_total         = floatval($row['pagado_hasta_ayer']) + floatval($row['pagado_hoy']);
    $diferencia            = $debio_pagar - $ya_pago_total;
    $row['saldo_atrasado'] = max(0, $diferencia);
    $row['al_corriente']   = ($diferencia <= 0);

    // ── NO ABONÓ AYER ──
    // Préstamo activo/atrasado sin ningún pago registrado el día hábil anterior
    $no_abono = (
        in_array($row['estado'], ['ACTIVO', 'ATRASADO']) &&
        floatval($row['pagado_ayer']) == 0
    );
    $row['no_abono_ayer'] = $no_abono;
    if ($no_abono) $no_abonaron++;

    if (in_array($row['estado'], ['PAGADO', 'RENOVADO'])) {
        $cobrados++;
        $total_cobrado += floatval($row['pagado_hoy']);
    } else {
        $total_esperado += $cuota;
        if (floatval($row['pagado_hoy']) > 0) {
            $cobrados++;
            $total_cobrado += floatval($row['pagado_hoy']);
        } else {
            $pendientes++;
        }
        if ($row['estado'] === 'ATRASADO') $atrasados++;
    }

    $cobros[] = $row;
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Lista de Cobro — <?= htmlspecialchars($asesor['nombre'] . ' ' . $asesor['apellido']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-sb { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger       { color:#f87171; }
.sb-nav a.danger.active { background:rgba(239,68,68,.12); color:#fca5a5; border-color:rgba(239,68,68,.2); }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 48px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-icon { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; text-decoration:none; }
.btn-icon:hover { color:#0f172a; border-color:#2563eb; }

/* ── BANNER ASESOR ── */
.asesor-banner { background:linear-gradient(135deg,#0f172a 0%,#1e3a8a 55%,#1d4ed8 100%); border-radius:16px; padding:18px 22px; margin-bottom:20px; display:flex; align-items:center; gap:14px; flex-wrap:wrap; box-shadow:0 6px 24px rgba(37,99,235,.2); position:relative; overflow:hidden; }
.asesor-banner::before { content:''; position:absolute; top:-40px; right:-40px; width:160px; height:160px; background:rgba(255,255,255,.04); border-radius:50%; }
.av-circle { width:52px; height:52px; border-radius:50%; background:rgba(255,255,255,.15); border:2px solid rgba(255,255,255,.25); display:flex; align-items:center; justify-content:center; font-size:1.2rem; font-weight:800; color:white; flex-shrink:0; position:relative; z-index:1; }
.av-circle.gerente { background:rgba(124,58,237,.4); border-color:rgba(196,181,253,.4); }
.av-info { flex:1; position:relative; z-index:1; }
.av-nombre { font-size:1.05rem; font-weight:800; color:white; }
.av-sub { font-size:.8rem; color:#93c5fd; margin-top:3px; }
.av-fecha { text-align:right; position:relative; z-index:1; }
.av-fecha .df { font-size:.82rem; color:#93c5fd; }
.badge-nolaboral { background:#fee2e2; color:#991b1b; border-radius:6px; padding:3px 8px; font-size:.72rem; font-weight:600; margin-top:4px; display:inline-block; }

/* ── AVISO PRÉSTAMO COMPARTIDO ── */
.aviso-asesor { font-size:.72rem; color:#93c5fd; margin-top:4px; display:flex; align-items:center; gap:4px; }
.aviso-asesor i { font-size:.7rem; }

/* ── STATS BAR ── */
.stats-bar { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:18px; }
.stat-box { background:white; border-radius:12px; padding:14px 10px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,.06); border-top:3px solid #e2e8f0; }
.stat-box .num { font-size:1.6rem; font-weight:800; }
.stat-box .lbl { font-size:.72rem; color:#64748b; margin-top:3px; font-weight:500; }
.stat-box.cobrado   { border-top-color:#22c55e; } .stat-box.cobrado .num   { color:#16a34a; }
.stat-box.pendiente { border-top-color:#f59e0b; } .stat-box.pendiente .num { color:#d97706; }
.stat-box.atrasado  { border-top-color:#ef4444; } .stat-box.atrasado .num  { color:#dc2626; }
.stat-box.total     { border-top-color:#3b82f6; } .stat-box.total .num     { color:#2563eb; }

/* ── PROGRESS ── */
.progress-card { background:white; border-radius:12px; padding:14px 18px; margin-bottom:16px; box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #f1f5f9; }
.progress-bar  { background:#e2e8f0; border-radius:10px; height:8px; overflow:hidden; margin:8px 0 4px; }
.progress-fill { height:100%; background:linear-gradient(90deg,#22c55e,#16a34a); border-radius:10px; transition:width .5s; }

/* ── TOOLBAR ── */
.toolbar { background:white; border-radius:12px; padding:14px; margin-bottom:14px; display:flex; gap:10px; align-items:center; box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #f1f5f9; flex-wrap:wrap; }
.toolbar input { flex:1; min-width:180px; border:1.5px solid #e2e8f0; border-radius:9px; padding:9px 14px; font-size:.88rem; outline:none; font-family:'Inter',sans-serif; background:#f8fafc; color:#1e293b; }
.toolbar input:focus { border-color:#2563eb; background:white; }
.btn-buscar { background:#2563eb; color:white; border:none; border-radius:9px; padding:9px 16px; font-size:.85rem; font-weight:600; cursor:pointer; font-family:'Inter',sans-serif; }
.btn-buscar:hover { background:#1d4ed8; }
.btn-enrutar { background:white; color:#2563eb; border:1.5px solid #2563eb; border-radius:9px; padding:9px 14px; font-size:.85rem; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
.btn-enrutar:hover { background:#eff6ff; }

/* ── FILTROS ── */
.filtros { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:16px; }
.filtro-btn { padding:6px 14px; border-radius:20px; border:1.5px solid #e2e8f0; background:white; font-size:.78rem; font-weight:600; cursor:pointer; transition:all .15s; font-family:'Inter',sans-serif; color:#64748b; }
.filtro-btn.activo { background:#2563eb; color:white; border-color:#2563eb; }
.filtro-btn:hover  { border-color:#2563eb; color:#2563eb; }

/* ── SECCIÓN LABEL ── */
.seccion-label { font-size:.75rem; font-weight:700; text-transform:uppercase; letter-spacing:1px; padding:5px 14px; border-radius:20px; margin:16px 0 10px; display:inline-flex; align-items:center; gap:6px; }
.seccion-label.diario  { background:#dbeafe; color:#1e40af; }
.seccion-label.semanal { background:#fef3c7; color:#92400e; }

/* ── COBRO ITEMS ── */
.cobro-item { background:white; border-radius:14px; margin-bottom:10px; box-shadow:0 2px 8px rgba(0,0,0,.06); overflow:hidden; border:1px solid #f1f5f9; border-left:4px solid #e2e8f0; transition:all .15s; }
.cobro-item.pagado    { border-left-color:#22c55e; }
.cobro-item.pendiente { border-left-color:#f59e0b; }
.cobro-item.atrasado  { border-left-color:#ef4444; }
.cobro-item.liquidado { border-left-color:#8b5cf6; }
.cobro-item.semanal   { border-left-style:dashed; }
.cobro-body { padding:16px 18px; }
.cobro-header-row { display:flex; align-items:flex-start; justify-content:space-between; gap:10px; margin-bottom:12px; }
.cliente-nombre { font-size:.95rem; font-weight:700; color:#0f172a; }
.cliente-sub { font-size:.78rem; color:#64748b; margin-top:3px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.badge-estado    { font-size:.72rem; font-weight:600; padding:4px 10px; border-radius:20px; white-space:nowrap; }
.badge-pagado    { background:#dcfce7; color:#166534; }
.badge-pendiente { background:#fef3c7; color:#92400e; }
.badge-atrasado  { background:#fee2e2; color:#991b1b; }
.badge-liquidado { background:#ede9fe; color:#5b21b6; }
.badge-renovado  { background:#dbeafe; color:#1e40af; }
.badge-semanal   { background:#fef3c7; color:#92400e; font-size:.62rem; padding:2px 7px; border-radius:8px; margin-left:4px; }
.cobro-datos { display:grid; grid-template-columns:repeat(auto-fit,minmax(110px,1fr)); gap:8px; margin-bottom:12px; }
.dato-item    { background:#f8fafc; border-radius:9px; padding:9px 10px; text-align:center; }
.dato-valor   { font-size:.9rem; font-weight:700; color:#1e293b; }
.dato-lbl     { font-size:.68rem; color:#64748b; margin-top:2px; }
.dato-verde   { color:#16a34a; }
.dato-rojo    { color:#dc2626; }
.dato-azul    { color:#2563eb; }
.dato-naranja { color:#d97706; }
.proximo-pago-bloque { display:flex; align-items:center; gap:8px; background:#fffbeb; border:1px solid #fde68a; border-radius:9px; padding:8px 12px; margin-bottom:10px; font-size:.82rem; flex-wrap:wrap; }
.proximo-pago-bloque.vencido { background:#fef2f2; border-color:#fca5a5; }
.pp-label { color:#78716c; }
.pp-fecha { font-weight:700; color:#92400e; }
.proximo-pago-bloque.vencido .pp-fecha { color:#991b1b; }
.pp-badge-vencido { background:#fee2e2; color:#991b1b; border-radius:6px; padding:2px 7px; font-size:.7rem; font-weight:700; }
.pp-badge-ok      { background:#dcfce7; color:#166534; border-radius:6px; padding:2px 7px; font-size:.7rem; font-weight:700; }
.atraso-badge { background:#fee2e2; color:#991b1b; border-radius:6px; padding:3px 8px; font-size:.72rem; font-weight:600; }
.nuevo-badge  { background:#dcfce7; color:#166534; border-radius:6px; padding:3px 8px; font-size:.72rem; font-weight:600; }
.cobro-acciones { display:flex; gap:8px; flex-wrap:wrap; }
.btn-pagar { flex:1; min-width:130px; background:#2563eb; color:white; border:none; border-radius:9px; padding:10px 14px; font-size:.85rem; font-weight:600; cursor:pointer; transition:background .15s; text-decoration:none; text-align:center; font-family:'Inter',sans-serif; display:inline-flex; align-items:center; justify-content:center; gap:6px; }
.btn-pagar:hover { background:#1d4ed8; }
.btn-atraso { background:white; color:#64748b; border:1.5px solid #e2e8f0; border-radius:9px; padding:10px 14px; font-size:.85rem; font-weight:600; cursor:pointer; transition:all .15s; font-family:'Inter',sans-serif; }
.btn-atraso:hover { border-color:#ef4444; color:#dc2626; }
.btn-ver { background:white; color:#2563eb; border:1.5px solid #bfdbfe; border-radius:9px; padding:10px 14px; font-size:.85rem; font-weight:600; cursor:pointer; transition:all .15s; text-decoration:none; text-align:center; font-family:'Inter',sans-serif; display:inline-flex; align-items:center; gap:5px; }
.btn-ver:hover { background:#eff6ff; }
.monto-pagado-hoy       { background:#dcfce7; color:#166534; border-radius:9px; padding:10px 14px; font-size:.88rem; font-weight:700; text-align:center; flex:1; display:flex; align-items:center; justify-content:center; gap:6px; }
.monto-pagado-liquidado { background:#ede9fe; color:#5b21b6; border-radius:9px; padding:10px 14px; font-size:.88rem; font-weight:700; text-align:center; flex:1; display:flex; align-items:center; justify-content:center; gap:6px; }
.monto-pagado-renovado  { background:#dbeafe; color:#1e40af; border-radius:9px; padding:10px 14px; font-size:.88rem; font-weight:700; text-align:center; flex:1; display:flex; align-items:center; justify-content:center; gap:6px; }
.empty-state { text-align:center; padding:50px 20px; color:#64748b; }
.empty-state i { font-size:3rem; display:block; margin-bottom:12px; opacity:.4; }

/* ── DARK MODE ── */
[data-theme="dark"] body  { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#e2e8f0; }
[data-theme="dark"] .btn-icon { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-icon:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .stat-box { background:#111827; }
[data-theme="dark"] .stat-box .lbl { color:#64748b; }
[data-theme="dark"] .progress-card { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .progress-bar  { background:#1e293b; }
[data-theme="dark"] .toolbar { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .toolbar input { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .btn-enrutar { background:#111827; }
[data-theme="dark"] .filtro-btn { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .filtro-btn.activo { background:#2563eb; color:white; }
[data-theme="dark"] .cobro-item { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .cliente-nombre { color:#e2e8f0; }
[data-theme="dark"] .dato-item { background:#1e293b; }
[data-theme="dark"] .dato-valor { color:#e2e8f0; }
[data-theme="dark"] .btn-ver    { background:#111827; border-color:#1e3a8a; }
[data-theme="dark"] .btn-ver:hover { background:#1e3a8a; }
[data-theme="dark"] .btn-atraso { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .modal-box  { background:#1e293b; }

/* ── RESPONSIVE ── */
@media(max-width:900px) {
    .sidebar   { display:none; }
    .main      { margin-left:0; padding:14px 12px 40px; }
    .stats-bar { grid-template-columns:1fr 1fr; }
    .cobro-datos { grid-template-columns:1fr 1fr; }
}
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="../index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="../dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="../caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="../registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="../nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="../cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario.php" class="danger active"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="../clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="../clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="../empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="../programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="../reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="../buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="../nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_buscar.php?id_empleado=<?= $id_empleado ?>" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <?php if ($rol !== 'ASESOR'): ?>
            <a href="cobro_diario.php" class="btn-icon" title="Regresar a asesores">
                <i class="bi bi-arrow-left"></i>
            </a>
            <?php else: ?>
            <a href="../index.php" class="btn-icon" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <?php endif; ?>
            <h1><i class="bi bi-calendar-check" style="color:#2563eb;"></i> Lista de Cobro del Día</h1>
        </div>
        <div class="topbar-right">
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- BANNER ASESOR -->
    <div class="asesor-banner">
        <div class="av-circle <?= ($asesor['rol'] === 'GERENTE') ? 'gerente' : '' ?>">
            <?= strtoupper(substr($asesor['nombre'], 0, 1)) ?>
        </div>
        <div class="av-info">
            <div class="av-nombre"><?= htmlspecialchars($asesor['nombre'] . ' ' . $asesor['apellido']) ?></div>
            <div class="av-sub">
                <?= htmlspecialchars($asesor['rol']) ?>
                <?php if ($asesor['ruta_tipo']): ?>&bull; Ruta <?= htmlspecialchars($asesor['ruta_tipo']) ?><?php endif; ?>
                <?php if ($asesor['telefono']): ?>&bull; <i class="bi bi-telephone"></i> <?= htmlspecialchars($asesor['telefono']) ?><?php endif; ?>
            </div>
            <div class="aviso-asesor">
                <i class="bi bi-info-circle"></i>
                Mostrando solo los préstamos asignados directamente a este asesor
            </div>
        </div>
        <div class="av-fecha">
            <div class="df"><?= fechaEs(null, 'larga') ?></div>
            <?php if (!esDiaHabil()): ?>
            <div class="badge-nolaboral"><i class="bi bi-slash-circle"></i> Día no laborable &mdash; no genera atraso</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- STATS -->
    <div class="stats-bar">
        <div class="stat-box total">
            <div class="num"><?= count($cobros) ?></div>
            <div class="lbl">Total cobros</div>
        </div>
        <div class="stat-box cobrado">
            <div class="num"><?= $cobrados ?></div>
            <div class="lbl">Cobrados hoy</div>
        </div>
        <div class="stat-box pendiente">
            <div class="num"><?= $pendientes ?></div>
            <div class="lbl">Pendientes</div>
        </div>
        <div class="stat-box atrasado">
            <div class="num"><?= $no_abonaron ?></div>
            <div class="lbl">No abonaron ayer</div>
        </div>
    </div>

    <?php if (count($cobros) > 0):
        $pct = $total_esperado > 0 ? min(100, round($total_cobrado / $total_esperado * 100)) : 0;
    ?>
    <div class="progress-card">
        <div style="display:flex;justify-content:space-between;font-size:.85rem;font-weight:600;">
            <span>Progreso del día</span>
            <span style="color:#16a34a;">$<?= number_format($total_cobrado,2) ?> / $<?= number_format($total_esperado,2) ?></span>
        </div>
        <div class="progress-bar">
            <div class="progress-fill" style="width:<?= $pct ?>%"></div>
        </div>
        <div style="text-align:right;font-size:.75rem;color:#64748b;margin-top:3px;"><?= $pct ?>% cobrado</div>
    </div>
    <?php endif; ?>

    <!-- TOOLBAR -->
    <div class="toolbar">
        <form method="GET" style="flex:1;display:flex;gap:8px;min-width:200px;">
            <input type="hidden" name="id_empleado" value="<?= $id_empleado ?>">
            <input type="text" name="buscar" placeholder="Buscar cliente..." value="<?= htmlspecialchars($busqueda) ?>">
            <button type="submit" class="btn-buscar"><i class="bi bi-search"></i> Buscar</button>
        </form>
        <a href="cobro_buscar.php?id_empleado=<?= $id_empleado ?>" class="btn-enrutar">
            <i class="bi bi-search-heart"></i> Buscar / Enrutar
        </a>
    </div>

    <!-- FILTROS -->
    <div class="filtros">
        <button class="filtro-btn activo" onclick="filtrar('todos',this)">Todos (<?= count($cobros) ?>)</button>
        <button class="filtro-btn" onclick="filtrar('pendiente',this)">Pendientes (<?= $pendientes ?>)</button>
        <button class="filtro-btn" onclick="filtrar('pagado',this)">Cobrados (<?= $cobrados ?>)</button>
        <button class="filtro-btn" onclick="filtrar('noabono',this)"
                title="Sin abono el <?= $ayer_dt->format('d/m/Y') ?>">
            <i class="bi bi-calendar-x" style="font-size:.8rem;"></i>
            No abonaron ayer (<?= $no_abonaron ?>)
        </button>
    </div>

    <?php
    $diarios   = array_filter($cobros, fn($c) => !$c['es_semanal']);
    $semanales = array_filter($cobros, fn($c) =>  $c['es_semanal']);
    ?>

    <div id="lista-cobros">
    <?php if (empty($cobros)): ?>
        <div class="empty-state">
            <i class="bi bi-folder-x"></i>
            <div>No hay cobros asignados a este asesor<?= $busqueda ? ' para esa búsqueda' : ' hoy' ?>.</div>
            <?php if ($busqueda): ?>
                <a href="?id_empleado=<?= $id_empleado ?>" style="color:#2563eb;display:block;margin-top:10px;">Limpiar búsqueda</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if (count($diarios) > 0): ?>
        <div class="seccion-label diario"><i class="bi bi-calendar-day"></i> Cobro Diario</div>
    <?php endif; ?>
    <?php foreach ($diarios as $c): ?>
        <?= renderCobro($c, $id_empleado) ?>
    <?php endforeach; ?>

    <?php if (count($semanales) > 0): ?>
        <div class="seccion-label semanal"><i class="bi bi-calendar-week"></i> Cobro Semanal</div>
    <?php endif; ?>
    <?php foreach ($semanales as $c): ?>
        <?= renderCobro($c, $id_empleado) ?>
    <?php endforeach; ?>
    </div>

</main>
</div>

<!-- MODAL ATRASO -->
<div id="modal-atraso" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;">
    <div class="modal-box" style="background:white;border-radius:18px;padding:30px;max-width:380px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.3);">
        <i class="bi bi-slash-circle" style="font-size:2.5rem;color:#dc2626;display:block;margin-bottom:12px;"></i>
        <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:8px;">Registrar Atraso</h3>
        <p style="font-size:.88rem;color:#64748b;margin-bottom:20px;">Se registrará que el cliente no abonó hoy.</p>
        <div style="display:flex;gap:10px;">
            <button onclick="cerrarModal()" style="flex:1;padding:10px;border-radius:9px;border:1.5px solid #e2e8f0;background:white;cursor:pointer;font-size:.9rem;font-family:'Inter',sans-serif;">Cancelar</button>
            <button onclick="confirmarAtraso()" style="flex:1;padding:10px;border-radius:9px;border:none;background:#dc2626;color:white;cursor:pointer;font-size:.9rem;font-weight:700;font-family:'Inter',sans-serif;">Confirmar Atraso</button>
        </div>
    </div>
</div>

<div id="toast" style="display:none;position:fixed;bottom:28px;left:50%;transform:translateX(-50%);background:#1e293b;color:white;padding:12px 24px;border-radius:30px;font-size:.88rem;z-index:2000;box-shadow:0 8px 24px rgba(0,0,0,.3);"></div>

<?php
function renderCobro(array $c, int $id_empleado): string {
    $es_liquidado = ($c['estado'] === 'PAGADO');
    $es_renovado  = ($c['estado'] === 'RENOVADO');
    $ya_pago      = floatval($c['pagado_hoy']) > 0;
    $es_semanal   = $c['es_semanal'];

    if ($es_liquidado || $es_renovado)       $estado_item = 'liquidado';
    elseif ($ya_pago)                        $estado_item = 'pagado';
    elseif ($c['estado'] === 'ATRASADO')     $estado_item = 'atrasado';
    else                                     $estado_item = 'pendiente';

    $data_estado    = ($es_liquidado || $es_renovado) ? 'pagado' : $estado_item;
    $etiqueta_cuota = $es_semanal ? 'Cuota semanal' : 'Cuota diaria';
    $clase_extra    = $es_semanal ? ' semanal' : '';

    $meses = [1=>'enero',2=>'febrero',3=>'marzo',4=>'abril',5=>'mayo',6=>'junio',
              7=>'julio',8=>'agosto',9=>'septiembre',10=>'octubre',11=>'noviembre',12=>'diciembre'];
    $fi = new DateTime($c['fecha_inicio']);
    $fecha_inicio_str = $fi->format('j') . ' de ' . $meses[(int)$fi->format('n')] . ' de ' . $fi->format('Y');

    ob_start();
    ?>
    <div class="cobro-item <?= $estado_item . $clase_extra ?>" data-estado="<?= $data_estado ?>" data-noabono="<?= $c['no_abono_ayer'] ? '1' : '0' ?>">
        <div class="cobro-body">
            <div class="cobro-header-row">
                <div>
                    <div class="cliente-nombre">
                        <?= htmlspecialchars($c['cliente_nombre'] . ' ' . $c['cliente_apellido']) ?>
                        <?php if ($es_semanal): ?><span class="badge-semanal">SEMANAL</span><?php endif; ?>
                    </div>
                    <div class="cliente-sub">
                        <?php if ($c['cliente_tel']): ?>
                            <span><i class="bi bi-telephone"></i> <?= htmlspecialchars($c['cliente_tel']) ?></span>
                        <?php endif; ?>
                        <span>Préstamo #<?= $c['id_prestamo'] ?> &bull; Inicio: <?= $fecha_inicio_str ?></span>
                        <?php if ($c['es_nuevo']): ?>
                            <span class="nuevo-badge"><i class="bi bi-star-fill"></i> Nuevo Préstamo</span>
                        <?php elseif ($c['saldo_atrasado'] > 0 && !$ya_pago && !$es_liquidado && !$es_renovado): ?>
                            <span class="atraso-badge"><i class="bi bi-exclamation-triangle"></i> Atraso: $<?= number_format($c['saldo_atrasado'],2) ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div>
                    <?php if ($es_liquidado): ?>
                        <span class="badge-estado badge-liquidado"><i class="bi bi-check-circle"></i> Liquidado</span>
                    <?php elseif ($es_renovado): ?>
                        <span class="badge-estado badge-renovado"><i class="bi bi-arrow-repeat"></i> Renovado</span>
                    <?php elseif ($ya_pago): ?>
                        <span class="badge-estado badge-pagado"><i class="bi bi-check-circle"></i> Cobrado</span>
                    <?php elseif ($c['estado'] === 'ATRASADO'): ?>
                        <span class="badge-estado badge-atrasado"><i class="bi bi-exclamation-circle"></i> Atrasado</span>
                    <?php else: ?>
                        <span class="badge-estado badge-pendiente"><i class="bi bi-clock"></i> Pendiente</span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($es_semanal && $c['proximo_pago_dt'] instanceof DateTime): ?>
            <?php
                $pp_dt      = $c['proximo_pago_dt'];
                $pp_vencido = $c['proximo_pago_vencido'] && !$ya_pago && !$es_liquidado && !$es_renovado;
                $pp_fecha   = $pp_dt->format('j') . ' de ' . $meses[(int)$pp_dt->format('n')];
            ?>
            <div class="proximo-pago-bloque <?= $pp_vencido ? 'vencido' : '' ?>">
                <i class="bi bi-calendar-week"></i>
                <span class="pp-label">Próximo pago:</span>
                <span class="pp-fecha"><?= $pp_fecha ?></span>
                <?php if ($ya_pago || $es_liquidado || $es_renovado): ?>
                    <span class="pp-badge-ok"><i class="bi bi-check"></i> Pagado</span>
                <?php elseif ($pp_vencido): ?>
                    <span class="pp-badge-vencido"><i class="bi bi-exclamation-triangle"></i> Vencido</span>
                <?php else: ?>
                    <span class="pp-badge-ok">Al corriente</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="cobro-datos">
                <div class="dato-item">
                    <div class="dato-valor <?= $es_semanal ? 'dato-naranja' : 'dato-azul' ?>">$<?= number_format($c['cuota'],2) ?></div>
                    <div class="dato-lbl"><?= $etiqueta_cuota ?></div>
                </div>
                <div class="dato-item">
                    <div class="dato-valor <?= $ya_pago ? 'dato-verde' : '' ?>">$<?= number_format($c['pagado_hoy'],2) ?></div>
                    <div class="dato-lbl">Pagado hoy</div>
                </div>
                <div class="dato-item">
                    <div class="dato-valor <?= ($c['saldo_actual'] <= 0 || $es_liquidado) ? 'dato-verde' : 'dato-rojo' ?>">$<?= number_format($c['saldo_actual'],2) ?></div>
                    <div class="dato-lbl">Saldo restante</div>
                </div>
                <div class="dato-item">
                    <div class="dato-valor">$<?= number_format($c['total_pagar'],2) ?></div>
                    <div class="dato-lbl">Total a pagar</div>
                </div>
            </div>

            <div class="cobro-acciones">
                <?php if ($es_liquidado): ?>
                    <div class="monto-pagado-liquidado"><i class="bi bi-check-circle-fill"></i> Liquidado hoy: $<?= number_format($c['pagado_hoy'],2) ?></div>
                    <a href="../historial_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ver"><i class="bi bi-eye"></i> Ver historial</a>
                <?php elseif ($es_renovado): ?>
                    <div class="monto-pagado-renovado"><i class="bi bi-arrow-repeat"></i> Renovado hoy: $<?= number_format($c['pagado_hoy'],2) ?></div>
                    <a href="../historial_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ver"><i class="bi bi-eye"></i> Ver historial</a>
                <?php elseif ($ya_pago): ?>
                    <div class="monto-pagado-hoy"><i class="bi bi-check-circle-fill"></i> Cobrado hoy: $<?= number_format($c['pagado_hoy'],2) ?></div>
                    <a href="../historial_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ver"><i class="bi bi-eye"></i> Ver historial</a>
                <?php else: ?>
                    <a href="../registrar_cobros.php?id_prestamo=<?= $c['id_prestamo'] ?>&id_empleado=<?= $id_empleado ?>" class="btn-pagar">
                        <i class="bi bi-cash-coin"></i> Registrar pago
                    </a>
                    <button class="btn-atraso" onclick="abrirModalAtraso(<?= $c['id_prestamo'] ?>, <?= $id_empleado ?>)">
                        <i class="bi bi-slash-circle"></i> Atraso
                    </button>
                    <a href="../historial_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ver"><i class="bi bi-eye"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
?>

<script>
/* ── TEMA ── */
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), p = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── FILTROS ── */
function filtrar(tipo, btn) {
    document.querySelectorAll('.filtro-btn').forEach(function(b) { b.classList.remove('activo'); });
    btn.classList.add('activo');
    document.querySelectorAll('.cobro-item').forEach(function(item) {
        var visible;
        if (tipo === 'todos') {
            visible = true;
        } else if (tipo === 'noabono') {
            visible = (item.dataset.noabono === '1');
        } else {
            visible = (item.dataset.estado === tipo);
        }
        item.style.display = visible ? '' : 'none';
    });
    // Ocultar etiquetas de sección si no tienen items visibles debajo
    document.querySelectorAll('.seccion-label').forEach(function(lbl) {
        var next = lbl.nextElementSibling;
        var tieneVisibles = false;
        while (next && next.classList.contains('cobro-item')) {
            if (next.style.display !== 'none') { tieneVisibles = true; break; }
            next = next.nextElementSibling;
        }
        lbl.style.display = tieneVisibles ? '' : 'none';
    });
}

/* ── MODAL ATRASO ── */
var _atrasoId = 0;
var _atrasoEmp = 0;

function abrirModalAtraso(idPrestamo, idEmp) {
    _atrasoId  = idPrestamo;
    _atrasoEmp = idEmp;
    var modal = document.getElementById('modal-atraso');
    modal.style.display = 'flex';
}
function cerrarModal() {
    document.getElementById('modal-atraso').style.display = 'none';
}
function confirmarAtraso() {
    cerrarModal();
    fetch('registrar_atraso.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id_prestamo=' + _atrasoId + '&id_empleado=' + _atrasoEmp
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        mostrarToast(d.ok ? 'Atraso registrado' : ('Error: ' + d.error));
        if (d.ok) setTimeout(function() { location.reload(); }, 1200);
    })
    .catch(function() { mostrarToast('Error de conexión'); });
}
function mostrarToast(msg) {
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.style.display = 'block';
    setTimeout(function() { t.style.display = 'none'; }, 2500);
}
document.getElementById('modal-atraso').addEventListener('click', function(e) {
    if (e.target === this) cerrarModal();
});
</script>
</body>
</html>

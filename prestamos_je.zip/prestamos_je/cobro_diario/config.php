<?php
/**
 * config.php - Configuracion del modulo de Cobro Diario
 *
 * =====================================================
 * ZONA HORARIA: Ajusta la linea de abajo segun tu pais
 * =====================================================
 * Mexico Centro / Honduras / Guatemala / El Salvador / Nicaragua / Costa Rica -> '-06:00'
 * Colombia / Peru / Ecuador                                                   -> '-05:00'
 * Venezuela                                                                   -> '-04:00'
 * Baja California (Mexico) / Pacific US                                       -> '-08:00'
 * =====================================================
 */
define('DB_OFFSET', '-07:00');   // <-- America/Hermosillo (igual que caja.php)

// Aplicar zona horaria a PHP (Etc/GMT+8 = UTC-8, Etc/GMT+6 = UTC-6, etc.)
// La convencion Etc/ invierte el signo: Etc/GMT+8 equivale a UTC-8
$_phpTZ = [
    '-08:00' => 'Etc/GMT+8',
    '-07:00' => 'Etc/GMT+7',
    '-06:00' => 'Etc/GMT+6',
    '-05:00' => 'Etc/GMT+5',
    '-04:00' => 'Etc/GMT+4',
    '-03:00' => 'Etc/GMT+3',
];
date_default_timezone_set($_phpTZ[DB_OFFSET] ?? 'Etc/GMT+6');

// Configuracion de base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'prestamos_je');

/**
 * getDB() - Retorna conexion MySQL con zona horaria correcta
 */
function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'Error de conexion a la BD']);
            exit;
        }
        die('<p style="color:red;font-family:sans-serif;padding:20px;">Error de conexion: ' . htmlspecialchars($conn->connect_error) . '</p>');
    }
    $conn->set_charset('utf8mb4');
    $offset = DB_OFFSET;
    $conn->query("SET time_zone = '$offset'");
    return $conn;
}

/**
 * fechaEs($fecha, $formato)
 * Formatea una fecha en Español.
 *
 * $formato : 'corta' -> "01/04/2026"
 *            'larga' -> "Martes, 01 de Abril de 2026"
 *            'hora'  -> "01/04/2026 22:35"
 *            'dia'   -> "Martes"
 */
function fechaEs($fecha = null, $formato = 'corta') {
    $dias  = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    $meses = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio',
              'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

    if ($fecha === null) {
        $ts = time();
    } elseif (is_numeric($fecha)) {
        $ts = (int)$fecha;
    } else {
        $ts = strtotime($fecha);
    }

    if (!$ts) return '-';

    switch ($formato) {
        case 'larga':
            return $dias[date('w',$ts)] . ', ' . date('d',$ts) . ' de ' . $meses[(int)date('n',$ts)] . ' de ' . date('Y',$ts);
        case 'hora':
            return date('d/m/Y H:i', $ts);
        case 'dia':
            return $dias[date('w',$ts)];
        case 'corta':
        default:
            return date('d/m/Y', $ts);
    }
}

// Iniciar sesion si no esta activa
function verificarSesion() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['id_usuario']) || !isset($_SESSION['rol'])) {
        header('Location: ../login.php');
        exit;
    }
}

// Verificar que el rol puede acceder al modulo de cobro
function verificarRolCobro() {
    $rolesPermitidos = ['GERENTE', 'SUPERVISOR', 'ASESOR'];
    if (!in_array($_SESSION['rol'] ?? '', $rolesPermitidos)) {
        header('Location: ../index.php?error=sin_permiso');
        exit;
    }
}

// ============================================================
// DIAS NO LABORABLES (no se cobra, no genera interes ni atraso)
// ============================================================

/**
 * festivosDelAnio(int $anio)
 * Fechas festivas fijas + Semana Santa por año.
 * Agrega cada año nuevo con sus 3 fechas de Semana Santa.
 */
function festivosDelAnio(int $anio): array {
    // Jueves, Viernes y Sabado de Semana Santa (cambia cada año)
    $semana_santa = [
        2025 => ['2025-04-17', '2025-04-18', '2025-04-19'],
        2026 => ['2026-04-02', '2026-04-03', '2026-04-04'],
        2027 => ['2027-03-25', '2027-03-26', '2027-03-27'],
        2028 => ['2028-04-13', '2028-04-14', '2028-04-15'],
    ];

    $fijos = [
        "$anio-01-01",   // Año Nuevo
        "$anio-12-25",   // Navidad
    ];

    return array_merge($fijos, $semana_santa[$anio] ?? []);
}

/**
 * domingosSiLaborables()
 * Domingos que EXCEPCIONALMENTE si se trabajan.
 * Agrega aqui cualquier domingo en que tu ruta trabaje.
 */
function domingosSiLaborables(): array {
    return [
        '2025-03-29',   // Domingo laboral por acuerdo de ruta
    ];
}

/**
 * diasHabiles($fecha_inicio, $fecha_hasta)
 * Cuenta dias laborables entre dos fechas (ambas inclusive).
 * NO cuenta: domingos ni festivos.
 * SI cuenta: domingos en domingosSiLaborables().
 */
function diasHabiles(string $fecha_inicio, ?string $fecha_hasta = null): int {
    if ($fecha_hasta === null) {
        $fecha_hasta = date('Y-m-d');
    }

    $ts_inicio = strtotime($fecha_inicio);
    $ts_hasta  = strtotime($fecha_hasta);

    if ($ts_hasta < $ts_inicio) return 0;

    // Cargar festivos de todos los años del rango
    $anio_ini = (int)date('Y', $ts_inicio);
    $anio_fin = (int)date('Y', $ts_hasta);
    $festivos = [];
    for ($a = $anio_ini; $a <= $anio_fin; $a++) {
        $festivos = array_merge($festivos, festivosDelAnio($a));
    }
    $festivos    = array_flip($festivos);
    $domingos_si = array_flip(domingosSiLaborables());

    $dias    = 0;
    $ts_curr = $ts_inicio;

    while ($ts_curr <= $ts_hasta) {
        $fecha_str  = date('Y-m-d', $ts_curr);
        $es_domingo = ((int)date('w', $ts_curr) === 0);

        // Cuenta si no es festivo Y (no es domingo O es domingo laboral)
        if (!isset($festivos[$fecha_str]) && (!$es_domingo || isset($domingos_si[$fecha_str]))) {
            $dias++;
        }

        $ts_curr = strtotime('+1 day', $ts_curr);
    }

    return $dias;
}

/**
 * esDiaHabil($fecha)
 * true si la fecha (o hoy) es dia laborable.
 */
function esDiaHabil(?string $fecha = null): bool {
    $f  = $fecha ?? date('Y-m-d');
    $ts = strtotime($f);

    $es_domingo  = ((int)date('w', $ts) === 0);
    $festivos    = array_flip(festivosDelAnio((int)date('Y', $ts)));
    $domingos_si = array_flip(domingosSiLaborables());

    if (isset($festivos[$f])) return false;
    if ($es_domingo && !isset($domingos_si[$f])) return false;

    return true;
}
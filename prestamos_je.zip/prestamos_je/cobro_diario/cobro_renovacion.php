<?php
require_once 'config.php';
verificarSesion();
verificarRolCobro();

$conn = getDB();
$rol        = $_SESSION['rol'];
$id_usuario = $_SESSION['id_usuario'];

$id_prestamo         = isset($_GET['id_prestamo']) ? intval($_GET['id_prestamo']) : 0;
$id_empleado_retorno = isset($_GET['id_empleado']) ? intval($_GET['id_empleado']) : 0;

if (!$id_prestamo) { header('Location: cobro_diario.php'); exit; }

$stmt = $conn->prepare("
    SELECT p.id_prestamo, p.monto_prestado, p.total_pagar, p.total_pagado,
           p.saldo_actual, p.pago_diario, p.estado, p.dias_prestamo,
           p.interes, p.fecha_inicio,
           c.id_cliente, c.nombre AS c_nombre, c.apellido AS c_apellido,
           c.telefono AS c_tel, c.id_asesor,
           e.nombre AS asesor_nombre, e.apellido AS asesor_apellido, e.id_empleado
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    INNER JOIN empleados e ON e.id_empleado = c.id_asesor
    WHERE p.id_prestamo = ?
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$prestamo = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$prestamo) { header('Location: cobro_lista.php?id_empleado=' . $id_empleado_retorno); exit; }

if ($rol === 'ASESOR') {
    $stmt = $conn->prepare("SELECT id_empleado FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($res['id_empleado'] != $prestamo['id_asesor']) {
        header('Location: cobro_lista.php?id_empleado=' . $res['id_empleado']); exit;
    }
}

$hoy = date('Y-m-d');
$porcentaje_pagado = 0;
if (floatval($prestamo['total_pagar']) > 0)
    $porcentaje_pagado = (floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100;

$dias_transcurridos = 0;
if ($prestamo['fecha_inicio'])
    $dias_transcurridos = max(0, (int)((strtotime($hoy) - strtotime($prestamo['fecha_inicio'])) / 86400) + 1);

$elegible = ($porcentaje_pagado >= 80) || ($dias_transcurridos >= 15);
$porcentaje_barra = min(100, $porcentaje_pagado);

$stmt = $conn->prepare("SELECT id_empleado FROM usuarios WHERE id_usuario = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resUser = $stmt->get_result()->fetch_assoc();
$stmt->close();
$id_empleado_logueado = $resUser['id_empleado'] ?? 0;
$id_empleado_caja = $id_empleado_retorno ?: $id_empleado_logueado;

$conn->close();

$monto_sugerido   = floatval($prestamo['monto_prestado']);
$interes_sugerido = floatval($prestamo['interes']) ?: 20;
$dias_sugeridos   = intval($prestamo['dias_prestamo']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Renovacion de Credito - <?= htmlspecialchars($prestamo['c_nombre'] . ' ' . $prestamo['c_apellido']) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;color:#1a1a2e}
.header{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:white;padding:14px 20px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.1rem;font-weight:600}
.btn-volver{color:white;text-decoration:none;font-size:.85rem;opacity:.8}
.container{max-width:680px;margin:0 auto;padding:20px 16px}
.card{background:white;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.card-titulo{font-size:.85rem;font-weight:700;color:#64748b;margin-bottom:14px;text-transform:uppercase;letter-spacing:.5px}
.cliente-header{display:flex;align-items:center;gap:14px;margin-bottom:14px}
.cliente-avatar{width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#5b21b6);color:white;font-size:1.2rem;font-weight:700;display:flex;align-items:center;justify-content:center}
.cliente-nombre-big{font-size:1.1rem;font-weight:700}
.cliente-sub{font-size:.82rem;color:#64748b;margin-top:4px}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.info-item{background:#f8fafc;border-radius:8px;padding:10px 12px}
.info-item .lbl{font-size:.72rem;color:#64748b;margin-bottom:3px}
.info-item .val{font-size:.95rem;font-weight:600}
.val-verde{color:#16a34a}.val-rojo{color:#dc2626}.val-azul{color:#2563eb}.val-morado{color:#7c3aed}
.eleg-box{border-radius:12px;padding:16px;margin-bottom:16px}
.eleg-box.si{background:#f0fdf4;border:1px solid #86efac}
.eleg-box.no{background:#fef2f2;border:1px solid #fca5a5}
.eleg-titulo{font-size:.95rem;font-weight:700;margin-bottom:10px}
.eleg-box.si .eleg-titulo{color:#166534}
.eleg-box.no .eleg-titulo{color:#991b1b}
.eleg-stats{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px}
.eleg-stat{flex:1;min-width:120px;background:white;border-radius:8px;padding:10px;text-align:center}
.eleg-stat .num{font-size:1.4rem;font-weight:700}
.eleg-box.si .eleg-stat .num{color:#16a34a}
.eleg-box.no .eleg-stat .num{color:#dc2626}
.eleg-stat .lbl{font-size:.72rem;color:#64748b;margin-top:2px}
.prog-label{display:flex;justify-content:space-between;font-size:.78rem;color:#64748b;margin-bottom:5px}
.prog-bar{background:#e2e8f0;border-radius:10px;height:10px;overflow:hidden}
.prog-fill{height:100%;border-radius:10px;transition:width .6s ease}
.prog-fill.verde{background:linear-gradient(90deg,#22c55e,#16a34a)}
.prog-fill.roja{background:linear-gradient(90deg,#f87171,#ef4444)}
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:.85rem;font-weight:600;color:#374151;margin-bottom:6px}
.form-group input,.form-group select{width:100%;padding:10px 14px;border:2px solid #e2e8f0;border-radius:10px;font-size:.95rem;outline:none;background:#fafafa;transition:border-color .2s}
.form-group input:focus{border-color:#7c3aed;background:white}
.form-group .hint{font-size:.75rem;color:#64748b;margin-top:4px}
.resumen{display:none;background:#f5f3ff;border:1px solid #c4b5fd;border-radius:12px;padding:16px;margin-bottom:16px}
.resumen.visible{display:block}
.res-titulo{font-size:.9rem;font-weight:700;color:#5b21b6;margin-bottom:12px}
.res-fila{display:flex;justify-content:space-between;align-items:center;padding:7px 0;font-size:.88rem;border-bottom:1px solid #ddd6fe}
.res-fila:last-child{border-bottom:none}
.res-fila .c{color:#4c1d95}
.res-fila .v{font-weight:700}
.res-fila.dest{background:#7c3aed;border-radius:8px;padding:10px 12px;margin-top:8px;border-bottom:none}
.res-fila.dest .c{color:white;font-size:.95rem}
.res-fila.dest .v{color:#fde68a;font-size:1.1rem}
.btn-group{display:flex;gap:10px;margin-top:8px}
.btn-calc{flex:1;background:#7c3aed;color:white;border:none;border-radius:10px;padding:12px;font-size:.95rem;font-weight:700;cursor:pointer}
.btn-calc:hover{background:#5b21b6}
.btn-conf{display:none;flex:2;background:#16a34a;color:white;border:none;border-radius:10px;padding:14px;font-size:1rem;font-weight:700;cursor:pointer}
.btn-conf.visible{display:flex;align-items:center;justify-content:center;gap:6px}
.btn-conf:hover{background:#15803d}
.btn-conf:disabled{background:#94a3b8;cursor:not-allowed}
.btn-cancel{flex:1;background:white;color:#64748b;border:2px solid #e2e8f0;border-radius:10px;padding:12px;font-size:.9rem;font-weight:600;cursor:pointer;text-decoration:none;text-align:center}
.btn-cancel:hover{border-color:#e94560;color:#e94560}
.msg{display:none;padding:16px;border-radius:12px;text-align:center;font-size:.95rem;font-weight:600;margin-top:14px}
.msg-ok{background:#dcfce7;color:#166534}
.msg-err{background:#fee2e2;color:#991b1b}
.bloqueado{opacity:.5;pointer-events:none}
@media(max-width:500px){.info-grid{grid-template-columns:1fr}.eleg-stats{flex-direction:column}.btn-group{flex-direction:column}}
</style>
</head>
<body>

<div class="header">
    <h1>&#128260; Renovacion de Credito</h1>
    <a href="cobro_pagar.php?id_prestamo=<?= $id_prestamo ?>&id_empleado=<?= $id_empleado_retorno ?>" class="btn-volver">&#8592; Volver</a>
</div>

<div class="container">

<div class="card">
    <div class="cliente-header">
        <div class="cliente-avatar"><?= strtoupper(substr($prestamo['c_nombre'],0,1)) ?></div>
        <div>
            <div class="cliente-nombre-big"><?= htmlspecialchars($prestamo['c_nombre'].' '.$prestamo['c_apellido']) ?></div>
            <div class="cliente-sub">
                <?php if($prestamo['c_tel']): ?>&#128222; <?= htmlspecialchars($prestamo['c_tel']) ?> &bull; <?php endif; ?>
                Credito #<?= $id_prestamo ?>
            </div>
        </div>
    </div>
    <div class="info-grid">
        <div class="info-item"><div class="lbl">Monto prestado</div><div class="val val-azul">$<?= number_format($prestamo['monto_prestado'],2) ?></div></div>
        <div class="info-item"><div class="lbl">Total a pagar</div><div class="val">$<?= number_format($prestamo['total_pagar'],2) ?></div></div>
        <div class="info-item"><div class="lbl">Total pagado</div><div class="val val-verde">$<?= number_format($prestamo['total_pagado'],2) ?></div></div>
        <div class="info-item"><div class="lbl">Saldo restante</div><div class="val val-rojo">$<?= number_format($prestamo['saldo_actual'],2) ?></div></div>
        <div class="info-item"><div class="lbl">Pago diario</div><div class="val val-morado">$<?= number_format($prestamo['pago_diario'],2) ?></div></div>
        <div class="info-item"><div class="lbl">Plazo</div><div class="val"><?= $prestamo['dias_prestamo'] ?> dias</div></div>
    </div>
</div>

<div class="eleg-box <?= $elegible ? 'si' : 'no' ?>">
    <div class="eleg-titulo"><?= $elegible ? '&#9989; Elegible para renovacion' : '&#10060; No elegible aun' ?></div>
    <div class="eleg-stats">
        <div class="eleg-stat"><div class="num"><?= round($porcentaje_pagado,1) ?>%</div><div class="lbl">Pagado del credito</div></div>
        <div class="eleg-stat"><div class="num"><?= $dias_transcurridos ?></div><div class="lbl">Dias transcurridos</div></div>
    </div>
    <div class="prog-label"><span>Progreso de pago</span><span>Meta: 80% o 15 dias</span></div>
    <div class="prog-bar">
        <div class="prog-fill <?= $porcentaje_pagado>=80?'verde':'roja' ?>" style="width:<?= round($porcentaje_barra,1) ?>%"></div>
    </div>
    <?php if(!$elegible): ?>
    <p style="font-size:.82rem;color:#991b1b;margin-top:8px;">
        Falta <?= max(0,80-round($porcentaje_pagado,1)) ?>% o <?= max(0,15-$dias_transcurridos) ?> dia(s) mas para renovar.
    </p>
    <?php endif; ?>
</div>

<div class="card <?= !$elegible?'bloqueado':'' ?>">
    <div class="card-titulo">&#128221; Condiciones del nuevo credito</div>
    <div class="form-group">
        <label>Monto solicitado (sin interes)</label>
        <input type="number" id="monto_nuevo" min="1" step="0.01" value="<?= $monto_sugerido ?>">
        <div class="hint">El monto base que el cliente solicita, sin incluir el interes.</div>
    </div>
    <div class="form-group">
        <label>Interes (%)</label>
        <input type="number" id="interes_pct" min="0" max="100" step="0.5" value="<?= $interes_sugerido ?>">
    </div>
    <div class="form-group">
        <label>Plazo (dias)</label>
        <input type="number" id="dias_nuevo" min="1" step="1" value="<?= $dias_sugeridos ?>">
    </div>
    <div class="btn-group">
        <button class="btn-calc" onclick="calcular()">&#128290; Calcular</button>
    </div>
</div>

<div class="resumen" id="resumen">
    <div class="res-titulo">&#128196; Resumen de la Renovacion</div>
    <div class="res-fila"><span class="c">Monto solicitado</span><span class="v" id="r_monto">-</span></div>
    <div class="res-fila"><span class="c">Interes aplicado</span><span class="v" id="r_interes">-</span></div>
    <div class="res-fila"><span class="c">Total nuevo credito (con interes)</span><span class="v" id="r_total">-</span></div>
    <div class="res-fila"><span class="c">Saldo restante a liquidar</span><span class="v" style="color:#dc2626" id="r_saldo">-</span></div>
    <div class="res-fila"><span class="c">Nuevo pago diario</span><span class="v" id="r_pago">-</span></div>
    <div class="res-fila"><span class="c">Plazo</span><span class="v" id="r_dias">-</span></div>
    <div class="res-fila dest"><span class="c">&#128181; Monto a entregar al cliente</span><span class="v" id="r_entrega">-</span></div>
    <div class="btn-group" style="margin-top:16px">
        <button class="btn-conf visible" id="btnConf" onclick="confirmar()">&#9989; Confirmar Renovacion</button>
        <button class="btn-cancel" onclick="cancelar()">Cancelar</button>
    </div>
</div>

<div class="msg" id="msg"></div>

</div>

<script>
const ID_PRESTAMO = <?= $id_prestamo ?>;
const ID_EMPLEADO = <?= $id_empleado_caja ?>;
const SALDO_REST  = <?= floatval($prestamo['saldo_actual']) ?>;

let calc = null;

function fmt(n){ return '$'+parseFloat(n).toLocaleString('es-MX',{minimumFractionDigits:2,maximumFractionDigits:2}); }

function calcular(){
    const monto = parseFloat(document.getElementById('monto_nuevo').value);
    const interes= parseFloat(document.getElementById('interes_pct').value);
    const dias   = parseInt(document.getElementById('dias_nuevo').value);
    if(!monto||monto<=0){ alert('Ingresa un monto valido.'); return; }
    if(!dias||dias<=0){ alert('Ingresa un plazo valido.'); return; }
    const total   = monto*(1+interes/100);
    const entrega = total - SALDO_REST;
    const pago    = dias>0 ? total/dias : 0;
    if(entrega<0){ mostrarError('El saldo restante ('+fmt(SALDO_REST)+') supera el total del nuevo credito ('+fmt(total)+'). Solicita un monto mayor.'); return; }
    calc = {monto,interes,dias,total,entrega,pago};
    document.getElementById('r_monto').textContent  = fmt(monto);
    document.getElementById('r_interes').textContent= interes.toFixed(1)+'%';
    document.getElementById('r_total').textContent  = fmt(total);
    document.getElementById('r_saldo').textContent  = '- '+fmt(SALDO_REST);
    document.getElementById('r_pago').textContent   = fmt(pago)+' / dia';
    document.getElementById('r_dias').textContent   = dias+' dias';
    document.getElementById('r_entrega').textContent= fmt(entrega);
    document.getElementById('resumen').classList.add('visible');
    document.getElementById('resumen').scrollIntoView({behavior:'smooth',block:'start'});
}

function cancelar(){
    calc = null;
    document.getElementById('resumen').classList.remove('visible');
    document.getElementById('msg').style.display='none';
}

function confirmar(){
    if(!calc) return;
    if(!confirm('Confirmar renovacion?\n\n- Saldo a liquidar: '+fmt(SALDO_REST)+'\n- Nuevo credito: '+fmt(calc.total)+'\n- Monto a entregar: '+fmt(calc.entrega)+'\n\nEsta accion no se puede deshacer.')) return;
    const btn = document.getElementById('btnConf');
    btn.disabled = true; btn.textContent = 'Procesando...';
    const fd = new FormData();
    fd.append('id_prestamo', ID_PRESTAMO);
    fd.append('monto_nuevo', calc.monto);
    fd.append('interes_pct', calc.interes);
    fd.append('dias_nuevo',  calc.dias);
    fd.append('id_empleado', ID_EMPLEADO);
    fetch('renovacion_ajax.php',{method:'POST',body:fd})
        .then(r=>r.json())
        .then(data=>{
            if(data.ok){
                const m=document.getElementById('msg');
                m.className='msg msg-ok';
                m.innerHTML='&#9989; <strong>Renovacion exitosa</strong><br>Nuevo credito #'+data.id_prestamo_nuevo+'<br>Entregado: <strong>'+fmt(data.monto_entregado)+'</strong><br>Pago diario: <strong>'+fmt(data.pago_diario_nuevo)+'</strong>';
                m.style.display='block';
                document.getElementById('resumen').classList.remove('visible');
                setTimeout(()=>{ window.location.href='cobro_pagar.php?id_prestamo='+data.id_prestamo_nuevo+'&id_empleado='+ID_EMPLEADO; },3000);
            } else {
                mostrarError(data.error||'Error desconocido');
                btn.disabled=false; btn.textContent='✅ Confirmar Renovacion';
            }
        })
        .catch(()=>{ mostrarError('Error de conexion.'); btn.disabled=false; btn.textContent='✅ Confirmar Renovacion'; });
}

function mostrarError(msg){
    const m=document.getElementById('msg');
    m.className='msg msg-err';
    m.textContent='❌ '+msg;
    m.style.display='block';
    m.scrollIntoView({behavior:'smooth',block:'center'});
}
</script>
</body>
</html>
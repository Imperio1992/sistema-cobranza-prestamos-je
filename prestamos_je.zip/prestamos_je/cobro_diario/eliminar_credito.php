<?php
require_once 'config.php';
verificarSesion();

// Solo GERENTE puede acceder
if ($_SESSION['rol'] !== 'GERENTE') {
    header('Location: ../index.php');
    exit;
}

$conn = getDB();
$msg  = '';
$tipo = '';

// -----------------------------------------------------------------------
// POST: ejecutar eliminacion
// -----------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_prestamo = intval($_POST['id_prestamo'] ?? 0);
    $confirma    = trim($_POST['confirma'] ?? '');

    if (!$id_prestamo) {
        $msg  = 'ID de prestamo invalido.';
        $tipo = 'error';
    } elseif ($confirma !== 'ELIMINAR') {
        $msg  = 'Debes escribir ELIMINAR para confirmar.';
        $tipo = 'error';
    } else {
        // Verificar que existe
        $chk = $conn->prepare("SELECT id_prestamo, estado FROM prestamos WHERE id_prestamo = ? LIMIT 1");
        $chk->bind_param("i", $id_prestamo);
        $chk->execute();
        $prestamo = $chk->get_result()->fetch_assoc();
        $chk->close();

        if (!$prestamo) {
            $msg  = "No se encontro el prestamo #$id_prestamo.";
            $tipo = 'error';
        } else {
            // Borrar en orden: pagos → movimientos de caja → prestamo
            $conn->begin_transaction();
            try {
                $s1 = $conn->prepare("DELETE FROM pagos WHERE id_prestamo = ?");
                $s1->bind_param("i", $id_prestamo);
                $s1->execute();
                $s1->close();

                // Si tienes tabla caja con referencia al prestamo
                $s2 = $conn->prepare("DELETE FROM caja WHERE id_prestamo = ?");
                $s2->bind_param("i", $id_prestamo);
                $s2->execute();
                $s2->close();

                $s3 = $conn->prepare("DELETE FROM prestamos WHERE id_prestamo = ?");
                $s3->bind_param("i", $id_prestamo);
                $s3->execute();
                $s3->close();

                $conn->commit();
                $msg  = "Prestamo #$id_prestamo eliminado correctamente junto con sus pagos.";
                $tipo = 'ok';
            } catch (Exception $e) {
                $conn->rollback();
                $msg  = 'Error al eliminar: ' . $e->getMessage();
                $tipo = 'error';
            }
        }
    }
}

// -----------------------------------------------------------------------
// GET: buscar prestamo por ID o por nombre de cliente
// -----------------------------------------------------------------------
$busqueda  = trim($_GET['buscar'] ?? '');
$resultados = [];

if ($busqueda !== '') {
    $like = "%$busqueda%";
    $sql = "
        SELECT
            p.id_prestamo,
            p.estado,
            p.fecha_inicio,
            p.monto_prestado,
            p.total_pagar,
            p.pago_diario,
            p.plazo_semanas,
            p.saldo_actual,
            c.nombre AS cliente_nombre,
            c.apellido AS cliente_apellido,
            c.telefono AS cliente_tel,
            e.nombre AS asesor_nombre,
            e.apellido AS asesor_apellido,
            (SELECT COUNT(*) FROM pagos pg WHERE pg.id_prestamo = p.id_prestamo) AS num_pagos,
            (SELECT COALESCE(SUM(pg2.monto_pagado),0) FROM pagos pg2 WHERE pg2.id_prestamo = p.id_prestamo) AS total_cobrado
        FROM prestamos p
        INNER JOIN clientes c ON c.id_cliente = p.id_cliente
        LEFT JOIN empleados e ON e.id_empleado = c.id_asesor
        WHERE p.id_prestamo = ?
           OR c.nombre LIKE ?
           OR c.apellido LIKE ?
           OR CONCAT(c.nombre,' ',c.apellido) LIKE ?
        ORDER BY p.id_prestamo DESC
        LIMIT 30
    ";
    $num = is_numeric($busqueda) ? intval($busqueda) : 0;
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $num, $like, $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $resultados[] = $row;
    }
    $stmt->close();
}

$conn->close();

function colorEstado($e) {
    return match($e) {
        'ACTIVO'   => '#dbeafe:#1e40af',
        'ATRASADO' => '#fee2e2:#991b1b',
        'PAGADO'   => '#dcfce7:#166534',
        'RENOVADO' => '#ede9fe:#5b21b6',
        default    => '#f1f5f9:#475569',
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Credito — Admin</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f1f5f9; color: #1e293b; min-height: 100vh; }

        .header {
            background: linear-gradient(135deg, #1a1a2e, #7f1d1d);
            color: white;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .header h1 { font-size: 1.2rem; font-weight: 700; }
        .header a { color: white; text-decoration: none; font-size: 0.85rem; opacity: 0.8; }
        .header a:hover { opacity: 1; }
        .badge-admin {
            background: #dc2626;
            color: white;
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .container { max-width: 860px; margin: 0 auto; padding: 28px 16px; }

        .aviso {
            background: #fef2f2;
            border: 1px solid #fca5a5;
            border-left: 5px solid #dc2626;
            border-radius: 10px;
            padding: 14px 18px;
            margin-bottom: 24px;
            font-size: 0.88rem;
            color: #7f1d1d;
        }
        .aviso strong { font-size: 0.95rem; }

        .alert {
            padding: 14px 18px;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 20px;
        }
        .alert-ok    { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

        .card {
            background: white;
            border-radius: 14px;
            box-shadow: 0 1px 6px rgba(0,0,0,0.07);
            overflow: hidden;
            margin-bottom: 20px;
        }
        .card-header {
            padding: 14px 20px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.95rem;
            font-weight: 700;
            color: #0f172a;
        }
        .card-body { padding: 20px; }

        .search-row {
            display: flex;
            gap: 10px;
        }
        .search-row input {
            flex: 1;
            border: 2px solid #e2e8f0;
            border-radius: 9px;
            padding: 10px 14px;
            font-size: 0.95rem;
            outline: none;
            font-family: inherit;
        }
        .search-row input:focus { border-color: #dc2626; }
        .btn-buscar {
            background: #1e293b;
            color: white;
            border: none;
            border-radius: 9px;
            padding: 10px 22px;
            font-size: 0.9rem;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
        }
        .btn-buscar:hover { background: #0f172a; }

        /* Tabla de resultados */
        .resultado-item {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 12px;
            background: #fafafa;
        }
        .resultado-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 12px;
        }
        .cliente-info h3 { font-size: 1rem; font-weight: 700; color: #0f172a; }
        .cliente-info p  { font-size: 0.78rem; color: #64748b; margin-top: 2px; }

        .badge-estado {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 20px;
            white-space: nowrap;
        }

        .datos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 8px;
            margin-bottom: 14px;
        }
        .dato {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 8px 10px;
            text-align: center;
        }
        .dato .val { font-size: 0.9rem; font-weight: 700; color: #1e293b; }
        .dato .lbl { font-size: 0.68rem; color: #94a3b8; margin-top: 2px; }

        /* Modal de confirmacion */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.activo { display: flex; }
        .modal {
            background: white;
            border-radius: 16px;
            padding: 30px;
            max-width: 420px;
            width: 92%;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .modal-icon { font-size: 3rem; margin-bottom: 12px; }
        .modal h3 { font-size: 1.1rem; font-weight: 800; color: #7f1d1d; margin-bottom: 8px; }
        .modal p  { font-size: 0.88rem; color: #64748b; margin-bottom: 16px; line-height: 1.5; }
        .modal-info {
            background: #fef2f2;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 16px;
            font-size: 0.88rem;
            color: #7f1d1d;
            text-align: left;
        }
        .modal-info strong { display: block; font-size: 0.95rem; margin-bottom: 4px; }
        .confirm-input {
            width: 100%;
            border: 2px solid #fca5a5;
            border-radius: 9px;
            padding: 10px 14px;
            font-size: 1rem;
            font-weight: 700;
            text-align: center;
            letter-spacing: 2px;
            outline: none;
            font-family: monospace;
            margin-bottom: 16px;
            color: #dc2626;
        }
        .confirm-input:focus { border-color: #dc2626; }
        .modal-btns { display: flex; gap: 10px; }
        .btn-cancelar {
            flex: 1;
            padding: 11px;
            border-radius: 9px;
            border: 1px solid #e2e8f0;
            background: white;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
            font-family: inherit;
        }
        .btn-cancelar:hover { background: #f1f5f9; }
        .btn-confirmar-del {
            flex: 1;
            padding: 11px;
            border-radius: 9px;
            border: none;
            background: #dc2626;
            color: white;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 700;
            font-family: inherit;
        }
        .btn-confirmar-del:hover { background: #b91c1c; }
        .btn-confirmar-del:disabled { background: #94a3b8; cursor: not-allowed; }

        .btn-eliminar {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.15s;
        }
        .btn-eliminar:hover { background: #dc2626; color: white; border-color: #dc2626; }

        .empty { text-align: center; padding: 30px; color: #94a3b8; font-size: 0.9rem; }

        /* Form oculto para POST */
        #form-delete { display: none; }
    </style>
</head>
<body>

<div class="header">
    <div>
        <h1>&#128683; Eliminar Credito</h1>
        <div style="font-size:0.8rem;opacity:0.7;margin-top:2px;">Solo para corregir errores de registro</div>
    </div>
    <div style="display:flex;align-items:center;gap:12px;">
        <span class="badge-admin">ADMIN</span>
        <a href="../index.php">&#8592; Volver</a>
    </div>
</div>

<div class="container">

    <!-- Aviso de peligro -->
    <div class="aviso">
        <strong>&#9888;&#65039; Zona de administracion — Usar con precaucion</strong><br>
        Esta accion elimina el prestamo y <u>todos sus pagos</u> de forma permanente. Usa esto unicamente para corregir registros duplicados o errores de captura.
    </div>

    <!-- Mensajes de resultado -->
    <?php if ($msg): ?>
    <div class="alert alert-<?= $tipo ?>">
        <?= $tipo === 'ok' ? '&#9989;' : '&#10060;' ?> <?= htmlspecialchars($msg) ?>
    </div>
    <?php endif; ?>

    <!-- Buscador -->
    <div class="card">
        <div class="card-header">&#128269; Buscar credito a eliminar</div>
        <div class="card-body">
            <form method="GET">
                <div class="search-row">
                    <input
                        type="text"
                        name="buscar"
                        value="<?= htmlspecialchars($busqueda) ?>"
                        placeholder="Escribe el # de prestamo o nombre del cliente..."
                        autofocus>
                    <button type="submit" class="btn-buscar">Buscar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Resultados -->
    <?php if ($busqueda !== '' && empty($resultados)): ?>
        <div class="card"><div class="card-body"><div class="empty">No se encontraron prestamos con esa busqueda.</div></div></div>
    <?php endif; ?>

    <?php foreach ($resultados as $p):
        [$bg, $fg] = explode(':', colorEstado($p['estado']));
        $es_semanal = (floatval($p['pago_diario']) == 0 && intval($p['plazo_semanas']) > 0);
        $cuota = $es_semanal
            ? ($p['plazo_semanas'] > 0 ? $p['total_pagar'] / $p['plazo_semanas'] : 0)
            : $p['pago_diario'];
    ?>
    <div class="resultado-item">
        <div class="resultado-header">
            <div class="cliente-info">
                <h3><?= htmlspecialchars($p['cliente_nombre'] . ' ' . $p['cliente_apellido']) ?></h3>
                <p>
                    Prestamo #<?= $p['id_prestamo'] ?>
                    &bull; <?= $es_semanal ? 'Semanal' : 'Diario' ?>
                    <?php if ($p['cliente_tel']): ?> &bull; &#128222; <?= htmlspecialchars($p['cliente_tel']) ?><?php endif; ?>
                    <?php if ($p['asesor_nombre']): ?> &bull; Asesor: <?= htmlspecialchars($p['asesor_nombre'] . ' ' . $p['asesor_apellido']) ?><?php endif; ?>
                </p>
            </div>
            <span class="badge-estado" style="background:<?= $bg ?>;color:<?= $fg ?>;">
                <?= $p['estado'] ?>
            </span>
        </div>

        <div class="datos-grid">
            <div class="dato">
                <div class="val">$<?= number_format($p['monto_prestado'], 2) ?></div>
                <div class="lbl">Prestado</div>
            </div>
            <div class="dato">
                <div class="val">$<?= number_format($p['total_pagar'], 2) ?></div>
                <div class="lbl">Total a pagar</div>
            </div>
            <div class="dato">
                <div class="val">$<?= number_format($cuota, 2) ?></div>
                <div class="lbl"><?= $es_semanal ? 'Cuota semanal' : 'Pago diario' ?></div>
            </div>
            <div class="dato">
                <div class="val">$<?= number_format($p['total_cobrado'], 2) ?></div>
                <div class="lbl">Total cobrado</div>
            </div>
            <div class="dato">
                <div class="val">$<?= number_format($p['saldo_actual'], 2) ?></div>
                <div class="lbl">Saldo restante</div>
            </div>
            <div class="dato">
                <div class="val"><?= $p['num_pagos'] ?></div>
                <div class="lbl">Num. pagos</div>
            </div>
            <div class="dato">
                <div class="val"><?= date('d/m/Y', strtotime($p['fecha_inicio'])) ?></div>
                <div class="lbl">Fecha inicio</div>
            </div>
        </div>

        <div style="display:flex;justify-content:flex-end;">
            <button class="btn-eliminar"
                onclick="abrirModal(
                    <?= $p['id_prestamo'] ?>,
                    '<?= addslashes(htmlspecialchars($p['cliente_nombre'] . ' ' . $p['cliente_apellido'])) ?>',
                    <?= $p['num_pagos'] ?>
                )">
                &#128465;&#65039; Eliminar este credito
            </button>
        </div>
    </div>
    <?php endforeach; ?>

</div>

<!-- Modal de confirmacion -->
<div class="modal-overlay" id="modal">
    <div class="modal">
        <div class="modal-icon">&#128683;</div>
        <h3>Confirmar Eliminacion</h3>
        <p>Esta accion no se puede deshacer. Se eliminara el prestamo y todos sus registros de pago.</p>

        <div class="modal-info" id="modal-info"></div>

        <p style="font-size:0.85rem;color:#dc2626;font-weight:700;margin-bottom:8px;">
            Escribe <span style="font-family:monospace;background:#fef2f2;padding:2px 6px;border-radius:4px;">ELIMINAR</span> para confirmar:
        </p>
        <input
            type="text"
            id="input-confirma"
            class="confirm-input"
            placeholder="ELIMINAR"
            oninput="validarInput(this)">

        <div class="modal-btns">
            <button class="btn-cancelar" onclick="cerrarModal()">Cancelar</button>
            <button class="btn-confirmar-del" id="btn-ok" disabled onclick="ejecutarEliminacion()">
                &#128465;&#65039; Eliminar
            </button>
        </div>
    </div>
</div>

<!-- Formulario oculto para POST -->
<form method="POST" id="form-delete">
    <input type="hidden" name="id_prestamo" id="f-id-prestamo">
    <input type="hidden" name="confirma" value="ELIMINAR">
</form>

<script>
let idActual = null;

function abrirModal(id, nombre, numPagos) {
    idActual = id;
    document.getElementById('modal-info').innerHTML =
        '<strong>Prestamo #' + id + ' — ' + nombre + '</strong>' +
        'Pagos registrados que tambien se eliminaran: <b>' + numPagos + '</b>';
    document.getElementById('input-confirma').value = '';
    document.getElementById('btn-ok').disabled = true;
    document.getElementById('modal').classList.add('activo');
    setTimeout(() => document.getElementById('input-confirma').focus(), 100);
}

function cerrarModal() {
    document.getElementById('modal').classList.remove('activo');
    idActual = null;
}

function validarInput(el) {
    document.getElementById('btn-ok').disabled = (el.value.trim() !== 'ELIMINAR');
}

function ejecutarEliminacion() {
    if (!idActual) return;
    document.getElementById('f-id-prestamo').value = idActual;
    document.getElementById('form-delete').submit();
}

// Cerrar modal con Escape
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') cerrarModal();
});
</script>
</body>
</html>

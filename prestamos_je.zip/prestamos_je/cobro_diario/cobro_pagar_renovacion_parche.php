<?php
/**
 * PARCHE PARA cobro_pagar.php
 *
 * INSTRUCCIONES:
 * 1. Abre cobro_pagar.php
 * 2. Localiza este bloque de PHP al inicio (donde se calcula $saldo_atrasado):
 *
 *       $saldo_atrasado = max(0, $deberia_haber_pagado - $total_ya_pagado_antes);
 *       $conn->close();
 *
 * 3. Justo DESPUES de esas dos lineas, agrega el bloque PHP marcado con
 *    === INICIO PARCHE PHP === y === FIN PARCHE PHP ===
 *
 * 4. Localiza la seccion del historial de pagos en el HTML, al final del </div>
 *    que cierra la tarjeta del historial, y agrega el bloque HTML/PHP
 *    marcado con === INICIO PARCHE HTML ===
 */

// === INICIO PARCHE PHP ===
// Calcular elegibilidad de renovacion
$porcentaje_pagado_reno = 0;
if (floatval($prestamo['total_pagar']) > 0) {
    $porcentaje_pagado_reno = (floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100;
}
$dias_transcurridos_reno = 0;
if ($prestamo['fecha_inicio']) {
    $dias_transcurridos_reno = max(0, (int)((strtotime($hoy) - strtotime($prestamo['fecha_inicio'])) / 86400) + 1);
}
$puede_renovar = ($porcentaje_pagado_reno >= 80 || $dias_transcurridos_reno >= 15)
              && in_array($prestamo['estado'], ['ACTIVO','ATRASADO']);
// === FIN PARCHE PHP ===
?>

<!-- ====================================================== -->
<!-- === INICIO PARCHE HTML: pegar justo despues del     === -->
<!-- === </div> que cierra la tarjeta del historial      === -->
<!-- ====================================================== -->

<?php if (in_array($prestamo['estado'], ['ACTIVO','ATRASADO'])): ?>
<div class="card" style="border: 2px solid <?= $puede_renovar ? '#7c3aed' : '#e2e8f0' ?>;">
    <div class="card-titulo" style="color: #7c3aed;">&#128260; Renovacion de Credito</div>

    <?php if ($puede_renovar): ?>
        <div style="background:#f5f3ff;border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:0.88rem;color:#5b21b6;">
            <strong>&#9989; Este cliente puede renovar su credito.</strong><br>
            Ha pagado el <?= round($porcentaje_pagado_reno, 1) ?>% del credito
            (<?= $dias_transcurridos_reno ?> dias transcurridos).
            El saldo restante (<strong>$<?= number_format($prestamo['saldo_actual'], 2) ?></strong>)
            se descontara del nuevo prestamo al momento de renovar.
        </div>
        <a href="cobro_renovacion.php?id_prestamo=<?= $id_prestamo ?>&id_empleado=<?= $id_empleado_retorno ?>"
           style="display:flex;align-items:center;justify-content:center;gap:8px;
                  background:#7c3aed;color:white;border-radius:10px;padding:12px;
                  font-size:0.95rem;font-weight:700;text-decoration:none;transition:background 0.2s;"
           onmouseover="this.style.background='#5b21b6'"
           onmouseout="this.style.background='#7c3aed'">
            &#128260; Renovar Credito
        </a>
    <?php else: ?>
        <div style="background:#f8fafc;border-radius:10px;padding:12px 14px;font-size:0.85rem;color:#64748b;">
            &#128274; No elegible aun para renovacion.<br>
            Requiere al menos <strong>80% pagado</strong> o <strong>15 dias</strong> de credito.<br>
            Actualmente: <?= round($porcentaje_pagado_reno, 1) ?>% pagado &bull; <?= $dias_transcurridos_reno ?> dias.
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- === FIN PARCHE HTML === -->

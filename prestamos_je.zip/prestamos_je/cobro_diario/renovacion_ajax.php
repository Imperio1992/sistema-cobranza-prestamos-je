<?php
require_once 'config.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario']) || !isset($_SESSION['rol'])) {
    echo json_encode(['ok' => false, 'error' => 'Sesion no activa']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'error' => 'Metodo no permitido']);
    exit;
}

$id_prestamo = intval($_POST['id_prestamo'] ?? 0);
$monto_nuevo = floatval($_POST['monto_nuevo'] ?? 0);
$interes_pct = floatval($_POST['interes_pct'] ?? 20);
$dias_nuevo  = intval($_POST['dias_nuevo'] ?? 0);
$id_empleado = intval($_POST['id_empleado'] ?? 0);

if (!$id_prestamo || $monto_nuevo <= 0 || $dias_nuevo <= 0) {
    echo json_encode(['ok' => false, 'error' => 'Datos incompletos o invalidos']);
    exit;
}

$conn = getDB();

$resTime = $conn->query("SELECT NOW() as ahora, CURDATE() as hoy");
$timeRow = $resTime->fetch_assoc();
$ahora_mysql = $timeRow['ahora'];
$hoy_mysql   = $timeRow['hoy'];

$stmt = $conn->prepare("
    SELECT p.id_prestamo, p.monto_prestado, p.total_pagar, p.total_pagado,
           p.saldo_actual, p.pago_diario, p.estado, p.dias_prestamo,
           p.interes, p.fecha_inicio,
           c.id_cliente, c.nombre AS c_nombre, c.apellido AS c_apellido,
           c.id_asesor
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    WHERE p.id_prestamo = ?
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$prestamo = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$prestamo) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'Prestamo no encontrado']);
    exit;
}

if (!in_array($prestamo['estado'], ['ACTIVO', 'ATRASADO'])) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'El prestamo no esta activo']);
    exit;
}

// Dias sin abonar
$stmt = $conn->prepare("
    SELECT DATEDIFF(CURDATE(), MAX(DATE(fecha_pago))) AS dias_sin_abonar
    FROM pagos WHERE id_prestamo = ? AND monto_pagado > 0
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$resUp = $stmt->get_result()->fetch_assoc();
$stmt->close();

$porcentaje_pagado = 0;
if (floatval($prestamo['total_pagar']) > 0)
    $porcentaje_pagado = (floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100;

$dias_transcurridos = diasHabiles($prestamo['fecha_inicio'], $hoy_mysql);

$dias_sin_abonar = $resUp['dias_sin_abonar'];
if ($dias_sin_abonar === null) $dias_sin_abonar = $dias_transcurridos;

// Bloquear si mas de 30 dias sin abonar
if ($dias_sin_abonar > 30) {
    $conn->close();
    echo json_encode([
        'ok'    => false,
        'error' => 'Renovacion bloqueada: cliente lleva ' . $dias_sin_abonar . ' dias sin abonar. Debe gestionarse como credito nuevo.',
    ]);
    exit;
}

if ($porcentaje_pagado < 75 && $dias_transcurridos < 15) {
    $conn->close();
    echo json_encode([
        'ok'    => false,
        'error' => 'No elegible para renovacion (' . round($porcentaje_pagado, 1) . '% pagado, ' . $dias_transcurridos . ' dias habiles)',
    ]);
    exit;
}

if ($_SESSION['rol'] === 'ASESOR') {
    $stmt = $conn->prepare("SELECT id_empleado FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $_SESSION['id_usuario']);
    $stmt->execute();
    $resUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($resUser['id_empleado'] != $prestamo['id_asesor']) {
        $conn->close();
        echo json_encode(['ok' => false, 'error' => 'Sin permiso para renovar este credito']);
        exit;
    }
}

$saldo_restante    = floatval($prestamo['saldo_actual']);
$interes_factor    = $interes_pct / 100;
$total_nuevo       = round($monto_nuevo * (1 + $interes_factor), 2);
$monto_a_entregar  = round($total_nuevo - $saldo_restante, 2);
$pago_diario_nuevo = $dias_nuevo > 0 ? round($total_nuevo / $dias_nuevo, 2) : 0;

if ($monto_a_entregar < 0) {
    $conn->close();
    echo json_encode([
        'ok'    => false,
        'error' => 'El saldo restante supera el monto del nuevo credito. Solicite un monto mayor.',
    ]);
    exit;
}

$id_cliente  = intval($prestamo['id_cliente']);
$usuario_log = $_SESSION['usuario'] ?? 'sistema';

$conn->begin_transaction();

try {
    // 1. Registrar pago de liquidacion
    $stmt = $conn->prepare("
        INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado, cuota_numero, tipo_pago, interes)
        VALUES (?, ?, ?, 0, 'RENOVACION', 0.00)
    ");
    $stmt->bind_param("isd", $id_prestamo, $ahora_mysql, $saldo_restante);
    $stmt->execute();
    $stmt->close();

    // 2. Cerrar prestamo anterior como RENOVADO
    $nuevo_total_pagado = floatval($prestamo['total_pagado']) + $saldo_restante;
    $stmt = $conn->prepare("
        UPDATE prestamos
        SET saldo_actual = 0, total_pagado = ?, estado = 'RENOVADO', fecha_liquidacion = ?
        WHERE id_prestamo = ?
    ");
    $stmt->bind_param("dsi", $nuevo_total_pagado, $hoy_mysql, $id_prestamo);
    $stmt->execute();
    $stmt->close();

    // 3. Crear el nuevo prestamo
    $stmt = $conn->prepare("
        INSERT INTO prestamos
            (id_cliente, id_empleado, monto_prestado, interes, dias_prestamo,
             total_pagar, pago_diario, saldo_actual, total_pagado,
             estado, fecha_inicio, id_prestamo_renovado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'ACTIVO', CURDATE(), ?)
    ");
    $stmt->bind_param(
        "iiddiiddi",
        $id_cliente, $id_empleado, $monto_nuevo, $interes_pct, $dias_nuevo,
        $total_nuevo, $pago_diario_nuevo, $total_nuevo, $id_prestamo
    );
    $stmt->execute();
    $id_prestamo_nuevo = $conn->insert_id;
    $stmt->close();

    // 4. Registrar salida en caja
    if ($monto_a_entregar > 0 && $id_empleado > 0) {
        $concepto_caja   = "Renovacion credito #$id_prestamo -> nuevo #$id_prestamo_nuevo";
        $tipo_caja       = 'SALIDA';
        $medio_caja      = 'EFECTIVO';
        $tipo_movimiento = 'RENOVACION';
        $stmt = $conn->prepare("
            INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, id_prestamo, tipo_movimiento, fecha)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("sssdiss", $tipo_caja, $concepto_caja, $medio_caja, $monto_a_entregar, $id_empleado, $id_prestamo_nuevo, $tipo_movimiento);
        $stmt->execute();
        $stmt->close();
    }

    // 5. Historial prestamo anterior
    $desc_anterior = "RENOVACION: Saldo liquidado $$saldo_restante. Nuevo prestamo #$id_prestamo_nuevo";
    $stmt = $conn->prepare("
        INSERT INTO historial_movimientos (id_prestamo, tipo, descripcion, usuario, fecha)
        VALUES (?, 'RENOVACION', ?, ?, NOW())
    ");
    $stmt->bind_param("iss", $id_prestamo, $desc_anterior, $usuario_log);
    $stmt->execute();
    $stmt->close();

    // 6. Historial nuevo prestamo
    $desc_nuevo = "Prestamo por renovacion del credito #$id_prestamo. Entregado: $$monto_a_entregar (descuento saldo $$saldo_restante)";
    $stmt = $conn->prepare("
        INSERT INTO historial_movimientos (id_prestamo, tipo, descripcion, usuario, fecha)
        VALUES (?, 'NUEVO_PRESTAMO', ?, ?, NOW())
    ");
    $stmt->bind_param("iss", $id_prestamo_nuevo, $desc_nuevo, $usuario_log);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    echo json_encode([
        'ok'                => true,
        'mensaje'           => 'Renovacion exitosa',
        'id_prestamo_nuevo' => $id_prestamo_nuevo,
        'id_prestamo_viejo' => $id_prestamo,
        'saldo_liquidado'   => $saldo_restante,
        'monto_nuevo'       => $monto_nuevo,
        'interes_pct'       => $interes_pct,
        'total_nuevo'       => $total_nuevo,
        'monto_entregado'   => $monto_a_entregar,
        'pago_diario_nuevo' => $pago_diario_nuevo,
        'dias_nuevo'        => $dias_nuevo,
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['ok' => false, 'error' => 'Error al procesar: ' . $e->getMessage()]);
} finally {
    $conn->close();
}
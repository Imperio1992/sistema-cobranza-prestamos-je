<?php
require_once 'config.php';
verificarSesion();
verificarRolCobro();

$conn = getDB();
$rol = $_SESSION['rol'];
$id_usuario = $_SESSION['id_usuario'];

$id_prestamo = isset($_GET['id_prestamo']) ? intval($_GET['id_prestamo']) : 0;
$id_empleado_retorno = isset($_GET['id_empleado']) ? intval($_GET['id_empleado']) : 0;

if (!$id_prestamo) {
    header('Location: cobro_diario.php');
    exit;
}

$stmt = $conn->prepare("
    SELECT 
        p.id_prestamo, p.pago_diario, p.saldo_actual, p.total_pagar,
        p.total_pagado, p.estado, p.fecha_inicio, p.mora_acumulada,
        p.monto_prestado, p.interes, p.dias_prestamo,
        c.id_cliente, c.nombre AS c_nombre, c.apellido AS c_apellido,
        c.telefono AS c_tel, c.direccion AS c_dir, c.id_asesor,
        e.nombre AS asesor_nombre, e.apellido AS asesor_apellido, e.id_empleado
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    INNER JOIN empleados e ON e.id_empleado = c.id_asesor
    WHERE p.id_prestamo = ?
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$prestamo = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$prestamo) {
    header('Location: cobro_lista.php?id_empleado=' . $id_empleado_retorno);
    exit;
}

if ($rol === 'ASESOR') {
    $stmt = $conn->prepare("SELECT id_empleado FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($res['id_empleado'] != $prestamo['id_asesor']) {
        header('Location: cobro_lista.php?id_empleado=' . $res['id_empleado']);
        exit;
    }
}

$hoy = date('Y-m-d');

$stmt = $conn->prepare("
    SELECT SUM(monto_pagado) as monto_hoy, MAX(id_pago) as id_pago
    FROM pagos 
    WHERE id_prestamo = ? AND DATE(fecha_pago) = ?
");
$stmt->bind_param("is", $id_prestamo, $hoy);
$stmt->execute();
$pagoHoy = $stmt->get_result()->fetch_assoc();
$stmt->close();

$stmt = $conn->prepare("
    SELECT id_pago, fecha_pago, monto_pagado, tipo_pago
    FROM pagos
    WHERE id_prestamo = ?
    ORDER BY fecha_pago DESC
    LIMIT 10
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$historial = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $conn->prepare("
    SELECT DATEDIFF(CURDATE(), MAX(DATE(fecha_pago))) AS dias_sin_abonar
    FROM pagos WHERE id_prestamo = ? AND monto_pagado > 0
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$resUp = $stmt->get_result()->fetch_assoc();
$stmt->close();

$dias_transcurridos = 0;
if ($prestamo['fecha_inicio']) {
    $inicio_cobro = date('Y-m-d', strtotime($prestamo['fecha_inicio'] . ' +1 day'));
    $dias_transcurridos = diasHabiles($inicio_cobro, $hoy);
}

$dias_sin_abonar = $resUp['dias_sin_abonar'];
if ($dias_sin_abonar === null) $dias_sin_abonar = $dias_transcurridos;

$deberia_haber_pagado  = $dias_transcurridos * floatval($prestamo['pago_diario']);
$total_ya_pagado_antes = floatval($prestamo['total_pagado']) - floatval($pagoHoy['monto_hoy'] ?? 0);
$saldo_atrasado        = max(0, $deberia_haber_pagado - $total_ya_pagado_antes);

$conn->close();

$porcentaje_reno = 0;
if (floatval($prestamo['total_pagar']) > 0)
    $porcentaje_reno = (floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100;

$dias_reno = diasHabiles($prestamo['fecha_inicio'], $hoy);

$puede_renovar = ($porcentaje_reno >= 75 || $dias_reno >= 15)
              && in_array($prestamo['estado'], ['ACTIVO','ATRASADO'])
              && $dias_sin_abonar <= 30;

$cliente_moroso = ($dias_sin_abonar > 30);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Registrar Pago - <?= htmlspecialchars($prestamo['c_nombre'] . ' ' . $prestamo['c_apellido']) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; color: #1a1a2e; }

        .header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 14px 20px;
            padding-top: max(env(safe-area-inset-top), 14px);
            padding-left: max(env(safe-area-inset-left), 20px);
            padding-right: max(env(safe-area-inset-right), 20px);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .header h1 { font-size: 1.1rem; font-weight: 600; }
        .btn-volver { color: white; text-decoration: none; font-size: 0.85rem; opacity: 0.8; }
        .btn-volver:hover { opacity: 1; }

        .container { max-width: 680px; margin: 0 auto; padding: 20px 16px; }
        .card {
            background: white; border-radius: 14px; padding: 20px;
            margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .card-titulo {
            font-size: 0.9rem; font-weight: 600; color: #64748b;
            margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .cliente-header { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
        .cliente-avatar {
            width: 52px; height: 52px; border-radius: 50%;
            background: linear-gradient(135deg, #e94560, #c0392b);
            color: white; font-size: 1.2rem; font-weight: 700;
            display: flex; align-items: center; justify-content: center;
        }
        .cliente-nombre-big { font-size: 1.15rem; font-weight: 700; }
        .cliente-sub { font-size: 0.82rem; color: #64748b; margin-top: 4px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .info-item { background: #f8fafc; border-radius: 8px; padding: 10px 12px; }
        .info-item .lbl { font-size: 0.72rem; color: #64748b; margin-bottom: 3px; }
        .info-item .val { font-size: 0.95rem; font-weight: 600; }
        .val-verde { color: #16a34a; }
        .val-rojo  { color: #dc2626; }
        .val-azul  { color: #2563eb; }

        .ya-pagado-banner {
            background: #dcfce7; border: 1px solid #86efac;
            border-radius: 10px; padding: 12px 16px;
            display: flex; align-items: center; gap: 10px; margin-bottom: 16px;
        }
        .ya-pagado-banner .icon { font-size: 1.5rem; }
        .ya-pagado-banner .txt  { font-size: 0.9rem; color: #166534; font-weight: 600; }
        .ya-pagado-banner .sub  { font-size: 0.8rem; color: #16a34a; }

        .atraso-banner {
            background: #fee2e2; border: 1px solid #fca5a5;
            border-radius: 10px; padding: 12px 16px;
            margin-bottom: 16px; font-size: 0.9rem; color: #991b1b;
        }
        .moroso-banner {
            background: #1a1a2e; border: 2px solid #dc2626;
            border-radius: 10px; padding: 12px 16px;
            margin-bottom: 16px; font-size: 0.9rem; color: #fca5a5;
        }

        .montos-rapidos { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
        .monto-btn {
            padding: 7px 14px; border-radius: 8px;
            border: 2px solid #e2e8f0; background: white;
            font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: all 0.15s;
        }
        .monto-btn:hover, .monto-btn.activo {
            border-color: #e94560; background: #fff5f6; color: #e94560;
        }

        .form-group { margin-bottom: 14px; }
        .form-group label {
            display: block; font-size: 0.85rem; font-weight: 600;
            color: #374151; margin-bottom: 6px;
        }
        .form-group input {
            width: 100%; padding: 10px 14px; border: 2px solid #e2e8f0;
            border-radius: 10px; font-size: 0.95rem; outline: none;
            transition: border-color 0.2s; background: #fafafa;
        }
        .form-group input:focus { border-color: #e94560; background: white; }
        .input-grande {
            font-size: 1.5rem !important; font-weight: 700 !important;
            text-align: center; color: #1a1a2e;
        }

        .btn-group { display: flex; gap: 10px; margin-top: 20px; }
        .btn-primary {
            flex: 2; background: #e94560; color: white; border: none;
            border-radius: 10px; padding: 14px; font-size: 1rem;
            font-weight: 700; cursor: pointer; transition: background 0.2s;
        }
        .btn-primary:hover    { background: #c0392b; }
        .btn-primary:disabled { background: #94a3b8; cursor: not-allowed; }
        .btn-secondary {
            flex: 1; background: white; color: #64748b;
            border: 2px solid #e2e8f0; border-radius: 10px; padding: 14px;
            font-size: 0.9rem; font-weight: 600; cursor: pointer;
            transition: all 0.2s; text-decoration: none; text-align: center;
        }
        .btn-secondary:hover { border-color: #e94560; color: #e94560; }

        .historial-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem;
        }
        .historial-item:last-child { border-bottom: none; }
        .historial-fecha { color: #64748b; }
        .historial-monto { font-weight: 600; }
        .historial-monto.atraso { color: #94a3b8; }
        .historial-tipo {
            font-size: 0.72rem; padding: 2px 8px;
            border-radius: 10px; background: #f1f5f9; color: #64748b;
        }

        .mensaje-resultado {
            display: none; padding: 14px; border-radius: 10px;
            text-align: center; font-size: 0.95rem; font-weight: 600; margin-top: 14px;
        }
        .mensaje-ok    { background: #dcfce7; color: #166534; }
        .mensaje-error { background: #fee2e2; color: #991b1b; }

        @media (max-width: 500px) {
            .info-grid { grid-template-columns: 1fr; }
            .btn-group { flex-direction: column; }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>&#128181; Registrar Pago</h1>
    <a href="cobro_lista.php?id_empleado=<?= $prestamo['id_empleado'] ?>" class="btn-volver">&#8592; Lista de cobro</a>
</div>

<div class="container">

    <!-- Info Cliente -->
    <div class="card">
        <div class="cliente-header">
            <div class="cliente-avatar"><?= strtoupper(substr($prestamo['c_nombre'], 0, 1)) ?></div>
            <div>
                <div class="cliente-nombre-big"><?= htmlspecialchars($prestamo['c_nombre'] . ' ' . $prestamo['c_apellido']) ?></div>
                <div class="cliente-sub">
                    <?php if ($prestamo['c_tel']): ?>&#128222; <?= htmlspecialchars($prestamo['c_tel']) ?> &bull; <?php endif; ?>
                    Asesor: <?= htmlspecialchars($prestamo['asesor_nombre'] . ' ' . $prestamo['asesor_apellido']) ?>
                </div>
            </div>
        </div>
        <?php if ($prestamo['c_dir']): ?>
        <div style="font-size:0.82rem;color:#64748b;margin-bottom:12px;">&#128205; <?= htmlspecialchars($prestamo['c_dir']) ?></div>
        <?php endif; ?>
        <div class="info-grid">
            <div class="info-item">
                <div class="lbl">Pago diario requerido</div>
                <div class="val val-azul">$<?= number_format($prestamo['pago_diario'], 2) ?></div>
            </div>
            <div class="info-item">
                <div class="lbl">Saldo restante</div>
                <div class="val <?= $prestamo['saldo_actual'] <= 0 ? 'val-verde' : 'val-rojo' ?>">$<?= number_format($prestamo['saldo_actual'], 2) ?></div>
            </div>
            <div class="info-item">
                <div class="lbl">Total prestado</div>
                <div class="val">$<?= number_format($prestamo['monto_prestado'], 2) ?></div>
            </div>
            <div class="info-item">
                <div class="lbl">Total pagado</div>
                <div class="val val-verde">$<?= number_format($prestamo['total_pagado'], 2) ?></div>
            </div>
            <div class="info-item">
                <div class="lbl">Estado prestamo</div>
                <div class="val <?= $prestamo['estado'] === 'ACTIVO' ? 'val-verde' : 'val-rojo' ?>"><?= htmlspecialchars($prestamo['estado']) ?></div>
            </div>
            <div class="info-item">
                <div class="lbl">Fecha inicio</div>
                <div class="val"><?= $prestamo['fecha_inicio'] ? fechaEs($prestamo['fecha_inicio'], 'corta') : '-' ?></div>
            </div>
        </div>
        <?php if ($prestamo['mora_acumulada'] > 0): ?>
        <div style="margin-top:10px;background:#fee2e2;border-radius:8px;padding:8px 12px;font-size:0.82rem;color:#991b1b;">
            &#9888; Mora acumulada: <strong>$<?= number_format($prestamo['mora_acumulada'], 2) ?></strong>
        </div>
        <?php endif; ?>
    </div>

    <!-- Banner cliente moroso -->
    <?php if ($cliente_moroso): ?>
    <div class="moroso-banner">
        &#128683; <strong>Cliente sin abono por <?= $dias_sin_abonar ?> dias.</strong>
        La renovacion esta bloqueada. Si se desea otorgar credito debe gestionarse como <strong>credito nuevo</strong>.
    </div>
    <?php endif; ?>

    <!-- Banner ya pagado hoy -->
    <?php if (floatval($pagoHoy['monto_hoy'] ?? 0) > 0): ?>
    <div class="ya-pagado-banner">
        <div class="icon">&#10003;</div>
        <div>
            <div class="txt">Ya se registro un pago hoy</div>
            <div class="sub">Monto: $<?= number_format($pagoHoy['monto_hoy'], 2) ?> &bull; Puedes actualizar o agregar otro pago</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Banner de atraso -->
    <?php if ($saldo_atrasado > 0): ?>
    <div class="atraso-banner">
        &#9888; <strong>Cliente con atraso.</strong> Segun los dias habiles transcurridos, deberia llevar pagado:
        <strong>$<?= number_format($dias_transcurridos * floatval($prestamo['pago_diario']), 2) ?></strong> —
        Diferencia pendiente: <strong>$<?= number_format($saldo_atrasado, 2) ?></strong>
    </div>
    <?php endif; ?>

    <!-- Formulario de pago -->
    <div class="card">
        <div class="card-titulo">Registrar Pago</div>
        <div class="form-pago">
            <p style="font-size:0.85rem;color:#64748b;margin-bottom:12px;">Selecciona un monto rapido o escribe cualquier cantidad:</p>
            <div class="montos-rapidos">
                <button class="monto-btn" onclick="setMonto(<?= floatval($prestamo['pago_diario']) ?>, this)">
                    Pago normal: $<?= number_format($prestamo['pago_diario'], 2) ?>
                </button>
                <?php if ($saldo_atrasado > 0): ?>
                <button class="monto-btn" onclick="setMonto(<?= $saldo_atrasado + floatval($prestamo['pago_diario']) ?>, this)">
                    Pago + atraso: $<?= number_format($saldo_atrasado + floatval($prestamo['pago_diario']), 2) ?>
                </button>
                <?php endif; ?>
                <?php if ($prestamo['saldo_actual'] > 0): ?>
                <button class="monto-btn" onclick="setMonto(<?= floatval($prestamo['saldo_actual']) ?>, this)">
                    Liquidar: $<?= number_format($prestamo['saldo_actual'], 2) ?>
                </button>
                <?php endif; ?>
                <button class="monto-btn" onclick="setMonto(0, this)">Atraso $0</button>
            </div>
            <div class="form-group">
                <label>Monto a pagar ($)</label>
                <input type="number" id="monto-pago" class="input-grande" min="0" step="0.01"
                    value="<?= number_format($prestamo['pago_diario'], 2, '.', '') ?>"
                    placeholder="0.00" oninput="actualizarBoton()">
                <div style="font-size:0.78rem;color:#64748b;margin-top:6px;text-align:center;">
                    ✏️ Puedes escribir cualquier monto manualmente
                </div>
            </div>
            <div class="form-group">
                <label>Medio de cobro</label>
                <div style="display:flex;gap:10px;margin-top:6px;">
                    <button type="button" id="btn-efectivo" onclick="seleccionarMedio('EFECTIVO')"
                        style="flex:1;padding:12px 8px;border-radius:10px;border:2px solid #22c55e;background:#f0fdf4;color:#166534;font-weight:700;font-size:0.95rem;cursor:pointer;transition:all 0.2s;">
                        💵 Efectivo
                    </button>
                    <button type="button" id="btn-transferencia" onclick="seleccionarMedio('TRANSFERENCIA')"
                        style="flex:1;padding:12px 8px;border-radius:10px;border:2px solid #e2e8f0;background:#f8fafc;color:#475569;font-weight:700;font-size:0.95rem;cursor:pointer;transition:all 0.2s;">
                        🏦 Transferencia
                    </button>
                </div>
                <input type="hidden" id="tipo-pago" value="EFECTIVO">
            </div>
            <div id="mensaje-resultado" class="mensaje-resultado"></div>
            <div class="btn-group">
                <button class="btn-primary" id="btn-guardar" onclick="guardarPago()">
                    &#128181; Guardar Pago
                </button>
                <a href="cobro_lista.php?id_empleado=<?= $prestamo['id_empleado'] ?>" class="btn-secondary">
                    Cancelar
                </a>
            </div>
        </div>
    </div>

    <!-- Historial de pagos -->
    <?php if (!empty($historial)): ?>
    <div class="card">
        <div class="card-titulo">Historial reciente de pagos</div>
        <?php foreach ($historial as $h): ?>
        <div class="historial-item">
            <div>
                <div class="historial-fecha"><?= fechaEs($h['fecha_pago'], 'hora') ?></div>
                <?php if ($h['tipo_pago']): ?>
                <span class="historial-tipo"><?= htmlspecialchars($h['tipo_pago']) ?></span>
                <?php endif; ?>
            </div>
            <div class="historial-monto <?= floatval($h['monto_pagado']) == 0 ? 'atraso' : '' ?>">
                <?= floatval($h['monto_pagado']) == 0 ? 'Atraso' : '$' . number_format($h['monto_pagado'], 2) ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Tarjeta de Renovacion -->
    <?php if (in_array($prestamo['estado'], ['ACTIVO','ATRASADO'])): ?>
    <div class="card" style="border:2px solid <?= $puede_renovar ? '#7c3aed' : '#e2e8f0' ?>;">
        <div class="card-titulo" style="color:#7c3aed;">&#128260; Renovacion de Credito</div>
        <?php if ($puede_renovar): ?>
            <div style="background:#f5f3ff;border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:.88rem;color:#5b21b6;">
                <strong>&#9989; Este cliente puede renovar su credito.</strong><br>
                Ha pagado el <?= round($porcentaje_reno,1) ?>% del credito
                (<?= $dias_reno ?> dias habiles). El saldo restante
                <strong>$<?= number_format($prestamo['saldo_actual'],2) ?></strong>
                se descontara del nuevo prestamo.
            </div>
            <a href="cobro_renovacion.php?id_prestamo=<?= $id_prestamo ?>&id_empleado=<?= $id_empleado_retorno ?>"
               style="display:flex;align-items:center;justify-content:center;gap:8px;
                      background:#7c3aed;color:white;border-radius:10px;padding:12px;
                      font-size:.95rem;font-weight:700;text-decoration:none;">
                &#128260; Renovar Credito
            </a>
        <?php else: ?>
            <div style="background:#f8fafc;border-radius:10px;padding:12px 14px;font-size:.85rem;color:#64748b;">
                <?php if ($cliente_moroso): ?>
                    &#128683; <strong style="color:#dc2626;">Renovacion bloqueada.</strong>
                    Este cliente lleva <strong><?= $dias_sin_abonar ?> dias</strong> sin abonar.
                    Para otorgar credito debe gestionarse como <strong>credito nuevo</strong>.
                <?php else: ?>
                    &#128274; No elegible aun. Requiere 75% pagado o 15 dias habiles.<br>
                    Actualmente: <?= round($porcentaje_reno,1) ?>% pagado &bull; <?= $dias_reno ?> dias.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>

<script>
const idPrestamo = <?= $id_prestamo ?>;
const idEmpleado = <?= $prestamo['id_empleado'] ?>;

function seleccionarMedio(medio) {
    document.getElementById('tipo-pago').value = medio;
    const btnEf = document.getElementById('btn-efectivo');
    const btnTr = document.getElementById('btn-transferencia');
    if (medio === 'EFECTIVO') {
        btnEf.style.border = '2px solid #22c55e'; btnEf.style.background = '#f0fdf4'; btnEf.style.color = '#166534';
        btnTr.style.border = '2px solid #e2e8f0'; btnTr.style.background = '#f8fafc'; btnTr.style.color = '#475569';
    } else {
        btnTr.style.border = '2px solid #3b82f6'; btnTr.style.background = '#eff6ff'; btnTr.style.color = '#1e40af';
        btnEf.style.border = '2px solid #e2e8f0'; btnEf.style.background = '#f8fafc'; btnEf.style.color = '#475569';
    }
}

function setMonto(val, btn) {
    document.getElementById('monto-pago').value = val.toFixed(2);
    if (val == 0) {
        document.getElementById('tipo-pago').value = 'ATRASO';
        document.getElementById('btn-efectivo').style.opacity = '0.4';
        document.getElementById('btn-transferencia').style.opacity = '0.4';
    } else {
        document.getElementById('btn-efectivo').style.opacity = '1';
        document.getElementById('btn-transferencia').style.opacity = '1';
        if (document.getElementById('tipo-pago').value === 'ATRASO') seleccionarMedio('EFECTIVO');
    }
    document.querySelectorAll('.monto-btn').forEach(b => b.classList.remove('activo'));
    if (btn) btn.classList.add('activo');
    actualizarBoton();
}

function actualizarBoton() {
    const monto = parseFloat(document.getElementById('monto-pago').value);
    const btn   = document.getElementById('btn-guardar');
    if (!isNaN(monto) && monto > 0) {
        btn.textContent = '💰 Guardar Pago: $' + monto.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    } else {
        btn.textContent = '⚠️ Registrar Atraso ($0)';
    }
}

function guardarPago() {
    const monto = parseFloat(document.getElementById('monto-pago').value);
    const tipo  = document.getElementById('tipo-pago').value;
    const btn   = document.getElementById('btn-guardar');
    const msg   = document.getElementById('mensaje-resultado');

    msg.style.display = 'none';

    if (isNaN(monto) || monto < 0) {
        msg.className = 'mensaje-resultado mensaje-error';
        msg.textContent = '✗ Ingresa un monto valido.';
        msg.style.display = 'block';
        return;
    }

    if (monto === 0) {
        if (!confirm('¿Registrar como ATRASO ($0.00)?\nEsto indica que el cliente no pago hoy.')) return;
    }

    btn.disabled = true;
    btn.textContent = 'Guardando...';

    const fd = new FormData();
    fd.append('id_prestamo', idPrestamo);
    fd.append('monto',       monto);
    fd.append('tipo',        tipo);
    fd.append('id_empleado', idEmpleado);

    fetch('cobro_ajax.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
        if (data.ok) {
            msg.className = 'mensaje-resultado mensaje-ok';
            msg.textContent = '✓ ' + data.mensaje;
            msg.style.display = 'block';
            setTimeout(() => { window.location.href = 'cobro_lista.php?id_empleado=' + idEmpleado; }, 1500);
        } else {
            msg.className = 'mensaje-resultado mensaje-error';
            msg.textContent = '✗ ' + (data.error || 'Error al guardar');
            msg.style.display = 'block';
            btn.disabled = false;
            actualizarBoton();
        }
    })
    .catch(() => {
        msg.className = 'mensaje-resultado mensaje-error';
        msg.textContent = '✗ Error de conexion. Intenta de nuevo.';
        msg.style.display = 'block';
        btn.disabled = false;
        actualizarBoton();
    });
}

actualizarBoton();
</script>
</body>
</html>
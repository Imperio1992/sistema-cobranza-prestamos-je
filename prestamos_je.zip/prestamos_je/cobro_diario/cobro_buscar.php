<?php
include("../seguridad.php");
include("../conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';

$id_empleado_logueado = intval($_SESSION['id_empleado'] ?? 0);
$id_empleado = isset($_GET['id_empleado']) ? intval($_GET['id_empleado']) : 0;

if ($rol === 'ASESOR') {
    $id_empleado = $id_empleado_logueado;
}

$busqueda   = trim($_POST['buscar'] ?? $_GET['buscar'] ?? '');
$resultados = [];

if ($busqueda !== '') {
    $bs = $conexion->real_escape_string($busqueda);

    $filtro_asesor = '';
    if ($rol === 'ASESOR' && $id_empleado_logueado) {
        $filtro_asesor = " AND c.id_asesor = $id_empleado_logueado";
    }

    $sql = "
        SELECT
            c.id_cliente,
            c.nombre    AS c_nombre,
            c.apellido  AS c_apellido,
            c.telefono  AS c_tel,
            c.direccion AS c_dir,
            c.id_asesor,
            e.nombre    AS asesor_nombre,
            e.apellido  AS asesor_apellido,
            p.id_prestamo,
            p.pago_diario,
            p.saldo_actual,
            p.estado    AS p_estado,
            p.total_pagar,
            COALESCE(pago_hoy.monto_hoy, 0) AS pagado_hoy
        FROM clientes c
        INNER JOIN empleados e ON e.id_empleado = c.id_asesor
        INNER JOIN prestamos p ON p.id_cliente = c.id_cliente
            AND p.estado IN ('ACTIVO','ATRASADO')
        LEFT JOIN (
            SELECT id_prestamo, SUM(monto_pagado) AS monto_hoy
            FROM pagos
            WHERE DATE(fecha_pago) = CURDATE()
            GROUP BY id_prestamo
        ) pago_hoy ON pago_hoy.id_prestamo = p.id_prestamo
        WHERE (
            c.nombre    LIKE '%$bs%'
            OR c.apellido  LIKE '%$bs%'
            OR c.telefono  LIKE '%$bs%'
            OR CONCAT(c.nombre,' ',c.apellido) LIKE '%$bs%'
        )
        $filtro_asesor
        ORDER BY c.nombre, c.apellido
        LIMIT 30
    ";

    $res = $conexion->query($sql);
    while ($row = $res->fetch_assoc()) {
        $resultados[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Buscar / Enrutar — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-sb { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special.active { background:rgba(124,58,237,.15); color:#ddd6fe; border:1px solid rgba(124,58,237,.2); }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 48px; max-width:calc(100% - 240px); }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-theme { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06); text-decoration:none; }
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── INFO AVISO ── */
.info-aviso { background:#eff6ff; border:1px solid #bfdbfe; border-radius:12px; padding:14px 18px; font-size:.85rem; color:#1e40af; margin-bottom:20px; display:flex; align-items:flex-start; gap:10px; }
.info-aviso i { font-size:1.1rem; flex-shrink:0; margin-top:1px; }

/* ── SEARCH BOX ── */
.search-box { background:white; border-radius:16px; padding:22px; margin-bottom:22px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid #f1f5f9; }
.search-box h2 { font-size:1rem; font-weight:700; color:#0f172a; margin-bottom:6px; display:flex; align-items:center; gap:8px; }
.search-box p  { font-size:.85rem; color:#64748b; margin-bottom:16px; }
.input-row { display:flex; gap:10px; }
.input-row input { flex:1; padding:11px 16px; border:1.5px solid #e2e8f0; border-radius:10px; font-size:.95rem; outline:none; font-family:'Inter',sans-serif; background:#f8fafc; color:#1e293b; }
.input-row input:focus { border-color:#2563eb; background:white; }
.btn-search { background:#2563eb; color:white; border:none; border-radius:10px; padding:11px 22px; font-size:.9rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; display:flex; align-items:center; gap:7px; white-space:nowrap; }
.btn-search:hover { background:#1d4ed8; }

/* ── RESULTADO ITEMS ── */
.resultado-item { background:white; border-radius:14px; padding:18px; margin-bottom:12px; box-shadow:0 2px 8px rgba(0,0,0,.06); border:1.5px solid #f1f5f9; border-left-width:4px; border-left-color:#e2e8f0; }
.resultado-item.mismo-asesor { border-left-color:#22c55e; }
.resultado-item.otro-asesor  { border-left-color:#f59e0b; }
.res-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px; gap:10px; }
.res-nombre { font-size:.95rem; font-weight:700; color:#0f172a; }
.res-sub { font-size:.78rem; color:#64748b; margin-top:4px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.badge-asesor { font-size:.72rem; padding:4px 10px; border-radius:20px; font-weight:700; white-space:nowrap; }
.badge-propio { background:#dcfce7; color:#166534; }
.badge-otro   { background:#fef3c7; color:#92400e; }
.res-datos { display:flex; gap:10px; flex-wrap:wrap; margin-bottom:14px; }
.res-dato { background:#f8fafc; border-radius:9px; padding:8px 14px; font-size:.82rem; }
.res-dato .lbl { color:#64748b; font-size:.7rem; margin-bottom:2px; }
.res-dato .val { font-weight:700; color:#0f172a; }
.res-dir { font-size:.78rem; color:#64748b; margin-bottom:12px; display:flex; align-items:center; gap:5px; }
.res-acciones { display:flex; gap:8px; flex-wrap:wrap; }
.btn-cobrar-res { background:#2563eb; color:white; border:none; border-radius:9px; padding:9px 18px; font-size:.85rem; font-weight:700; cursor:pointer; text-decoration:none; transition:background .15s; display:inline-flex; align-items:center; gap:6px; font-family:'Inter',sans-serif; }
.btn-cobrar-res:hover { background:#1d4ed8; }
.btn-ver-res { background:white; color:#2563eb; border:1.5px solid #bfdbfe; border-radius:9px; padding:9px 16px; font-size:.85rem; font-weight:600; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:6px; font-family:'Inter',sans-serif; }
.btn-ver-res:hover { background:#eff6ff; }
.ya-cobrado { background:#dcfce7; color:#166534; border-radius:9px; padding:9px 16px; font-size:.84rem; font-weight:700; display:inline-flex; align-items:center; gap:6px; }
.empty-search { text-align:center; padding:48px 20px; color:#64748b; }
.empty-search i { font-size:3rem; display:block; margin-bottom:12px; opacity:.4; }

/* ── DARK MODE ── */
[data-theme="dark"] body  { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#e2e8f0; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .info-aviso { background:#0c1a3a; border-color:#1e3a8a; color:#93c5fd; }
[data-theme="dark"] .search-box { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .search-box h2 { color:#e2e8f0; }
[data-theme="dark"] .input-row input { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .resultado-item { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .res-nombre { color:#e2e8f0; }
[data-theme="dark"] .res-dato { background:#1e293b; }
[data-theme="dark"] .res-dato .val { color:#e2e8f0; }
[data-theme="dark"] .btn-ver-res { background:#111827; border-color:#1e3a8a; }
[data-theme="dark"] .btn-ver-res:hover { background:#1e3a8a; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main { margin-left:0; max-width:100%; padding:14px 12px 40px; }
}
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="../index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="../dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="../caja.php"><i class="bi bi-cash-coin"></i> Caja</a>
        <a href="../registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="../nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="../cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="../clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="../empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="../programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="../reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="../buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="../nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_buscar.php?id_empleado=<?= $id_empleado ?>" class="special active"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="cobro_lista.php?id_empleado=<?= $id_empleado ?>" class="btn-theme" title="Regresar a lista de cobro">
                <i class="bi bi-arrow-left"></i>
            </a>
            <h1><i class="bi bi-search-heart" style="color:#7c3aed;"></i> Buscar / Enrutar Cliente</h1>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <div class="info-aviso">
        <i class="bi bi-info-circle-fill"></i>
        <span>Busca un cliente que quiera realizar un pago aunque no esté en tu ruta de hoy. Puedes registrar su pago directamente desde aquí.</span>
    </div>

    <div class="search-box">
        <h2><i class="bi bi-search" style="color:#2563eb;"></i> Buscar Cliente</h2>
        <p>Ingresa el nombre o teléfono del cliente que quiere pagar:</p>
        <form method="POST" action="">
            <input type="hidden" name="id_empleado" value="<?= $id_empleado ?>">
            <div class="input-row">
                <input type="text" name="buscar"
                    placeholder="Nombre o teléfono del cliente..."
                    value="<?= htmlspecialchars($busqueda) ?>"
                    autofocus required>
                <button type="submit" class="btn-search">
                    <i class="bi bi-search"></i> Buscar
                </button>
            </div>
        </form>
    </div>

    <?php if ($busqueda !== '' && empty($resultados)): ?>
    <div class="empty-search">
        <i class="bi bi-person-x"></i>
        <div>No se encontró ningún cliente con préstamo activo que coincida con <strong>"<?= htmlspecialchars($busqueda) ?>"</strong></div>
    </div>
    <?php endif; ?>

    <?php if (!empty($resultados)): ?>
    <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
        <span><?= count($resultados) ?> resultado<?= count($resultados) !== 1 ? 's' : '' ?> encontrado<?= count($resultados) !== 1 ? 's' : '' ?></span>
        <span style="flex:1;height:1px;background:#e2e8f0;display:block;"></span>
    </div>
    <?php endif; ?>

    <?php foreach ($resultados as $r):
        $es_mismo_asesor = ($r['id_asesor'] == $id_empleado);
        $ya_cobrado      = floatval($r['pagado_hoy']) > 0;
        $clase           = $es_mismo_asesor ? 'mismo-asesor' : 'otro-asesor';
    ?>
    <div class="resultado-item <?= $clase ?>">
        <div class="res-header">
            <div>
                <div class="res-nombre"><?= htmlspecialchars($r['c_nombre'] . ' ' . $r['c_apellido']) ?></div>
                <div class="res-sub">
                    <?php if ($r['c_tel']): ?>
                        <span><i class="bi bi-telephone"></i> <?= htmlspecialchars($r['c_tel']) ?></span>
                    <?php endif; ?>
                    <span><i class="bi bi-person-badge"></i> <?= htmlspecialchars($r['asesor_nombre'] . ' ' . $r['asesor_apellido']) ?></span>
                </div>
            </div>
            <span class="badge-asesor <?= $es_mismo_asesor ? 'badge-propio' : 'badge-otro' ?>">
                <?= $es_mismo_asesor ? 'Mi ruta' : 'Otra ruta' ?>
            </span>
        </div>

        <div class="res-datos">
            <div class="res-dato">
                <div class="lbl">Pago diario</div>
                <div class="val">$<?= number_format($r['pago_diario'], 2) ?></div>
            </div>
            <div class="res-dato">
                <div class="lbl">Saldo restante</div>
                <div class="val">$<?= number_format($r['saldo_actual'], 2) ?></div>
            </div>
            <div class="res-dato">
                <div class="lbl">Total a pagar</div>
                <div class="val">$<?= number_format($r['total_pagar'], 2) ?></div>
            </div>
            <div class="res-dato">
                <div class="lbl">Estado</div>
                <div class="val"><?= htmlspecialchars($r['p_estado']) ?></div>
            </div>
        </div>

        <?php if ($r['c_dir']): ?>
        <div class="res-dir"><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($r['c_dir']) ?></div>
        <?php endif; ?>

        <div class="res-acciones">
            <?php if ($ya_cobrado): ?>
                <span class="ya-cobrado"><i class="bi bi-check-circle-fill"></i> Ya cobrado hoy: $<?= number_format($r['pagado_hoy'], 2) ?></span>
                <a href="cobro_pagar.php?id_prestamo=<?= $r['id_prestamo'] ?>&id_empleado=<?= $id_empleado ?>" class="btn-ver-res">
                    <i class="bi bi-pencil"></i> Editar pago
                </a>
            <?php else: ?>
                <a href="cobro_pagar.php?id_prestamo=<?= $r['id_prestamo'] ?>&id_empleado=<?= $id_empleado ?>" class="btn-cobrar-res">
                    <i class="bi bi-cash-coin"></i> Cobrar
                </a>
                <?php if (!$es_mismo_asesor && $rol !== 'ASESOR'): ?>
                <span class="badge-otro" style="padding:9px 14px;font-size:.78rem;border-radius:9px;">
                    <i class="bi bi-arrows-move"></i> De otra ruta
                </span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>

</main>
</div>

<script>
function toggleTema() {
    const html = document.documentElement;
    const isDark = html.getAttribute('data-theme') === 'dark';
    html.setAttribute('data-theme', isDark ? 'light' : 'dark');
    document.getElementById('themeIcon').className = isDark ? 'bi bi-moon-fill' : 'bi bi-sun-fill';
    localStorage.setItem('pje_tema', isDark ? 'light' : 'dark');
}

document.addEventListener('DOMContentLoaded', () => {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
    setInterval(() => {
        document.getElementById('reloj').textContent = new Date().toLocaleTimeString('es-MX');
    }, 1000);
});
</script>
</body>
</html>

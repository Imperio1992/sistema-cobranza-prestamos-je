<?php
require_once 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['id_usuario']) || !isset($_SESSION['rol'])) {
    echo json_encode(['ok' => false, 'error' => 'Sesion no activa']);
    exit;
}
$id_prestamo = intval($_REQUEST['id_prestamo'] ?? 0);
$monto_nuevo = floatval($_REQUEST['monto_nuevo'] ?? 0);
$interes_pct = floatval($_REQUEST['interes_pct'] ?? 20);
$dias_nuevo  = intval($_REQUEST['dias_nuevo'] ?? 0);
if (!$id_prestamo) {
    echo json_encode(['ok' => false, 'error' => 'ID de prestamo invalido']);
    exit;
}
$conn = getDB();
$stmt = $conn->prepare("
    SELECT p.id_prestamo, p.monto_prestado, p.total_pagar, p.total_pagado,
           p.saldo_actual, p.pago_diario, p.estado, p.dias_prestamo,
           p.interes, p.fecha_inicio,
           c.id_cliente, c.nombre AS c_nombre, c.apellido AS c_apellido,
           c.id_asesor
    FROM prestamos p
    INNER JOIN clientes c ON c.id_cliente = p.id_cliente
    WHERE p.id_prestamo = ?
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$prestamo = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$prestamo) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'Prestamo no encontrado']);
    exit;
}
if (!in_array($prestamo['estado'], ['ACTIVO', 'ATRASADO'])) {
    $conn->close();
    echo json_encode(['ok' => false, 'error' => 'El prestamo no esta activo o atrasado']);
    exit;
}
// Dias sin abonar
$stmt = $conn->prepare("
    SELECT DATEDIFF(CURDATE(), MAX(DATE(fecha_pago))) AS dias_sin_abonar
    FROM pagos WHERE id_prestamo = ? AND monto_pagado > 0
");
$stmt->bind_param("i", $id_prestamo);
$stmt->execute();
$resUp = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();
$hoy = date('Y-m-d');
$porcentaje_pagado = 0;
if (floatval($prestamo['total_pagar']) > 0)
    $porcentaje_pagado = (floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100;
$dias_transcurridos = diasHabiles($prestamo['fecha_inicio'], $hoy);
$dias_sin_abonar = $resUp['dias_sin_abonar'];
if ($dias_sin_abonar === null) $dias_sin_abonar = $dias_transcurridos;
// Bloquear si lleva mas de 30 dias sin abonar
if ($dias_sin_abonar > 30) {
    echo json_encode([
        'ok'              => false,
        'error'           => 'Renovacion bloqueada: este cliente lleva ' . $dias_sin_abonar . ' dias sin abonar. Debe gestionarse como credito nuevo.',
        'dias_sin_abonar' => $dias_sin_abonar,
        'bloqueado'       => true,
    ]);
    exit;
}
$elegible = ($porcentaje_pagado >= 75) || ($dias_transcurridos >= 15);
if ($monto_nuevo <= 0) {
    echo json_encode([
        'ok'                 => true,
        'elegible'           => $elegible,
        'razon'              => $elegible
            ? ($porcentaje_pagado >= 75
                ? 'Ha pagado el ' . round($porcentaje_pagado, 1) . '% del credito'
                : 'Lleva ' . $dias_transcurridos . ' dias habiles de pago')
            : 'Necesita pagar al menos el 75% o llevar 15 pagos habiles',
        'porcentaje_pagado'  => round($porcentaje_pagado, 2),
        'dias_transcurridos' => $dias_transcurridos,
        'dias_sin_abonar'    => $dias_sin_abonar,
        'saldo_restante'     => floatval($prestamo['saldo_actual']),
        'total_pagado'       => floatval($prestamo['total_pagado']),
        'total_pagar'        => floatval($prestamo['total_pagar']),
        'dias_prestamo_orig' => intval($prestamo['dias_prestamo']),
        'monto_prestado_orig'=> floatval($prestamo['monto_prestado']),
        'cliente'            => htmlspecialchars($prestamo['c_nombre'] . ' ' . $prestamo['c_apellido']),
    ]);
    exit;
}
if (!$elegible) {
    echo json_encode([
        'ok'    => false,
        'error' => 'No elegible: ' . round($porcentaje_pagado, 1) . '% pagado, ' . $dias_transcurridos . ' dias habiles.',
    ]);
    exit;
}
$saldo_restante   = floatval($prestamo['saldo_actual']);
$interes_factor   = $interes_pct / 100;
$total_nuevo      = $monto_nuevo * (1 + $interes_factor);
$monto_a_entregar = $total_nuevo - $saldo_restante;
if ($monto_a_entregar < 0) {
    echo json_encode([
        'ok'    => false,
        'error' => 'El saldo restante ($' . number_format($saldo_restante, 2) . ') supera el nuevo credito ($' . number_format($total_nuevo, 2) . '). Solicite un monto mayor.',
    ]);
    exit;
}
$dias_final = $dias_nuevo > 0 ? $dias_nuevo : intval($prestamo['dias_prestamo']);
$pago_diario_nuevo = $dias_final > 0 ? round($total_nuevo / $dias_final, 2) : 0;
echo json_encode([
    'ok'                 => true,
    'elegible'           => true,
    'porcentaje_pagado'  => round($porcentaje_pagado, 2),
    'dias_transcurridos' => $dias_transcurridos,
    'dias_sin_abonar'    => $dias_sin_abonar,
    'saldo_restante'     => $saldo_restante,
    'monto_solicitado'   => $monto_nuevo,
    'interes_pct'        => $interes_pct,
    'total_nuevo'        => round($total_nuevo, 2),
    'monto_a_entregar'   => round($monto_a_entregar, 2),
    'dias_nuevo'         => $dias_final,
    'pago_diario_nuevo'  => $pago_diario_nuevo,
    'cliente'            => htmlspecialchars($prestamo['c_nombre'] . ' ' . $prestamo['c_apellido']),
    'id_cliente'         => intval($prestamo['id_cliente']),
    'id_asesor'          => intval($prestamo['id_asesor']),
]);
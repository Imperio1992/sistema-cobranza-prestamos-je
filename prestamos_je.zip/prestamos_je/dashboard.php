<?php
include("seguridad.php");
include("conexion.php");

$hoy        = date("Y-m-d");
$mes_actual  = date("m");
$anio_actual = date("Y");

$rol  = $_SESSION['rol']        ?? 'ASESOR';
$user = $_SESSION['usuario']    ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);

// ==========================
// CARTERAS
// ==========================
$cartera_activa  = $conexion->query("SELECT COALESCE(SUM(saldo_actual),0) AS t FROM prestamos WHERE estado='ACTIVO'")->fetch_assoc()['t'];
$cartera_vencida = $conexion->query("SELECT COALESCE(SUM(saldo_actual),0) AS t FROM prestamos WHERE estado='VENCIDO'")->fetch_assoc()['t'];
$cartera_total   = $cartera_activa + $cartera_vencida;
$porcentaje_mora = ($cartera_total > 0) ? ($cartera_vencida / $cartera_total) * 100 : 0;

// ==========================
// COBROS MES ACTUAL Y MES ANTERIOR
// ==========================
$cobrado_mes = $conexion->query("
    SELECT COALESCE(SUM(monto_pagado),0) AS t FROM pagos
    WHERE MONTH(fecha_pago)=MONTH(CURRENT_DATE()) AND YEAR(fecha_pago)=YEAR(CURRENT_DATE())
")->fetch_assoc()['t'];

$cobrado_mes_anterior = $conexion->query("
    SELECT COALESCE(SUM(monto_pagado),0) AS t FROM pagos
    WHERE MONTH(fecha_pago)=MONTH(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))
    AND YEAR(fecha_pago)=YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))
")->fetch_assoc()['t'];

$variacion_cobro = ($cobrado_mes_anterior > 0)
    ? (($cobrado_mes - $cobrado_mes_anterior) / $cobrado_mes_anterior) * 100
    : 0;

$utilidad_estimada = $cobrado_mes * 0.20;

// ==========================
// PRÉSTAMOS
// ==========================
$total_prestamos_activos = $conexion->query("SELECT COUNT(*) AS t FROM prestamos WHERE estado='ACTIVO'")->fetch_assoc()['t'];
$total_vencidos          = $conexion->query("SELECT COUNT(*) AS t FROM prestamos WHERE estado='VENCIDO'")->fetch_assoc()['t'];

$nuevos_hoy = $conexion->query("
    SELECT COUNT(*) AS t FROM prestamos WHERE DATE(fecha_inicio)=CURRENT_DATE()
")->fetch_assoc()['t'];

$nuevos_semana = $conexion->query("
    SELECT COUNT(*) AS t FROM prestamos WHERE fecha_inicio >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
")->fetch_assoc()['t'];

$prestamos_por_renovar = $conexion->query("
    SELECT COUNT(*) AS t FROM (
        SELECT pr.id_prestamo
        FROM prestamos pr
        LEFT JOIN pagos pa ON pa.id_prestamo = pr.id_prestamo
        WHERE pr.estado = 'ACTIVO' AND pr.pago_diario > 0
        GROUP BY pr.id_prestamo, pr.pago_diario
        HAVING COALESCE(SUM(pa.monto_pagado), 0) >= (pr.pago_diario * 20)
    ) AS sub
")->fetch_assoc()['t'];

// ==========================
// CLIENTES
// ==========================
$total_clientes = $conexion->query("SELECT COUNT(*) AS t FROM clientes")->fetch_assoc()['t'];
$clientes_nuevos_mes = $conexion->query("
    SELECT COUNT(*) AS t FROM clientes
    WHERE MONTH(fecha_registro)=MONTH(CURRENT_DATE()) AND YEAR(fecha_registro)=YEAR(CURRENT_DATE())
")->fetch_assoc()['t'];

// ==========================
// COBROS HOY
// ==========================
$cobrado_hoy = $conexion->query("
    SELECT COALESCE(SUM(monto_pagado),0) AS t FROM pagos WHERE DATE(fecha_pago)=CURRENT_DATE()
")->fetch_assoc()['t'];

$cobros_hoy_count = $conexion->query("
    SELECT COUNT(*) AS t FROM pagos WHERE DATE(fecha_pago)=CURRENT_DATE()
")->fetch_assoc()['t'];

// ==========================
// GRÁFICA: COBROS POR MES (AÑO ACTUAL)
// ==========================
$resGrafica = $conexion->query("
    SELECT MONTH(fecha_pago) AS mes, SUM(monto_pagado) AS total
    FROM pagos WHERE YEAR(fecha_pago)=YEAR(CURRENT_DATE())
    GROUP BY MONTH(fecha_pago) ORDER BY mes
");
$meses_nombres = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
$graf_labels = array_fill(0, 12, '0');
$graf_data   = array_fill(0, 12, 0);
foreach ($meses_nombres as $i => $mn) $graf_labels[$i] = $mn;
while ($row = $resGrafica->fetch_assoc()) {
    $graf_data[(int)$row['mes'] - 1] = (float)$row['total'];
}

// ==========================
// GRÁFICA: PRÉSTAMOS NUEVOS POR MES
// ==========================
$resNuevos = $conexion->query("
    SELECT MONTH(fecha_inicio) AS mes, COUNT(*) AS total
    FROM prestamos WHERE YEAR(fecha_inicio)=YEAR(CURRENT_DATE())
    GROUP BY MONTH(fecha_inicio) ORDER BY mes
");
$graf_nuevos = array_fill(0, 12, 0);
while ($row = $resNuevos->fetch_assoc()) {
    $graf_nuevos[(int)$row['mes'] - 1] = (int)$row['total'];
}

// ==========================
// GRÁFICA DONA
// ==========================
$dona_labels = ['Cartera Activa','Cartera Vencida'];
$dona_data   = [$cartera_activa, $cartera_vencida];

// ==========================
// RANKING ASESORES
// ==========================
$resRanking = $conexion->query("
    SELECT e.nombre, e.apellido,
           COALESCE(SUM(p.monto_pagado),0) AS total_cobrado,
           COUNT(DISTINCT pr.id_prestamo)   AS prestamos_activos
    FROM empleados e
    LEFT JOIN prestamos pr ON pr.id_empleado=e.id_empleado AND pr.estado='ACTIVO'
    LEFT JOIN pagos p      ON p.id_prestamo=pr.id_prestamo
                           AND MONTH(p.fecha_pago)=MONTH(CURRENT_DATE())
                           AND YEAR(p.fecha_pago)=YEAR(CURRENT_DATE())
    WHERE e.estatus='ACTIVO'
    GROUP BY e.id_empleado
    ORDER BY total_cobrado DESC
    LIMIT 5
");
$ranking = [];
$max_cobro = 0;
while ($r = $resRanking->fetch_assoc()) {
    $ranking[] = $r;
    if ($r['total_cobrado'] > $max_cobro) $max_cobro = $r['total_cobrado'];
}

// ==========================
// ÚLTIMOS 8 PAGOS
// ==========================
$resUltimos = $conexion->query("
    SELECT p.fecha_pago, p.monto_pagado,
           c.nombre AS cn, c.apellido AS ca,
           e.nombre AS en, e.apellido AS ea
    FROM pagos p
    INNER JOIN prestamos pr ON pr.id_prestamo=p.id_prestamo
    INNER JOIN clientes c   ON c.id_cliente=pr.id_cliente
    INNER JOIN empleados e  ON e.id_empleado=pr.id_empleado
    ORDER BY p.fecha_pago DESC, p.id_pago DESC
    LIMIT 8
");

// ==========================
// VENCIMIENTOS ESTA SEMANA
// ==========================
$resVencenSemana = $conexion->query("
    SELECT c.nombre, c.apellido, pr.total_pagar,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_fin,
           e.nombre AS asesor
    FROM prestamos pr
    INNER JOIN clientes c ON c.id_cliente=pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado=pr.id_empleado
    WHERE pr.estado='ACTIVO'
    AND DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 7 DAY)
    ORDER BY fecha_fin ASC
    LIMIT 6
");
$vencen_semana = [];
while ($v = $resVencenSemana->fetch_assoc()) $vencen_semana[] = $v;

// Semáforo mora
$semaforo = $porcentaje_mora > 10
    ? ['🔴 Crítico',   '#ef4444']
    : ($porcentaje_mora > 5
        ? ['🟡 Atención', '#f59e0b']
        : ['🟢 Saludable','#10b981']);

$mora_color = $porcentaje_mora > 10 ? '#ef4444' : ($porcentaje_mora > 5 ? '#f59e0b' : '#10b981');
$mora_bar_bg = $porcentaje_mora > 10
    ? 'linear-gradient(90deg,#ef4444,#b91c1c)'
    : ($porcentaje_mora > 5
        ? 'linear-gradient(90deg,#f59e0b,#d97706)'
        : 'linear-gradient(90deg,#10b981,#059669)');
$mora_pct = min(100, $porcentaje_mora);
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Dashboard | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<style>
/* ─── RESET ─── */
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }

/* ─── LAYOUT ─── */
.app { display:flex; min-height:100vh; }

/* ══════════════════════════
   SIDEBAR (idéntico a index.php)
══════════════════════════ */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px;
    background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-0.3px; }
.sb-brand .brand-sub  { font-size:0.65rem; color:#475569; text-transform:uppercase; letter-spacing:0.8px; margin-top:2px; }

.sb-user {
    padding:12px 16px; background:#1e293b;
    border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px;
    background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:0.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:0.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }

.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:0.68rem; color:#475569; margin-top:2px; }

.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section {
    font-size:0.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em;
    color:#475569; padding:12px 8px 4px;
}
.sb-nav a {
    display:flex; align-items:center; gap:9px;
    color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px;
    font-size:0.84rem; font-weight:500;
    margin-bottom:1px; transition:all 0.15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-badge {
    margin-left:auto; background:#ef4444; color:white;
    font-size:0.65rem; font-weight:700; border-radius:99px;
    padding:1px 6px; min-width:18px; text-align:center;
}
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px;
    color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px;
    font-size:0.84rem; transition:all 0.15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ══════════════════════════
   MAIN
══════════════════════════ */
.main { margin-left:240px; flex:1; padding:24px 28px 48px; }

/* ─── TOP BAR ─── */
.topbar {
    display:flex; justify-content:space-between; align-items:center;
    margin-bottom:24px; gap:12px; flex-wrap:wrap;
}
.topbar-left { display:flex; align-items:center; gap:14px; }
.back-btn {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0;
    border-radius:10px; padding:8px 14px;
    color:#64748b; text-decoration:none;
    font-size:0.82rem; font-weight:600;
    transition:all 0.15s;
    box-shadow:0 1px 4px rgba(0,0,0,0.05);
}
.back-btn:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.topbar-title { }
.topbar-title h3 { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-0.4px; }
.topbar-title p  { font-size:0.82rem; color:#64748b; margin-top:1px; }
.topbar-right { display:flex; align-items:center; gap:10px; }

.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all 0.2s;
    box-shadow:0 1px 4px rgba(0,0,0,0.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

.topbar-fecha {
    display:inline-flex; align-items:center; gap:6px;
    background:white; border:1px solid #e2e8f0;
    border-radius:10px; padding:8px 14px;
    font-size:0.82rem; color:#64748b;
    box-shadow:0 1px 4px rgba(0,0,0,0.05);
}

/* ─── ALERTA VENCIDOS ─── */
.alerta-vencidos {
    background:linear-gradient(135deg,#450a0a,#7f1d1d);
    border:1px solid #ef4444; border-radius:14px;
    padding:14px 20px; display:flex; align-items:center; gap:14px;
    margin-bottom:24px; animation:pulseAlert 2s infinite;
}
@keyframes pulseAlert {
    0%,100%{ box-shadow:0 0 0 0 rgba(239,68,68,0.2); }
    50%    { box-shadow:0 0 0 8px rgba(239,68,68,0); }
}
.alerta-vencidos .alerta-icon { font-size:1.6rem; color:#f87171; flex-shrink:0; }
.alerta-vencidos .alerta-text { flex:1; }
.alerta-vencidos .alerta-text strong { color:#fca5a5; font-size:0.9rem; display:block; }
.alerta-vencidos .alerta-text span   { color:#f87171; font-size:0.78rem; }
.alerta-vencidos .alerta-btn {
    background:#ef4444; color:white; border:none; border-radius:8px;
    padding:7px 14px; font-size:0.78rem; font-weight:600;
    text-decoration:none; white-space:nowrap;
}

/* ─── KPI GRID ─── */
.kpi-grid {
    display:grid; grid-template-columns:repeat(4,1fr);
    gap:16px; margin-bottom:24px;
}
.kpi-card {
    background:white; border:1px solid #f1f5f9;
    border-radius:16px; padding:20px;
    position:relative; overflow:hidden;
    box-shadow:0 2px 8px rgba(0,0,0,0.05);
    transition:transform 0.2s, border-color 0.2s;
}
.kpi-card:hover { transform:translateY(-2px); border-color:#e2e8f0; }
.kpi-card::before {
    content:''; position:absolute; top:0; right:0;
    width:80px; height:80px; border-radius:0 16px 0 80px; opacity:0.08;
}
.kpi-card.verde::before   { background:#10b981; }
.kpi-card.rojo::before    { background:#ef4444; }
.kpi-card.azul::before    { background:#3b82f6; }
.kpi-card.purpura::before { background:#8b5cf6; }
.kpi-icon-wrap {
    width:44px; height:44px; border-radius:12px;
    display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; margin-bottom:14px;
}
.kpi-card.verde  .kpi-icon-wrap { background:rgba(16,185,129,0.12);  color:#10b981; }
.kpi-card.rojo   .kpi-icon-wrap { background:rgba(239,68,68,0.12);   color:#ef4444; }
.kpi-card.azul   .kpi-icon-wrap { background:rgba(59,130,246,0.12);  color:#3b82f6; }
.kpi-card.purpura .kpi-icon-wrap{ background:rgba(139,92,246,0.12);  color:#8b5cf6; }
.kpi-valor { font-size:1.85rem; font-weight:800; color:#0f172a; line-height:1; letter-spacing:-1px; margin-bottom:4px; }
.kpi-label { font-size:0.78rem; color:#64748b; font-weight:500; text-transform:uppercase; letter-spacing:0.5px; }
.kpi-sub {
    font-size:0.75rem; margin-top:10px;
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 8px; border-radius:20px; font-weight:600;
}
.kpi-sub.up  { background:rgba(16,185,129,0.12); color:#059669; }
.kpi-sub.down{ background:rgba(239,68,68,0.12);  color:#dc2626; }
.kpi-sub.neu { background:#f1f5f9; color:#64748b; }

/* ─── KPI MINI ─── */
.kpi-mini-grid {
    display:grid; grid-template-columns:repeat(4,1fr);
    gap:12px; margin-bottom:24px;
}
.kpi-mini {
    background:white; border:1px solid #f1f5f9;
    border-radius:12px; padding:14px 18px;
    display:flex; align-items:center; gap:14px;
    box-shadow:0 1px 4px rgba(0,0,0,0.04);
    transition:border-color 0.2s;
}
.kpi-mini:hover { border-color:#e2e8f0; }
.kpi-mini-icon  { font-size:1.4rem; opacity:0.8; }
.kpi-mini-info .val { font-size:1.25rem; font-weight:700; color:#0f172a; line-height:1; }
.kpi-mini-info .lbl { font-size:0.72rem; color:#64748b; font-weight:500; text-transform:uppercase; letter-spacing:0.5px; margin-top:2px; }

/* ─── GRIDS ─── */
.main-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:24px; }
.main-grid.tres { grid-template-columns:2fr 1fr; }

/* ─── DASH CARD ─── */
.dash-card {
    background:white; border:1px solid #f1f5f9;
    border-radius:16px; overflow:hidden;
    box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
.dash-card-header {
    padding:16px 20px; border-bottom:1px solid #f1f5f9;
    display:flex; justify-content:space-between; align-items:center;
}
.dash-card-header h6 { font-size:0.88rem; font-weight:700; color:#0f172a; margin:0; }
.dash-card-header .badge-card {
    font-size:0.72rem; padding:3px 10px; border-radius:20px;
    background:#eff6ff; color:#2563eb; font-weight:600;
}
.dash-card-body { padding:20px; }

/* ─── GRÁFICAS ─── */
.chart-wrap { position:relative; height:220px; }

/* ─── RANKING ─── */
.ranking-item {
    display:flex; align-items:center; gap:12px;
    padding:10px 0; border-bottom:1px solid #f8fafc;
}
.ranking-item:last-child { border-bottom:none; }
.ranking-pos {
    width:26px; height:26px; border-radius:8px;
    display:flex; align-items:center; justify-content:center;
    font-size:0.8rem; font-weight:800; flex-shrink:0;
}
.ranking-pos.p1 { background:linear-gradient(135deg,#f59e0b,#d97706); color:white; }
.ranking-pos.p2 { background:linear-gradient(135deg,#94a3b8,#64748b); color:white; }
.ranking-pos.p3 { background:linear-gradient(135deg,#cd7c2f,#a36027); color:white; }
.ranking-pos.p4,.ranking-pos.p5 { background:#f1f5f9; color:#64748b; }
.ranking-info .nombre   { font-size:0.85rem; font-weight:600; color:#0f172a; }
.ranking-info .prestamos{ font-size:0.72rem; color:#94a3b8; margin-top:2px; }
.ranking-monto .val { font-size:0.9rem; font-weight:700; color:#0f172a; }
.ranking-barra-wrap {
    width:100%; height:4px; background:#f1f5f9;
    border-radius:4px; margin-top:6px; overflow:hidden;
}
.ranking-barra {
    height:100%; border-radius:4px;
    background:linear-gradient(90deg,#3b82f6,#8b5cf6);
    transition:width 0.6s;
}

/* ─── PAGOS ─── */
.pago-item {
    display:flex; align-items:center; gap:12px;
    padding:9px 0; border-bottom:1px solid #f8fafc;
}
.pago-item:last-child { border-bottom:none; }
.pago-avatar {
    width:34px; height:34px; border-radius:10px;
    background:linear-gradient(135deg,#3b82f6,#8b5cf6);
    display:flex; align-items:center; justify-content:center;
    font-size:0.72rem; font-weight:700; color:white; flex-shrink:0;
}
.pago-info .cliente { font-size:0.83rem; font-weight:600; color:#0f172a; }
.pago-info .asesor  { font-size:0.72rem; color:#94a3b8; margin-top:1px; }
.pago-monto { margin-left:auto; text-align:right; }
.pago-monto .monto { font-size:0.88rem; font-weight:700; color:#16a34a; }
.pago-monto .fecha { font-size:0.7rem; color:#94a3b8; margin-top:1px; }

/* ─── VENCIMIENTOS ─── */
.vencimiento-item {
    display:flex; align-items:center; gap:12px;
    padding:9px 0; border-bottom:1px solid #f8fafc;
}
.vencimiento-item:last-child { border-bottom:none; }
.v-dias { text-align:center; min-width:38px; flex-shrink:0; }
.v-dias .num { font-size:1.1rem; font-weight:800; line-height:1; }
.v-dias .lbl { font-size:0.65rem; color:#94a3b8; text-transform:uppercase; }
.v-info .cliente { font-size:0.83rem; font-weight:600; color:#0f172a; }
.v-info .asesor  { font-size:0.72rem; color:#94a3b8; margin-top:1px; }
.v-monto { margin-left:auto; font-size:0.85rem; font-weight:700; color:#d97706; }

/* ─── MORA GAUGE ─── */
.mora-gauge { display:flex; flex-direction:column; align-items:center; padding:8px 0 16px; }
.mora-num { font-size:3rem; font-weight:800; line-height:1; letter-spacing:-2px; color:<?= $mora_color ?>; }
.mora-num span { font-size:1.5rem; }
.mora-label { font-size:0.78rem; color:#94a3b8; margin-top:4px; text-transform:uppercase; letter-spacing:0.5px; }
.mora-barra-wrap {
    width:100%; height:10px; background:#f1f5f9;
    border-radius:10px; overflow:hidden; margin-top:16px;
}
.mora-barra {
    height:100%; border-radius:10px;
    background:<?= $mora_bar_bg ?>;
    width:<?= $mora_pct ?>%; transition:width 0.8s;
}
.mora-desglose { display:flex; justify-content:space-between; margin-top:12px; width:100%; }
.mora-desglose .item { text-align:center; }
.mora-desglose .item .v { font-size:1rem; font-weight:700; color:#0f172a; }
.mora-desglose .item .l { font-size:0.7rem; color:#94a3b8; text-transform:uppercase; margin-top:2px; }

/* ─── SUGERENCIAS ─── */
.sugerencia-card {
    background:#f8faff; border:1px solid rgba(59,130,246,0.15);
    border-radius:14px; padding:14px 18px; margin-bottom:10px;
    display:flex; align-items:flex-start; gap:14px; transition:border-color 0.2s;
}
.sugerencia-card:hover { border-color:rgba(59,130,246,0.3); }
.sug-icon  { font-size:1.3rem; margin-top:1px; flex-shrink:0; }
.sug-title { font-size:0.85rem; font-weight:700; color:#1e40af; margin-bottom:2px; }
.sug-desc  { font-size:0.78rem; color:#64748b; line-height:1.5; }

/* ─── FOOTER ─── */
.dash-footer {
    text-align:center; color:#94a3b8; font-size:0.72rem;
    padding:24px 0 8px; border-top:1px solid #e2e8f0; margin-top:16px;
}

/* ─── RESPONSIVE ─── */
@media(max-width:1024px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 40px; }
    .kpi-grid,.kpi-mini-grid { grid-template-columns:repeat(2,1fr); }
    .main-grid,.main-grid.tres { grid-template-columns:1fr; }
}
@media(max-width:540px){
    .kpi-grid,.kpi-mini-grid { grid-template-columns:1fr 1fr; }
}
@media print {
    .sidebar { display:none; }
    .main { margin-left:0; }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }

[data-theme="dark"] .topbar-title h3 { color:#e2e8f0; }
[data-theme="dark"] .topbar-title p  { color:#94a3b8; }

[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }

[data-theme="dark"] .back-btn { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .back-btn:hover { background:#1e293b; color:#e2e8f0; border-color:#334155; }

[data-theme="dark"] .topbar-fecha { background:#111827; border-color:#1e293b; color:#64748b; }

[data-theme="dark"] .kpi-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .kpi-valor { color:#f8fafc; }
[data-theme="dark"] .kpi-sub.neu { background:rgba(100,116,139,0.2); color:#94a3b8; }

[data-theme="dark"] .kpi-mini { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .kpi-mini-info .val { color:#f8fafc; }

[data-theme="dark"] .dash-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .dash-card-header { border-color:#1e293b; }
[data-theme="dark"] .dash-card-header h6 { color:#f1f5f9; }
[data-theme="dark"] .dash-card-header .badge-card { background:rgba(59,130,246,0.15); color:#93c5fd; }
[data-theme="dark"] .dash-card-body  { }

[data-theme="dark"] .ranking-item { border-color:rgba(255,255,255,0.04); }
[data-theme="dark"] .ranking-info .nombre { color:#f1f5f9; }
[data-theme="dark"] .ranking-monto .val   { color:#f1f5f9; }
[data-theme="dark"] .ranking-barra-wrap   { background:rgba(255,255,255,0.06); }
[data-theme="dark"] .ranking-pos.p4,.ranking-pos.p5 { background:rgba(255,255,255,0.06); }

[data-theme="dark"] .pago-item   { border-color:rgba(255,255,255,0.04); }
[data-theme="dark"] .pago-info .cliente { color:#f1f5f9; }
[data-theme="dark"] .pago-monto .monto  { color:#4ade80; }

[data-theme="dark"] .vencimiento-item { border-color:rgba(255,255,255,0.04); }
[data-theme="dark"] .v-info .cliente  { color:#f1f5f9; }

[data-theme="dark"] .mora-desglose .item .v { color:#f1f5f9; }
[data-theme="dark"] .mora-barra-wrap { background:rgba(255,255,255,0.06); }

[data-theme="dark"] .sugerencia-card {
    background:linear-gradient(135deg,#1e3a5f,#111827);
    border-color:rgba(59,130,246,0.2);
}
[data-theme="dark"] .sugerencia-card:hover { border-color:rgba(59,130,246,0.4); }
[data-theme="dark"] .sug-title { color:#bfdbfe; }
[data-theme="dark"] .sug-desc  { color:#64748b; }

[data-theme="dark"] .dash-footer { color:#334155; border-color:rgba(255,255,255,0.04); }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">

    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>

    <nav class="sb-nav">

        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php" class="active"><i class="bi bi-speedometer2"></i> Dashboard</a>

        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-cash-coin"></i> Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger">
            <i class="bi bi-calendar-check"></i> Cobro Diario
            <?php if ($total_vencidos > 0): ?>
            <span class="sb-badge"><?= $total_vencidos ?></span>
            <?php endif; ?>
        </a>

        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>

        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>

    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>

</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOP BAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="back-btn">
                <i class="bi bi-arrow-left"></i> Inicio
            </a>
            <div class="topbar-title">
                <h3>Dashboard Ejecutivo</h3>
                <p>Resumen general del sistema — <?= date('d \d\e F Y') ?></p>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
            <div class="topbar-fecha">
                <i class="bi bi-calendar3" style="margin-right:4px;"></i>
                <?= $meses_nombres[(int)$mes_actual - 1] ?> <?= $anio_actual ?>
            </div>
            <button onclick="window.print()" style="width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 4px rgba(0,0,0,0.06);" title="Imprimir">
                <i class="bi bi-printer"></i>
            </button>
        </div>
    </div>

    <!-- ALERTA VENCIDOS -->
    <?php if ($total_vencidos > 0): ?>
    <div class="alerta-vencidos">
        <i class="bi bi-exclamation-triangle-fill alerta-icon"></i>
        <div class="alerta-text">
            <strong><?= $total_vencidos ?> préstamo<?= $total_vencidos > 1 ? 's' : '' ?> vencido<?= $total_vencidos > 1 ? 's' : '' ?></strong>
            <span>Requieren atención inmediata para evitar deterioro de cartera</span>
        </div>
        <a href="prestamos.php?estado=VENCIDO" class="alerta-btn">
            <i class="bi bi-arrow-right-circle" style="margin-right:4px;"></i> Ver Vencidos
        </a>
    </div>
    <?php endif; ?>

    <!-- KPI CARDS PRINCIPALES -->
    <div class="kpi-grid">

        <div class="kpi-card verde">
            <div class="kpi-icon-wrap"><i class="bi bi-graph-up-arrow"></i></div>
            <div class="kpi-valor">$<?= number_format($cartera_activa, 2) ?></div>
            <div class="kpi-label">Cartera Activa</div>
            <div class="kpi-sub neu"><i class="bi bi-circle-fill" style="font-size:6px;"></i> <?= $total_prestamos_activos ?> préstamos</div>
        </div>

        <div class="kpi-card rojo">
            <div class="kpi-icon-wrap"><i class="bi bi-exclamation-circle"></i></div>
            <div class="kpi-valor">$<?= number_format($cartera_vencida, 2) ?></div>
            <div class="kpi-label">Cartera Vencida</div>
            <div class="kpi-sub <?= $total_vencidos > 0 ? 'down' : 'up' ?>">
                <i class="bi bi-<?= $total_vencidos > 0 ? 'arrow-up' : 'check' ?>"></i>
                <?= $total_vencidos ?> vencidos
            </div>
        </div>

        <div class="kpi-card azul">
            <div class="kpi-icon-wrap"><i class="bi bi-cash-stack"></i></div>
            <div class="kpi-valor">$<?= number_format($cobrado_mes, 2) ?></div>
            <div class="kpi-label">Cobrado este mes</div>
            <div class="kpi-sub <?= $variacion_cobro >= 0 ? 'up' : 'down' ?>">
                <i class="bi bi-arrow-<?= $variacion_cobro >= 0 ? 'up' : 'down' ?>"></i>
                <?= number_format(abs($variacion_cobro), 1) ?>% vs mes ant.
            </div>
        </div>

        <div class="kpi-card purpura">
            <div class="kpi-icon-wrap"><i class="bi bi-piggy-bank"></i></div>
            <div class="kpi-valor">$<?= number_format($utilidad_estimada, 2) ?></div>
            <div class="kpi-label">Utilidad estimada</div>
            <div class="kpi-sub neu"><i class="bi bi-info-circle" style="font-size:9px;"></i> 20% del cobro</div>
        </div>

    </div>

    <!-- KPI MINI -->
    <div class="kpi-mini-grid">

        <div class="kpi-mini">
            <div class="kpi-mini-icon">💰</div>
            <div class="kpi-mini-info">
                <div class="val">$<?= number_format($cobrado_hoy, 0) ?></div>
                <div class="lbl">Cobrado hoy (<?= $cobros_hoy_count ?> pagos)</div>
            </div>
        </div>

        <div class="kpi-mini">
            <div class="kpi-mini-icon">🆕</div>
            <div class="kpi-mini-info">
                <div class="val"><?= $nuevos_hoy ?> / <?= $nuevos_semana ?></div>
                <div class="lbl">Nuevos hoy / semana</div>
            </div>
        </div>

        <div class="kpi-mini">
            <div class="kpi-mini-icon">👥</div>
            <div class="kpi-mini-info">
                <div class="val"><?= number_format($total_clientes) ?></div>
                <div class="lbl">Clientes totales (<?= $clientes_nuevos_mes ?> este mes)</div>
            </div>
        </div>

        <div class="kpi-mini">
            <div class="kpi-mini-icon">🔄</div>
            <div class="kpi-mini-info">
                <div class="val"><?= $prestamos_por_renovar ?></div>
                <div class="lbl">Listos para renovar</div>
            </div>
        </div>

    </div>

    <!-- GRÁFICAS PRINCIPALES: COBROS + MORA -->
    <div class="main-grid tres">

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-bar-chart-fill" style="color:#3b82f6;margin-right:8px;"></i>Cobros por mes — <?= $anio_actual ?></h6>
                <span class="badge-card">Anual</span>
            </div>
            <div class="dash-card-body">
                <div class="chart-wrap">
                    <canvas id="graficaCobros"></canvas>
                </div>
            </div>
        </div>

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-speedometer" style="color:#f59e0b;margin-right:8px;"></i>Índice de Morosidad</h6>
            </div>
            <div class="dash-card-body">
                <div class="mora-gauge">
                    <div class="mora-num"><?= number_format($porcentaje_mora, 1) ?><span>%</span></div>
                    <div class="mora-label">Tasa de mora actual</div>
                    <div class="mora-barra-wrap" style="margin-top:20px;">
                        <div class="mora-barra"></div>
                    </div>
                    <div style="margin-top:10px;font-size:0.78rem;font-weight:600;color:<?= $semaforo[1] ?>;">
                        <?= $semaforo[0] ?> — Meta: &lt; 5%
                    </div>
                </div>
                <div class="mora-desglose">
                    <div class="item">
                        <div class="v" style="color:#10b981;">$<?= number_format($cartera_activa,2) ?></div>
                        <div class="l">Activa</div>
                    </div>
                    <div class="item">
                        <div class="v" style="color:#ef4444;">$<?= number_format($cartera_vencida,2) ?></div>
                        <div class="l">Vencida</div>
                    </div>
                    <div class="item">
                        <div class="v">$<?= number_format($cartera_total,2) ?></div>
                        <div class="l">Total</div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- GRÁFICA LÍNEA NUEVOS + DONA -->
    <div class="main-grid">

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-file-earmark-plus" style="color:#10b981;margin-right:8px;"></i>Préstamos otorgados — <?= $anio_actual ?></h6>
                <span class="badge-card">Anual</span>
            </div>
            <div class="dash-card-body">
                <div class="chart-wrap">
                    <canvas id="graficaNuevos"></canvas>
                </div>
            </div>
        </div>

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-pie-chart-fill" style="color:#8b5cf6;margin-right:8px;"></i>Distribución de Cartera</h6>
            </div>
            <div class="dash-card-body">
                <div class="chart-wrap" style="height:190px;">
                    <canvas id="graficaDona"></canvas>
                </div>
            </div>
        </div>

    </div>

    <!-- RANKING + ÚLTIMOS PAGOS -->
    <div class="main-grid">

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-trophy-fill" style="color:#f59e0b;margin-right:8px;"></i>Top Asesores — <?= $meses_nombres[(int)$mes_actual-1] ?></h6>
                <span class="badge-card">Este mes</span>
            </div>
            <div class="dash-card-body">
                <?php if (empty($ranking)): ?>
                <p style="color:#94a3b8;font-size:0.85rem;text-align:center;padding:20px 0;">Sin datos este mes</p>
                <?php else: ?>
                <?php foreach ($ranking as $i => $r):
                    $pos_clase = ['p1','p2','p3','p4','p5'][$i] ?? 'p5';
                    $pct_barra  = ($max_cobro > 0) ? ($r['total_cobrado'] / $max_cobro) * 100 : 0;
                ?>
                <div class="ranking-item">
                    <div class="ranking-pos <?= $pos_clase ?>"><?= $i+1 ?></div>
                    <div class="ranking-info" style="flex:1;">
                        <div class="nombre"><?= htmlspecialchars($r['nombre'].' '.$r['apellido']) ?></div>
                        <div class="prestamos"><?= $r['prestamos_activos'] ?> préstamos activos</div>
                        <div class="ranking-barra-wrap">
                            <div class="ranking-barra" style="width:<?= $pct_barra ?>%;"></div>
                        </div>
                    </div>
                    <div class="ranking-monto">
                        <div class="val">$<?= number_format($r['total_cobrado'],2) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-clock-history" style="color:#06b6d4;margin-right:8px;"></i>Últimos Pagos Registrados</h6>
            </div>
            <div class="dash-card-body">
                <?php
                $pagos_arr = [];
                while ($p = $resUltimos->fetch_assoc()) $pagos_arr[] = $p;
                if (empty($pagos_arr)): ?>
                <p style="color:#94a3b8;font-size:0.85rem;text-align:center;padding:20px 0;">Sin pagos registrados</p>
                <?php else: ?>
                <?php foreach ($pagos_arr as $p):
                    $ini = strtoupper(substr($p['cn'],0,1) . substr($p['ca'],0,1));
                ?>
                <div class="pago-item">
                    <div class="pago-avatar"><?= $ini ?></div>
                    <div class="pago-info">
                        <div class="cliente"><?= htmlspecialchars($p['cn'].' '.$p['ca']) ?></div>
                        <div class="asesor">Asesor: <?= htmlspecialchars($p['en'].' '.$p['ea']) ?></div>
                    </div>
                    <div class="pago-monto">
                        <div class="monto">+$<?= number_format($p['monto_pagado'],2) ?></div>
                        <div class="fecha"><?= date('d/m/Y', strtotime($p['fecha_pago'])) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- VENCIMIENTOS SEMANA + SUGERENCIAS -->
    <div class="main-grid">

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-calendar-event" style="color:#ef4444;margin-right:8px;"></i>Vencimientos próximos 7 días</h6>
                <span class="badge-card" style="background:rgba(239,68,68,0.1);color:#dc2626;">
                    <?= count($vencen_semana) ?> préstamos
                </span>
            </div>
            <div class="dash-card-body">
                <?php if (empty($vencen_semana)): ?>
                <p style="color:#94a3b8;font-size:0.85rem;text-align:center;padding:20px 0;">
                    <i class="bi bi-check-circle-fill" style="color:#10b981;font-size:1.4rem;display:block;margin-bottom:8px;"></i>
                    No hay vencimientos próximos
                </p>
                <?php else: ?>
                <?php foreach ($vencen_semana as $v):
                    $dias_diff  = (int)ceil((strtotime($v['fecha_fin']) - strtotime($hoy)) / 86400);
                    $color_dias = ($dias_diff <= 1) ? '#ef4444' : (($dias_diff <= 3) ? '#d97706' : '#94a3b8');
                ?>
                <div class="vencimiento-item">
                    <div class="v-dias">
                        <div class="num" style="color:<?= $color_dias ?>;"><?= $dias_diff ?></div>
                        <div class="lbl">días</div>
                    </div>
                    <div class="v-info">
                        <div class="cliente"><?= htmlspecialchars($v['nombre'].' '.$v['apellido']) ?></div>
                        <div class="asesor"><?= htmlspecialchars($v['asesor']) ?> — <?= date('d/m/Y',strtotime($v['fecha_fin'])) ?></div>
                    </div>
                    <div class="v-monto">$<?= number_format($v['total_pagar'],0) ?></div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-lightbulb-fill" style="color:#f59e0b;margin-right:8px;"></i>Sugerencias y Acciones</h6>
            </div>
            <div class="dash-card-body">

                <?php if ($porcentaje_mora > 5): ?>
                <div class="sugerencia-card" style="background:linear-gradient(135deg,#fff1f2,#fef2f2);border-color:rgba(239,68,68,0.2);">
                    <div class="sug-icon">🚨</div>
                    <div>
                        <div class="sug-title" style="color:#b91c1c;">Mora elevada (<?= number_format($porcentaje_mora,1) ?>%)</div>
                        <div class="sug-desc">Se recomienda iniciar proceso de cobranza preventiva en préstamos con más de 15 días sin pago. Meta interna: &lt; 5%.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($prestamos_por_renovar > 0): ?>
                <div class="sugerencia-card">
                    <div class="sug-icon">🔄</div>
                    <div>
                        <div class="sug-title">Renovaciones disponibles</div>
                        <div class="sug-desc"><?= $prestamos_por_renovar ?> cliente<?= $prestamos_por_renovar > 1 ? 's han' : ' ha' ?> completado 20+ abonos. Es buen momento para ofrecer renovación y aumentar cartera.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($variacion_cobro < -10): ?>
                <div class="sugerencia-card" style="background:#fffbeb;border-color:rgba(245,158,11,0.2);">
                    <div class="sug-icon">📉</div>
                    <div>
                        <div class="sug-title" style="color:#92400e;">Cobro por debajo del mes anterior</div>
                        <div class="sug-desc">El cobro bajó <?= number_format(abs($variacion_cobro),1) ?>% vs el mes pasado. Revisar la ruta de cobranza y asignar metas individuales a asesores.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($nuevos_semana == 0): ?>
                <div class="sugerencia-card" style="background:#fffbeb;border-color:rgba(245,158,11,0.15);">
                    <div class="sug-icon">📢</div>
                    <div>
                        <div class="sug-title" style="color:#92400e;">Sin nuevos préstamos esta semana</div>
                        <div class="sug-desc">No se han registrado nuevos créditos en los últimos 7 días. Considera activar campañas de captación o referidos de clientes activos.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (count($vencen_semana) > 3): ?>
                <div class="sugerencia-card" style="background:#fff1f2;border-color:rgba(239,68,68,0.15);">
                    <div class="sug-icon">⏰</div>
                    <div>
                        <div class="sug-title" style="color:#b91c1c;">Varios vencimientos esta semana</div>
                        <div class="sug-desc"><?= count($vencen_semana) ?> préstamos vencen en 7 días. Asegurar que los asesores contacten a sus clientes para coordinar el pago o renovación.</div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="sugerencia-card">
                    <div class="sug-icon">📊</div>
                    <div>
                        <div class="sug-title">Ver programación completa</div>
                        <div class="sug-desc">Accede al calendario de vencimientos para planificar la cobranza del mes.</div>
                    </div>
                </div>

                <a href="programacion_prestamo.php"
                   style="display:block;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:white;border-radius:10px;padding:10px 16px;text-align:center;text-decoration:none;font-size:0.83rem;font-weight:600;margin-top:12px;">
                    <i class="bi bi-calendar3-range" style="margin-right:6px;"></i> Ver Programación de Préstamos
                </a>

            </div>
        </div>

    </div>

        <div class="dash-card">
            <div class="dash-card-header">
                <h6><i class="bi bi-lightbulb-fill" style="color:#f59e0b;margin-right:8px;"></i>Sugerencias y Acciones</h6>
            </div>
            <div class="dash-card-body">

                <?php if ($porcentaje_mora > 5): ?>
                <div class="sugerencia-card" style="background:linear-gradient(135deg,#fff1f2,#fef2f2);border-color:rgba(239,68,68,0.2);">
                    <div class="sug-icon">🚨</div>
                    <div>
                        <div class="sug-title" style="color:#b91c1c;">Mora elevada (<?= number_format($porcentaje_mora,1) ?>%)</div>
                        <div class="sug-desc">Se recomienda iniciar proceso de cobranza preventiva en préstamos con más de 15 días sin pago. Meta interna: &lt; 5%.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($prestamos_por_renovar > 0): ?>
                <div class="sugerencia-card">
                    <div class="sug-icon">🔄</div>
                    <div>
                        <div class="sug-title">Renovaciones disponibles</div>
                        <div class="sug-desc"><?= $prestamos_por_renovar ?> cliente<?= $prestamos_por_renovar > 1 ? 's han' : ' ha' ?> completado 20+ abonos. Es buen momento para ofrecer renovación y aumentar cartera.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($variacion_cobro < -10): ?>
                <div class="sugerencia-card" style="background:#fffbeb;border-color:rgba(245,158,11,0.2);">
                    <div class="sug-icon">📉</div>
                    <div>
                        <div class="sug-title" style="color:#92400e;">Cobro por debajo del mes anterior</div>
                        <div class="sug-desc">El cobro bajó <?= number_format(abs($variacion_cobro),1) ?>% vs el mes pasado. Revisar la ruta de cobranza y asignar metas individuales a asesores.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($nuevos_semana == 0): ?>
                <div class="sugerencia-card" style="background:#fffbeb;border-color:rgba(245,158,11,0.15);">
                    <div class="sug-icon">📢</div>
                    <div>
                        <div class="sug-title" style="color:#92400e;">Sin nuevos préstamos esta semana</div>
                        <div class="sug-desc">No se han registrado nuevos créditos en los últimos 7 días. Considera activar campañas de captación o referidos de clientes activos.</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (count($vencen_semana) > 3): ?>
                <div class="sugerencia-card" style="background:#fff1f2;border-color:rgba(239,68,68,0.15);">
                    <div class="sug-icon">⏰</div>
                    <div>
                        <div class="sug-title" style="color:#b91c1c;">Varios vencimientos esta semana</div>
                        <div class="sug-desc"><?= count($vencen_semana) ?> préstamos vencen en 7 días. Asegurar que los asesores contacten a sus clientes para coordinar el pago o renovación.</div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="sugerencia-card">
                    <div class="sug-icon">📊</div>
                    <div>
                        <div class="sug-title">Ver programación completa</div>
                        <div class="sug-desc">Accede al calendario de vencimientos para planificar la cobranza del mes.</div>
                    </div>
                </div>

                <a href="programacion_prestamo.php"
                   style="display:block;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:white;border-radius:10px;padding:10px 16px;text-align:center;text-decoration:none;font-size:0.83rem;font-weight:600;margin-top:12px;">
                    <i class="bi bi-calendar3-range" style="margin-right:6px;"></i> Ver Programación de Préstamos
                </a>

            </div>
        </div>

    </div>

    <div class="dash-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Actualizado el <?= date('d/m/Y \a \l\a\s H:i') ?>
    </div>

</main>
</div>

<!-- ═══════════ CHART.JS ═══════════ -->
<script>
// ── TEMA CLARO / OSCURO ──
const THEME_KEY = 'pje_tema';

function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
    updateChartColors(t);
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}

// ── RELOJ ──
function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

// ── CHARTS ──
function gridColor(t)  { return t === 'dark' ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.05)'; }
function tickColor(t)  { return t === 'dark' ? '#475569' : '#94a3b8'; }
function donaBorder(t) { return t === 'dark' ? '#111827' : '#ffffff'; }

const gradBlue = (ctx) => {
    const g = ctx.chart.ctx.createLinearGradient(0,0,0,220);
    g.addColorStop(0,'rgba(59,130,246,0.6)');
    g.addColorStop(1,'rgba(59,130,246,0.05)');
    return g;
};
const gradGreen = (ctx) => {
    const g = ctx.chart.ctx.createLinearGradient(0,0,0,220);
    g.addColorStop(0,'rgba(16,185,129,0.6)');
    g.addColorStop(1,'rgba(16,185,129,0.05)');
    return g;
};

const chartCobros = new Chart(document.getElementById('graficaCobros'), {
    type:'bar',
    data:{
        labels: <?= json_encode($graf_labels) ?>,
        datasets:[{
            label:'Cobros',
            data: <?= json_encode($graf_data) ?>,
            backgroundColor:(ctx) => gradBlue(ctx),
            borderColor:'#3b82f6', borderWidth:2,
            borderRadius:8, borderSkipped:false,
        }]
    },
    options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{
            legend:{display:false},
            tooltip:{ callbacks:{ label:(c)=>' $'+c.raw.toLocaleString('es-MX',{minimumFractionDigits:2}) } }
        },
        scales:{
            x:{ grid:{color:gridColor('light')}, ticks:{color:tickColor('light')} },
            y:{ grid:{color:gridColor('light')}, ticks:{color:tickColor('light'), callback:(v)=>'$'+v.toLocaleString('es-MX')} }
        }
    }
});

const chartNuevos = new Chart(document.getElementById('graficaNuevos'), {
    type:'line',
    data:{
        labels: <?= json_encode($graf_labels) ?>,
        datasets:[{
            label:'Nuevos',
            data: <?= json_encode($graf_nuevos) ?>,
            fill:true,
            backgroundColor:(ctx)=>gradGreen(ctx),
            borderColor:'#10b981', borderWidth:2.5, tension:0.4,
            pointBackgroundColor:'#10b981', pointRadius:4, pointHoverRadius:7,
        }]
    },
    options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{
            legend:{display:false},
            tooltip:{ callbacks:{ label:(c)=>' '+c.raw+' préstamos' } }
        },
        scales:{
            x:{ grid:{color:gridColor('light')}, ticks:{color:tickColor('light')} },
            y:{ grid:{color:gridColor('light')}, ticks:{color:tickColor('light'), stepSize:1} }
        }
    }
});

const chartDona = new Chart(document.getElementById('graficaDona'), {
    type:'doughnut',
    data:{
        labels:['Cartera Activa','Cartera Vencida'],
        datasets:[{
            data: <?= json_encode($dona_data) ?>,
            backgroundColor:['#10b981','#ef4444'],
            borderColor:'#ffffff', borderWidth:3, hoverOffset:8,
        }]
    },
    options:{
        responsive:true, maintainAspectRatio:false, cutout:'68%',
        plugins:{
            legend:{
                display:true, position:'bottom',
                labels:{ color:'#94a3b8', padding:14, usePointStyle:true, font:{size:11} }
            },
            tooltip:{ callbacks:{ label:(c)=>' $'+c.raw.toLocaleString('es-MX',{minimumFractionDigits:2}) } }
        }
    }
});

function updateChartColors(t) {
    const gc = gridColor(t);
    const tc = tickColor(t);
    const db = donaBorder(t);

    [chartCobros, chartNuevos].forEach(chart => {
        chart.options.scales.x.grid.color  = gc;
        chart.options.scales.y.grid.color  = gc;
        chart.options.scales.x.ticks.color = tc;
        chart.options.scales.y.ticks.color = tc;
        chart.update('none');
    });

    chartDona.data.datasets[0].borderColor = db;
    chartDona.options.plugins.legend.labels.color = tc;
    chartDona.update('none');
}

// Aplicar tema guardado al cargar
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();
</script>
</body>
</html>
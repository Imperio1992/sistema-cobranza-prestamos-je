<?php
include("seguridad.php");
include("conexion.php");
include("validar_cliente.php");

date_default_timezone_set('America/Hermosillo');

/* ════════════════════════════
   FUNCIONES DE CAJA
════════════════════════════ */
function totalCaja($c, $id, $medio = null) {
    $f   = $medio ? "AND medio='$medio'" : "";
    $res = $c->query("
        SELECT IFNULL(SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END),0) t
        FROM caja WHERE id_empleado=$id $f
    ");
    return $res->fetch_assoc()['t'];
}

/* ════════════════════════════
   DATOS DE SESIÓN
════════════════════════════ */
$rol    = $_SESSION['rol']         ?? 'ASESOR';
$user   = $_SESSION['usuario']     ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);

/* ════════════════════════════
   EMPLEADOS (SOLO GERENTE)
════════════════════════════ */
$empleados_array = [];
if ($rol === 'GERENTE') {
    $empleados = $conexion->query("
        SELECT id_empleado, nombre, apellido
        FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre
    ");
    while ($e = $empleados->fetch_assoc()) {
        $e['efectivo'] = totalCaja($conexion, $e['id_empleado'], 'EFECTIVO');
        $e['banco']    = totalCaja($conexion, $e['id_empleado'], 'BANCO');
        $empleados_array[] = $e;
    }
}

/* ════════════════════════════
   CLIENTES AGRUPADOS POR ASESOR (GERENTE)
   Para ASESOR: solo sus propios clientes
════════════════════════════ */
$clientes_array      = [];   // todos los clientes (para ASESOR o fallback)
$clientes_por_asesor = [];   // ['id_emp' => [clientes...]] para GERENTE

if ($rol === 'ASESOR') {
    /* El asesor ve SOLO sus clientes propios (id_asesor directo en tabla clientes) */
    $q = $conexion->query("
        SELECT id_cliente, nombre, apellido
        FROM clientes
        WHERE id_asesor = $id_emp AND estatus = 'ACTIVO'
        ORDER BY nombre, apellido
    ");
    while ($c = $q->fetch_assoc()) $clientes_array[] = $c;
} else {
    /* GERENTE: agrupa clientes por su id_asesor directo (columna en tabla clientes)
       Incluye también clientes SIN asesor asignado (NULL) como fallback */
    $q = $conexion->query("
        SELECT c.id_cliente, c.nombre, c.apellido, c.id_asesor
        FROM clientes c
        WHERE c.estatus = 'ACTIVO'
        ORDER BY c.nombre, c.apellido
    ");
    while ($r = $q->fetch_assoc()) {
        $id_as = (int)$r['id_asesor'];
        if ($id_as > 0) {
            $clientes_por_asesor[$id_as][] = [
                'id_cliente' => (int)$r['id_cliente'],
                'nombre'     => $r['nombre'],
                'apellido'   => $r['apellido'],
            ];
        }
        $clientes_array[] = [
            'id_cliente' => (int)$r['id_cliente'],
            'nombre'     => $r['nombre'],
            'apellido'   => $r['apellido'],
        ];
    }
}

/* ════════════════════════════
   PROCESAR POST
════════════════════════════ */
$alerta = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cliente'])) {
    $id_cliente   = intval($_POST['cliente']);
    $id_empleado  = ($rol === 'GERENTE') ? intval($_POST['empleado']) : $id_emp;
    $monto_orig   = floatval($_POST['monto']);
    $desc_efec    = floatval($_POST['descEfectivo']);
    $desc_banco   = floatval($_POST['descBanco']);
    $tipo         = $_POST['tipoPrestamo'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $plazo_sem    = intval($_POST['plazoSemanas'] ?? 0);

    $s_efec = totalCaja($conexion, $id_empleado, 'EFECTIVO');
    $s_banc = totalCaja($conexion, $id_empleado, 'BANCO');

    if ($desc_efec > $s_efec || $desc_banco > $s_banc) {
        $alerta = 'error|El asesor no tiene saldo suficiente en caja.';
    } elseif ($id_cliente <= 0 || $id_empleado <= 0) {
        $alerta = 'error|Debes seleccionar un cliente y un asesor válidos.';
    } else {
        $monto = puedePrestar($id_cliente, $monto_orig);
        if ($tipo === 'DIARIO') {
            $interes      = $monto * 0.20;
            $p_diario     = ($monto + $interes) / 20;
            $plazo_sem    = 0;
        } else {
            $pct          = ($plazo_sem == 4) ? 0.20 : (($plazo_sem == 6) ? 0.30 : 0.40);
            $interes      = $monto * $pct;
            $p_diario     = 0;
        }
        $total = $monto + $interes;

        $r = $conexion->query("SELECT MAX(numero_credito_asesor) as u FROM prestamos WHERE id_empleado=$id_empleado")->fetch_assoc();
        $nuevo_num = ($r['u'] >= 99) ? 1 : ($r['u'] + 1);

        $stmt = $conexion->prepare("
            INSERT INTO prestamos
                (id_cliente, id_empleado, numero_credito_asesor,
                 monto_prestado, interes, total_pagar, pago_diario,
                 fecha_inicio, estado)
            VALUES (?,?,?,?,?,?,?,?,'ACTIVO')
        ");
        $stmt->bind_param("iiidddds", $id_cliente, $id_empleado, $nuevo_num,
                          $monto, $interes, $total, $p_diario, $fecha_inicio);

        if ($stmt->execute()) {
            $num_fmt  = str_pad($nuevo_num, 2, '0', STR_PAD_LEFT);
            $concepto = "PRESTAMO #$num_fmt";

            if ($desc_efec > 0) {
                $stmtC = $conexion->prepare("INSERT INTO caja (tipo, concepto, medio, monto, id_empleado) VALUES ('SALIDA', ?, 'EFECTIVO', ?, ?)");
                $stmtC->bind_param("sdi", $concepto, $desc_efec, $id_empleado);
                $stmtC->execute();
            }
            if ($desc_banco > 0) {
                $stmtC = $conexion->prepare("INSERT INTO caja (tipo, concepto, medio, monto, id_empleado) VALUES ('SALIDA', ?, 'BANCO', ?, ?)");
                $stmtC->bind_param("sdi", $concepto, $desc_banco, $id_empleado);
                $stmtC->execute();
            }
            $alerta = 'ok|Préstamo #' . $num_fmt . ' registrado correctamente.';
        } else {
            $alerta = 'error|Error al guardar el préstamo. Intenta de nuevo.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Nuevo Préstamo — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --bg-base:    #f0f4f8;
    --bg-card:    #ffffff;
    --bg-card2:   #f8fafc;
    --bg-input:   #f8fafc;
    --border:     #e2e8f0;
    --text-main:  #0f172a;
    --text-sub:   #64748b;
    --text-muted: #94a3b8;
    --shadow:     0 2px 12px rgba(0,0,0,.07);
    --shadow-lg:  0 8px 28px rgba(0,0,0,.11);
}
[data-theme="dark"] {
    --bg-base:    #0a0f1e;
    --bg-card:    #111827;
    --bg-card2:   #1a2235;
    --bg-input:   #1e293b;
    --border:     #2d3748;
    --text-main:  #e2e8f0;
    --text-sub:   #94a3b8;
    --text-muted: #64748b;
    --shadow:     0 2px 12px rgba(0,0,0,.3);
    --shadow-lg:  0 8px 28px rgba(0,0,0,.4);
}

*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { font-family:'Inter',sans-serif; background:var(--bg-base); color:var(--text-main); min-height:100vh; transition:background .3s,color .3s; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 24px rgba(0,0,0,.25);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.63rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:11px 16px; background:rgba(255,255,255,.03); border-bottom:1px solid #1e293b; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.63rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px; }
.sb-section { font-size:.6rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; flex-shrink:0; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger { color:#f87171; }
.sb-nav a.danger:hover { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:28px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.page-icon { width:50px; height:50px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:14px; display:flex; align-items:center; justify-content:center; font-size:1.5rem; box-shadow:0 4px 14px rgba(37,99,235,.35); flex-shrink:0; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:var(--text-main); letter-spacing:-.3px; }
.topbar-left p  { font-size:.82rem; color:var(--text-sub); margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.btn-icon { width:38px; height:38px; border-radius:10px; border:1.5px solid var(--border); background:var(--bg-card); color:var(--text-sub); cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; text-decoration:none; }
.btn-icon:hover { color:var(--text-main); border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta-ok    { background:#f0fdf4; border:1.5px solid #86efac; color:#166534; border-radius:12px; padding:14px 18px; font-size:.88rem; font-weight:600; margin-bottom:22px; display:flex; align-items:center; gap:10px; }
.alerta-error { background:#fef2f2; border:1.5px solid #fca5a5; color:#991b1b; border-radius:12px; padding:14px 18px; font-size:.88rem; font-weight:600; margin-bottom:22px; display:flex; align-items:center; gap:10px; }

/* ── LAYOUT FORM ── */
.form-grid { display:grid; grid-template-columns:1fr 300px; gap:24px; align-items:start; }

/* ── CARD ── */
.card { background:var(--bg-card); border-radius:16px; box-shadow:var(--shadow); margin-bottom:18px; border:1px solid var(--border); transition:background .25s, border-color .25s; }
.card-header { padding:16px 22px; display:flex; align-items:center; gap:10px; border-bottom:1px solid var(--border); }
.card-header i  { font-size:1.1rem; color:#2563eb; }
.card-header h2 { font-size:.95rem; font-weight:700; color:var(--text-main); }
.card-header .step-badge {
    margin-left:auto; background:#2563eb; color:#fff;
    font-size:.65rem; font-weight:800; border-radius:99px;
    padding:2px 9px; letter-spacing:.06em; text-transform:uppercase;
}
.card-body { padding:20px 22px; }

/* ── PASO VISUAL ── */
.paso-header {
    display:flex; align-items:center; gap:12px; margin-bottom:16px;
}
.paso-num {
    width:30px; height:30px; border-radius:50%;
    background:#2563eb; color:#fff;
    display:flex; align-items:center; justify-content:center;
    font-size:.8rem; font-weight:800; flex-shrink:0;
}
.paso-num.done { background:#16a34a; }
.paso-num.locked { background:#94a3b8; }
.paso-titulo { font-size:.9rem; font-weight:700; color:var(--text-main); }
.paso-sub    { font-size:.75rem; color:var(--text-sub); margin-top:1px; }

/* ── FORM ELEMENTS ── */
.form-row   { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:16px; }
.form-row:last-child { margin-bottom:0; }
.form-group { display:flex; flex-direction:column; gap:6px; }
.form-group label { font-size:.75rem; font-weight:700; color:var(--text-sub); text-transform:uppercase; letter-spacing:.04em; display:flex; align-items:center; gap:5px; }
.form-group select,
.form-group input[type="text"],
.form-group input[type="number"],
.form-group input[type="date"] {
    border:1.5px solid var(--border); border-radius:10px;
    padding:10px 14px; font-size:.9rem; color:var(--text-main);
    background:var(--bg-input); outline:none; font-family:'Inter',sans-serif;
    transition:border-color .2s, box-shadow .2s; appearance:none; width:100%;
}
.form-group select:focus,
.form-group input:focus { border-color:#2563eb; background:var(--bg-card); box-shadow:0 0 0 3px rgba(37,99,235,.1); }
.form-group input[readonly] { background:var(--bg-card2); color:var(--text-muted); cursor:not-allowed; }

/* Cliente bloqueado */
.cliente-bloqueado {
    padding:12px 14px; background:var(--bg-card2); border:1.5px dashed var(--border);
    border-radius:10px; font-size:.85rem; color:var(--text-muted);
    display:flex; align-items:center; gap:8px;
}

/* Saldo asesor */
.saldo-box { display:none; background:var(--bg-card2); border:1px solid var(--border); border-radius:10px; padding:14px 16px; margin-top:12px; }
.saldo-box-titulo { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--text-sub); margin-bottom:10px; display:flex; align-items:center; gap:6px; }
.saldo-box-grid  { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.saldo-item small  { display:block; font-size:.7rem; color:var(--text-muted); margin-bottom:3px; }
.saldo-item strong { font-size:1rem; font-weight:800; color:var(--text-main); }

/* Tipo de cobro */
.tipo-selector { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px; }
.tipo-btn {
    border:2px solid var(--border); border-radius:12px; padding:14px 16px;
    cursor:pointer; transition:all .2s; text-align:center; background:var(--bg-card2);
    font-size:.88rem; font-weight:600; color:var(--text-sub);
}
.tipo-btn .tipo-icon { display:block; font-size:1.5rem; margin-bottom:4px; }
.tipo-btn small { display:block; font-size:.7rem; font-weight:400; margin-top:2px; color:var(--text-muted); }
.tipo-btn.activo { border-color:#2563eb; background:#eff6ff; color:#1d4ed8; }
[data-theme="dark"] .tipo-btn.activo { background:#1e3a6e; color:#93c5fd; }

/* Descuentos */
.desc-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.desc-card { background:var(--bg-card2); border:1.5px solid var(--border); border-radius:12px; padding:16px; }
.desc-card.efectivo { border-color:#bbf7d0; }
.desc-card.banco    { border-color:#bfdbfe; }
.desc-card label { display:block; font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#16a34a; margin-bottom:8px; }
.desc-card.banco label { color:#2563eb; }
[data-theme="dark"] .desc-card.efectivo label { color:#4ade80; }
[data-theme="dark"] .desc-card.banco    label { color:#60a5fa; }
.desc-card input { width:100%; border:1.5px solid var(--border); border-radius:9px; padding:9px 12px; font-size:.9rem; background:var(--bg-card); color:var(--text-main); outline:none; transition:border-color .2s; font-family:inherit; }
.desc-card input:focus { border-color:#2563eb; }
.desc-card input[readonly] { background:var(--bg-card2); color:var(--text-muted); cursor:not-allowed; }
.desc-total { text-align:right; margin-top:12px; font-size:.83rem; color:var(--text-sub); }
.desc-total strong { color:var(--text-main); font-size:.95rem; font-weight:700; }

/* Botón registrar */
.btn-registrar { width:100%; background:linear-gradient(135deg,#2563eb,#1d4ed8); color:#fff; border:none; border-radius:12px; padding:15px; font-size:1rem; font-weight:700; cursor:pointer; transition:all .2s; box-shadow:0 4px 16px rgba(37,99,235,.35); display:flex; align-items:center; justify-content:center; gap:8px; font-family:inherit; margin-top:6px; }
.btn-registrar:hover { background:linear-gradient(135deg,#1d4ed8,#1e40af); transform:translateY(-1px); box-shadow:0 6px 20px rgba(37,99,235,.4); }

/* Resumen derecha */
.resumen-card { background:linear-gradient(160deg,#1e293b 0%,#0f172a 100%); border-radius:16px; padding:22px 20px; color:#fff; box-shadow:0 4px 24px rgba(0,0,0,.25); position:sticky; top:24px; border:1px solid #334155; }
.resumen-header { display:flex; align-items:center; gap:8px; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid #334155; }
.resumen-header i  { font-size:1.1rem; color:#60a5fa; }
.resumen-header h3 { font-size:.88rem; font-weight:700; color:#e2e8f0; }
.resumen-item { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid rgba(255,255,255,.06); font-size:.86rem; }
.resumen-item:last-of-type { border-bottom:none; }
.resumen-item .lbl { color:#94a3b8; }
.resumen-item .val { font-weight:700; font-size:.95rem; color:#fff; }
.resumen-item .val.verde   { color:#4ade80; }
.resumen-item .val.azul    { color:#60a5fa; }
.resumen-item .val.naranja { color:#fb923c; }
.resumen-item .val.morado  { color:#c4b5fd; }
.resumen-total { background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:12px; padding:18px; text-align:center; margin-top:16px; box-shadow:0 4px 14px rgba(37,99,235,.3); }
.resumen-total small { display:block; font-size:.72rem; color:rgba(255,255,255,.7); margin-bottom:5px; text-transform:uppercase; letter-spacing:.06em; }
.resumen-total .monto-total { font-size:2rem; font-weight:800; color:#fff; line-height:1; }
.resumen-cuota { background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.1); border-radius:12px; padding:14px; text-align:center; margin-top:12px; }
.resumen-cuota small { font-size:.72rem; color:#94a3b8; display:block; margin-bottom:5px; text-transform:uppercase; letter-spacing:.06em; }
.resumen-cuota .cuota-val { font-size:1.5rem; font-weight:800; color:#4ade80; }
.resumen-vacio { text-align:center; padding:28px 0; color:#475569; font-size:.85rem; }
.resumen-vacio i { font-size:2.2rem; display:block; margin-bottom:10px; color:#334155; }
.resumen-tipo-badge { display:inline-flex; align-items:center; gap:5px; background:rgba(37,99,235,.2); border:1px solid rgba(37,99,235,.3); border-radius:99px; padding:3px 10px; font-size:.72rem; font-weight:700; color:#93c5fd; text-transform:uppercase; letter-spacing:.06em; margin-top:12px; }

/* Error msg */
.error-msg { display:none; font-size:.78rem; color:#dc2626; padding:6px 10px; background:#fff1f2; border-radius:8px; margin-top:4px; }

/* Divider */
.divider { border:none; border-top:1px solid var(--border); margin:16px 0; }

/* Fade */
.fade { opacity:0; transform:translateY(14px); animation:fadeUp .4s forwards; }
@keyframes fadeUp { to { opacity:1; transform:translateY(0); } }

/* Responsive */
@media(max-width:1000px){ .form-grid { grid-template-columns:1fr; } }
@media(max-width:900px) { .sidebar { display:none; } .main { margin-left:0; padding:16px 14px 48px; } }
@media(max-width:580px) { .form-row { grid-template-columns:1fr; } .desc-grid { grid-template-columns:1fr; } .tipo-selector { grid-template-columns:1fr; } }
</style>
</head>
<body>
<div class="app">

<!-- ══ SIDEBAR ══ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php" class="active"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══ MAIN ══ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar fade">
        <div class="topbar-left">
            <a href="index.php" class="btn-icon" title="Regresar"><i class="bi bi-arrow-left"></i></a>
            <div class="page-icon"><i class="bi bi-file-earmark-plus" style="color:white;font-size:1.4rem;"></i></div>
            <div>
                <h1>Nuevo Préstamo</h1>
                <p>Registra un nuevo crédito — <?= date('d/m/Y') ?></p>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ALERTAS -->
    <?php if ($alerta): ?>
    <?php [$tipo_alert, $msg_alert] = explode('|', $alerta, 2); ?>
    <div class="alerta-<?= $tipo_alert ?> fade">
        <i class="bi bi-<?= $tipo_alert === 'ok' ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
        <?= htmlspecialchars($msg_alert) ?>
    </div>
    <?php endif; ?>

    <!-- GRID FORM + RESUMEN -->
    <div class="form-grid">
    <form method="POST" onsubmit="return validarAntesEnviar()">

        <?php if ($rol === 'GERENTE'): ?>
        <!-- ══ PASO 1: ASESOR ══ -->
        <div class="card fade" style="animation-delay:.06s">
            <div class="card-header">
                <i class="bi bi-person-badge-fill"></i>
                <h2>Seleccionar Asesor</h2>
                <span class="step-badge">Paso 1</span>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label><i class="bi bi-person-workspace"></i> Asesor responsable</label>
                    <select name="empleado" id="empleadoSelect" required onchange="onAsesorChange()">
                        <option value="">— Selecciona un asesor —</option>
                        <?php foreach ($empleados_array as $e): ?>
                        <option value="<?= $e['id_empleado'] ?>">
                            <?= htmlspecialchars($e['nombre'] . ' ' . $e['apellido']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Saldo del asesor -->
                <div class="saldo-box" id="saldoCaja">
                    <div class="saldo-box-titulo">
                        <i class="bi bi-wallet2"></i> Saldo disponible del asesor
                    </div>
                    <div class="saldo-box-grid">
                        <div class="saldo-item">
                            <small><i class="bi bi-cash"></i> Efectivo</small>
                            <strong id="saldoEfectivo">$0.00</strong>
                        </div>
                        <div class="saldo-item">
                            <small><i class="bi bi-bank"></i> Banco</small>
                            <strong id="saldoBanco">$0.00</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ══ PASO 2: CLIENTE (filtrado por asesor) ══ -->
        <div class="card fade" style="animation-delay:.10s">
            <div class="card-header">
                <i class="bi bi-person-circle"></i>
                <h2>Seleccionar Cliente</h2>
                <span class="step-badge">Paso 2</span>
            </div>
            <div class="card-body">
                <div id="clienteBloqueado" class="cliente-bloqueado">
                    <i class="bi bi-lock-fill" style="color:#94a3b8;"></i>
                    Selecciona primero un asesor para ver sus clientes
                </div>
                <div class="form-group" id="clienteGrupo" style="display:none;">
                    <label><i class="bi bi-people-fill"></i> Cliente del asesor</label>
                    <select name="cliente" id="clienteSelect" required>
                        <option value="">— Selecciona un cliente —</option>
                    </select>
                    <div id="errorCliente" class="error-msg">
                        <i class="bi bi-exclamation-triangle"></i> Selecciona un cliente válido.
                    </div>
                </div>
            </div>
        </div>

        <?php else: ?>
        <!-- ══ ASESOR LOGUEADO: clientes directos ══ -->
        <input type="hidden" name="empleado" value="<?= $id_emp ?>">
        <div class="card fade" style="animation-delay:.06s">
            <div class="card-header">
                <i class="bi bi-person-circle"></i>
                <h2>Seleccionar Cliente</h2>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label><i class="bi bi-people-fill"></i> Tus clientes</label>
                    <select name="cliente" id="clienteSelect" required>
                        <option value="">— Selecciona un cliente —</option>
                        <?php foreach ($clientes_array as $c): ?>
                        <option value="<?= $c['id_cliente'] ?>">
                            <?= htmlspecialchars($c['nombre'] . ' ' . $c['apellido']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="errorCliente" class="error-msg">
                        <i class="bi bi-exclamation-triangle"></i> Selecciona un cliente válido.
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- ══ DATOS DEL PRÉSTAMO ══ -->
        <div class="card fade" style="animation-delay:.14s">
            <div class="card-header">
                <i class="bi bi-cash-coin"></i>
                <h2>Datos del Préstamo</h2>
                <?php if ($rol === 'GERENTE'): ?><span class="step-badge">Paso 3</span><?php endif; ?>
            </div>
            <div class="card-body">

                <!-- Monto y Fecha -->
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="bi bi-currency-dollar"></i> Monto a prestar</label>
                        <input type="text" name="monto" id="montoPrestamo"
                               placeholder="0.00" required
                               oninput="calcularTodo()"
                               onblur="this.value=formatoMoneda(limpiarMoneda(this.value))">
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-calendar3"></i> Fecha del préstamo</label>
                        <input type="date" name="fecha_inicio" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>

                <hr class="divider">

                <!-- Tipo de cobro -->
                <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--text-sub);margin-bottom:10px;">
                    <i class="bi bi-toggles"></i> Tipo de cobro
                </div>
                <div class="tipo-selector">
                    <div class="tipo-btn activo" id="tipoBtnDiario" onclick="seleccionarTipo('DIARIO')">
                        <span class="tipo-icon">📆</span>
                        Diario
                        <small>20 días / 20% interés</small>
                    </div>
                    <div class="tipo-btn" id="tipoBtnSemanal" onclick="seleccionarTipo('SEMANAL')">
                        <span class="tipo-icon">📅</span>
                        Semanal
                        <small>4, 6 u 8 semanas</small>
                    </div>
                </div>
                <input type="hidden" name="tipoPrestamo" id="tipoPrestamo" value="DIARIO">

                <div id="plazoSemanalDiv" style="display:none;margin-top:12px;">
                    <div class="form-group">
                        <label><i class="bi bi-list-ol"></i> Plazo semanal</label>
                        <select name="plazoSemanas" id="plazoSemanas" onchange="calcularTodo()">
                            <option value="4">4 semanas — 20% interés</option>
                            <option value="6">6 semanas — 30% interés</option>
                            <option value="8">8 semanas — 40% interés</option>
                        </select>
                    </div>
                </div>

            </div>
        </div>

        <!-- ══ DESCUENTOS DE CAJA ══ -->
        <div class="card fade" style="animation-delay:.18s">
            <div class="card-header">
                <i class="bi bi-safe"></i>
                <h2>Descontar de Caja</h2>
            </div>
            <div class="card-body">
                <p style="font-size:.82rem;color:var(--text-sub);margin-bottom:16px;line-height:1.6;">
                    <i class="bi bi-info-circle" style="margin-right:4px;"></i>
                    Indica cuánto se descuenta de efectivo y cuánto de banco para este préstamo.
                </p>
                <div class="desc-grid">
                    <div class="desc-card efectivo">
                        <label><i class="bi bi-cash"></i> Efectivo</label>
                        <input type="text" id="descEfectivo" name="descEfectivo"
                               placeholder="$0.00"
                               oninput="calcularDescuento()"
                               onblur="this.value=formatoMoneda(limpiarMoneda(this.value))">
                    </div>
                    <div class="desc-card banco">
                        <label><i class="bi bi-bank"></i> Banco</label>
                        <input type="text" id="descBanco" name="descBanco" placeholder="$0.00" readonly>
                    </div>
                </div>
                <div class="desc-total">
                    Total descontado: <strong id="totalDescuento">$0.00</strong>
                </div>
            </div>
        </div>

        <!-- BOTÓN REGISTRAR -->
        <button type="submit" class="btn-registrar fade" style="animation-delay:.22s">
            <i class="bi bi-check2-circle"></i> Registrar Préstamo
        </button>

    </form>

    <!-- ══ RESUMEN ══ -->
    <div>
        <div class="resumen-card fade" style="animation-delay:.1s">
            <div class="resumen-header">
                <i class="bi bi-bar-chart-line-fill"></i>
                <h3>Resumen del Préstamo</h3>
            </div>
            <div id="resumenVacio" class="resumen-vacio">
                <i class="bi bi-calculator"></i>
                Ingresa el monto para<br>ver el cálculo aquí
            </div>
            <div id="resumenContenido" style="display:none;">
                <div class="resumen-item">
                    <span class="lbl">Monto prestado</span>
                    <span class="val azul" id="r-monto">$0.00</span>
                </div>
                <div class="resumen-item">
                    <span class="lbl">Tasa de interés</span>
                    <span class="val morado" id="r-tasa">20%</span>
                </div>
                <div class="resumen-item">
                    <span class="lbl">Interés</span>
                    <span class="val naranja" id="r-interes">$0.00</span>
                </div>
                <div class="resumen-item">
                    <span class="lbl">Plazo</span>
                    <span class="val" id="r-plazo">—</span>
                </div>
                <div class="resumen-total">
                    <small>Total a pagar</small>
                    <div class="monto-total" id="r-total">$0.00</div>
                </div>
                <div class="resumen-cuota" id="r-cuota-box">
                    <small id="r-cuota-lbl">Pago diario</small>
                    <div class="cuota-val" id="r-cuota">$0.00</div>
                </div>
                <div style="text-align:center;">
                    <span class="resumen-tipo-badge" id="r-tipo-badge">
                        <i class="bi bi-calendar-day"></i> DIARIO
                    </span>
                </div>
            </div>
        </div>
    </div>

    </div><!-- /form-grid -->

</main>
</div>

<script>
/* ─── TEMA ─── */
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    const ic = document.getElementById('themeIcon');
    if (ic) ic.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ─── RELOJ ─── */
function actualizarReloj() {
    const n = new Date(), p = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ─── DATOS PHP → JS ─── */
const empleados          = <?= json_encode($empleados_array) ?>;
const clientesPorAsesor  = <?= json_encode($clientes_por_asesor) ?>;
const clientesAsesor     = <?= json_encode($clientes_array) ?>; // para rol ASESOR

/* ─── FORMATO MONEDA ─── */
function formatoMoneda(n) {
    n = parseFloat(n) || 0;
    return '$' + n.toLocaleString('en-US', { minimumFractionDigits:2, maximumFractionDigits:2 });
}
function limpiarMoneda(v) { return v.toString().replace(/[$,]/g, ''); }

/* ─── CAMBIO DE ASESOR (solo GERENTE) ─── */
function onAsesorChange() {
    const sel   = document.getElementById('empleadoSelect');
    const idStr = String(sel?.value || '');
    const idNum = parseInt(idStr) || 0;

    const bloqueado  = document.getElementById('clienteBloqueado');
    const grupoSel   = document.getElementById('clienteGrupo');
    const clienteSel = document.getElementById('clienteSelect');
    const cajaBox    = document.getElementById('saldoCaja');

    /* Sin asesor seleccionado → estado inicial */
    if (!idNum) {
        if (cajaBox)   cajaBox.style.display   = 'none';
        if (bloqueado) bloqueado.style.display = 'flex';
        if (grupoSel)  grupoSel.style.display  = 'none';
        return;
    }

    /* ── Saldo del asesor ──
       Comparamos como String para evitar problemas de tipo int/string en JSON */
    const emp = empleados.find(e => String(e.id_empleado) === idStr);
    if (emp && cajaBox) {
        document.getElementById('saldoEfectivo').textContent = formatoMoneda(emp.efectivo);
        document.getElementById('saldoBanco').textContent    = formatoMoneda(emp.banco);
        cajaBox.style.display = 'block';
    } else if (cajaBox) {
        cajaBox.style.display = 'none';
    }

    /* ── Poblar select de clientes ──
       clientesPorAsesor keys son números enteros (json_encode de PHP int-key array)
       Probamos tanto idNum como idStr para cubrir ambos casos */
    const lista = clientesPorAsesor[idNum] || clientesPorAsesor[idStr] || [];

    clienteSel.innerHTML = '<option value="">— Selecciona un cliente —</option>';
    if (lista.length === 0) {
        const opt = document.createElement('option');
        opt.disabled = true;
        opt.textContent = '(Este asesor no tiene clientes registrados)';
        clienteSel.appendChild(opt);
    } else {
        lista.forEach(c => {
            const opt = document.createElement('option');
            opt.value       = c.id_cliente;
            opt.textContent = c.nombre + ' ' + c.apellido;
            clienteSel.appendChild(opt);
        });
    }

    if (bloqueado) bloqueado.style.display = 'none';
    if (grupoSel)  grupoSel.style.display  = 'block';

    /* Actualizar etiqueta con conteo */
    const lbl = document.querySelector('#clienteGrupo label');
    if (lbl) {
        lbl.innerHTML = '<i class="bi bi-people-fill"></i> Clientes del asesor'
            + ' <span style="color:#64748b;font-weight:400;margin-left:6px;">('
            + lista.length + ')</span>';
    }
}

/* ─── TIPO DE COBRO ─── */
function seleccionarTipo(tipo) {
    document.getElementById('tipoPrestamo').value = tipo;
    document.getElementById('tipoBtnDiario').classList.toggle('activo',  tipo === 'DIARIO');
    document.getElementById('tipoBtnSemanal').classList.toggle('activo', tipo === 'SEMANAL');
    document.getElementById('plazoSemanalDiv').style.display = tipo === 'SEMANAL' ? 'block' : 'none';
    calcularTodo();
}

/* ─── CALCULAR RESUMEN ─── */
function calcularTodo() {
    const monto = parseFloat(limpiarMoneda(document.getElementById('montoPrestamo').value)) || 0;
    const tipo  = document.getElementById('tipoPrestamo').value;
    const plazo = parseInt(document.getElementById('plazoSemanas')?.value || 4);

    if (monto <= 0) {
        document.getElementById('resumenVacio').style.display     = 'block';
        document.getElementById('resumenContenido').style.display = 'none';
        return;
    }

    let interes, total, cuota, plazoTxt, cuotaLbl, tasaPct, tipoBadge;
    if (tipo === 'DIARIO') {
        tasaPct   = 20; interes = monto * 0.20; total = monto + interes;
        cuota     = total / 20; plazoTxt = '20 días hábiles'; cuotaLbl = 'Pago diario';
        tipoBadge = '<i class="bi bi-calendar-day"></i> DIARIO';
    } else {
        const pct = plazo === 4 ? 0.20 : (plazo === 6 ? 0.30 : 0.40);
        tasaPct   = pct * 100; interes = monto * pct; total = monto + interes;
        cuota     = total / plazo; plazoTxt = plazo + ' semanas'; cuotaLbl = 'Pago semanal';
        tipoBadge = '<i class="bi bi-calendar-week"></i> SEMANAL';
    }

    document.getElementById('r-monto').textContent     = formatoMoneda(monto);
    document.getElementById('r-tasa').textContent      = tasaPct + '%';
    document.getElementById('r-interes').textContent   = formatoMoneda(interes);
    document.getElementById('r-plazo').textContent     = plazoTxt;
    document.getElementById('r-total').textContent     = formatoMoneda(total);
    document.getElementById('r-cuota').textContent     = formatoMoneda(cuota);
    document.getElementById('r-cuota-lbl').textContent = cuotaLbl;
    document.getElementById('r-tipo-badge').innerHTML  = tipoBadge;
    document.getElementById('resumenVacio').style.display     = 'none';
    document.getElementById('resumenContenido').style.display = 'block';
    calcularDescuento();
}

/* ─── DESCUENTOS ─── */
function calcularDescuento() {
    const monto    = parseFloat(limpiarMoneda(document.getElementById('montoPrestamo').value)) || 0;
    let descEfec   = parseFloat(limpiarMoneda(document.getElementById('descEfectivo').value)) || 0;
    if (descEfec > monto) {
        descEfec = monto;
        document.getElementById('descEfectivo').value = formatoMoneda(monto);
    }
    document.getElementById('descBanco').value          = formatoMoneda(monto - descEfec);
    document.getElementById('totalDescuento').textContent = formatoMoneda(monto);
}

/* ─── VALIDAR ANTES DE ENVIAR ─── */
function validarAntesEnviar() {
    const clienteSel = document.getElementById('clienteSelect');
    const errorDiv   = document.getElementById('errorCliente');
    if (!clienteSel || !clienteSel.value) {
        if (errorDiv) errorDiv.style.display = 'block';
        if (clienteSel) clienteSel.focus();
        return false;
    }
    if (errorDiv) errorDiv.style.display = 'none';
    document.getElementById('montoPrestamo').value = limpiarMoneda(document.getElementById('montoPrestamo').value);
    document.getElementById('descEfectivo').value  = limpiarMoneda(document.getElementById('descEfectivo').value);
    document.getElementById('descBanco').value     = limpiarMoneda(document.getElementById('descBanco').value);
    return true;
}
</script>
</body>
</html>

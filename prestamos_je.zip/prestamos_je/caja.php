<?php
include("seguridad.php");
include("conexion.php");

$rol      = $_SESSION['rol']         ?? 'ASESOR';
$user     = $_SESSION['usuario']     ?? 'Usuario';
$id_ses   = intval($_SESSION['id_empleado'] ?? 0);
$hoy      = date('Y-m-d');
$msg      = '';
$msg_tipo = 'ok';

// ══════════════════════════════════════════════════
// CREAR / REPARAR TABLAS (seguro, no borra datos)
// ══════════════════════════════════════════════════
$conexion->query("CREATE TABLE IF NOT EXISTS caja_entrega (
    id_entrega     INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado    INT NOT NULL DEFAULT 0,
    fecha          DATE NOT NULL DEFAULT '2000-01-01',
    efectivo_nuevo DECIMAL(10,2) NOT NULL DEFAULT 0,
    banca_nueva    DECIMAL(10,2) NOT NULL DEFAULT 0,
    creado_en      DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conexion->query("ALTER TABLE caja_entrega ADD COLUMN IF NOT EXISTS id_empleado    INT NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_entrega ADD COLUMN IF NOT EXISTS fecha          DATE NOT NULL DEFAULT '2000-01-01'");
$conexion->query("ALTER TABLE caja_entrega ADD COLUMN IF NOT EXISTS efectivo_nuevo DECIMAL(10,2) NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_entrega ADD COLUMN IF NOT EXISTS banca_nueva    DECIMAL(10,2) NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_entrega ADD COLUMN IF NOT EXISTS creado_en      DATETIME DEFAULT CURRENT_TIMESTAMP");
$verificar = $conexion->query("SHOW INDEX FROM caja_entrega WHERE Key_name = 'unico_dia'");
if ($verificar->num_rows == 0) {
    $conexion->query("ALTER TABLE caja_entrega ADD UNIQUE KEY unico_dia (id_empleado, fecha)");
}

$conexion->query("CREATE TABLE IF NOT EXISTS caja_gastos (
    id_gasto    INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado INT NOT NULL DEFAULT 0,
    fecha       DATE NOT NULL DEFAULT '2000-01-01',
    tipo_gasto  ENUM('GASOLINA','TIEMPO_AIRE','REPARACION_MOTO',
                     'ACCESORIO_MOTO','SERVICIO_MOTO','CONSUMO_GENERAL') NOT NULL DEFAULT 'CONSUMO_GENERAL',
    monto       DECIMAL(10,2) NOT NULL DEFAULT 0,
    descripcion VARCHAR(200) DEFAULT NULL,
    creado_en   DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conexion->query("ALTER TABLE caja_gastos ADD COLUMN IF NOT EXISTS id_empleado INT NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_gastos ADD COLUMN IF NOT EXISTS fecha       DATE NOT NULL DEFAULT '2000-01-01'");
$conexion->query("ALTER TABLE caja_gastos ADD COLUMN IF NOT EXISTS monto       DECIMAL(10,2) NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_gastos ADD COLUMN IF NOT EXISTS descripcion VARCHAR(200) DEFAULT NULL");
$conexion->query("ALTER TABLE caja_gastos ADD COLUMN IF NOT EXISTS creado_en   DATETIME DEFAULT CURRENT_TIMESTAMP");

$conexion->query("CREATE TABLE IF NOT EXISTS caja_corte (
    id_corte         INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado      INT NOT NULL DEFAULT 0,
    fecha            DATE NOT NULL DEFAULT '2000-01-01',
    cobrado          DECIMAL(10,2) DEFAULT 0,
    efectivo_llevado DECIMAL(10,2) DEFAULT 0,
    banca_llevada    DECIMAL(10,2) DEFAULT 0,
    prestamos_dia    DECIMAL(10,2) DEFAULT 0,
    banca_actual     DECIMAL(10,2) DEFAULT 0,
    total_gastos     DECIMAL(10,2) DEFAULT 0,
    resultado        DECIMAL(10,2) DEFAULT 0,
    notas            TEXT DEFAULT NULL,
    creado_en        DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS id_empleado      INT NOT NULL DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS fecha            DATE NOT NULL DEFAULT '2000-01-01'");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS cobrado          DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS efectivo_llevado DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS banca_llevada    DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS prestamos_dia    DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS banca_actual     DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS total_gastos     DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS resultado        DECIMAL(10,2) DEFAULT 0");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS notas            TEXT DEFAULT NULL");
$conexion->query("ALTER TABLE caja_corte ADD COLUMN IF NOT EXISTS creado_en        DATETIME DEFAULT CURRENT_TIMESTAMP");
$verificar2 = $conexion->query("SHOW INDEX FROM caja_corte WHERE Key_name = 'unico_corte'");
if ($verificar2->num_rows == 0) {
    $conexion->query("ALTER TABLE caja_corte ADD UNIQUE KEY unico_corte (id_empleado, fecha)");
}

// ══════════════════════════════════════════════════
// EMPLEADOS + ASESOR ACTIVO
// ══════════════════════════════════════════════════
$empleados = [];
$r = $conexion->query("SELECT id_empleado, nombre FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
while ($e = $r->fetch_assoc()) $empleados[] = $e;

if ($rol === 'GERENTE') {
    $id_emp = intval($_GET['id_empleado'] ?? $_POST['id_empleado'] ?? ($empleados[0]['id_empleado'] ?? 0));
} else {
    $id_emp = $id_ses;
}

// ══════════════════════════════════════════════════
// SALDOS DE TODOS LOS ASESORES (para el selector)
// ══════════════════════════════════════════════════
$saldos_asesores = [];
if ($rol === 'GERENTE') {
    foreach ($empleados as $e) {
        $eid_q = $e['id_empleado'];
        $sq = $conexion->query("
            SELECT
                SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) AS saldo_total,
                SUM(CASE WHEN tipo='ENTRADA' AND medio='EFECTIVO' THEN monto WHEN tipo='SALIDA' AND medio='EFECTIVO' THEN -monto ELSE 0 END) AS efectivo,
                SUM(CASE WHEN tipo='ENTRADA' AND medio='BANCO'    THEN monto WHEN tipo='SALIDA' AND medio='BANCO'    THEN -monto ELSE 0 END) AS banco,
                SUM(CASE WHEN tipo_movimiento='COBRO' AND DATE(fecha)=CURDATE() THEN monto ELSE 0 END) AS cobrado_hoy
            FROM caja WHERE id_empleado=$eid_q
        ")->fetch_assoc();
        $saldos_asesores[$eid_q] = [
            'nombre'      => $e['nombre'],
            'saldo_total' => floatval($sq['saldo_total'] ?? 0),
            'efectivo'    => floatval($sq['efectivo']    ?? 0),
            'banco'       => floatval($sq['banco']       ?? 0),
            'cobrado_hoy' => floatval($sq['cobrado_hoy'] ?? 0),
        ];
    }
}

// ══════════════════════════════════════════════════
// ACCIONES POST
// ══════════════════════════════════════════════════
if (isset($_POST['accion']) && $_POST['accion'] === 'apertura') {
    $eid   = intval($_POST['id_empleado']);
    $ef    = floatval($_POST['efectivo_nuevo']);
    $bn    = floatval($_POST['banca_nueva']);
    $fecha = $_POST['fecha'] ?? $hoy;
    $stmt = $conexion->prepare("
        INSERT INTO caja_entrega (id_empleado, fecha, efectivo_nuevo, banca_nueva)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE efectivo_nuevo=VALUES(efectivo_nuevo), banca_nueva=VALUES(banca_nueva)
    ");
    $stmt->bind_param("isdd", $eid, $fecha, $ef, $bn);
    $msg = $stmt->execute() ? "Apertura guardada correctamente." : "Error: " . $conexion->error;
    if (!$msg) $msg_tipo = 'error';
}

if (isset($_POST['accion']) && $_POST['accion'] === 'gasto') {
    $eid   = intval($_POST['id_empleado']);
    $tipo  = $_POST['tipo_gasto'];
    $monto = floatval($_POST['monto_gasto']);
    $desc  = $conexion->real_escape_string($_POST['descripcion'] ?? '');
    $fecha = $_POST['fecha'] ?? $hoy;
    $stmt = $conexion->prepare("
        INSERT INTO caja_gastos (id_empleado, fecha, tipo_gasto, monto, descripcion)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("issds", $eid, $fecha, $tipo, $monto, $desc);
    if ($stmt->execute()) {
        $msg = "Gasto registrado correctamente.";
    } else {
        $msg = "Error: " . $conexion->error;
        $msg_tipo = 'error';
    }
}

if (isset($_GET['del_gasto'])) {
    $idg = intval($_GET['del_gasto']);
    $conexion->query("DELETE FROM caja_gastos WHERE id_gasto=$idg");
    $msg = "Gasto eliminado.";
}

if (isset($_POST['accion']) && $_POST['accion'] === 'corte') {
    $eid     = intval($_POST['id_empleado']);
    $cobrado = floatval($_POST['cobrado']);
    $ef_lv   = floatval($_POST['efectivo_llevado']);
    $bn_lv   = floatval($_POST['banca_llevada']);
    $prest   = floatval($_POST['prestamos_dia']);
    $bn_act  = floatval($_POST['banca_actual']);
    $gastos  = floatval($_POST['total_gastos']);
    $notas   = $conexion->real_escape_string($_POST['notas'] ?? '');
    $fecha   = $_POST['fecha'] ?? $hoy;
    $resultado = $cobrado + $ef_lv + $bn_lv - $prest - $bn_act - $gastos;
    $stmt = $conexion->prepare("
        INSERT INTO caja_corte
          (id_empleado, fecha, cobrado, efectivo_llevado, banca_llevada,
           prestamos_dia, banca_actual, total_gastos, resultado, notas)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          cobrado=VALUES(cobrado), efectivo_llevado=VALUES(efectivo_llevado),
          banca_llevada=VALUES(banca_llevada), prestamos_dia=VALUES(prestamos_dia),
          banca_actual=VALUES(banca_actual), total_gastos=VALUES(total_gastos),
          resultado=VALUES(resultado), notas=VALUES(notas)
    ");
    $stmt->bind_param("isddddddds", $eid, $fecha, $cobrado, $ef_lv, $bn_lv, $prest, $bn_act, $gastos, $resultado, $notas);
    if ($stmt->execute()) {
        $msg = "Corte guardado correctamente.";
    } else {
        $msg = "Error: " . $conexion->error;
        $msg_tipo = 'error';
    }
}

// ══════════════════════════════════════════════════
// LEER DATOS DEL DÍA
// ══════════════════════════════════════════════════
$fecha_vista    = $_GET['fecha'] ?? $hoy;
$fecha_safe     = $conexion->real_escape_string($fecha_vista);
$fecha_ant      = date('Y-m-d', strtotime($fecha_vista . ' -1 day'));
$fecha_ant_safe = $conexion->real_escape_string($fecha_ant);

$apertura  = $conexion->query("SELECT * FROM caja_entrega WHERE id_empleado=$id_emp AND fecha='$fecha_safe'")->fetch_assoc();
$corte_ant = $conexion->query("SELECT * FROM caja_corte WHERE id_empleado=$id_emp AND fecha='$fecha_ant_safe'")->fetch_assoc();

$ef_anterior = 0;
$ap_ant = $conexion->query("SELECT efectivo_nuevo FROM caja_entrega WHERE id_empleado=$id_emp AND fecha='$fecha_ant_safe'")->fetch_assoc();
if ($ap_ant) {
    $ef_anterior = $corte_ant ? max(0, (float)$corte_ant['resultado']) : (float)$ap_ant['efectivo_nuevo'];
}

$banca_actual_db = (float)($conexion->query("
    SELECT banca_nueva FROM caja_entrega
    WHERE id_empleado=$id_emp AND fecha<='$fecha_safe'
    ORDER BY fecha DESC LIMIT 1
")->fetch_assoc()['banca_nueva'] ?? 0);

$cobrado_hoy = (float)$conexion->query("
    SELECT COALESCE(SUM(p.monto_pagado),0) AS total
    FROM pagos p INNER JOIN prestamos pr ON pr.id_prestamo = p.id_prestamo
    WHERE pr.id_empleado = $id_emp AND DATE(p.fecha_pago) = '$fecha_safe'
")->fetch_assoc()['total'];

$prestamos_hoy = (float)$conexion->query("
    SELECT COALESCE(SUM(monto),0) AS total FROM caja
    WHERE id_empleado=$id_emp AND tipo='SALIDA'
    AND tipo_movimiento='PRESTAMO' AND DATE(fecha)='$fecha_safe'
")->fetch_assoc()['total'];

$gastos_hoy = [];
$r_g = $conexion->query("SELECT * FROM caja_gastos WHERE id_empleado=$id_emp AND fecha='$fecha_safe' ORDER BY creado_en ASC");
while ($g = $r_g->fetch_assoc()) $gastos_hoy[] = $g;
$total_gastos = array_sum(array_column($gastos_hoy, 'monto'));

$corte_hoy = $conexion->query("SELECT * FROM caja_corte WHERE id_empleado=$id_emp AND fecha='$fecha_safe'")->fetch_assoc();

$nombre_emp = '';
foreach ($empleados as $e) {
    if ($e['id_empleado'] == $id_emp) { $nombre_emp = $e['nombre']; break; }
}

$etiquetas_gasto = [
    'GASOLINA'        => ['Gasolina',             'bi-fuel-pump',         '#f59e0b'],
    'TIEMPO_AIRE'     => ['Tiempo Aire / Celular', 'bi-phone',             '#06b6d4'],
    'REPARACION_MOTO' => ['Reparación de Moto',   'bi-tools',             '#ef4444'],
    'ACCESORIO_MOTO'  => ['Accesorio de Moto',    'bi-gear',              '#8b5cf6'],
    'SERVICIO_MOTO'   => ['Servicio de Moto',     'bi-wrench-adjustable', '#10b981'],
    'CONSUMO_GENERAL' => ['Consumo General',      'bi-bag',               '#64748b'],
];
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Caja Diaria | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
/* ─── RESET ─── */
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }

/* ─── LAYOUT ─── */
.app { display:flex; min-height:100vh; }

/* ══════════════════════════
   SIDEBAR
══════════════════════════ */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px;
    background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-0.3px; }
.sb-brand .brand-sub  { font-size:0.65rem; color:#475569; text-transform:uppercase; letter-spacing:0.8px; margin-top:2px; }
.sb-user {
    padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px;
    background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:0.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:0.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:0.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:0.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:0.84rem; font-weight:500;
    margin-bottom:1px; transition:all 0.15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-nav a.verde { color:#86efac; }
.sb-nav a.verde:hover { background:#1e293b; color:#4ade80; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:0.84rem; transition:all 0.15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ══════════════════════════
   MAIN
══════════════════════════ */
.main { margin-left:240px; padding:24px 28px 60px; min-height:100vh; }

/* ─── TOPBAR ─── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-logo { height:50px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,.1); object-fit:cover; }
.topbar-title { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:1px; display:flex; align-items:center; gap:6px; }
.topbar-sub a { color:#64748b; text-decoration:none; }
.topbar-sub a:hover { color:#2563eb; }
.topbar-right { display:flex; align-items:center; gap:10px; }

.back-btn {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0;
    border-radius:10px; padding:8px 14px;
    color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,0.05);
}
.back-btn:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }

.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all 0.2s;
    box-shadow:0 1px 4px rgba(0,0,0,0.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ─── FLASH ─── */
.flash { border-radius:12px; padding:12px 18px; margin-bottom:20px; font-size:.85rem; font-weight:600; display:flex; align-items:center; gap:8px; }
.flash.ok    { background:#f0fdf4; border:1px solid #bbf7d0; color:#15803d; }
.flash.error { background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; }

/* ─── SALDO PANEL ASESOR ─── */
.saldo-asesor-panel {
    display:none; background:white; border-radius:14px;
    border:2px solid #2563eb; margin-bottom:18px;
    box-shadow:0 4px 16px rgba(37,99,235,.1); overflow:hidden;
    animation:fadeIn .2s ease;
}
@keyframes fadeIn { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
.sap-header {
    background:linear-gradient(135deg,#1e3a5f,#1d4ed8);
    padding:12px 18px; display:flex; align-items:center; gap:10px;
}
.sap-header .sap-avatar {
    width:34px; height:34px; background:rgba(255,255,255,.15);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.9rem; font-weight:800; color:white; flex-shrink:0;
}
.sap-header .sap-nombre { font-size:.92rem; font-weight:800; color:white; }
.sap-header .sap-sub    { font-size:.7rem; color:#93c5fd; margin-top:1px; }
.sap-header .sap-link   {
    margin-left:auto; display:inline-flex; align-items:center; gap:5px;
    background:rgba(255,255,255,.15); color:white; padding:5px 12px;
    border-radius:8px; font-size:.75rem; font-weight:700; text-decoration:none;
    transition:background .15s;
}
.sap-header .sap-link:hover { background:rgba(255,255,255,.3); }
.sap-body { display:grid; grid-template-columns:repeat(4,1fr); gap:0; }
.sap-stat {
    padding:14px 16px; text-align:center;
    border-right:1px solid #f1f5f9;
}
.sap-stat:last-child { border-right:none; }
.sap-stat .ss-label { font-size:.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; }
.sap-stat .ss-val   { font-size:1.1rem; font-weight:800; color:#0f172a; margin-top:4px; }
.sap-stat.positivo .ss-val { color:#16a34a; }
.sap-stat.negativo .ss-val { color:#dc2626; }
.sap-stat.azul .ss-val  { color:#2563eb; }
.sap-stat.verde .ss-val { color:#16a34a; }
[data-theme="dark"] .saldo-asesor-panel { background:#1e293b; border-color:#2563eb; }
[data-theme="dark"] .sap-body          { background:#1e293b; }
[data-theme="dark"] .sap-stat          { border-color:#334155; }
[data-theme="dark"] .sap-stat .ss-val  { color:#e2e8f0; }

/* ─── QUICK ACCESS STRIP ─── */
.quick-strip {
    display:flex; gap:10px; margin-bottom:22px; flex-wrap:wrap;
}
.qs-btn {
    display:inline-flex; align-items:center; gap:8px;
    padding:10px 18px; border-radius:12px;
    text-decoration:none; font-size:.84rem; font-weight:700;
    border:2px solid transparent; transition:all .15s; white-space:nowrap;
}
.qs-btn.wallet  { background:#f0fdf4; border-color:#86efac; color:#15803d; }
.qs-btn.wallet:hover  { background:#16a34a; color:white; border-color:#16a34a; }
.qs-btn.people  { background:#eff6ff; border-color:#93c5fd; color:#1d4ed8; }
.qs-btn.people:hover  { background:#2563eb; color:white; border-color:#2563eb; }
.qs-btn.ingreso { background:#f0fdf4; border-color:#bbf7d0; color:#166534; }
.qs-btn.ingreso:hover { background:#16a34a; color:white; border-color:#16a34a; }
.qs-btn.egreso  { background:#fff1f2; border-color:#fecdd3; color:#9f1239; }
.qs-btn.egreso:hover  { background:#dc2626; color:white; border-color:#dc2626; }
.qs-label { font-size:.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; margin-bottom:6px; }

/* ─── SELECTOR ─── */
.selector-bar {
    background:white; border-radius:14px; padding:14px 18px; margin-bottom:22px;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    display:flex; align-items:center; gap:14px; flex-wrap:wrap;
}
.selector-bar label { font-size:.78rem; font-weight:600; color:#475569; }
.selector-bar select,
.selector-bar input[type=date] {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 12px;
    font-size:.83rem; font-family:'Inter',sans-serif; color:#1e293b; background:#f8fafc;
}
.selector-bar select:focus,
.selector-bar input:focus { outline:none; border-color:#2563eb; background:white; }
.btn-ir {
    background:#2563eb; color:white; border:none; border-radius:9px;
    padding:9px 16px; font-size:.83rem; font-weight:600; cursor:pointer;
    display:flex; align-items:center; gap:6px;
}
.btn-ir:hover { background:#1d4ed8; }

/* ─── RESUMEN ─── */
.resumen-dia { display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:12px; margin-bottom:22px; }
.rd-card {
    background:white; border-radius:14px; padding:14px 16px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    border-left:4px solid transparent;
}
.rd-card.azul    { border-left-color:#2563eb; }
.rd-card.verde   { border-left-color:#16a34a; }
.rd-card.naranja { border-left-color:#f59e0b; }
.rd-card.rojo    { border-left-color:#dc2626; }
.rd-card.morado  { border-left-color:#7c3aed; }
.rd-card.cyan    { border-left-color:#0891b2; }
.rd-val { font-size:1.3rem; font-weight:800; color:#0f172a; line-height:1; margin-bottom:3px; }
.rd-lbl { font-size:.68rem; color:#94a3b8; text-transform:uppercase; letter-spacing:.05em; font-weight:500; }

/* ─── TABS ─── */
.tabs { display:flex; gap:6px; margin-bottom:20px; flex-wrap:wrap; }
.tab {
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 18px; font-size:.84rem; font-weight:600; color:#64748b;
    cursor:pointer; transition:all .15s; text-decoration:none;
    display:flex; align-items:center; gap:7px;
}
.tab:hover  { border-color:#2563eb; color:#2563eb; }
.tab.activo { background:#2563eb; border-color:#2563eb; color:white; }
.tab .tb-dot { width:8px; height:8px; border-radius:50%; background:currentColor; opacity:.5; }
.tab .tb-dot.done { background:#22c55e; opacity:1; }

/* ─── SECCIÓN ─── */
.seccion { background:white; border-radius:16px; border:1px solid #f1f5f9; box-shadow:0 2px 10px rgba(0,0,0,.06); margin-bottom:20px; overflow:hidden; }
.sec-head { padding:16px 20px; border-bottom:1px solid #f8fafc; display:flex; align-items:center; gap:10px; }
.sec-head h4 { font-size:.95rem; font-weight:700; color:#0f172a; margin:0; }
.sec-badge { font-size:.7rem; background:#eff6ff; color:#2563eb; border-radius:99px; padding:2px 10px; font-weight:600; }
.sec-body { padding:20px; }

/* ─── FORM ─── */
.form-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:14px; }
.fg { display:flex; flex-direction:column; gap:5px; }
.fg label { font-size:.76rem; font-weight:600; color:#475569; }
.fg input,
.fg select,
.fg textarea {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:10px 12px;
    font-size:.85rem; font-family:'Inter',sans-serif; color:#1e293b;
    background:#f8fafc; transition:border .15s;
}
.fg input:focus,
.fg select:focus,
.fg textarea:focus { outline:none; border-color:#2563eb; background:white; }
.fg .ayuda { font-size:.7rem; color:#94a3b8; margin-top:2px; }
.fg.full { grid-column:1 / -1; }

/* ─── BOTONES ─── */
.btn-guardar {
    background:#16a34a; color:white; border:none; border-radius:10px;
    padding:11px 22px; font-size:.88rem; font-weight:700; cursor:pointer;
    display:flex; align-items:center; gap:7px;
}
.btn-guardar:hover { background:#15803d; }
.btn-rojo  { background:#dc2626 !important; }
.btn-rojo:hover { background:#b91c1c !important; }
.btn-corte {
    background:#7c3aed; color:white; border:none; border-radius:10px;
    padding:11px 22px; font-size:.88rem; font-weight:700; cursor:pointer;
    display:flex; align-items:center; gap:7px;
}
.btn-corte:hover { background:#6d28d9; }

/* ─── GASTOS ─── */
.gastos-lista { display:flex; flex-direction:column; gap:8px; margin-top:16px; }
.gasto-item {
    background:#f8fafc; border-radius:10px; padding:10px 14px;
    display:flex; align-items:center; gap:12px; border:1px solid #f1f5f9;
}
.gasto-icon { width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
.gasto-nom  { font-size:.83rem; font-weight:600; color:#1e293b; }
.gasto-desc { font-size:.72rem; color:#94a3b8; }
.gasto-monto { margin-left:auto; font-size:.9rem; font-weight:700; color:#dc2626; white-space:nowrap; }
.btn-del-g { background:none; border:none; color:#94a3b8; cursor:pointer; font-size:1rem; padding:4px; border-radius:6px; transition:all .15s; }
.btn-del-g:hover { color:#dc2626; background:#fef2f2; }

/* ─── FORMULA ─── */
.formula-box { background:#0f172a; border-radius:14px; padding:20px; margin-bottom:16px; }
.formula-box h5 { color:#93c5fd; font-size:.78rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; margin-bottom:14px; }
.formula-row { display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid #1e293b; font-size:.86rem; }
.formula-row:last-child { border-bottom:none; }
.formula-row.positivo .fval { color:#4ade80; font-weight:700; }
.formula-row.negativo .fval { color:#f87171; font-weight:700; }
.formula-row .flbl { color:#94a3b8; }
.formula-total { margin-top:12px; padding-top:12px; border-top:2px solid #334155; display:flex; justify-content:space-between; align-items:center; }
.formula-total .flbl { color:#e2e8f0; font-weight:700; font-size:.9rem; }
.formula-total .fval { font-size:1.4rem; font-weight:800; }
.formula-total .fval.pos { color:#4ade80; }
.formula-total .fval.neg { color:#f87171; }
.formula-total .fval.neu { color:#94a3b8; }

/* ─── CORTE GUARDADO ─── */
.corte-guardado { background:#f0fdf4; border:1.5px solid #86efac; border-radius:14px; padding:18px 20px; margin-bottom:16px; }
.corte-guardado h5 { color:#15803d; font-size:.85rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:6px; }

/* ─── AVISO EFECTIVO ─── */
.aviso-ef { background:#fffbeb; border:1px solid #fde68a; border-radius:10px; padding:10px 14px; font-size:.82rem; color:#92400e; margin-bottom:16px; display:flex; align-items:center; gap:8px; }

/* ─── RESPONSIVE ─── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .tabs    { overflow-x:auto; flex-wrap:nowrap; }
    .quick-strip { gap:8px; }
    .qs-btn  { font-size:.78rem; padding:9px 14px; }
    .sap-body { grid-template-columns:repeat(2,1fr); }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }

[data-theme="dark"] .topbar-title { color:#e2e8f0; }
[data-theme="dark"] .topbar-sub   { color:#94a3b8; }
[data-theme="dark"] .topbar-sub a { color:#94a3b8; }

[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }

[data-theme="dark"] .back-btn { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .back-btn:hover { background:#1e293b; color:#e2e8f0; }

[data-theme="dark"] .flash.ok    { background:#052e16; border-color:#166534; color:#4ade80; }
[data-theme="dark"] .flash.error { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }

[data-theme="dark"] .quick-strip .qs-btn.wallet  { background:#071f12; border-color:#166534; color:#86efac; }
[data-theme="dark"] .quick-strip .qs-btn.people  { background:#0c1a3a; border-color:#1d4ed8; color:#93c5fd; }
[data-theme="dark"] .quick-strip .qs-btn.ingreso { background:#071f12; border-color:#15803d; color:#4ade80; }
[data-theme="dark"] .quick-strip .qs-btn.egreso  { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }
[data-theme="dark"] .qs-label { color:#475569; }

[data-theme="dark"] .selector-bar { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .selector-bar select,
[data-theme="dark"] .selector-bar input[type=date] { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .selector-bar label { color:#94a3b8; }

[data-theme="dark"] .rd-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .rd-val  { color:#e2e8f0; }

[data-theme="dark"] .tab { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .tab:hover  { border-color:#3b82f6; color:#93c5fd; }
[data-theme="dark"] .tab.activo { background:#2563eb; border-color:#2563eb; color:white; }

[data-theme="dark"] .seccion { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .sec-head { border-color:#1e293b; }
[data-theme="dark"] .sec-head h4 { color:#e2e8f0; }
[data-theme="dark"] .sec-badge { background:rgba(37,99,235,0.15); color:#93c5fd; }

[data-theme="dark"] .fg label { color:#94a3b8; }
[data-theme="dark"] .fg input,
[data-theme="dark"] .fg select,
[data-theme="dark"] .fg textarea { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .fg input:focus,
[data-theme="dark"] .fg select:focus,
[data-theme="dark"] .fg textarea:focus { border-color:#3b82f6; background:#1e293b; }

[data-theme="dark"] .gasto-item { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .gasto-nom  { color:#e2e8f0; }

[data-theme="dark"] .aviso-ef { background:#1c1500; border-color:#78350f; color:#fde68a; }

[data-theme="dark"] .corte-guardado { background:#052e16; border-color:#166534; }
[data-theme="dark"] .corte-guardado h5 { color:#4ade80; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">

    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>

    <nav class="sb-nav">

        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>

        <div class="sb-section">Operaciones</div>
        <a href="caja.php" class="active"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>

        <div class="sb-section">Caja Personal</div>
        <a href="caja_asesor.php" class="verde"><i class="bi bi-wallet2"></i> Caja por Asesor</a>
        <?php if ($rol !== 'ASESOR'): ?>
        <a href="caja_asesores.php" class="verde"><i class="bi bi-people-fill"></i> Resumen Asesores</a>
        <?php endif; ?>
        <a href="ingreso_caja.php"><i class="bi bi-plus-circle"></i> Registrar Ingreso</a>
        <a href="egreso_caja.php"><i class="bi bi-dash-circle"></i> Retiro / Gasto</a>

        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>

        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>

    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>

</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="back-btn">
                <i class="bi bi-arrow-left"></i> Inicio
            </a>
            <img src="img/logo.jpeg" class="topbar-logo" alt="J.E." onerror="this.style.display='none'">
            <div>
                <div class="topbar-title">Caja Diaria</div>
                <div class="topbar-sub">
                    <?= date('d/m/Y', strtotime($fecha_vista)) ?>
                    &nbsp;|&nbsp; <strong><?= htmlspecialchars($nombre_emp) ?></strong>
                </div>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
            <a href="historial_caja.php" style="text-decoration:none;display:inline-flex;align-items:center;gap:6px;background:white;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 16px;font-size:.82rem;font-weight:600;color:#475569;box-shadow:0 1px 4px rgba(0,0,0,.05);">
                <i class="bi bi-clock-history"></i> Historial
            </a>
        </div>
    </div>

    <!-- MENSAJE FLASH -->
    <?php if ($msg): ?>
    <div class="flash <?= $msg_tipo ?>">
        <i class="bi bi-<?= $msg_tipo === 'ok' ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
        <?= htmlspecialchars($msg) ?>
    </div>
    <?php endif; ?>

    <!-- ── ACCESO RÁPIDO: CAJA PERSONAL ── -->
    <div class="qs-label"><i class="bi bi-lightning-fill"></i> Acceso rápido — Caja Personal</div>
    <div class="quick-strip">
        <a href="caja_asesor.php" class="qs-btn wallet">
            <i class="bi bi-wallet2"></i> Caja Asesor
        </a>
        <?php if ($rol !== 'ASESOR'): ?>
        <a href="caja_asesores.php" class="qs-btn people">
            <i class="bi bi-people-fill"></i> Resumen Asesores
        </a>
        <?php endif; ?>
        <a href="ingreso_caja.php" class="qs-btn ingreso">
            <i class="bi bi-plus-circle-fill"></i> Registrar Ingreso
        </a>
        <a href="egreso_caja.php" class="qs-btn egreso">
            <i class="bi bi-dash-circle-fill"></i> Retiro / Gasto
        </a>
    </div>

    <!-- SELECTOR ASESOR + FECHA -->
    <form method="GET" class="selector-bar">
        <?php if ($rol === 'GERENTE'): ?>
        <div style="display:flex;flex-direction:column;gap:4px;">
            <label>Asesor</label>
            <select name="id_empleado" id="sel_asesor" onchange="mostrarSaldoAsesor(this.value)">
                <?php foreach ($empleados as $e): ?>
                <option value="<?= $e['id_empleado'] ?>" <?= $e['id_empleado'] == $id_emp ? 'selected' : '' ?>>
                    <?= htmlspecialchars($e['nombre']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div style="display:flex;flex-direction:column;gap:4px;">
            <label>Fecha</label>
            <input type="date" name="fecha" value="<?= htmlspecialchars($fecha_vista) ?>">
        </div>
        <button type="submit" class="btn-ir"><i class="bi bi-search"></i> Ver</button>
    </form>

    <?php if ($rol === 'GERENTE' && !empty($saldos_asesores)): ?>
    <!-- PANEL SALDO ASESOR (visible solo para GERENTE) -->
    <div class="saldo-asesor-panel" id="saldo_panel">
        <div class="sap-header">
            <div class="sap-avatar" id="sap_ini">?</div>
            <div>
                <div class="sap-nombre" id="sap_nombre">—</div>
                <div class="sap-sub">Saldo acumulado en su caja personal</div>
            </div>
            <a href="#" class="sap-link" id="sap_link">
                <i class="bi bi-eye"></i> Ver caja completa
            </a>
        </div>
        <div class="sap-body">
            <div class="sap-stat" id="sap_st_total">
                <div class="ss-label"><i class="bi bi-calculator"></i> Saldo Total</div>
                <div class="ss-val" id="sap_total">$0.00</div>
            </div>
            <div class="sap-stat">
                <div class="ss-label"><i class="bi bi-cash"></i> Efectivo</div>
                <div class="ss-val verde" id="sap_ef">$0.00</div>
            </div>
            <div class="sap-stat azul">
                <div class="ss-label"><i class="bi bi-bank"></i> Banco</div>
                <div class="ss-val" id="sap_banco">$0.00</div>
            </div>
            <div class="sap-stat verde">
                <div class="ss-label"><i class="bi bi-calendar-day"></i> Cobrado hoy</div>
                <div class="ss-val" id="sap_hoy">$0.00</div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- RESUMEN RÁPIDO -->
    <div class="resumen-dia">
        <div class="rd-card azul">
            <div class="rd-val">$<?= number_format($cobrado_hoy,2) ?></div>
            <div class="rd-lbl">Cobrado hoy</div>
        </div>
        <div class="rd-card verde">
            <div class="rd-val">$<?= number_format($apertura['efectivo_nuevo'] ?? 0,2) ?></div>
            <div class="rd-lbl">Efectivo entregado</div>
        </div>
        <?php if ($ef_anterior > 0): ?>
        <div class="rd-card naranja">
            <div class="rd-val">$<?= number_format($ef_anterior,2) ?></div>
            <div class="rd-lbl">Ef. día anterior</div>
        </div>
        <?php endif; ?>
        <div class="rd-card cyan">
            <div class="rd-val">$<?= number_format($apertura['banca_nueva'] ?? $banca_actual_db,2) ?></div>
            <div class="rd-lbl">Banca</div>
        </div>
        <div class="rd-card rojo">
            <div class="rd-val">$<?= number_format($total_gastos,2) ?></div>
            <div class="rd-lbl">Gastos del día</div>
        </div>
        <div class="rd-card morado">
            <div class="rd-val">$<?= number_format($prestamos_hoy,2) ?></div>
            <div class="rd-lbl">Préstamos del día</div>
        </div>
    </div>

    <!-- TABS -->
    <div class="tabs">
        <a href="javascript:void(0)" class="tab" onclick="mostrarTab('apertura',this)">
            <span class="tb-dot <?= $apertura ? 'done' : '' ?>"></span>
            <i class="bi bi-sun"></i> 1. Apertura
        </a>
        <a href="javascript:void(0)" class="tab" onclick="mostrarTab('gastos',this)">
            <span class="tb-dot <?= count($gastos_hoy)>0 ? 'done' : '' ?>"></span>
            <i class="bi bi-receipt"></i> 2. Gastos (<?= count($gastos_hoy) ?>)
        </a>
        <a href="javascript:void(0)" class="tab" onclick="mostrarTab('corte',this)">
            <span class="tb-dot <?= $corte_hoy ? 'done' : '' ?>"></span>
            <i class="bi bi-flag-fill"></i> 3. Corte de Caja
        </a>
    </div>

    <!-- ████ TAB 1: APERTURA ████ -->
    <div id="tab-apertura">

        <?php if ($ef_anterior > 0): ?>
        <div class="aviso-ef">
            <i class="bi bi-info-circle-fill"></i>
            El día anterior quedaron <strong>$<?= number_format($ef_anterior,2) ?></strong> en efectivo sin retirar — se suman automáticamente al corte de hoy.
        </div>
        <?php endif; ?>

        <div class="seccion">
            <div class="sec-head">
                <i class="bi bi-sun" style="color:#f59e0b;font-size:1.2rem;"></i>
                <h4>Entrega de Dinero — Apertura de Caja</h4>
                <span class="sec-badge"><?= $apertura ? 'GUARDADA' : 'PENDIENTE' ?></span>
            </div>
            <div class="sec-body">
                <p style="font-size:.83rem;color:#64748b;margin-bottom:18px;line-height:1.6;">
                    Registra el dinero que se entrega al asesor cada mañana.
                    El <strong>efectivo</strong> del día anterior se acumula si no fue retirado.
                    La <strong>banca</strong> se actualiza al nuevo monto que ingreses.
                </p>
                <form method="POST" class="form-grid">
                    <input type="hidden" name="accion" value="apertura">
                    <input type="hidden" name="id_empleado" value="<?= $id_emp ?>">
                    <input type="hidden" name="fecha" value="<?= $fecha_vista ?>">

                    <div class="fg">
                        <label><i class="bi bi-cash"></i> Efectivo nuevo a entregar ($)</label>
                        <input type="number" name="efectivo_nuevo" step="0.01" min="0"
                               value="<?= $apertura['efectivo_nuevo'] ?? '' ?>" placeholder="Ej: 3000.00">
                        <?php if ($ef_anterior > 0): ?>
                        <span class="ayuda">
                            + $<?= number_format($ef_anterior,2) ?> del día anterior =
                            <strong>$<?= number_format(($apertura['efectivo_nuevo'] ?? 0)+$ef_anterior,2) ?> disponibles</strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="fg">
                        <label><i class="bi bi-bank"></i> Banca ($)</label>
                        <input type="number" name="banca_nueva" step="0.01" min="0"
                               value="<?= $apertura['banca_nueva'] ?? $banca_actual_db ?>" placeholder="Ej: 9000.00">
                        <span class="ayuda">La banca se actualiza a este monto al guardar.</span>
                    </div>

                    <div class="fg full" style="margin-top:6px;">
                        <button type="submit" class="btn-guardar" style="width:fit-content;">
                            <i class="bi bi-<?= $apertura ? 'pencil' : 'check-circle' ?>"></i>
                            <?= $apertura ? 'Actualizar Apertura' : 'Guardar Apertura' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ████ TAB 2: GASTOS ████ -->
    <div id="tab-gastos" style="display:none;">
        <div class="seccion">
            <div class="sec-head">
                <i class="bi bi-receipt" style="color:#dc2626;font-size:1.2rem;"></i>
                <h4>Gastos del Día</h4>
                <span class="sec-badge" style="background:#fef2f2;color:#dc2626;">$<?= number_format($total_gastos,2) ?></span>
            </div>
            <div class="sec-body">
                <p style="font-size:.83rem;color:#64748b;margin-bottom:18px;line-height:1.6;">
                    Registra cada gasto del asesor. Se descuentan automáticamente en el corte.
                </p>
                <form method="POST" class="form-grid">
                    <input type="hidden" name="accion" value="gasto">
                    <input type="hidden" name="id_empleado" value="<?= $id_emp ?>">
                    <input type="hidden" name="fecha" value="<?= $fecha_vista ?>">

                    <div class="fg">
                        <label><i class="bi bi-tag"></i> Tipo de Gasto</label>
                        <select name="tipo_gasto">
                            <?php foreach ($etiquetas_gasto as $k => $v): ?>
                            <option value="<?= $k ?>"><?= $v[0] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="fg">
                        <label><i class="bi bi-cash"></i> Monto ($)</label>
                        <input type="number" name="monto_gasto" step="0.01" min="0.01" placeholder="Ej: 150.00" required>
                    </div>
                    <div class="fg">
                        <label><i class="bi bi-pencil"></i> Descripción (opcional)</label>
                        <input type="text" name="descripcion" placeholder="Ej: Gasolina magna 5L">
                    </div>
                    <div class="fg full" style="margin-top:4px;">
                        <button type="submit" class="btn-guardar btn-rojo" style="width:fit-content;">
                            <i class="bi bi-plus-circle"></i> Agregar Gasto
                        </button>
                    </div>
                </form>

                <?php if (!empty($gastos_hoy)): ?>
                <div class="gastos-lista">
                    <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;color:#94a3b8;margin:12px 0 4px;">Gastos de hoy</div>
                    <?php foreach ($gastos_hoy as $g):
                        $meta = $etiquetas_gasto[$g['tipo_gasto']] ?? ['Gasto','bi-dash','#64748b'];
                    ?>
                    <div class="gasto-item">
                        <div class="gasto-icon" style="background:<?= $meta[2] ?>22;color:<?= $meta[2] ?>;">
                            <i class="bi <?= $meta[1] ?>"></i>
                        </div>
                        <div>
                            <div class="gasto-nom"><?= $meta[0] ?></div>
                            <?php if ($g['descripcion']): ?>
                            <div class="gasto-desc"><?= htmlspecialchars($g['descripcion']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="gasto-monto">-$<?= number_format($g['monto'],2) ?></div>
                        <a href="?id_empleado=<?= $id_emp ?>&fecha=<?= $fecha_vista ?>&del_gasto=<?= $g['id_gasto'] ?>"
                           class="btn-del-g" onclick="return confirm('¿Eliminar este gasto?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                    <?php endforeach; ?>
                    <div style="background:#fef2f2;border-radius:9px;padding:10px 14px;font-size:.85rem;font-weight:700;color:#dc2626;display:flex;justify-content:space-between;">
                        <span>Total Gastos</span><span>-$<?= number_format($total_gastos,2) ?></span>
                    </div>
                </div>
                <?php else: ?>
                <div style="text-align:center;padding:24px;color:#94a3b8;font-size:.83rem;margin-top:12px;">
                    <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:8px;opacity:.35;"></i>
                    Sin gastos registrados hoy
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ████ TAB 3: CORTE ████ -->
    <div id="tab-corte" style="display:none;">
        <div class="seccion">
            <div class="sec-head">
                <i class="bi bi-flag-fill" style="color:#7c3aed;font-size:1.2rem;"></i>
                <h4>Corte de Caja</h4>
                <span class="sec-badge" style="background:#faf5ff;color:#7c3aed;"><?= $corte_hoy ? 'REALIZADO' : 'PENDIENTE' ?></span>
            </div>
            <div class="sec-body">

                <?php if ($corte_hoy): ?>
                <div class="corte-guardado">
                    <h5><i class="bi bi-check-circle-fill"></i> Corte del <?= date('d/m/Y',strtotime($fecha_vista)) ?> guardado</h5>
                    <div class="formula-box">
                        <h5>Desglose</h5>
                        <div class="formula-row positivo"><span class="flbl">Cobrado del día</span><span class="fval">+$<?= number_format($corte_hoy['cobrado'],2) ?></span></div>
                        <div class="formula-row positivo"><span class="flbl">Efectivo llevado</span><span class="fval">+$<?= number_format($corte_hoy['efectivo_llevado'],2) ?></span></div>
                        <div class="formula-row positivo"><span class="flbl">Banca llevada</span><span class="fval">+$<?= number_format($corte_hoy['banca_llevada'],2) ?></span></div>
                        <div class="formula-row negativo"><span class="flbl">Préstamos realizados</span><span class="fval">-$<?= number_format($corte_hoy['prestamos_dia'],2) ?></span></div>
                        <div class="formula-row negativo"><span class="flbl">Banca actual</span><span class="fval">-$<?= number_format($corte_hoy['banca_actual'],2) ?></span></div>
                        <div class="formula-row negativo"><span class="flbl">Gastos del día</span><span class="fval">-$<?= number_format($corte_hoy['total_gastos'],2) ?></span></div>
                        <div class="formula-total">
                            <span class="flbl">RESULTADO</span>
                            <span class="fval <?= $corte_hoy['resultado']>0?'pos':($corte_hoy['resultado']<0?'neg':'neu') ?>">
                                $<?= number_format($corte_hoy['resultado'],2) ?>
                            </span>
                        </div>
                    </div>
                    <?php if ($corte_hoy['notas']): ?>
                    <p style="font-size:.82rem;color:#475569;margin-top:8px;"><strong>Notas:</strong> <?= htmlspecialchars($corte_hoy['notas']) ?></p>
                    <?php endif; ?>
                </div>
                <p style="font-size:.78rem;color:#94a3b8;text-align:center;margin-bottom:16px;">¿Necesitas corregir algo? Edita los valores abajo y guarda de nuevo.</p>
                <?php endif; ?>

                <div style="background:#f8fafc;border-radius:12px;padding:14px 16px;margin-bottom:18px;font-size:.82rem;color:#64748b;line-height:1.9;">
                    <strong style="color:#1e293b;">Fórmula:</strong>
                    <span style="color:#16a34a;">Cobrado</span> +
                    <span style="color:#16a34a;">Efectivo Llevado</span> +
                    <span style="color:#16a34a;">Banca Llevada</span> −
                    <span style="color:#dc2626;">Préstamos del Día</span> −
                    <span style="color:#dc2626;">Banca Actual</span> −
                    <span style="color:#dc2626;">Gastos</span>
                    = <strong style="color:#7c3aed;">Resultado</strong>
                </div>

                <form method="POST" class="form-grid">
                    <input type="hidden" name="accion" value="corte">
                    <input type="hidden" name="id_empleado" value="<?= $id_emp ?>">
                    <input type="hidden" name="fecha" value="<?= $fecha_vista ?>">

                    <div class="fg">
                        <label style="color:#16a34a;"><i class="bi bi-cash-stack"></i> Cobrado del día (+)</label>
                        <input type="number" name="cobrado" id="f_cobrado" step="0.01" min="0"
                               value="<?= $corte_hoy['cobrado'] ?? number_format($cobrado_hoy,2,'.','') ?>"
                               oninput="calcularCorte()">
                        <span class="ayuda">Pagos registrados hoy: $<?= number_format($cobrado_hoy,2) ?></span>
                    </div>
                    <div class="fg">
                        <label style="color:#16a34a;"><i class="bi bi-cash"></i> Efectivo Llevado (+)</label>
                        <input type="number" name="efectivo_llevado" id="f_ef_lv" step="0.01" min="0"
                               value="<?= $corte_hoy['efectivo_llevado'] ?? number_format(($apertura['efectivo_nuevo']??0)+$ef_anterior,2,'.','') ?>"
                               oninput="calcularCorte()">
                        <span class="ayuda">Efectivo entregado + sobrante día anterior</span>
                    </div>
                    <div class="fg">
                        <label style="color:#16a34a;"><i class="bi bi-bank"></i> Banca Llevada (+)</label>
                        <input type="number" name="banca_llevada" id="f_bn_lv" step="0.01" min="0"
                               value="<?= $corte_hoy['banca_llevada'] ?? number_format($apertura['banca_nueva']??$banca_actual_db,2,'.','') ?>"
                               oninput="calcularCorte()">
                    </div>
                    <div class="fg">
                        <label style="color:#dc2626;"><i class="bi bi-file-earmark-minus"></i> Préstamos Realizados hoy (−)</label>
                        <input type="number" name="prestamos_dia" id="f_prest" step="0.01" min="0"
                               value="<?= $corte_hoy['prestamos_dia'] ?? number_format($prestamos_hoy,2,'.','') ?>"
                               oninput="calcularCorte()">
                        <span class="ayuda">Préstamos otorgados hoy: $<?= number_format($prestamos_hoy,2) ?></span>
                    </div>
                    <div class="fg">
                        <label style="color:#dc2626;"><i class="bi bi-bank"></i> Banca Actual al cierre (−)</label>
                        <input type="number" name="banca_actual" id="f_bn_act" step="0.01" min="0"
                               value="<?= $corte_hoy['banca_actual'] ?? number_format($banca_actual_db,2,'.','') ?>"
                               oninput="calcularCorte()">
                        <span class="ayuda">Cuánto quedó en la banca al terminar el día</span>
                    </div>
                    <div class="fg">
                        <label style="color:#dc2626;"><i class="bi bi-receipt"></i> Total Gastos (−)</label>
                        <input type="number" name="total_gastos" id="f_gastos" step="0.01" min="0"
                               value="<?= $corte_hoy['total_gastos'] ?? number_format($total_gastos,2,'.','') ?>"
                               oninput="calcularCorte()">
                        <span class="ayuda">Gastos registrados hoy: $<?= number_format($total_gastos,2) ?></span>
                    </div>
                    <div class="fg full">
                        <label><i class="bi bi-chat-left-text"></i> Notas (opcional)</label>
                        <textarea name="notas" rows="2" placeholder="Observaciones del día..."><?= htmlspecialchars($corte_hoy['notas'] ?? '') ?></textarea>
                    </div>
                    <div class="fg full">
                        <div class="formula-box">
                            <h5>Vista previa del resultado</h5>
                            <div class="formula-row positivo">
                                <span class="flbl">Cobrado</span>
                                <span class="fval" id="r_cobrado">$0.00</span>
                            </div>
                            <div class="formula-row positivo">
                                <span class="flbl">+ Efectivo llevado</span>
                                <span class="fval" id="r_ef_lv">$0.00</span>
                            </div>
                            <div class="formula-row positivo">
                                <span class="flbl">+ Banca llevada</span>
                                <span class="fval" id="r_bn_lv">$0.00</span>
                            </div>
                            <div class="formula-row negativo">
                                <span class="flbl">− Préstamos del día</span>
                                <span class="fval" id="r_prest">$0.00</span>
                            </div>
                            <div class="formula-row negativo">
                                <span class="flbl">− Banca actual</span>
                                <span class="fval" id="r_bn_act">$0.00</span>
                            </div>
                            <div class="formula-row negativo">
                                <span class="flbl">− Gastos del día</span>
                                <span class="fval" id="r_gastos">$0.00</span>
                            </div>
                            <div class="formula-total">
                                <span class="flbl">RESULTADO</span>
                                <span class="fval" id="r_resultado">$0.00</span>
                            </div>
                        </div>
                    </div>
                    <div class="fg full">
                        <button type="submit" class="btn-corte" style="width:fit-content;">
                            <i class="bi bi-<?= $corte_hoy ? 'arrow-clockwise' : 'flag-fill' ?>"></i>
                            <?= $corte_hoy ? 'Actualizar Corte' : 'Realizar Corte de Caja' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</main>
</div>

<script>
// ── Datos de saldos por asesor ──
const SALDOS_ASESORES = <?= json_encode($saldos_asesores, JSON_UNESCAPED_UNICODE) ?>;

function fmt_mxn(n) {
    return '$' + parseFloat(n).toLocaleString('es-MX', {minimumFractionDigits:2, maximumFractionDigits:2});
}

function mostrarSaldoAsesor(id) {
    const panel = document.getElementById('saldo_panel');
    if (!panel) return;
    const d = SALDOS_ASESORES[id];
    if (!d) { panel.style.display = 'none'; return; }

    document.getElementById('sap_ini').textContent    = d.nombre.charAt(0).toUpperCase();
    document.getElementById('sap_nombre').textContent = d.nombre;
    document.getElementById('sap_total').textContent  = fmt_mxn(d.saldo_total);
    document.getElementById('sap_ef').textContent     = fmt_mxn(d.efectivo);
    document.getElementById('sap_banco').textContent  = fmt_mxn(d.banco);
    document.getElementById('sap_hoy').textContent    = fmt_mxn(d.cobrado_hoy);

    // Color del saldo total según positivo/negativo
    const stEl = document.getElementById('sap_total');
    stEl.style.color = d.saldo_total >= 0 ? '#16a34a' : '#dc2626';

    // Link a caja_asesor.php con id
    document.getElementById('sap_link').href = 'caja_asesor.php?id=' + id;

    panel.style.display = 'block';
    // Re-trigger animation
    panel.style.animation = 'none';
    panel.offsetHeight; // reflow
    panel.style.animation = 'fadeIn .2s ease';
}

// Mostrar panel para el asesor ya seleccionado al cargar la página
(function() {
    const sel = document.getElementById('sel_asesor');
    if (sel) mostrarSaldoAsesor(sel.value);
})();

const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

function mostrarTab(tab, el) {
    ['apertura','gastos','corte'].forEach(t => {
        document.getElementById('tab-'+t).style.display = 'none';
    });
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('activo'));
    document.getElementById('tab-'+tab).style.display = 'block';
    el.classList.add('activo');
}
document.querySelector('.tab').classList.add('activo');

function fmt(n) {
    return '$' + Math.abs(n).toLocaleString('es-MX', {minimumFractionDigits:2, maximumFractionDigits:2});
}
function calcularCorte() {
    const cobrado = parseFloat(document.getElementById('f_cobrado')?.value  || 0);
    const ef_lv   = parseFloat(document.getElementById('f_ef_lv')?.value    || 0);
    const bn_lv   = parseFloat(document.getElementById('f_bn_lv')?.value    || 0);
    const prest   = parseFloat(document.getElementById('f_prest')?.value    || 0);
    const bn_act  = parseFloat(document.getElementById('f_bn_act')?.value   || 0);
    const gastos  = parseFloat(document.getElementById('f_gastos')?.value   || 0);
    const res     = cobrado + ef_lv + bn_lv - prest - bn_act - gastos;
    document.getElementById('r_cobrado').textContent = fmt(cobrado);
    document.getElementById('r_ef_lv').textContent   = fmt(ef_lv);
    document.getElementById('r_bn_lv').textContent   = fmt(bn_lv);
    document.getElementById('r_prest').textContent   = fmt(prest);
    document.getElementById('r_bn_act').textContent  = fmt(bn_act);
    document.getElementById('r_gastos').textContent  = fmt(gastos);
    const rEl = document.getElementById('r_resultado');
    rEl.textContent = (res >= 0 ? '+' : '-') + fmt(res);
    rEl.className   = 'fval ' + (res > 0 ? 'pos' : res < 0 ? 'neg' : 'neu');
}
calcularCorte();
</script>
</body>
</html>

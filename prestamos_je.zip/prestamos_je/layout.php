<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.sidebar{
    width:230px;
    height:100vh;
    position:fixed;
    background:#1e293b;
    color:white;
    padding:20px;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:10px;
    border-radius:8px;
    margin-bottom:8px;
}

.sidebar a:hover{
    background:#334155;
    color:white;
}

.content{
    margin-left:250px;
    padding:20px;
}

body{
    background:#f4f6f9;
}

/* TABLAS MODO PRO */
.table-dark-custom thead{
    background:#1e293b;
    color:white;
}

</style>

<div class="sidebar">

    <h5 class="fw-bold">💼 Préstamos JE</h5>
    <small class="text-secondary">Sistema financiero</small>

    <a href="index.php">🏠 Inicio</a>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="caja.php">💰 Caja</a>
    <a href="registrar_cliente.php">👥 Clientes</a>
    <a href="nuevo_prestamo.php">📄 Préstamos</a>
    <a href="cobranza_diaria.php">💳 Cobranza</a>
    <a href="reporte_diario.php">📁 Reportes</a>

    <hr style="border-color:#475569;">

    <a href="logout.php">🔒 Cerrar sesión</a>

</div>

<div class="content">
<?php
include("seguridad.php");
include("conexion.php");

$rol    = $_SESSION['rol']        ?? 'ASESOR';
$user   = $_SESSION['usuario']    ?? 'Usuario';
$id_ses = intval($_SESSION['id_empleado'] ?? 0);
$hoy    = date('Y-m-d');

// ── EMPLEADOS ──
$empleados = [];
$r = $conexion->query("SELECT id_empleado, nombre FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
while ($e = $r->fetch_assoc()) $empleados[] = $e;

// ── FILTROS ──
if ($rol === 'GERENTE') {
    $id_emp = intval($_GET['id_empleado'] ?? 0);
} else {
    $id_emp = $id_ses;
}

$fecha_desde = $_GET['fecha_desde'] ?? date('Y-m-01');
$fecha_hasta = $_GET['fecha_hasta'] ?? $hoy;
$fecha_desde_safe = $conexion->real_escape_string($fecha_desde);
$fecha_hasta_safe = $conexion->real_escape_string($fecha_hasta);

// ── NOMBRE DEL ASESOR ──
$nombre_emp = 'Todos los asesores';
foreach ($empleados as $e) {
    if ($e['id_empleado'] == $id_emp) { $nombre_emp = $e['nombre']; break; }
}

// ── QUERY HISTORIAL ──
$where_emp = ($id_emp > 0) ? "AND cc.id_empleado = $id_emp" : "";
$historial = [];
$r_hist = $conexion->query("
    SELECT cc.*,
           e.nombre  AS asesor_nombre,
           COALESCE(ce.efectivo_nuevo, 0) AS efectivo_apertura,
           COALESCE(ce.banca_nueva, 0)    AS banca_apertura
    FROM caja_corte cc
    LEFT JOIN empleados e   ON e.id_empleado = cc.id_empleado
    LEFT JOIN caja_entrega ce ON ce.id_empleado = cc.id_empleado AND ce.fecha = cc.fecha
    WHERE cc.fecha BETWEEN '$fecha_desde_safe' AND '$fecha_hasta_safe'
    $where_emp
    ORDER BY cc.fecha DESC, e.nombre ASC
");
while ($h = $r_hist->fetch_assoc()) $historial[] = $h;

// ── GASTOS POR DÍA (para expandir) ──
$gastos_por_dia = [];
if (!empty($historial)) {
    $ids_emp   = array_unique(array_column($historial, 'id_empleado'));
    $fechas    = array_unique(array_column($historial, 'fecha'));
    $ids_str   = implode(',', array_map('intval', $ids_emp));
    $fechas_str = implode(',', array_map(fn($f) => "'".addslashes($f)."'", $fechas));
    $r_gastos = $conexion->query("
        SELECT * FROM caja_gastos
        WHERE id_empleado IN ($ids_str)
        AND fecha IN ($fechas_str)
        ORDER BY creado_en ASC
    ");
    while ($g = $r_gastos->fetch_assoc()) {
        $gastos_por_dia[$g['id_empleado'].'-'.$g['fecha']][] = $g;
    }
}

// ── TOTALES DEL PERÍODO ──
$total_cobrado  = array_sum(array_column($historial, 'cobrado'));
$total_gastos   = array_sum(array_column($historial, 'total_gastos'));
$total_prestamos= array_sum(array_column($historial, 'prestamos_dia'));
$total_resultado= array_sum(array_column($historial, 'resultado'));

// ── ETIQUETAS GASTO ──
$etiquetas_gasto = [
    'GASOLINA'        => ['Gasolina',             'bi-fuel-pump',         '#f59e0b'],
    'TIEMPO_AIRE'     => ['Tiempo Aire / Celular', 'bi-phone',             '#06b6d4'],
    'REPARACION_MOTO' => ['Reparación de Moto',   'bi-tools',             '#ef4444'],
    'ACCESORIO_MOTO'  => ['Accesorio de Moto',    'bi-gear',              '#8b5cf6'],
    'SERVICIO_MOTO'   => ['Servicio de Moto',     'bi-wrench-adjustable', '#10b981'],
    'CONSUMO_GENERAL' => ['Consumo General',      'bi-bag',               '#64748b'],
];
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Historial de Caja | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-0.3px; }
.sb-brand .brand-sub  { font-size:0.65rem; color:#475569; text-transform:uppercase; letter-spacing:0.8px; margin-top:2px; }
.sb-user {
    padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:0.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:0.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:0.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:0.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:0.84rem; font-weight:500;
    margin-bottom:1px; transition:all 0.15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:0.84rem; transition:all 0.15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-title { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:1px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.back-btn {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 14px; color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,0.05);
}
.back-btn:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all 0.2s; box-shadow:0 1px 4px rgba(0,0,0,0.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── FILTROS ── */
.filtros-bar {
    background:white; border-radius:14px; padding:14px 18px; margin-bottom:22px;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    display:flex; align-items:flex-end; gap:14px; flex-wrap:wrap;
}
.filtro-grupo { display:flex; flex-direction:column; gap:4px; }
.filtro-grupo label { font-size:.76rem; font-weight:600; color:#475569; }
.filtro-grupo select,
.filtro-grupo input[type=date] {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 12px;
    font-size:.83rem; font-family:'Inter',sans-serif; color:#1e293b; background:#f8fafc;
}
.filtro-grupo select:focus,
.filtro-grupo input:focus { outline:none; border-color:#2563eb; background:white; }
.btn-filtrar {
    background:#2563eb; color:white; border:none; border-radius:9px;
    padding:9px 18px; font-size:.83rem; font-weight:600; cursor:pointer;
    display:flex; align-items:center; gap:6px; align-self:flex-end;
}
.btn-filtrar:hover { background:#1d4ed8; }

/* ── KPI RESUMEN ── */
.resumen-periodo {
    display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:12px; margin-bottom:22px;
}
.rp-card {
    background:white; border-radius:14px; padding:16px 18px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    border-left:4px solid transparent;
}
.rp-card.azul    { border-left-color:#2563eb; }
.rp-card.verde   { border-left-color:#16a34a; }
.rp-card.rojo    { border-left-color:#dc2626; }
.rp-card.morado  { border-left-color:#7c3aed; }
.rp-card.naranja { border-left-color:#f59e0b; }
.rp-val { font-size:1.3rem; font-weight:800; color:#0f172a; line-height:1; margin-bottom:3px; }
.rp-val.pos { color:#16a34a; }
.rp-val.neg { color:#dc2626; }
.rp-lbl { font-size:.68rem; color:#94a3b8; text-transform:uppercase; letter-spacing:.05em; font-weight:500; }
.rp-sub { font-size:.7rem; color:#64748b; margin-top:3px; }

/* ── TABLA / CARDS DE HISTORIAL ── */
.seccion {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06); margin-bottom:20px; overflow:hidden;
}
.sec-head {
    padding:16px 20px; border-bottom:1px solid #f8fafc;
    display:flex; align-items:center; gap:10px; justify-content:space-between;
}
.sec-head-left { display:flex; align-items:center; gap:10px; }
.sec-head h4 { font-size:.95rem; font-weight:700; color:#0f172a; margin:0; }
.sec-badge {
    font-size:.7rem; background:#eff6ff; color:#2563eb;
    border-radius:99px; padding:2px 10px; font-weight:600;
}
.sec-body { padding:0; }

/* ── FILA DE CORTE ── */
.corte-fila {
    border-bottom:1px solid #f8fafc;
    transition:background .15s;
}
.corte-fila:last-child { border-bottom:none; }
.corte-fila-head {
    display:flex; align-items:center; gap:12px;
    padding:14px 20px; cursor:pointer;
}
.corte-fila-head:hover { background:#f8fafc; }
.cf-fecha {
    min-width:90px; font-size:.83rem; font-weight:700; color:#0f172a;
}
.cf-asesor {
    flex:1; font-size:.83rem; color:#475569; font-weight:500;
}
.cf-chips { display:flex; gap:8px; flex-wrap:wrap; }
.chip {
    display:inline-flex; align-items:center; gap:4px;
    font-size:.72rem; font-weight:600; padding:3px 9px; border-radius:99px;
}
.chip.cobrado  { background:#dcfce7; color:#15803d; }
.chip.gastos   { background:#fef2f2; color:#b91c1c; }
.chip.prestamos{ background:#eff6ff; color:#1d4ed8; }
.cf-resultado {
    font-size:.95rem; font-weight:800; min-width:90px; text-align:right;
}
.cf-resultado.pos { color:#16a34a; }
.cf-resultado.neg { color:#dc2626; }
.cf-resultado.neu { color:#94a3b8; }
.cf-toggle { color:#94a3b8; font-size:.9rem; margin-left:8px; transition:transform .2s; }
.cf-toggle.open { transform:rotate(180deg); }

/* ── DETALLE EXPANDIBLE ── */
.corte-detalle {
    display:none; padding:0 20px 16px 20px;
    border-top:1px solid #f1f5f9;
    background:#fafbfc;
}
.corte-detalle.visible { display:block; }
.detalle-grid {
    display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:14px; margin-top:14px;
}
.detalle-formula {
    background:#0f172a; border-radius:12px; padding:16px 18px;
}
.detalle-formula .df-row {
    display:flex; justify-content:space-between;
    padding:6px 0; border-bottom:1px solid #1e293b; font-size:.82rem;
}
.detalle-formula .df-row:last-child { border-bottom:none; }
.detalle-formula .df-lbl { color:#94a3b8; }
.detalle-formula .df-val.pos { color:#4ade80; font-weight:700; }
.detalle-formula .df-val.neg { color:#f87171; font-weight:700; }
.detalle-formula .df-total {
    display:flex; justify-content:space-between; align-items:center;
    margin-top:10px; padding-top:10px; border-top:2px solid #334155;
}
.detalle-formula .df-total .df-lbl { color:#e2e8f0; font-weight:700; font-size:.88rem; }
.detalle-formula .df-total .df-val { font-size:1.3rem; font-weight:800; }

.detalle-gastos-titulo {
    font-size:.72rem; font-weight:700; text-transform:uppercase;
    color:#94a3b8; margin-bottom:8px;
}
.mini-gasto {
    display:flex; align-items:center; gap:8px;
    padding:7px 10px; background:white; border-radius:8px;
    border:1px solid #f1f5f9; margin-bottom:6px; font-size:.8rem;
}
.mini-gasto-icon {
    width:28px; height:28px; border-radius:7px;
    display:flex; align-items:center; justify-content:center; font-size:.85rem; flex-shrink:0;
}
.mini-gasto-nom  { font-weight:600; color:#0f172a; }
.mini-gasto-desc { font-size:.7rem; color:#94a3b8; }
.mini-gasto-monto { margin-left:auto; font-weight:700; color:#dc2626; white-space:nowrap; }

.detalle-notas {
    background:#fffbeb; border:1px solid #fde68a; border-radius:9px;
    padding:9px 13px; font-size:.8rem; color:#92400e; margin-top:10px;
    display:flex; align-items:flex-start; gap:7px;
}

/* ── VACÍO ── */
.vacio {
    text-align:center; padding:48px 24px; color:#94a3b8;
}
.vacio i { font-size:2.5rem; display:block; margin-bottom:12px; opacity:.3; }
.vacio p { font-size:.88rem; }

/* ── FOOTER ── */
.page-footer { text-align:center; color:#cbd5e1; font-size:.72rem; padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .detalle-grid { grid-template-columns:1fr; }
    .cf-chips { display:none; }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-title { color:#e2e8f0; }
[data-theme="dark"] .topbar-sub   { color:#94a3b8; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .back-btn { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .back-btn:hover { background:#1e293b; color:#e2e8f0; }
[data-theme="dark"] .filtros-bar { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .filtro-grupo label { color:#94a3b8; }
[data-theme="dark"] .filtro-grupo select,
[data-theme="dark"] .filtro-grupo input[type=date] { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .rp-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .rp-val  { color:#e2e8f0; }
[data-theme="dark"] .seccion { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .sec-head { border-color:#1e293b; }
[data-theme="dark"] .sec-head h4 { color:#e2e8f0; }
[data-theme="dark"] .sec-badge { background:rgba(37,99,235,0.15); color:#93c5fd; }
[data-theme="dark"] .corte-fila { border-color:#1e293b; }
[data-theme="dark"] .corte-fila-head:hover { background:#1a2235; }
[data-theme="dark"] .cf-fecha  { color:#e2e8f0; }
[data-theme="dark"] .corte-detalle { background:#0f172a; border-color:#1e293b; }
[data-theme="dark"] .mini-gasto { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .mini-gasto-nom { color:#e2e8f0; }
[data-theme="dark"] .detalle-notas { background:#1c1500; border-color:#78350f; color:#fde68a; }
[data-theme="dark"] .page-footer { color:#334155; border-color:#1e293b; }
[data-theme="dark"] .chip.cobrado   { background:rgba(22,163,74,0.15);  color:#4ade80; }
[data-theme="dark"] .chip.gastos    { background:rgba(220,38,38,0.15);  color:#f87171; }
[data-theme="dark"] .chip.prestamos { background:rgba(37,99,235,0.15);  color:#93c5fd; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php" class="active"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="caja.php" class="back-btn">
                <i class="bi bi-arrow-left"></i> Caja
            </a>
            <div>
                <div class="topbar-title">Historial de Caja</div>
                <div class="topbar-sub"><?= htmlspecialchars($nombre_emp) ?> — <?= date('d/m/Y', strtotime($fecha_desde)) ?> al <?= date('d/m/Y', strtotime($fecha_hasta)) ?></div>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
        </div>
    </div>

    <!-- FILTROS -->
    <form method="GET" class="filtros-bar">
        <?php if ($rol === 'GERENTE'): ?>
        <div class="filtro-grupo">
            <label>Asesor</label>
            <select name="id_empleado">
                <option value="0">Todos los asesores</option>
                <?php foreach ($empleados as $e): ?>
                <option value="<?= $e['id_empleado'] ?>" <?= $e['id_empleado'] == $id_emp ? 'selected' : '' ?>>
                    <?= htmlspecialchars($e['nombre']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="filtro-grupo">
            <label>Desde</label>
            <input type="date" name="fecha_desde" value="<?= htmlspecialchars($fecha_desde) ?>">
        </div>
        <div class="filtro-grupo">
            <label>Hasta</label>
            <input type="date" name="fecha_hasta" value="<?= htmlspecialchars($fecha_hasta) ?>">
        </div>
        <button type="submit" class="btn-filtrar">
            <i class="bi bi-funnel-fill"></i> Filtrar
        </button>
        <a href="historial_caja.php" style="display:inline-flex;align-items:center;gap:6px;background:white;border:1.5px solid #e2e8f0;border-radius:9px;padding:9px 14px;font-size:.83rem;font-weight:600;color:#64748b;text-decoration:none;align-self:flex-end;">
            <i class="bi bi-x-circle"></i> Limpiar
        </a>
    </form>

    <!-- RESUMEN DEL PERÍODO -->
    <?php if (!empty($historial)): ?>
    <div class="resumen-periodo">
        <div class="rp-card azul">
            <div class="rp-val">$<?= number_format($total_cobrado,2) ?></div>
            <div class="rp-lbl">Total Cobrado</div>
            <div class="rp-sub"><?= count($historial) ?> día<?= count($historial)!=1?'s':'' ?> con corte</div>
        </div>
        <div class="rp-card rojo">
            <div class="rp-val neg">-$<?= number_format($total_gastos,2) ?></div>
            <div class="rp-lbl">Total Gastos</div>
        </div>
        <div class="rp-card naranja">
            <div class="rp-val">$<?= number_format($total_prestamos,2) ?></div>
            <div class="rp-lbl">Préstamos Otorgados</div>
        </div>
        <div class="rp-card <?= $total_resultado >= 0 ? 'verde' : 'rojo' ?>">
            <div class="rp-val <?= $total_resultado >= 0 ? 'pos' : 'neg' ?>">
                <?= $total_resultado >= 0 ? '+' : '' ?>$<?= number_format($total_resultado,2) ?>
            </div>
            <div class="rp-lbl">Resultado Total</div>
        </div>
        <div class="rp-card morado">
            <div class="rp-val">$<?= count($historial) > 0 ? number_format($total_cobrado / count($historial), 2) : '0.00' ?></div>
            <div class="rp-lbl">Promedio por día</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- TABLA DE HISTORIAL -->
    <div class="seccion">
        <div class="sec-head">
            <div class="sec-head-left">
                <i class="bi bi-clock-history" style="color:#7c3aed;font-size:1.2rem;"></i>
                <h4>Cortes registrados</h4>
            </div>
            <span class="sec-badge"><?= count($historial) ?> registros</span>
        </div>
        <div class="sec-body">

            <?php if (empty($historial)): ?>
            <div class="vacio">
                <i class="bi bi-inbox"></i>
                <p>No hay cortes registrados en el período seleccionado.</p>
                <a href="caja.php" style="display:inline-block;margin-top:12px;background:#2563eb;color:white;border-radius:9px;padding:8px 18px;text-decoration:none;font-size:.83rem;font-weight:600;">
                    Ir a Caja Diaria
                </a>
            </div>
            <?php else: ?>

            <?php foreach ($historial as $idx => $h):
                $res_clase = $h['resultado'] > 0 ? 'pos' : ($h['resultado'] < 0 ? 'neg' : 'neu');
                $key_gastos = $h['id_empleado'].'-'.$h['fecha'];
                $gastos_dia = $gastos_por_dia[$key_gastos] ?? [];
            ?>
            <div class="corte-fila">
                <div class="corte-fila-head" onclick="toggleDetalle(<?= $idx ?>)">
                    <div class="cf-fecha"><?= date('d/m/Y', strtotime($h['fecha'])) ?></div>
                    <?php if ($rol === 'GERENTE'): ?>
                    <div class="cf-asesor"><i class="bi bi-person-fill" style="opacity:.5;margin-right:4px;"></i><?= htmlspecialchars($h['asesor_nombre'] ?? '') ?></div>
                    <?php endif; ?>
                    <div class="cf-chips">
                        <span class="chip cobrado"><i class="bi bi-cash-coin"></i> $<?= number_format($h['cobrado'],0) ?></span>
                        <?php if ($h['total_gastos'] > 0): ?>
                        <span class="chip gastos"><i class="bi bi-receipt"></i> -$<?= number_format($h['total_gastos'],0) ?></span>
                        <?php endif; ?>
                        <?php if ($h['prestamos_dia'] > 0): ?>
                        <span class="chip prestamos"><i class="bi bi-file-earmark-plus"></i> $<?= number_format($h['prestamos_dia'],0) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="cf-resultado <?= $res_clase ?>">
                        <?= $h['resultado'] > 0 ? '+' : '' ?>$<?= number_format($h['resultado'],2) ?>
                    </div>
                    <i class="bi bi-chevron-down cf-toggle" id="toggle-<?= $idx ?>"></i>
                </div>

                <div class="corte-detalle" id="detalle-<?= $idx ?>">
                    <div class="detalle-grid">

                        <!-- Fórmula -->
                        <div class="detalle-formula">
                            <div class="df-row">
                                <span class="df-lbl">Cobrado del día</span>
                                <span class="df-val pos">+$<?= number_format($h['cobrado'],2) ?></span>
                            </div>
                            <div class="df-row">
                                <span class="df-lbl">Efectivo llevado</span>
                                <span class="df-val pos">+$<?= number_format($h['efectivo_llevado'],2) ?></span>
                            </div>
                            <div class="df-row">
                                <span class="df-lbl">Banca llevada</span>
                                <span class="df-val pos">+$<?= number_format($h['banca_llevada'],2) ?></span>
                            </div>
                            <div class="df-row">
                                <span class="df-lbl">Préstamos del día</span>
                                <span class="df-val neg">-$<?= number_format($h['prestamos_dia'],2) ?></span>
                            </div>
                            <div class="df-row">
                                <span class="df-lbl">Banca actual</span>
                                <span class="df-val neg">-$<?= number_format($h['banca_actual'],2) ?></span>
                            </div>
                            <div class="df-row">
                                <span class="df-lbl">Gastos del día</span>
                                <span class="df-val neg">-$<?= number_format($h['total_gastos'],2) ?></span>
                            </div>
                            <div class="df-total">
                                <span class="df-lbl">RESULTADO</span>
                                <span class="df-val <?= $res_clase ?>">
                                    <?= $h['resultado'] > 0 ? '+' : '' ?>$<?= number_format($h['resultado'],2) ?>
                                </span>
                            </div>
                        </div>

                        <!-- Gastos detallados -->
                        <div>
                            <div class="detalle-gastos-titulo">
                                <i class="bi bi-receipt" style="margin-right:4px;"></i>
                                Gastos del día (<?= count($gastos_dia) ?>)
                            </div>
                            <?php if (empty($gastos_dia)): ?>
                            <p style="font-size:.8rem;color:#94a3b8;padding:8px 0;">Sin gastos registrados</p>
                            <?php else: ?>
                            <?php foreach ($gastos_dia as $g):
                                $meta = $etiquetas_gasto[$g['tipo_gasto']] ?? ['Gasto','bi-dash','#64748b'];
                            ?>
                            <div class="mini-gasto">
                                <div class="mini-gasto-icon" style="background:<?= $meta[2] ?>22;color:<?= $meta[2] ?>;">
                                    <i class="bi <?= $meta[1] ?>"></i>
                                </div>
                                <div>
                                    <div class="mini-gasto-nom"><?= $meta[0] ?></div>
                                    <?php if ($g['descripcion']): ?>
                                    <div class="mini-gasto-desc"><?= htmlspecialchars($g['descripcion']) ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="mini-gasto-monto">-$<?= number_format($g['monto'],2) ?></div>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>

                            <?php if ($h['notas']): ?>
                            <div class="detalle-notas">
                                <i class="bi bi-chat-left-text-fill"></i>
                                <div><?= htmlspecialchars($h['notas']) ?></div>
                            </div>
                            <?php endif; ?>

                            <a href="caja.php?id_empleado=<?= $h['id_empleado'] ?>&fecha=<?= $h['fecha'] ?>"
                               style="display:inline-flex;align-items:center;gap:6px;margin-top:12px;background:#7c3aed;color:white;border-radius:8px;padding:7px 14px;text-decoration:none;font-size:.78rem;font-weight:600;">
                                <i class="bi bi-pencil-square"></i> Editar este corte
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <?php endif; ?>
        </div>
    </div>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Historial de Caja
    </div>

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

function toggleDetalle(idx) {
    const detalle = document.getElementById('detalle-' + idx);
    const toggle  = document.getElementById('toggle-' + idx);
    const visible = detalle.classList.contains('visible');
    detalle.classList.toggle('visible', !visible);
    toggle.classList.toggle('open', !visible);
}
</script>
</body>
</html>
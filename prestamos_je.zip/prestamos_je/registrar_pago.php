<?php
$roles_permitidos = ['GERENTE', 'ASESOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Mexico_City');

// ============================
// VALIDAR POST
// ============================
if (!isset($_POST['id_prestamo'], $_POST['monto_pagado'])) {
    die("Datos incompletos");
}

$id_prestamo  = intval($_POST['id_prestamo']);
$monto_pagado = floatval($_POST['monto_pagado']);
$fecha_pago   = $_POST['fecha_pago'] ?? date('Y-m-d');

// 🚫 No permitir fechas futuras
if ($fecha_pago > date('Y-m-d')) {
    die("No se permiten fechas futuras");
}

if ($id_prestamo <= 0 || $monto_pagado <= 0) {
    die("Datos inválidos");
}

// ============================
// OBTENER SALDO ACTUAL
// ============================
$sql = "
    SELECT 
        pr.total_pagar,
        IFNULL(SUM(pa.monto_pagado),0) AS pagado
    FROM prestamos pr
    LEFT JOIN pagos pa 
        ON pr.id_prestamo = pa.id_prestamo
       AND pa.fecha_pago <= '$fecha_pago'
    WHERE pr.id_prestamo = $id_prestamo
    GROUP BY pr.id_prestamo
";

$res = $conexion->query($sql);

if (!$res || $res->num_rows === 0) {
    die("Préstamo no encontrado");
}

$data = $res->fetch_assoc();
$saldo = $data['total_pagar'] - $data['pagado'];

if ($monto_pagado > $saldo) {
    die("El monto excede el saldo");
}

// ============================
// REGISTRAR PAGO
// ============================
$conexion->query("
    INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado)
    VALUES ($id_prestamo, '$fecha_pago', $monto_pagado)
");

// ============================
// ACTUALIZAR PRÉSTAMO
// ============================
$nuevo_total_pagado = $data['pagado'] + $monto_pagado;
$nuevo_saldo = $data['total_pagar'] - $nuevo_total_pagado;

$conexion->query("
    UPDATE prestamos
    SET total_pagado = $nuevo_total_pagado,
        saldo_actual = $nuevo_saldo
    WHERE id_prestamo = $id_prestamo
");

// ============================
// MARCAR COMO PAGADO SI LIQUIDA
// ============================
if ($nuevo_saldo <= 0) {
    $conexion->query("
        UPDATE prestamos
        SET estado = 'PAGADO',
            fecha_liquidacion = '$fecha_pago'
        WHERE id_prestamo = $id_prestamo
    ");
}

// ============================
// REGISTRAR EN CAJA
// ============================
$id_empleado = $_SESSION['id_empleado'];

$conexion->query("
    INSERT INTO caja (tipo, monto, concepto, id_empleado, fecha, id_prestamo)
    VALUES ('ENTRADA', $monto_pagado, 'Pago individual', $id_empleado, '$fecha_pago', $id_prestamo)
");

// ============================
// REDIRECCIÓN
// ============================
header("Location: cobranza_diaria.php?fecha=".$fecha_pago."&pago=ok");
exit;
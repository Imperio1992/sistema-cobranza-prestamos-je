<style>

.sidebar{
    width:230px;
    height:100vh;
    position:fixed;
    background:#1e293b;
    color:white;
    padding:20px;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:10px;
    border-radius:8px;
    margin-bottom:8px;
}

.sidebar a:hover{
    background:#334155;
    color:white;
}

.content{
    margin-left:250px;
    padding:20px;
}

body{
    background:#f4f6f9;
}

</style>
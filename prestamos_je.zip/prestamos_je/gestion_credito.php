<?php
session_start();
include("conexion.php");

/* =========================
   VALIDAR SOLO SESIÓN ACTIVA
=========================*/
if (!isset($_SESSION['usuario'])) {
    die("Debe iniciar sesión");
}

if (!isset($_GET['id'])) {
    die("Crédito no especificado");
}

$id_prestamo = (int)$_GET['id'];

/* =========================
   EDITAR PAGO
=========================*/
if (isset($_POST['editar_pago'])) {

    $id_pago = (int)$_POST['id_pago'];
    $nuevo_monto = (float)$_POST['nuevo_monto'];

    $stmt = $conexion->prepare("UPDATE pagos SET monto_pagado=? WHERE id_pago=? AND id_prestamo=?");
    $stmt->bind_param("dii", $nuevo_monto, $id_pago, $id_prestamo);
    $stmt->execute();

    $conexion->query("
        UPDATE prestamos 
        SET total_pagado = (SELECT IFNULL(SUM(monto_pagado),0) 
                            FROM pagos WHERE id_prestamo=$id_prestamo)
        WHERE id_prestamo=$id_prestamo
    ");

    $conexion->query("
        INSERT INTO historial_movimientos 
        (id_prestamo,tipo,descripcion,usuario)
        VALUES 
        ($id_prestamo,'EDICION PAGO',
        'Se modificó el pago ID $id_pago',
        '".$_SESSION['usuario']."')
    ");

    header("Location: gestion_credito.php?id=$id_prestamo");
    exit;
}

/* =========================
   ELIMINAR PAGO
=========================*/
if (isset($_GET['eliminar_pago'])) {

    $id_pago = (int)$_GET['eliminar_pago'];

    $stmt = $conexion->prepare("DELETE FROM pagos WHERE id_pago=? AND id_prestamo=?");
    $stmt->bind_param("ii",$id_pago,$id_prestamo);
    $stmt->execute();

    $conexion->query("
        UPDATE prestamos 
        SET total_pagado = (SELECT IFNULL(SUM(monto_pagado),0) 
                            FROM pagos WHERE id_prestamo=$id_prestamo)
        WHERE id_prestamo=$id_prestamo
    ");

    $conexion->query("
        INSERT INTO historial_movimientos 
        (id_prestamo,tipo,descripcion,usuario)
        VALUES 
        ($id_prestamo,'ELIMINACION PAGO',
        'Se eliminó pago ID $id_pago',
        '".$_SESSION['usuario']."')
    ");

    header("Location: gestion_credito.php?id=$id_prestamo");
    exit;
}

/* =========================
   MIGRAR ASESOR
=========================*/
if (isset($_POST['migrar_asesor'])) {

    $nuevo_asesor = (int)$_POST['nuevo_asesor'];

    $stmt = $conexion->prepare("UPDATE prestamos SET id_empleado=? WHERE id_prestamo=?");
    $stmt->bind_param("ii",$nuevo_asesor,$id_prestamo);
    $stmt->execute();

    $conexion->query("
        INSERT INTO historial_movimientos 
        (id_prestamo,tipo,descripcion,usuario)
        VALUES 
        ($id_prestamo,'MIGRACION',
        'Migrado al asesor ID $nuevo_asesor',
        '".$_SESSION['usuario']."')
    ");

    header("Location: gestion_credito.php?id=$id_prestamo");
    exit;
}

/* =========================
   OBTENER DATOS COMPLETOS
=========================*/
$stmt = $conexion->prepare("
SELECT p.*, 
       c.nombre AS nombre_cliente,
       c.apellido AS apellido_cliente,
       c.telefono,
       c.direccion,
       e.nombre AS nombre_asesor,
       e.apellido AS apellido_asesor
FROM prestamos p
LEFT JOIN clientes c ON p.id_cliente=c.id_cliente
LEFT JOIN empleados e ON p.id_empleado=e.id_empleado
WHERE p.id_prestamo=?
");
$stmt->bind_param("i",$id_prestamo);
$stmt->execute();
$credito = $stmt->get_result()->fetch_assoc();

if(!$credito) die("Crédito no encontrado");

/* =========================
   CÁLCULOS
=========================*/
$monto_total  = $credito['monto_total'];
$total_pagado = $credito['total_pagado'];
$saldo_actual = max($monto_total - $total_pagado,0);
$estado       = $credito['estado'];

/* SINCRONIZAR ESTADO */
if ($saldo_actual <= 0 && $estado != 'PAGADO') {
    $conexion->query("
        UPDATE prestamos 
        SET estado='PAGADO',
            fecha_liquidacion=CURDATE(),
            saldo_actual=0
        WHERE id_prestamo=$id_prestamo
    ");
    $estado="PAGADO";
}

if ($saldo_actual > 0 && $estado == 'PAGADO') {
    $conexion->query("
        UPDATE prestamos 
        SET estado='ACTIVO',
            fecha_liquidacion=NULL
        WHERE id_prestamo=$id_prestamo
    ");
    $estado="ACTIVO";
}

$conexion->query("
    UPDATE prestamos 
    SET saldo_actual=$saldo_actual
    WHERE id_prestamo=$id_prestamo
");

function money($v){ return "$".number_format((float)$v,2); }

/* =========================
   PAGOS
=========================*/
$pagos = $conexion->query("
SELECT * FROM pagos 
WHERE id_prestamo=$id_prestamo 
ORDER BY cuota_numero ASC
");

$pagos_array=[];
while($p=$pagos->fetch_assoc()){
    $pagos_array[$p['cuota_numero']]=$p;
}

/* =========================
   BITACORA
=========================*/
$historial = $conexion->query("
SELECT * FROM historial_movimientos 
WHERE id_prestamo=$id_prestamo 
ORDER BY fecha DESC
");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Gestión Crédito</title>
<style>
body{font-family:Segoe UI;background:#f4f6f9;margin:0}
.container{max-width:1200px;margin:40px auto}
.card{background:white;padding:30px;border-radius:12px;box-shadow:0 5px 20px rgba(0,0,0,0.08)}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.box{background:#f8f9fa;padding:18px;border-radius:10px;border-left:5px solid #2c7be5}
.money{color:#2c7be5;font-weight:bold}
.estado{padding:6px 12px;border-radius:20px;color:white;font-size:12px;font-weight:bold}
.ACTIVO{background:#28a745}
.PAGADO{background:#007bff}
table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:10px;border-bottom:1px solid #ddd;text-align:center}
th{background:#2c7be5;color:white}
button{padding:6px 12px;border:none;border-radius:6px;color:white;cursor:pointer}
</style>
</head>
<body>
<div class="container">
<div class="card">

<h2>
Gestión Crédito #<?php echo $id_prestamo; ?>
<span class="estado <?php echo $estado; ?>">
<?php echo $estado; ?>
</span>
</h2>

<div class="grid">
<div class="box"><b>Cliente</b><br><?php echo $credito['nombre_cliente']." ".$credito['apellido_cliente']; ?></div>
<div class="box"><b>Teléfono</b><br><?php echo $credito['telefono']; ?></div>
<div class="box"><b>Dirección</b><br><?php echo $credito['direccion']; ?></div>
<div class="box"><b>Total</b><br><span class="money"><?php echo money($monto_total); ?></span></div>
<div class="box"><b>Pagado</b><br><span class="money"><?php echo money($total_pagado); ?></span></div>
<div class="box"><b>Saldo</b><br><span class="money"><?php echo money($saldo_actual); ?></span></div>
</div>

<h3>Historial Pagos</h3>
<table>
<tr><th>Cuota</th><th>Monto</th><th>Fecha</th><th>Acción</th></tr>
<?php foreach($pagos_array as $p): ?>
<tr>
<td><?php echo $p['cuota_numero']; ?></td>
<td><?php echo money($p['monto_pagado']); ?></td>
<td><?php echo $p['fecha_pago']; ?></td>
<td>
<a href="gestion_credito.php?id=<?php echo $id_prestamo; ?>&eliminar_pago=<?php echo $p['id_pago']; ?>">
<button style="background:#dc3545;">Eliminar</button>
</a>
</td>
</tr>
<?php endforeach; ?>
</table>

</div>
</div>
</body>
</html>
<?php
session_start();
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

if (!isset($_SESSION['rol']) || !in_array($_SESSION['rol'], ['GERENTE','SUPERVISOR'])) {
    header("Location: index.php"); exit;
}

$rol_actual  = $_SESSION['rol'];
$usuario_yo  = $_SESSION['usuario']    ?? 'Usuario';
$id_usuario  = intval($_SESSION['id_usuario'] ?? 0);
$error       = '';
$exito       = '';

$ext_permitidas = ['jpg','jpeg','png','pdf','webp'];
$max_bytes      = 5 * 1024 * 1024;
$tipos_doc      = [
    'ine_frente'  => 'INE_FRENTE',
    'ine_reverso' => 'INE_REVERSO',
    'comprobante' => 'COMPROBANTE'
];

// ── SUBIR / REEMPLAZAR DOCUMENTO ──
if (isset($_POST['accion']) && $_POST['accion'] === 'subir_doc') {
    $id_cliente = intval($_POST['id_cliente'] ?? 0);
    $campo      = $_POST['campo'] ?? '';
    $tipo_enum  = $tipos_doc[$campo] ?? '';

    if ($id_cliente && $tipo_enum && isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['archivo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $ext_permitidas)) {
            $err_redir = 'Formato no permitido. Usa JPG, PNG o PDF.';
        } elseif ($_FILES['archivo']['size'] > $max_bytes) {
            $err_redir = 'El archivo supera los 5 MB.';
        } else {
            $dir_base = __DIR__ . "/uploads/clientes/$id_cliente/";
            if (!is_dir($dir_base)) mkdir($dir_base, 0755, true);

            $nombre_archivo = $tipo_enum . '_' . time() . '.' . $ext;
            $ruta_relativa  = "uploads/clientes/$id_cliente/$nombre_archivo";

            if (move_uploaded_file($_FILES['archivo']['tmp_name'], $dir_base . $nombre_archivo)) {
                // Borrar archivo anterior del mismo tipo
                $del = $conexion->prepare("SELECT ruta_archivo FROM documentos_cliente WHERE id_cliente=? AND tipo=? LIMIT 1");
                $del->bind_param("is", $id_cliente, $tipo_enum);
                $del->execute();
                $old = $del->get_result()->fetch_assoc();
                $del->close();
                if ($old && file_exists(__DIR__ . '/' . $old['ruta_archivo'])) {
                    unlink(__DIR__ . '/' . $old['ruta_archivo']);
                }
                // Borrar registro anterior e insertar nuevo
                $del2 = $conexion->prepare("DELETE FROM documentos_cliente WHERE id_cliente=? AND tipo=?");
                $del2->bind_param("is", $id_cliente, $tipo_enum);
                $del2->execute();
                $del2->close();

                $ins = $conexion->prepare("
                    INSERT INTO documentos_cliente (id_cliente, tipo, nombre_archivo, ruta_archivo, id_empleado)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $ins->bind_param("isssi", $id_cliente, $tipo_enum, $nombre_archivo, $ruta_relativa, $id_usuario);
                $ins->execute();
                $ins->close();
                header("Location: editar_cliente.php?id=$id_cliente&ok_doc=1");
                exit;
            } else {
                $err_redir = 'Error al mover el archivo. Verifica permisos de uploads/.';
            }
        }
    } else {
        $err_redir = 'No se recibió ningún archivo válido.';
    }
    header("Location: editar_cliente.php?id=" . intval($_POST['id_cliente']) . "&err=" . urlencode($err_redir ?? ''));
    exit;
}

// ── ELIMINAR DOCUMENTO ──
if (isset($_GET['del_doc']) && isset($_GET['id'])) {
    $id_doc     = intval($_GET['del_doc']);
    $id_cliente = intval($_GET['id']);
    $del = $conexion->prepare("SELECT ruta_archivo FROM documentos_cliente WHERE id_doc=? AND id_cliente=? LIMIT 1");
    $del->bind_param("ii", $id_doc, $id_cliente);
    $del->execute();
    $old = $del->get_result()->fetch_assoc();
    $del->close();
    if ($old) {
        if (file_exists(__DIR__ . '/' . $old['ruta_archivo'])) unlink(__DIR__ . '/' . $old['ruta_archivo']);
        $r = $conexion->prepare("DELETE FROM documentos_cliente WHERE id_doc=?");
        $r->bind_param("i", $id_doc);
        $r->execute();
        $r->close();
    }
    header("Location: editar_cliente.php?id=$id_cliente&ok_doc=1");
    exit;
}

// ── GUARDAR DATOS DEL CLIENTE ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['accion'])) {
    $id_cliente       = intval($_POST['id_cliente']);
    $curp_ine         = trim($_POST['curp_ine']         ?? '');
    $nombre           = trim($_POST['nombre']);
    $apellido         = trim($_POST['apellido']);
    $fecha_nacimiento = $_POST['fecha_nacimiento']      ?? '';
    $direccion        = trim($_POST['direccion']);
    $num_exterior     = trim($_POST['numero_exterior'])  ?: 'S/N';
    $colonia          = trim($_POST['colonia']);
    $telefono         = trim($_POST['telefono']);
    $negocio          = trim($_POST['negocio']          ?? '');
    $observaciones    = trim($_POST['observaciones']    ?? '');
    $autoriza_credito = $_POST['autoriza_credito'];
    $id_asesor        = intval($_POST['id_asesor']);

    if ($rol_actual === 'GERENTE') {
        $fecha_registro = $_POST['fecha_registro'];
    } else {
        $tmp = $conexion->prepare("SELECT fecha_registro FROM clientes WHERE id_cliente = ?");
        $tmp->bind_param("i", $id_cliente);
        $tmp->execute();
        $fecha_registro = $tmp->get_result()->fetch_assoc()['fecha_registro'];
        $tmp->close();
    }

    $stmt = $conexion->prepare("
        UPDATE clientes SET
            curp_ine=?, nombre=?, apellido=?, fecha_nacimiento=?,
            direccion=?, numero_exterior=?, colonia=?, telefono=?,
            negocio=?, observaciones=?, autoriza_credito=?, id_asesor=?, fecha_registro=?
        WHERE id_cliente=?
    ");
    $stmt->bind_param("sssssssssssisi",
        $curp_ine, $nombre, $apellido, $fecha_nacimiento,
        $direccion, $num_exterior, $colonia, $telefono,
        $negocio, $observaciones, $autoriza_credito, $id_asesor, $fecha_registro,
        $id_cliente
    );
    if ($stmt->execute()) {
        header("Location: clientes.php?ok=1"); exit;
    } else {
        $error = 'Error al actualizar el cliente. Intenta de nuevo.';
    }
}

// ── CARGAR CLIENTE ──
$id_cliente = intval($_GET['id'] ?? $_POST['id_cliente'] ?? 0);
if (!$id_cliente) { header("Location: clientes.php"); exit; }

$stmt = $conexion->prepare("SELECT * FROM clientes WHERE id_cliente = ? LIMIT 1");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();
if (!$c) { header("Location: clientes.php"); exit; }

$asesores = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido
    FROM empleados e
    INNER JOIN usuarios u ON u.id_empleado = e.id_empleado
    WHERE u.rol = 'ASESOR' AND e.estatus = 'ACTIVO'
    ORDER BY e.apellido, e.nombre
");

// ── CARGAR DOCUMENTOS EXISTENTES ──
$q_docs = $conexion->prepare("SELECT * FROM documentos_cliente WHERE id_cliente = ? ORDER BY tipo");
$q_docs->bind_param("i", $id_cliente);
$q_docs->execute();
$docs_result = $q_docs->get_result();
$docs_existentes = [];
while ($d = $docs_result->fetch_assoc()) {
    $docs_existentes[$d['tipo']] = $d;
}
$q_docs->close();

if (!$error && isset($_GET['err']))    $error = htmlspecialchars(urldecode($_GET['err']));
if (!$exito && isset($_GET['ok_doc'])) $exito = 'Documento actualizado correctamente.';
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Editar Cliente — Préstamos J.E.</title>
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ══ SIDEBAR ══ */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ══ MAIN ══ */
.main { margin-left:240px; flex:1; padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-title { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:2px; display:flex; align-items:center; gap:6px; }
.topbar-sub a { color:#64748b; text-decoration:none; }
.topbar-sub a:hover { color:#2563eb; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.btn-back {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 14px; color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,.05);
}
.btn-back:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.btn-theme {
    width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0;
    background:white; color:#64748b; cursor:pointer;
    display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s;
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── FLASH ── */
.flash { border-radius:12px; padding:12px 18px; margin-bottom:20px; font-size:.85rem; font-weight:600; display:flex; align-items:center; gap:8px; }
.flash.error { background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; }
.flash.exito { background:#f0fdf4; border:1px solid #86efac; color:#166534; }
.flash.warn  { background:#fffbeb; border:1px solid #fde68a; color:#92400e; }

/* ── FORM CARDS ── */
.form-card {
    background:white; border-radius:16px; margin-bottom:16px;
    box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #f1f5f9; overflow:hidden;
}
.form-card-header {
    padding:16px 22px; border-bottom:1px solid #f1f5f9;
    display:flex; align-items:center; gap:12px;
}
.fch-icon {
    width:38px; height:38px; border-radius:10px;
    display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0;
}
.fch-icon.amber  { background:#fffbeb; color:#d97706; }
.fch-icon.blue   { background:#eff6ff; color:#2563eb; }
.fch-icon.slate  { background:#f8fafc; color:#475569; }
.fch-icon.green  { background:#f0fdf4; color:#16a34a; }
.fch-icon.purple { background:#faf5ff; color:#7c3aed; }
.fch-title { font-size:.95rem; font-weight:800; color:#0f172a; }
.fch-sub   { font-size:.75rem; color:#94a3b8; margin-top:2px; }
.badge-id  { background:#f1f5f9; color:#475569; font-size:.78rem; padding:4px 12px; border-radius:20px; font-weight:700; margin-left:auto; }

.form-card-body { padding:22px; }

/* ── GRID FIELDS ── */
.form-row    { display:grid; gap:14px; margin-bottom:14px; }
.form-row:last-child { margin-bottom:0; }
.form-row.c2 { grid-template-columns:1fr 1fr; }
.form-row.c3 { grid-template-columns:1fr 1fr 1fr; }

.field label {
    display:block; font-size:.72rem; font-weight:700; color:#475569;
    text-transform:uppercase; letter-spacing:.05em; margin-bottom:6px;
}
.field label .req { color:#dc2626; }
.field label .opc { font-weight:400; text-transform:none; color:#94a3b8; letter-spacing:0; }
.field input,
.field select,
.field textarea {
    width:100%; border:1.5px solid #e2e8f0; border-radius:9px;
    padding:10px 13px; font-size:.87rem; color:#1e293b;
    font-family:'Inter',sans-serif; background:#f8fafc;
    outline:none; transition:border-color .15s, background .15s;
}
.field input:focus,
.field select:focus,
.field textarea:focus { border-color:#d97706; background:white; box-shadow:0 0 0 3px rgba(217,119,6,.08); }
.field input:disabled { background:#f1f5f9; color:#94a3b8; cursor:not-allowed; }
.field textarea { resize:vertical; min-height:90px; }
.field .hint { font-size:.72rem; color:#94a3b8; margin-top:5px; display:flex; align-items:center; gap:4px; }

/* ── CREDITO RADIOS ── */
.radio-group { display:flex; gap:10px; }
.radio-pill {
    flex:1; display:flex; align-items:center; justify-content:center; gap:7px;
    border:2px solid #e2e8f0; border-radius:10px; padding:10px;
    font-size:.84rem; font-weight:700; cursor:pointer; transition:all .15s;
    background:#f8fafc; color:#64748b;
}
.radio-pill input { display:none; }
.radio-pill.si  { border-color:#bbf7d0; }
.radio-pill.no  { border-color:#fecaca; }
.radio-pill.si:has(input:checked)  { background:#16a34a; color:white; border-color:#16a34a; }
.radio-pill.no:has(input:checked)  { background:#dc2626; color:white; border-color:#dc2626; }

/* ── FORM ACTIONS ── */
.form-actions {
    display:flex; justify-content:space-between; align-items:center;
    padding:18px 22px; border-top:1px solid #f1f5f9;
    background:#fafafa;
}
.btn-save {
    display:inline-flex; align-items:center; gap:8px;
    background:#d97706; color:white; border:none; border-radius:10px;
    padding:10px 24px; font-size:.88rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:background .15s;
}
.btn-save:hover { background:#b45309; }
.btn-cancel {
    display:inline-flex; align-items:center; gap:8px;
    background:#f1f5f9; color:#475569; border:none; border-radius:10px;
    padding:10px 20px; font-size:.88rem; font-weight:600; cursor:pointer;
    font-family:'Inter',sans-serif; text-decoration:none; transition:all .15s;
}
.btn-cancel:hover { background:#e2e8f0; color:#1e293b; }

/* ── AVISO GERENTE ── */
.gerente-badge {
    display:inline-flex; align-items:center; gap:6px;
    background:#fffbeb; border:1px solid #fde68a; border-radius:8px;
    padding:5px 12px; font-size:.75rem; font-weight:700; color:#92400e; margin-bottom:16px;
}

/* ── DOCUMENTOS ── */
.docs-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }
.doc-card {
    border:1.5px solid #e2e8f0; border-radius:14px; overflow:hidden;
    background:#fafafa; transition:box-shadow .15s;
}
.doc-card:hover { box-shadow:0 4px 14px rgba(0,0,0,.08); }
.doc-card-head {
    padding:12px 14px; background:#f8fafc; border-bottom:1px solid #f1f5f9;
    display:flex; align-items:center; gap:8px;
}
.doc-card-head i  { font-size:1.1rem; }
.doc-tipo { font-size:.78rem; font-weight:700; color:#0f172a; text-transform:uppercase; letter-spacing:.04em; }
.doc-badge-ok { margin-left:auto; background:#dcfce7; color:#166534; font-size:.68rem; font-weight:700; border-radius:20px; padding:2px 9px; }
.doc-badge-no { margin-left:auto; background:#f1f5f9; color:#94a3b8; font-size:.68rem; font-weight:700; border-radius:20px; padding:2px 9px; }
.doc-card-body { padding:14px; }
.doc-thumb {
    width:100%; height:110px; object-fit:cover; border-radius:8px;
    border:1px solid #e2e8f0; margin-bottom:10px; background:#e2e8f0;
    display:block; cursor:pointer;
}
.doc-thumb-pdf {
    width:100%; height:110px; border-radius:8px;
    border:1px solid #fecaca; margin-bottom:10px; background:#fff1f2;
    display:flex; flex-direction:column; align-items:center; justify-content:center; gap:4px;
    color:#b91c1c; font-size:.82rem; font-weight:600; cursor:pointer; text-decoration:none;
}
.doc-thumb-pdf i { font-size:2rem; }
.doc-vacio {
    width:100%; height:110px; border-radius:8px; border:2px dashed #e2e8f0;
    margin-bottom:10px; background:#f8fafc;
    display:flex; flex-direction:column; align-items:center; justify-content:center; gap:4px;
    color:#94a3b8; font-size:.78rem;
}
.doc-vacio i { font-size:1.8rem; }
.doc-meta { font-size:.7rem; color:#94a3b8; margin-bottom:10px; display:flex; align-items:center; gap:4px; }
.doc-acciones { display:flex; gap:6px; flex-wrap:wrap; }
.btn-doc {
    flex:1; min-width:50px; display:inline-flex; align-items:center; justify-content:center; gap:5px;
    border-radius:8px; padding:7px 8px; font-size:.74rem; font-weight:700;
    text-decoration:none; cursor:pointer; border:none; font-family:'Inter',sans-serif;
    transition:all .15s;
}
.btn-doc.ver      { background:#eff6ff; color:#2563eb; }
.btn-doc.ver:hover { background:#dbeafe; }
.btn-doc.dl       { background:#f0fdf4; color:#16a34a; }
.btn-doc.dl:hover { background:#dcfce7; }
.btn-doc.del      { background:#fef2f2; color:#b91c1c; flex:0 0 auto; }
.btn-doc.del:hover { background:#fecaca; }
.btn-doc.subir    { background:#faf5ff; color:#7c3aed; }
.btn-doc.subir:hover { background:#ede9fe; }

/* ── Upload inline ── */
.upload-form { margin-top:10px; display:none; }
.upload-form.abierto { display:block; }
.upload-form input[type="file"] {
    width:100%; border:1.5px dashed #a78bfa; border-radius:8px;
    padding:8px 10px; font-size:.78rem; color:#7c3aed; background:#faf5ff;
    cursor:pointer; outline:none;
}
.btn-upload-enviar {
    margin-top:8px; width:100%;
    display:flex; align-items:center; justify-content:center; gap:6px;
    background:#7c3aed; color:white; border:none; border-radius:8px;
    padding:8px; font-size:.78rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:background .15s;
}
.btn-upload-enviar:hover { background:#6d28d9; }

/* ══ DARK MODE ══ */
[data-theme="dark"] body          { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-title { color:#f8fafc; }
[data-theme="dark"] .topbar-sub   { color:#64748b; }
[data-theme="dark"] .btn-back     { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-theme    { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .form-card    { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .form-card-header { border-color:#334155; }
[data-theme="dark"] .fch-title    { color:#f1f5f9; }
[data-theme="dark"] .field label  { color:#94a3b8; }
[data-theme="dark"] .field input,
[data-theme="dark"] .field select,
[data-theme="dark"] .field textarea { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .field input:focus,
[data-theme="dark"] .field select:focus,
[data-theme="dark"] .field textarea:focus { border-color:#d97706; background:#1e293b; }
[data-theme="dark"] .field input:disabled { background:#162032; color:#475569; }
[data-theme="dark"] .form-actions { background:#162032; border-color:#334155; }
[data-theme="dark"] .btn-cancel   { background:#0f172a; color:#94a3b8; }
[data-theme="dark"] .btn-cancel:hover { background:#334155; color:#e2e8f0; }
[data-theme="dark"] .badge-id     { background:#334155; color:#94a3b8; }
[data-theme="dark"] .radio-pill   { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .fch-icon.amber  { background:rgba(217,119,6,.15); }
[data-theme="dark"] .fch-icon.blue   { background:rgba(37,99,235,.15); }
[data-theme="dark"] .fch-icon.slate  { background:#162032; }
[data-theme="dark"] .fch-icon.green  { background:rgba(22,163,74,.15); }
[data-theme="dark"] .fch-icon.purple { background:rgba(124,58,237,.15); }
[data-theme="dark"] .doc-card     { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .doc-card-head { background:#162032; border-color:#334155; }
[data-theme="dark"] .doc-tipo     { color:#e2e8f0; }
[data-theme="dark"] .doc-vacio    { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .flash.exito  { background:rgba(22,163,74,.1); border-color:rgba(134,239,172,.3); color:#4ade80; }
[data-theme="dark"] .flash.error  { background:rgba(153,27,27,.15); border-color:rgba(252,165,165,.3); color:#fca5a5; }

@media (max-width:900px) {
    .sidebar   { display:none; }
    .main      { margin-left:0; padding:14px 14px 80px; }
    .form-row.c2, .form-row.c3 { grid-template-columns:1fr; }
    .docs-grid { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($usuario_yo, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($usuario_yo) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <div class="sb-section">Clientes</div>
        <a href="clientes.php" class="active"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Atrasados</a>
        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja General</a>
        <a href="caja_asesor.php"><i class="bi bi-wallet2"></i> Caja Asesor</a>
        <a href="caja_asesores.php"><i class="bi bi-people-fill"></i> Resumen Asesores</a>
        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <div>
                <div class="topbar-title">
                    <i class="bi bi-pencil-square" style="color:#d97706;"></i>
                    Editar Cliente
                </div>
                <div class="topbar-sub">
                    <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                    <i class="bi bi-chevron-right"></i>
                    <span><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></span>
                    <i class="bi bi-chevron-right"></i>
                    <span>Editar</span>
                </div>
            </div>
        </div>
        <div class="topbar-right">
            <a href="clientes.php" class="btn-back"><i class="bi bi-arrow-left"></i> Volver</a>
            <button class="btn-theme" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="flash error"><i class="bi bi-x-circle-fill"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($exito): ?>
    <div class="flash exito"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <?php if ($rol_actual === 'GERENTE'): ?>
    <div class="gerente-badge">
        <i class="bi bi-shield-fill-check"></i> Modo Gerente — puedes modificar la fecha de registro
    </div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="id_cliente" value="<?= $c['id_cliente'] ?>">

        <!-- ── Identificación ── -->
        <div class="form-card">
            <div class="form-card-header">
                <div class="fch-icon amber"><i class="bi bi-person-badge-fill"></i></div>
                <div>
                    <div class="fch-title">Identificación personal</div>
                    <div class="fch-sub">Nombre, fecha de nacimiento y CURP/INE</div>
                </div>
                <span class="badge-id"># <?= $c['id_cliente'] ?></span>
            </div>
            <div class="form-card-body">
                <div class="form-row c3">
                    <div class="field">
                        <label>Nombre <span class="req">*</span></label>
                        <input type="text" name="nombre" required value="<?= htmlspecialchars($c['nombre']) ?>">
                    </div>
                    <div class="field">
                        <label>Apellido <span class="req">*</span></label>
                        <input type="text" name="apellido" required value="<?= htmlspecialchars($c['apellido']) ?>">
                    </div>
                    <div class="field">
                        <label>Fecha de nacimiento <span class="opc">(opcional)</span></label>
                        <input type="date" name="fecha_nacimiento" value="<?= htmlspecialchars($c['fecha_nacimiento'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-row c2">
                    <div class="field">
                        <label>CURP / INE <span class="opc">(opcional)</span></label>
                        <input type="text" name="curp_ine" value="<?= htmlspecialchars($c['curp_ine'] ?? '') ?>" placeholder="18 caracteres CURP o número INE">
                    </div>
                    <div class="field">
                        <label>Teléfono <span class="req">*</span></label>
                        <input type="tel" name="telefono" required value="<?= htmlspecialchars($c['telefono']) ?>" placeholder="10 dígitos">
                    </div>
                </div>
            </div>
        </div>

        <!-- ── Domicilio ── -->
        <div class="form-card">
            <div class="form-card-header">
                <div class="fch-icon blue"><i class="bi bi-geo-alt-fill"></i></div>
                <div>
                    <div class="fch-title">Domicilio</div>
                    <div class="fch-sub">Calle, número exterior y colonia</div>
                </div>
            </div>
            <div class="form-card-body">
                <div class="form-row c2">
                    <div class="field">
                        <label>Calle / Dirección <span class="req">*</span></label>
                        <input type="text" name="direccion" required value="<?= htmlspecialchars($c['direccion']) ?>" placeholder="Nombre de la calle">
                    </div>
                    <div class="field">
                        <label>Núm. exterior <span class="opc">(o S/N)</span></label>
                        <input type="text" name="numero_exterior" value="<?= htmlspecialchars($c['numero_exterior'] ?? '') ?>" placeholder="S/N">
                    </div>
                </div>
                <div class="form-row">
                    <div class="field">
                        <label>Colonia <span class="req">*</span></label>
                        <input type="text" name="colonia" required value="<?= htmlspecialchars($c['colonia']) ?>" placeholder="Nombre de la colonia">
                    </div>
                </div>
            </div>
        </div>

        <!-- ── Información adicional ── -->
        <div class="form-card">
            <div class="form-card-header">
                <div class="fch-icon slate"><i class="bi bi-info-circle-fill"></i></div>
                <div>
                    <div class="fch-title">Información adicional</div>
                    <div class="fch-sub">Negocio, observaciones y crédito</div>
                </div>
            </div>
            <div class="form-card-body">
                <div class="form-row c2">
                    <div class="field">
                        <label>Negocio <span class="opc">(opcional)</span></label>
                        <input type="text" name="negocio" value="<?= htmlspecialchars($c['negocio'] ?? '') ?>" placeholder="Nombre o tipo de negocio">
                    </div>
                    <div class="field">
                        <label>¿Autoriza crédito?</label>
                        <div class="radio-group">
                            <label class="radio-pill si">
                                <input type="radio" name="autoriza_credito" value="SI" <?= ($c['autoriza_credito'] === 'SI') ? 'checked' : '' ?>>
                                <i class="bi bi-check-circle-fill"></i> Sí
                            </label>
                            <label class="radio-pill no">
                                <input type="radio" name="autoriza_credito" value="NO" <?= ($c['autoriza_credito'] === 'NO') ? 'checked' : '' ?>>
                                <i class="bi bi-x-circle-fill"></i> No
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="field">
                        <label>Observaciones <span class="opc">(opcional)</span></label>
                        <textarea name="observaciones" placeholder="Notas sobre el cliente..."><?= htmlspecialchars($c['observaciones'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- ── Asignación ── -->
        <div class="form-card">
            <div class="form-card-header">
                <div class="fch-icon green"><i class="bi bi-person-check-fill"></i></div>
                <div>
                    <div class="fch-title">Asignación y registro</div>
                    <div class="fch-sub">Asesor asignado y fecha de alta</div>
                </div>
            </div>
            <div class="form-card-body">
                <div class="form-row <?= $rol_actual === 'GERENTE' ? 'c2' : '' ?>">
                    <div class="field">
                        <label>Asesor asignado <span class="req">*</span></label>
                        <select name="id_asesor" required>
                            <option value="">— Seleccionar asesor —</option>
                            <?php while ($a = $asesores->fetch_assoc()): ?>
                            <option value="<?= $a['id_empleado'] ?>" <?= ($a['id_empleado'] == $c['id_asesor']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($a['nombre'].' '.$a['apellido']) ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <?php if ($rol_actual === 'GERENTE'): ?>
                    <div class="field">
                        <label>Fecha de registro <span class="req">*</span></label>
                        <input type="date" name="fecha_registro" value="<?= htmlspecialchars($c['fecha_registro'] ?? '') ?>" required>
                        <div class="hint"><i class="bi bi-shield-fill"></i> Solo visible para Gerente</div>
                    </div>
                    <?php else: ?>
                    <div class="field">
                        <label>Fecha de registro</label>
                        <input type="text" value="<?= htmlspecialchars($c['fecha_registro'] ?? '—') ?>" disabled>
                        <div class="hint"><i class="bi bi-lock-fill"></i> Solo el Gerente puede modificar este campo</div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-actions">
                <a href="clientes.php" class="btn-cancel"><i class="bi bi-x-lg"></i> Cancelar</a>
                <button type="submit" class="btn-save"><i class="bi bi-floppy-fill"></i> Guardar cambios</button>
            </div>
        </div>

    </form>

    <!-- ════ DOCUMENTOS ════ -->
    <div class="form-card">
        <div class="form-card-header">
            <div class="fch-icon purple"><i class="bi bi-file-earmark-image-fill"></i></div>
            <div>
                <div class="fch-title">Documentos del cliente</div>
                <div class="fch-sub">Haz clic en "Reemplazar" para actualizar · JPG, PNG o PDF · Máx. 5 MB</div>
            </div>
        </div>
        <div class="form-card-body">
            <div class="docs-grid">

                <?php
                $slots = [
                    'INE_FRENTE'  => ['label'=>'INE Frente',           'icon'=>'bi-person-vcard',      'campo'=>'ine_frente'],
                    'INE_REVERSO' => ['label'=>'INE Reverso',          'icon'=>'bi-person-vcard-fill', 'campo'=>'ine_reverso'],
                    'COMPROBANTE' => ['label'=>'Comprobante domicilio', 'icon'=>'bi-house-door',        'campo'=>'comprobante'],
                ];
                foreach ($slots as $tipo => $info):
                    $doc    = $docs_existentes[$tipo] ?? null;
                    $tiene  = ($doc !== null);
                    $es_img = $doc && preg_match('/\.(jpg|jpeg|png|webp)$/i', $doc['nombre_archivo'] ?? '');
                    $es_pdf = $doc && preg_match('/\.pdf$/i', $doc['nombre_archivo'] ?? '');
                    $fid    = 'upload-' . $info['campo'];
                ?>
                <div class="doc-card">
                    <div class="doc-card-head">
                        <i class="bi <?= $info['icon'] ?>" style="color:<?= $tiene ? '#16a34a' : '#94a3b8' ?>;"></i>
                        <span class="doc-tipo"><?= $info['label'] ?></span>
                        <?php if ($tiene): ?>
                        <span class="doc-badge-ok"><i class="bi bi-check-circle-fill"></i> OK</span>
                        <?php else: ?>
                        <span class="doc-badge-no">Sin archivo</span>
                        <?php endif; ?>
                    </div>
                    <div class="doc-card-body">

                        <?php if ($tiene && $es_img): ?>
                        <a href="<?= htmlspecialchars($doc['ruta_archivo']) ?>" target="_blank">
                            <img class="doc-thumb"
                                 src="<?= htmlspecialchars($doc['ruta_archivo']) ?>"
                                 alt="<?= htmlspecialchars($info['label']) ?>">
                        </a>
                        <?php elseif ($tiene && $es_pdf): ?>
                        <a href="<?= htmlspecialchars($doc['ruta_archivo']) ?>" target="_blank" class="doc-thumb-pdf">
                            <i class="bi bi-file-pdf-fill"></i>
                            <span>Ver PDF</span>
                        </a>
                        <?php else: ?>
                        <div class="doc-vacio">
                            <i class="bi <?= $info['icon'] ?>"></i>
                            <span>Sin documento</span>
                        </div>
                        <?php endif; ?>

                        <?php if ($tiene): ?>
                        <div class="doc-meta">
                            <i class="bi bi-clock"></i>
                            <?= date('d/m/Y H:i', strtotime($doc['fecha_subida'])) ?>
                        </div>
                        <?php endif; ?>

                        <div class="doc-acciones">
                            <?php if ($tiene): ?>
                            <a href="<?= htmlspecialchars($doc['ruta_archivo']) ?>"
                               target="_blank" class="btn-doc ver">
                                <i class="bi bi-eye-fill"></i> Ver
                            </a>
                            <a href="descargar_doc.php?id=<?= $doc['id_doc'] ?>"
                               class="btn-doc dl">
                                <i class="bi bi-download"></i> Descargar
                            </a>
                            <a href="editar_cliente.php?id=<?= $id_cliente ?>&del_doc=<?= $doc['id_doc'] ?>"
                               class="btn-doc del"
                               onclick="return confirm('¿Eliminar este documento? No se puede deshacer.')">
                                <i class="bi bi-trash3-fill"></i>
                            </a>
                            <?php endif; ?>
                            <button type="button" class="btn-doc subir"
                                    onclick="toggleUpload('<?= $fid ?>')">
                                <i class="bi bi-cloud-arrow-up-fill"></i>
                                <?= $tiene ? 'Reemplazar' : 'Subir' ?>
                            </button>
                        </div>

                        <div class="upload-form" id="<?= $fid ?>">
                            <form method="POST" enctype="multipart/form-data"
                                  action="editar_cliente.php?id=<?= $id_cliente ?>">
                                <input type="hidden" name="accion"     value="subir_doc">
                                <input type="hidden" name="id_cliente" value="<?= $id_cliente ?>">
                                <input type="hidden" name="campo"      value="<?= $info['campo'] ?>">
                                <input type="file"   name="archivo"
                                       accept=".jpg,.jpeg,.png,.pdf,.webp" required>
                                <button type="submit" class="btn-upload-enviar">
                                    <i class="bi bi-cloud-arrow-up-fill"></i> Confirmar subida
                                </button>
                            </form>
                        </div>

                    </div>
                </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>

</main>
</div>

<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    var icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    var n = new Date(), pad = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = pad(n.getHours())+':'+pad(n.getMinutes())+':'+pad(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

function toggleUpload(id) {
    var el = document.getElementById(id);
    if (el) el.classList.toggle('abierto');
}
</script>
</body>
</html>

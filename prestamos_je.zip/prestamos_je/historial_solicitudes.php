<?php
include("seguridad.php");
include("conexion.php");
date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';

// ── Filtros ───────────────────────────────────────────────────────
$f_estado  = $_GET['estado']  ?? 'TODOS';
$f_buscar  = $conexion->real_escape_string($_GET['buscar'] ?? '');
$f_fecha_i = $_GET['fecha_i'] ?? '';
$f_fecha_f = $_GET['fecha_f'] ?? '';
$f_asesor  = (int)($_GET['id_empleado'] ?? 0);

$where = "WHERE 1=1";
if ($f_estado !== 'TODOS' && $f_estado !== '')
    $where .= " AND s.estado = '$f_estado'";
if ($f_buscar)
    $where .= " AND (CONCAT(c.nombre,' ',c.apellido) LIKE '%$f_buscar%'
                  OR c.telefono LIKE '%$f_buscar%')";
if ($f_fecha_i)
    $where .= " AND DATE(s.fecha_solicitud) >= '$f_fecha_i'";
if ($f_fecha_f)
    $where .= " AND DATE(s.fecha_solicitud) <= '$f_fecha_f'";
if ($f_asesor > 0)
    $where .= " AND s.id_empleado = $f_asesor";

$solicitudes = $conexion->query("
    SELECT s.*,
           CONCAT(c.nombre,' ',c.apellido)  AS nombre_cliente,
           c.telefono,
           CONCAT(e.nombre,' ',e.apellido)  AS nombre_asesor
    FROM   solicitudes s
    JOIN   clientes    c ON c.id_cliente  = s.id_cliente
    JOIN   empleados   e ON e.id_empleado = s.id_empleado
    $where
    ORDER  BY s.fecha_solicitud DESC
    LIMIT  200
");

// Contadores por estado
$cnts = [];
foreach (['PENDIENTE','APROBADA','RECHAZADA','CANCELADA'] as $est) {
    $r = $conexion->query("SELECT COUNT(*) n FROM solicitudes WHERE estado='$est'")->fetch_assoc();
    $cnts[$est] = (int)$r['n'];
}
$cnts['TODOS'] = array_sum($cnts);

// Totales de la consulta actual
$tot_monto = 0; $tot_rows = 0;
$rows_buf  = [];
if ($solicitudes) {
    while ($r = $solicitudes->fetch_assoc()) {
        $rows_buf[] = $r;
        $tot_monto += (float)$r['monto_solicitado'];
        $tot_rows++;
    }
}

// Lista de asesores para filtro
$asesores = $conexion->query("
    SELECT e.id_empleado, CONCAT(e.nombre,' ',e.apellido) AS nombre
    FROM   empleados e
    WHERE  e.estatus = 'ACTIVO'
    ORDER  BY e.nombre
");
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Historial de Solicitudes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}
.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;box-shadow:0 4px 14px rgba(37,99,235,.4);flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;letter-spacing:-.3px;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-sb{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}
.main{margin-left:240px;padding:24px 28px 60px;}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.3rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.btn-icon{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;text-decoration:none;}
.btn-icon:hover{color:#0f172a;border-color:#2563eb;}
.btn-back{display:inline-flex;align-items:center;gap:7px;background:white;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 14px;color:#64748b;text-decoration:none;font-size:.82rem;font-weight:600;transition:all .15s;}
.btn-back:hover{background:#f8fafc;color:#0f172a;}
.btn-nueva{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:white;border:none;border-radius:10px;padding:10px 18px;font-size:.88rem;font-weight:700;text-decoration:none;transition:all .15s;box-shadow:0 4px 12px rgba(37,99,235,.3);}
.btn-nueva:hover{transform:translateY(-1px);}
/* Stats */
.stats-bar{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px;}
.stat-box{background:white;border-radius:12px;padding:14px 10px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border-top:3px solid #e2e8f0;cursor:pointer;text-decoration:none;transition:all .15s;display:block;}
.stat-box:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(0,0,0,.1);}
.stat-box .num{font-size:1.5rem;font-weight:800;}
.stat-box .lbl{font-size:.68rem;color:#64748b;margin-top:3px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;}
.sb-todos  {border-top-color:#64748b;} .sb-todos  .num{color:#475569;}
.sb-pend   {border-top-color:#f59e0b;} .sb-pend   .num{color:#d97706;}
.sb-apro   {border-top-color:#22c55e;} .sb-apro   .num{color:#16a34a;}
.sb-rech   {border-top-color:#ef4444;} .sb-rech   .num{color:#dc2626;}
.sb-monto  {border-top-color:#2563eb;} .sb-monto  .num{color:#2563eb;font-size:1.1rem;}
/* Filtros */
.filtros-card{background:white;border-radius:12px;padding:16px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.05);border:1px solid #f1f5f9;}
.filtros-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto auto;gap:10px;align-items:end;}
.fg-label{font-size:.72rem;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px;}
.fg-input{border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 11px;font-size:.83rem;color:#1e293b;background:white;outline:none;width:100%;font-family:'Inter',sans-serif;}
.fg-input:focus{border-color:#2563eb;}
.btn-filtrar{background:#2563eb;color:white;border:none;border-radius:8px;padding:9px 16px;font-size:.83rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:6px;white-space:nowrap;height:38px;}
.btn-filtrar:hover{background:#1d4ed8;}
.btn-limpiar-f{background:white;border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:.83rem;font-weight:600;color:#64748b;cursor:pointer;text-decoration:none;display:flex;align-items:center;gap:5px;white-space:nowrap;height:38px;}
.btn-limpiar-f:hover{border-color:#94a3b8;color:#0f172a;}
/* Tabla */
.tabla-wrap{background:white;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.07);border:1px solid #f1f5f9;}
.tabla-header{padding:14px 18px;display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #f1f5f9;flex-wrap:wrap;gap:8px;}
.th-title{font-size:.88rem;font-weight:800;color:#0f172a;display:flex;align-items:center;gap:7px;}
.th-count{font-size:.78rem;color:#64748b;background:#f1f5f9;border-radius:20px;padding:3px 10px;}
.btn-imprimir{display:inline-flex;align-items:center;gap:6px;background:white;border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 13px;font-size:.8rem;font-weight:600;color:#475569;cursor:pointer;transition:all .15s;}
.btn-imprimir:hover{border-color:#2563eb;color:#2563eb;}
table{width:100%;border-collapse:collapse;}
thead{background:#f8fafc;}
th{padding:10px 14px;text-align:left;font-size:.72rem;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.06em;border-bottom:2px solid #e2e8f0;}
td{padding:11px 14px;border-bottom:1px solid #f8fafc;font-size:.84rem;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#fafbff;}
.tfoot-row td{background:#f8fafc;font-weight:700;font-size:.82rem;border-top:2px solid #e2e8f0;color:#1e293b;}
.badge-estado{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:.72rem;font-weight:800;white-space:nowrap;}
.be-pend{background:#fef9c3;color:#713f12;border:1px solid #fde68a;}
.be-apro{background:#dcfce7;color:#166534;border:1px solid #86efac;}
.be-rech{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;}
.be-canc{background:#f1f5f9;color:#475569;border:1px solid #cbd5e1;}
.score-chip{display:inline-block;padding:3px 8px;border-radius:20px;font-size:.72rem;font-weight:800;}
.sc-ex{background:#dcfce7;color:#166534;}
.sc-bu{background:#dbeafe;color:#1e40af;}
.sc-re{background:#fef3c7;color:#92400e;}
.sc-ri{background:#fee2e2;color:#991b1b;}
.sc-nd{background:#f1f5f9;color:#94a3b8;}
.btn-ver{display:inline-flex;align-items:center;gap:5px;background:white;border:1.5px solid #e2e8f0;border-radius:7px;padding:5px 10px;font-size:.78rem;font-weight:600;color:#475569;text-decoration:none;transition:all .15s;}
.btn-ver:hover{border-color:#2563eb;color:#2563eb;}
.btn-ver-pr{display:inline-flex;align-items:center;gap:5px;background:#f0fdf4;border:1.5px solid #86efac;border-radius:7px;padding:5px 10px;font-size:.78rem;font-weight:600;color:#166534;text-decoration:none;transition:all .15s;}
.btn-ver-pr:hover{background:#dcfce7;}
.sin-datos{padding:40px;text-align:center;color:#94a3b8;font-size:.88rem;}
.sin-datos i{font-size:2.5rem;display:block;margin-bottom:10px;}
/* Dark */
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .stat-box{background:#111827;}
[data-theme="dark"] .filtros-card{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .fg-input{background:#1e293b;border-color:#334155;color:#e2e8f0;}
[data-theme="dark"] .tabla-wrap{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .tabla-header{border-color:#1e293b;}
[data-theme="dark"] .th-title{color:#e2e8f0;}
[data-theme="dark"] .th-count{background:#1e293b;color:#64748b;}
[data-theme="dark"] thead{background:#1e293b;}
[data-theme="dark"] th{color:#64748b;border-color:#334155;}
[data-theme="dark"] td{border-color:#1e293b;color:#e2e8f0;}
[data-theme="dark"] tr:hover td{background:#1a2234;}
[data-theme="dark"] .tfoot-row td{background:#1e293b;border-color:#334155;color:#e2e8f0;}
[data-theme="dark"] .btn-back,.btn-icon,.btn-ver,.btn-imprimir,.btn-limpiar-f{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .btn-ver-pr{background:rgba(22,163,74,.1);border-color:rgba(134,239,172,.3);}
@media(max-width:900px){
    .sidebar{display:none;}.main{margin-left:0;padding:14px 14px 50px;}
    .stats-bar{grid-template-columns:1fr 1fr;}
    .filtros-grid{grid-template-columns:1fr 1fr;}
    .th-hide,.td-hide{display:none;}
}
@media print{
    .sidebar,.topbar,.filtros-card,.stats-bar,.btn-ver,.btn-ver-pr,.btn-imprimir{display:none!important;}
    .main{margin-left:0;padding:0;}
    .tabla-wrap{box-shadow:none;border:1px solid #ccc;}
}
</style>
</head>
<body>
<div class="app">

<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div><div class="brand-name">Préstamos J.E.</div><div class="brand-sub">Sistema Financiero</div></div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div><div class="u-name"><?= htmlspecialchars($user) ?></div><div class="u-rol"><?= htmlspecialchars($rol) ?></div></div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Solicitudes</div>
        <a href="solicitud_nueva.php"><i class="bi bi-file-earmark-plus"></i> Nueva Solicitud</a>
        <a href="solicitudes_pendientes.php"><i class="bi bi-hourglass-split"></i> Pendientes</a>
        <a href="historial_solicitudes.php" class="active"><i class="bi bi-clock-history"></i> Historial Solicitudes</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="cobro_diario/cobro_diario.php"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">

    <div class="topbar">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <a href="solicitudes_pendientes.php" class="btn-back"><i class="bi bi-arrow-left"></i> Pendientes</a>
            <div>
                <div class="topbar-title">Historial de Solicitudes</div>
                <div class="topbar-sub">Registro completo de todas las solicitudes de préstamo</div>
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
            <a href="solicitud_nueva.php" class="btn-nueva"><i class="bi bi-plus-lg"></i> Nueva Solicitud</a>
            <button class="btn-icon" onclick="window.print()" title="Imprimir"><i class="bi bi-printer"></i></button>
            <button class="btn-icon" onclick="exportarCSV()" title="Exportar CSV"><i class="bi bi-download"></i></button>
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- STATS -->
    <div class="stats-bar">
        <a href="?estado=TODOS" class="stat-box sb-todos">
            <div class="num"><?= $cnts['TODOS'] ?></div>
            <div class="lbl">Total</div>
        </a>
        <a href="?estado=PENDIENTE" class="stat-box sb-pend">
            <div class="num"><?= $cnts['PENDIENTE'] ?></div>
            <div class="lbl">Pendientes</div>
        </a>
        <a href="?estado=APROBADA" class="stat-box sb-apro">
            <div class="num"><?= $cnts['APROBADA'] ?></div>
            <div class="lbl">Aprobadas</div>
        </a>
        <a href="?estado=RECHAZADA" class="stat-box sb-rech">
            <div class="num"><?= $cnts['RECHAZADA'] ?></div>
            <div class="lbl">Rechazadas</div>
        </a>
        <div class="stat-box sb-monto">
            <div class="num">$<?= number_format($tot_monto, 0) ?></div>
            <div class="lbl">Monto filtrado</div>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros-card">
        <form method="GET" id="formFiltros">
            <div class="filtros-grid">
                <div>
                    <div class="fg-label">Buscar cliente</div>
                    <input type="text" name="buscar" class="fg-input"
                           value="<?= htmlspecialchars($_GET['buscar'] ?? '') ?>"
                           placeholder="Nombre o teléfono...">
                </div>
                <div>
                    <div class="fg-label">Estado</div>
                    <select name="estado" class="fg-input">
                        <option value="TODOS"     <?= $f_estado==='TODOS'    ?'selected':'' ?>>Todos</option>
                        <option value="PENDIENTE" <?= $f_estado==='PENDIENTE'?'selected':'' ?>>Pendiente</option>
                        <option value="APROBADA"  <?= $f_estado==='APROBADA' ?'selected':'' ?>>Aprobada</option>
                        <option value="RECHAZADA" <?= $f_estado==='RECHAZADA'?'selected':'' ?>>Rechazada</option>
                        <option value="CANCELADA" <?= $f_estado==='CANCELADA'?'selected':'' ?>>Cancelada</option>
                    </select>
                </div>
                <div>
                    <div class="fg-label">Fecha desde</div>
                    <input type="date" name="fecha_i" class="fg-input"
                           value="<?= htmlspecialchars($f_fecha_i) ?>">
                </div>
                <div>
                    <div class="fg-label">Fecha hasta</div>
                    <input type="date" name="fecha_f" class="fg-input"
                           value="<?= htmlspecialchars($f_fecha_f) ?>">
                </div>
                <button type="submit" class="btn-filtrar">
                    <i class="bi bi-search"></i> Filtrar
                </button>
                <a href="historial_solicitudes.php" class="btn-limpiar-f">
                    <i class="bi bi-x"></i> Limpiar
                </a>
            </div>
        </form>
    </div>

    <!-- TABLA -->
    <div class="tabla-wrap">
        <div class="tabla-header">
            <div class="th-title">
                <i class="bi bi-clock-history" style="color:#2563eb;"></i>
                Solicitudes
                <span class="th-count"><?= $tot_rows ?> resultado(s)</span>
            </div>
            <button class="btn-imprimir" onclick="window.print()">
                <i class="bi bi-printer"></i> Imprimir tabla
            </button>
        </div>
        <table id="tablaHistorial">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th class="th-hide">Asesor</th>
                    <th>Monto</th>
                    <th class="th-hide">Plazo</th>
                    <th>Score</th>
                    <th>Estado</th>
                    <th class="th-hide">Fecha solicitud</th>
                    <th class="th-hide">Resuelto por</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($rows_buf)):
                $sum_aprobado  = 0;
                $sum_rechazado = 0;
                foreach ($rows_buf as $s):
                    $folio    = str_pad($s['id_solicitud'], 5, '0', STR_PAD_LEFT);
                    $score    = (float)$s['score_cliente'];
                    $be_map   = ['PENDIENTE'=>'be-pend','APROBADA'=>'be-apro','RECHAZADA'=>'be-rech','CANCELADA'=>'be-canc'];
                    $be_ico   = ['PENDIENTE'=>'hourglass-split','APROBADA'=>'check-circle-fill','RECHAZADA'=>'x-circle-fill','CANCELADA'=>'dash-circle'];
                    $sc_class = $score >= 80 ? 'sc-ex' : ($score >= 60 ? 'sc-bu' : ($score >= 40 ? 'sc-re' : ($score > 0 ? 'sc-ri' : 'sc-nd')));
                    if ($s['estado'] === 'APROBADA')  $sum_aprobado  += (float)$s['monto_solicitado'];
                    if ($s['estado'] === 'RECHAZADA') $sum_rechazado += (float)$s['monto_solicitado'];
            ?>
                <tr>
                    <td><strong style="color:#64748b;">#<?= $folio ?></strong></td>
                    <td>
                        <div style="font-weight:700;color:#0f172a;"><?= htmlspecialchars($s['nombre_cliente']) ?></div>
                        <div style="font-size:.75rem;color:#64748b;">
                            <i class="bi bi-telephone"></i> <?= htmlspecialchars($s['telefono'] ?? '—') ?>
                        </div>
                    </td>
                    <td class="td-hide" style="font-size:.82rem;color:#475569;">
                        <?= htmlspecialchars($s['nombre_asesor']) ?>
                    </td>
                    <td>
                        <strong style="color:#1d4ed8;">$<?= number_format($s['monto_solicitado'],2) ?></strong>
                    </td>
                    <td class="td-hide" style="font-size:.82rem;color:#475569;">
                        <?= $s['tipo_plazo'] === 'DIARIO'
                            ? $s['plazo_valor'].' días'
                            : $s['plazo_valor'].' semanas' ?>
                    </td>
                    <td>
                        <?php if ($score > 0): ?>
                        <span class="score-chip <?= $sc_class ?>"><?= number_format($score,1) ?></span>
                        <?php else: ?>
                        <span class="score-chip sc-nd">N/D</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge-estado <?= $be_map[$s['estado']] ?? 'be-pend' ?>">
                            <i class="bi bi-<?= $be_ico[$s['estado']] ?? 'hourglass-split' ?>"></i>
                            <?= $s['estado'] ?>
                        </span>
                    </td>
                    <td class="td-hide" style="font-size:.8rem;color:#64748b;">
                        <?= date('d/m/Y', strtotime($s['fecha_solicitud'])) ?>
                        <div style="font-size:.72rem;color:#94a3b8;">
                            <?= date('H:i', strtotime($s['fecha_solicitud'])) ?>
                        </div>
                    </td>
                    <td class="td-hide" style="font-size:.8rem;color:#64748b;">
                        <?php if ($s['resuelto_por']): ?>
                            <?= htmlspecialchars($s['resuelto_por']) ?>
                            <?php if ($s['fecha_resolucion']): ?>
                            <div style="font-size:.72rem;color:#94a3b8;">
                                <?= date('d/m/Y H:i', strtotime($s['fecha_resolucion'])) ?>
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span style="color:#cbd5e1;">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;">
                            <a href="historial_cliente.php?id=<?= $s['id_cliente'] ?>"
                               class="btn-ver" title="Ver cliente" target="_blank">
                                <i class="bi bi-person"></i> Cliente
                            </a>
                            <?php if ($s['id_prestamo']): ?>
                            <a href="estado_cuenta.php?id=<?= $s['id_cliente'] ?>"
                               class="btn-ver-pr" title="Ver préstamo" target="_blank">
                                <i class="bi bi-file-earmark-text"></i> Préstamo
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php if ($s['observaciones_resolucion']): ?>
                        <div style="font-size:.72rem;color:#94a3b8;margin-top:5px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                             title="<?= htmlspecialchars($s['observaciones_resolucion']) ?>">
                            <i class="bi bi-chat-left-dots"></i> <?= htmlspecialchars($s['observaciones_resolucion']) ?>
                        </div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
                <tr class="tfoot-row">
                    <td colspan="3" style="text-align:right;color:#64748b;">Totales del filtro:</td>
                    <td style="color:#2563eb;">$<?= number_format($tot_monto,2) ?></td>
                    <td class="td-hide"></td>
                    <td></td>
                    <td style="font-size:.78rem;">
                        <span style="color:#16a34a;">✓ $<?= number_format($sum_aprobado,2) ?></span><br>
                        <span style="color:#dc2626;">✗ $<?= number_format($sum_rechazado,2) ?></span>
                    </td>
                    <td class="td-hide" colspan="3"></td>
                </tr>
            <?php else: ?>
                <tr><td colspan="10">
                    <div class="sin-datos">
                        <i class="bi bi-inbox"></i>
                        No se encontraron solicitudes con los filtros aplicados.
                        <br><a href="solicitud_nueva.php" style="color:#2563eb;font-weight:700;text-decoration:none;margin-top:8px;display:inline-block;">
                            + Registrar nueva solicitud
                        </a>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</main>
</div>

<script>
function toggleTema(){
    var c=document.documentElement.getAttribute('data-theme')||'light';
    var n=c==='dark'?'light':'dark';
    localStorage.setItem('pje_tema',n);
    document.documentElement.setAttribute('data-theme',n);
    document.getElementById('themeIcon').className=n==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';
}
(function(){
    var t=localStorage.getItem('pje_tema')||'light';
    document.getElementById('themeIcon').className=t==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';
})();
function actualizarReloj(){
    var n=new Date(),p=function(x){return String(x).padStart(2,'0');};
    var el=document.getElementById('reloj');
    if(el) el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj,1000);

function exportarCSV(){
    var tabla=document.getElementById('tablaHistorial');
    var filas=tabla.querySelectorAll('tr');
    var csv=[];
    filas.forEach(function(fila){
        var celdas=fila.querySelectorAll('th,td');
        var row=[];
        celdas.forEach(function(celda){
            var txt=celda.innerText.replace(/\n/g,' ').replace(/,/g,';').trim();
            row.push('"'+txt+'"');
        });
        csv.push(row.join(','));
    });
    var blob=new Blob(['\uFEFF'+csv.join('\n')],{type:'text/csv;charset=utf-8;'});
    var url=URL.createObjectURL(blob);
    var a=document.createElement('a');
    a.href=url;
    a.download='historial_solicitudes_<?= date('Ymd') ?>.csv';
    a.click();
    URL.revokeObjectURL(url);
}
</script>
</body>
</html>
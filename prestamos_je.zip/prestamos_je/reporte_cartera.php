<?php
include("seguridad.php");
include("conexion.php");

// Solo roles con acceso a reportes
$roles_permitidos = ['GERENTE','SUPERVISOR','ADMIN'];
$rol    = $_SESSION['rol']        ?? 'ASESOR';
$user   = $_SESSION['usuario']    ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);

if (!in_array($rol, $roles_permitidos)) {
    header("Location: index.php"); exit;
}

$hoy = date("Y-m-d");

// ── Filtros ─────────────────────────────────────────────────────
$filtro_estado  = $_GET['estado']      ?? '';
$filtro_asesor  = intval($_GET['asesor'] ?? 0);
$filtro_desde   = $_GET['desde']       ?? date('Y-m-01');
$filtro_hasta   = $_GET['hasta']       ?? $hoy;

// ── Asesores para el select ──────────────────────────────────────
$asesores = [];
$ra = $conexion->query("SELECT id_empleado, nombre FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
while ($a = $ra->fetch_assoc()) $asesores[] = $a;

// ── Query principal de cartera ───────────────────────────────────
$where  = ["DATE(pr.fecha_inicio) BETWEEN '$filtro_desde' AND '$filtro_hasta'"];
if ($filtro_estado)  $where[] = "pr.estado = '".mysqli_real_escape_string($conexion,$filtro_estado)."'";
if ($filtro_asesor)  $where[] = "pr.id_empleado = $filtro_asesor";
$where_sql = implode(' AND ', $where);

$prestamos = [];
$rq = $conexion->query("
    SELECT pr.id_prestamo, pr.monto_prestado, pr.total_pagar, pr.dias, pr.estado,
           pr.fecha_inicio,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_fin,
           c.nombre   AS c_nombre, c.apellido  AS c_apellido,
           c.telefono AS c_tel,
           e.nombre   AS asesor,
           COALESCE((SELECT SUM(pa.monto_pagado) FROM pagos pa WHERE pa.id_prestamo=pr.id_prestamo),0) AS total_pagado
    FROM   prestamos pr
    INNER JOIN clientes  c ON c.id_cliente  = pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado = pr.id_empleado
    WHERE  $where_sql
    ORDER  BY pr.fecha_inicio DESC
");
while ($row = $rq->fetch_assoc()) {
    $row['saldo'] = max(0, (float)$row['total_pagar'] - (float)$row['total_pagado']);
    $prestamos[] = $row;
}

// ── Totales ──────────────────────────────────────────────────────
$t_monto    = array_sum(array_column($prestamos,'monto_prestado'));
$t_total    = array_sum(array_column($prestamos,'total_pagar'));
$t_pagado   = array_sum(array_column($prestamos,'total_pagado'));
$t_saldo    = array_sum(array_column($prestamos,'saldo'));

$cnt_activo    = count(array_filter($prestamos, fn($r) => $r['estado']==='ACTIVO'));
$cnt_vencido   = count(array_filter($prestamos, fn($r) => $r['estado']==='ATRASADO'));
$cnt_liquidado = count(array_filter($prestamos, fn($r) => $r['estado']==='PAGADO'));
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reporte de Cartera | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}

/* ── SIDEBAR ── */
.sidebar a{display:block;color:#94a3b8;text-decoration:none;padding:8px 10px;border-radius:8px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}.sidebar a:hover{background:#1e293b;color:#e2e8f0;}.sidebar a.active,.sidebar a[style*="background"]{background:rgba(37,99,235,.15)!important;color:#93c5fd!important;}.sidebar h5{padding:14px 12px 2px;color:#fff;margin:0;font-size:.95rem;}.sidebar small{padding:0 12px;display:block;margin-bottom:8px;}.sidebar hr{border-color:#1e293b;}.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,0.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;line-height:1.2;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;background:#0f172a;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-hoy{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}

/* ── MAIN ── */
.main{margin-left:240px;flex:1;padding:24px 28px 48px;}

/* ── TOPBAR ── */
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.35rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:10px;}
.btn-theme{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;}
.btn-theme:hover{color:#0f172a;border-color:#2563eb;}
.btn-print{display:inline-flex;align-items:center;gap:7px;background:#0f172a;color:white;border:none;border-radius:10px;padding:9px 18px;font-size:.84rem;font-weight:600;cursor:pointer;transition:background .15s;}
.btn-print:hover{background:#1e293b;}

/* ── TARJETAS RESUMEN ── */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px;}
.stat-card{background:white;border-radius:14px;padding:16px 18px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);}
.stat-card .s-val{font-size:1.5rem;font-weight:800;color:#0f172a;line-height:1;margin-bottom:3px;}
.stat-card .s-lbl{font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;font-weight:600;}
.stat-card .s-sub{font-size:.75rem;color:#64748b;margin-top:4px;}
.stat-card.azul  .s-val{color:#2563eb;}
.stat-card.verde .s-val{color:#16a34a;}
.stat-card.rojo  .s-val{color:#dc2626;}
.stat-card.ambar .s-val{color:#d97706;}

/* ── FILTROS ── */
.filtros{background:white;border-radius:14px;padding:16px 20px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:20px;}
.filtros form{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;}
.f-group{display:flex;flex-direction:column;gap:4px;min-width:140px;}
.f-group label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#64748b;}
.f-group select,.f-group input{border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 12px;font-size:.84rem;font-family:'Inter',sans-serif;color:#1e293b;background:white;outline:none;transition:border-color .15s;}
.f-group select:focus,.f-group input:focus{border-color:#2563eb;}
.btn-filtrar{background:#2563eb;color:white;border:none;border-radius:9px;padding:9px 20px;font-size:.84rem;font-weight:600;cursor:pointer;transition:background .15s;white-space:nowrap;}
.btn-filtrar:hover{background:#1d4ed8;}
.btn-limpiar{background:white;color:#64748b;border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 16px;font-size:.84rem;font-weight:600;cursor:pointer;text-decoration:none;transition:all .15s;display:inline-block;}
.btn-limpiar:hover{border-color:#94a3b8;color:#0f172a;}

/* ── TABLA ── */
.tabla-wrap{background:white;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);overflow:hidden;}
.tabla-header{padding:14px 20px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;gap:10px;}
.tabla-header h6{font-size:.9rem;font-weight:700;color:#0f172a;margin:0;}
.tabla-header span{font-size:.78rem;color:#94a3b8;}
.tabla-scroll{overflow-x:auto;}
.tabla{width:100%;border-collapse:collapse;font-size:.82rem;}
.tabla thead th{padding:10px 14px;text-align:left;font-size:.67rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#94a3b8;border-bottom:2px solid #f1f5f9;white-space:nowrap;background:#fafbfc;}
.tabla tbody td{padding:11px 14px;border-bottom:1px solid #f9fafb;vertical-align:middle;}
.tabla tbody tr:hover{background:#fafbfc;}
.tabla tbody tr:last-child td{border-bottom:none;}
.tabla tfoot td{padding:12px 14px;font-weight:700;font-size:.84rem;background:#f8fafc;border-top:2px solid #e2e8f0;}
.estado-pill{display:inline-flex;align-items:center;gap:4px;border-radius:99px;padding:3px 10px;font-size:.7rem;font-weight:700;border:1.5px solid;}
.estado-pill.activo   {background:#eff6ff;border-color:#bfdbfe;color:#1d4ed8;}
.estado-pill.vencido  {background:#fef2f2;border-color:#fecaca;color:#dc2626;}
.estado-pill.liquidado{background:#f0fdf4;border-color:#bbf7d0;color:#15803d;}
.estado-pill.renovado {background:#faf5ff;border-color:#e9d5ff;color:#7c3aed;}
.monto-verde{color:#16a34a;font-weight:600;}
.monto-rojo {color:#dc2626;font-weight:600;}
.link-ver{color:#2563eb;text-decoration:none;font-weight:600;font-size:.78rem;}
.link-ver:hover{text-decoration:underline;}
.vacio-msg{text-align:center;padding:36px;color:#94a3b8;}

/* ── DARK ── */
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .btn-theme{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .stat-card{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .stat-card .s-val{color:#e2e8f0;}
[data-theme="dark"] .stat-card.azul  .s-val{color:#60a5fa;}
[data-theme="dark"] .stat-card.verde .s-val{color:#4ade80;}
[data-theme="dark"] .stat-card.rojo  .s-val{color:#f87171;}
[data-theme="dark"] .stat-card.ambar .s-val{color:#fbbf24;}
[data-theme="dark"] .filtros{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .f-group select,[data-theme="dark"] .f-group input{background:#0f172a;border-color:#1e293b;color:#e2e8f0;}
[data-theme="dark"] .btn-limpiar{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .tabla-wrap{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .tabla-header{border-bottom-color:#1e293b;}
[data-theme="dark"] .tabla-header h6{color:#e2e8f0;}
[data-theme="dark"] .tabla thead th{background:#0f172a;border-bottom-color:#1e293b;}
[data-theme="dark"] .tabla tbody td{border-bottom-color:#1a2235;color:#e2e8f0;}
[data-theme="dark"] .tabla tbody tr:hover{background:#0f172a;}
[data-theme="dark"] .tabla tfoot td{background:#0f172a;border-top-color:#1e293b;}

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar{display:none;}
    .main{margin-left:0;padding:14px 14px 40px;}
    .stats-row{grid-template-columns:1fr 1fr;}
}
@media(max-width:540px){
    .stats-row{grid-template-columns:1fr 1fr;}
    .filtros form{flex-direction:column;}
}

/* ── PRINT ── */
@media print{
    .sidebar,.topbar-right,.filtros,.btn-print{display:none!important;}
    .main{margin-left:0!important;padding:0!important;}
    .app{display:block;}
    body{background:white!important;}
    .tabla-wrap{box-shadow:none!important;border:1px solid #ccc!important;}
    .stats-row{break-inside:avoid;}
    .tabla tbody tr{break-inside:avoid;}
}
</style>
</head>
<body>
<div class="app">

<!-- ══════════ SIDEBAR ══════════ -->
<?php include("sidebar.php"); ?>

<!-- ══════════ MAIN ══════════ -->
<main class="main">

    <div class="topbar">
        <div>
            <div class="topbar-title"><i class="bi bi-bar-chart-fill" style="color:#2563eb;font-size:1.1rem;"></i> Reporte de Cartera</div>
            <div class="topbar-sub"><?= date('d/m/Y H:i') ?> — <?= count($prestamos) ?> préstamo<?= count($prestamos) != 1 ? 's' : '' ?> encontrado<?= count($prestamos) != 1 ? 's' : '' ?></div>
        </div>
        <div class="topbar-right">
            <button class="btn-print" onclick="window.print()">
                <i class="bi bi-printer-fill"></i> Imprimir / PDF
            </button>
            <button class="btn-theme" onclick="toggleTheme()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- TARJETAS RESUMEN -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="s-val"><?= count($prestamos) ?></div>
            <div class="s-lbl">Total préstamos</div>
            <div class="s-sub"><?= $cnt_activo ?> activos · <?= $cnt_vencido ?> vencidos · <?= $cnt_liquidado ?> liquidados</div>
        </div>
        <div class="stat-card azul">
            <div class="s-val">$<?= number_format($t_monto,0) ?></div>
            <div class="s-lbl">Capital colocado</div>
            <div class="s-sub">Total prestado</div>
        </div>
        <div class="stat-card verde">
            <div class="s-val">$<?= number_format($t_pagado,0) ?></div>
            <div class="s-lbl">Total cobrado</div>
            <div class="s-sub">De $<?= number_format($t_total,0) ?> total</div>
        </div>
        <div class="stat-card <?= $t_saldo > 0 ? 'rojo' : 'verde' ?>">
            <div class="s-val">$<?= number_format($t_saldo,0) ?></div>
            <div class="s-lbl">Saldo pendiente</div>
            <div class="s-sub">Por recuperar</div>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros">
        <form method="GET" action="reporte_cartera.php">
            <div class="f-group">
                <label>Desde</label>
                <input type="date" name="desde" value="<?= htmlspecialchars($filtro_desde) ?>">
            </div>
            <div class="f-group">
                <label>Hasta</label>
                <input type="date" name="hasta" value="<?= htmlspecialchars($filtro_hasta) ?>">
            </div>
            <div class="f-group">
                <label>Estado</label>
                <select name="estado">
                    <option value="">Todos</option>
                    <option value="ACTIVO"    <?= $filtro_estado === 'ACTIVO'    ? 'selected' : '' ?>>Activo</option>
                    <option value="ATRASADO"   <?= $filtro_estado === 'ATRASADO'   ? 'selected' : '' ?>>Vencido</option>
                    <option value="PAGADO" <?= $filtro_estado === 'PAGADO' ? 'selected' : '' ?>>Liquidado</option>
                    <option value="RENOVADO"  <?= $filtro_estado === 'RENOVADO'  ? 'selected' : '' ?>>Renovado</option>
                </select>
            </div>
            <div class="f-group">
                <label>Asesor</label>
                <select name="asesor">
                    <option value="0">Todos</option>
                    <?php foreach ($asesores as $a): ?>
                    <option value="<?= $a['id_empleado'] ?>" <?= $filtro_asesor === intval($a['id_empleado']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a['nombre']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-filtrar"><i class="bi bi-funnel-fill"></i> Filtrar</button>
            <a href="reporte_cartera.php" class="btn-limpiar"><i class="bi bi-x-circle"></i> Limpiar</a>
        </form>
    </div>

    <!-- TABLA CARTERA -->
    <div class="tabla-wrap">
        <div class="tabla-header">
            <h6><i class="bi bi-table" style="color:#2563eb;"></i> Cartera de Préstamos</h6>
            <span><?= count($prestamos) ?> registro<?= count($prestamos) != 1 ? 's' : '' ?></span>
        </div>
        <div class="tabla-scroll">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>Folio</th>
                        <th>Cliente</th>
                        <th>Asesor</th>
                        <th>Capital</th>
                        <th>Total a Pagar</th>
                        <th>Cobrado</th>
                        <th>Saldo</th>
                        <th>Fecha Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($prestamos)): ?>
                    <tr><td colspan="11" class="vacio-msg"><i class="bi bi-inbox" style="font-size:1.5rem;"></i><br>No hay préstamos con los filtros seleccionados</td></tr>
                <?php else: ?>
                    <?php foreach ($prestamos as $pr):
                        $pill_class = match($pr['estado']) {
                            'ACTIVO'    => 'activo',
                            'ATRASADO'  => 'atrasado',
                            'PAGADO'    => 'pagado',
                            'RENOVADO'  => 'renovado',
                            default     => 'activo',
                        };
                    ?>
                    <tr>
                        <td><strong>#<?= str_pad($pr['id_prestamo'],4,'0',STR_PAD_LEFT) ?></strong></td>
                        <td>
                            <div style="font-weight:600;"><?= htmlspecialchars($pr['c_nombre'].' '.$pr['c_apellido']) ?></div>
                            <div style="font-size:.72rem;color:#94a3b8;"><?= htmlspecialchars($pr['c_tel'] ?: '—') ?></div>
                        </td>
                        <td><?= htmlspecialchars($pr['asesor']) ?></td>
                        <td>$<?= number_format($pr['monto_prestado'],2) ?></td>
                        <td>$<?= number_format($pr['total_pagar'],2) ?></td>
                        <td><span class="monto-verde">$<?= number_format($pr['total_pagado'],2) ?></span></td>
                        <td><span class="<?= $pr['saldo'] > 0 ? 'monto-rojo' : 'monto-verde' ?>">$<?= number_format($pr['saldo'],2) ?></span></td>
                        <td><?= date('d/m/Y', strtotime($pr['fecha_inicio'])) ?></td>
                        <td><?= date('d/m/Y', strtotime($pr['fecha_fin'])) ?></td>
                        <td><span class="estado-pill <?= $pill_class ?>"><?= ucfirst(strtolower($pr['estado'])) ?></span></td>
                        <td>
                            <a href="detalle_prestamo.php?id_prestamo=<?= $pr['id_prestamo'] ?>" class="link-ver">
                                <i class="bi bi-eye"></i> Ver
                            </a>
                            &nbsp;
                            <a href="contrato_prestamo.php?id_prestamo=<?= $pr['id_prestamo'] ?>" class="link-ver" style="color:#7c3aed;">
                                <i class="bi bi-file-earmark-text"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
                <?php if (!empty($prestamos)): ?>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>TOTALES (<?= count($prestamos) ?> préstamos)</strong></td>
                        <td>$<?= number_format($t_monto,2) ?></td>
                        <td>$<?= number_format($t_total,2) ?></td>
                        <td style="color:#16a34a;">$<?= number_format($t_pagado,2) ?></td>
                        <td style="color:#dc2626;">$<?= number_format($t_saldo,2) ?></td>
                        <td colspan="4"></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div style="text-align:center;color:#cbd5e1;font-size:.72rem;padding:12px 0;border-top:1px solid #e2e8f0;margin-top:20px;">
        Préstamos J.E. © <?= date('Y') ?> — Reporte generado el <?= date('d/m/Y H:i') ?>
    </div>

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const ic = document.getElementById('themeIcon');
    if (ic) ic.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();
function actualizarReloj() {
    const a = new Date();
    const el = document.getElementById('reloj');
    if (el) el.textContent = String(a.getHours()).padStart(2,'0')+':'+String(a.getMinutes()).padStart(2,'0')+':'+String(a.getSeconds()).padStart(2,'0');
}
actualizarReloj(); setInterval(actualizarReloj,1000);
</script>
</body>
</html>

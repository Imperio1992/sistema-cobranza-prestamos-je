<style>

.btn{
border-radius:10px;
}

.card{
border-radius:15px;
}

.card{
    border-radius:15px;
    transition: all 0.2s ease;
}

.card:hover{
    transform: translateY(-5px);
    box-shadow:0 12px 25px rgba(0,0,0,0.15);
}
</style>


<?php
include("seguridad.php");
//include("menu.php");
include("conexion.php");

/* OBTENER ESTATUS DEL EMPLEADO */
$estatus = "ACTIVO";

if(isset($_SESSION['id_empleado'])){

    $id = intval($_SESSION['id_empleado']);

    $res = $conexion->query("
        SELECT estatus
        FROM empleados
        WHERE id_empleado = $id
        LIMIT 1
    ");

    if($res && $res->num_rows > 0){
        $estatus = $res->fetch_assoc()['estatus'];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel Principal | Préstamos JE</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

<!-- HEADER -->
<div class="card shadow-sm mb-4 border-0">
<div class="card-body d-flex align-items-center gap-4">
<div class="ms-auto text-end">

<img src="img/logo.jpeg" alt="Préstamos JE" style="height:80px;" class="me-4">

<div>
<h3 class="mb-0 fw-bold">Préstamos JE</h3>

<div class="text-muted small mt-2">
👤 <?= htmlspecialchars($_SESSION['usuario']) ?> |
🎖 <?= htmlspecialchars($_SESSION['rol']) ?> |
📌 
<?php if($estatus == "ACTIVO"){ ?>
<span class="badge bg-success">Activo</span>
<?php }else{ ?>
<span class="badge bg-secondary">Baja</span>
<?php } ?>
</div>

</div>
</div>
</div>

<!-- TARJETAS -->
<div class="row g-4">

<!-- DASHBOARD -->
<div class="col-md-4">
<div class="card shadow h-100 border-primary">
<div class="card-body text-center">
<h5 class="fw-bold">📊 Dashboard Financiero</h5>
<p class="text-muted small">Resumen general del negocio</p>

<a href="dashboard.php" class="btn btn-primary btn-sm w-100 mb-2 w-100">
Ver Dashboard
</a>

</div>
</div>
</div>

<!-- CLIENTES -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">👥 Clientes</h5>
<p class="text-muted small">Registro y administración</p>

<a href="registrar_cliente.php" class="btn btn-primary btn-sm w-100 mb-2">
Nuevo Cliente
</a>

<a href="buscar_cliente.php" class="btn btn-outline-primary btn-sm w-100 mb-2 w-100 mb-1">
Buscar
</a>

<a href="clientes.php" class="btn btn-outline-primary btn-sm w-100 mb-2 w-100">
Migrar Cliente
</a>

</div>
</div>
</div>

<!-- PRÉSTAMOS -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">📄 Préstamos</h5>
<p class="text-muted small">Alta y control</p>

<a href="nuevo_prestamo.php" class="btn btn-success btn-sm w-100 mb-2 w-100 mb-1">
Nuevo Préstamo
</a>

<a href="historial_cliente.php" class="btn btn-success btn-sm w-100 mb-2 mb-1">
Historial
</a>

</div>
</div>
</div>

<!-- COBRANZA -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">💳 Cobranza</h5>
<p class="text-muted small">Pagos diarios</p>

<a href="cobranza_diaria.php" class="btn btn-warning btn-sm w-100 mb-2">
Cobrar
</a>

<a href="clientes_atrasados.php" class="btn btn-danger btn-sm w-100 mb-2 mt-1">
Atrasos
</a>

</div>
</div>
</div>

<!-- PROGRAMACIÓN -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">📅 Programación de Préstamos</h5>
<p class="text-muted small">Calendario de finalización</p>

<a href="programacion_prestamo.php" class="btn btn-info btn-sm w-100 mb-2 text-white">
Ver Calendario
</a>

</div>
</div>
</div>

<!-- EMPLEADOS -->
<?php if ($_SESSION['rol'] == 'GERENTE') { ?>

<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">👔 Empleados</h5>
<p class="text-muted small">Gestión interna</p>

<a href="empleados.php" class="btn btn-dark btn-sm w-100 mb-2 mb-1">
Administrar
</a>

<a href="registrar_empleado.php" class="btn btn-outline-dark btn-sm w-100 mb-2 mb-1">
Nuevo
</a>

<a href="estatus_empleado.php" class="btn btn-info btn-sm w-100 mb-2 text-white">
Estatus
</a>

</div>
</div>
</div>

<?php } ?>

<!-- CAJA (NUEVO MÓDULO) -->
<?php if ($_SESSION['rol'] == 'GERENTE') { ?>

<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">💰 Caja</h5>
<p class="text-muted small">Control de dinero del día</p>

<a href="caja.php" class="btn btn-success btn-sm w-100 mb-2 mb-1">
Administrar Caja
</a>

<a href="historial_caja.php" class="btn btn-outline-success btn-sm w-100 mb-2">
Historial
</a>

</div>
</div>
</div>

<?php } ?>

<!-- REPORTES -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">📁 Reportes</h5>
<p class="text-muted small">PDF / Excel</p>

<a href="reporte_diario.php" class="btn btn-secondary btn-sm w-100 mb-2">
Ver
</a>

</div>
</div>
</div>

<!-- SALIR -->
<div class="col-md-4">
<div class="card shadow-sm h-100 border-0">
<div class="card-body text-center">

<h5 class="fw-bold">🔒 Sesión</h5>
<p class="text-muted small">Cerrar sistema</p>

<a href="logout.php" class="btn btn-danger btn-sm w-100 mb-2 w-100">
Cerrar sesión
</a>

</div>
</div>
</div>

</div>

</div>

</body>
</html>
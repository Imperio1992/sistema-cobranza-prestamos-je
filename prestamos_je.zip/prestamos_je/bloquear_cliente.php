<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$id_cliente = intval($_GET['id'] ?? 0);
if (!$id_cliente) { header("Location: clientes.php"); exit; }

$stmt = $conexion->prepare("SELECT id_cliente, nombre, apellido, estatus FROM clientes WHERE id_cliente = ? LIMIT 1");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();
if (!$c || $c['estatus'] === 'BLOQUEADO') { header("Location: clientes.php"); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motivo          = trim($_POST['motivo'] ?? '');
    $fecha_desbloqueo= $_POST['fecha_desbloqueo'] ?? '';
    $nuevo_estatus   = $_POST['nuevo_estatus'] ?? 'BLOQUEADO';

    if (!$motivo) {
        $error = 'El motivo es obligatorio.';
    } elseif (!$fecha_desbloqueo) {
        $error = 'La fecha de desbloqueo es obligatoria.';
    } else {
        $stmt2 = $conexion->prepare("
            UPDATE clientes SET estatus=?, motivo_bloqueo=?, fecha_desbloqueo=? WHERE id_cliente=?
        ");
        $stmt2->bind_param("sssi", $nuevo_estatus, $motivo, $fecha_desbloqueo, $id_cliente);
        if ($stmt2->execute()) {
            header("Location: clientes.php?bloqueado=1"); exit;
        }
        $error = 'Error al guardar. Intenta de nuevo.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bloquear Cliente — Préstamos JE</title>
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', Arial, sans-serif; background: #f1f5f9; color: #1e293b; display: flex; min-height: 100vh; }

.sidebar { width: 230px; min-height: 100vh; background: #0f172a; display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; }
.sidebar-brand { padding: 22px 20px 16px; border-bottom: 1px solid #1e293b; }
.sidebar-brand h2 { font-size: 16px; font-weight: 800; color: #f8fafc; }
.sidebar-brand p  { font-size: 11px; color: #64748b; margin-top: 2px; }
.sidebar nav { padding: 12px 10px; }
.nav-section { font-size: 10px; color: #475569; text-transform: uppercase; letter-spacing: 1px; padding: 10px 10px 4px; font-weight: 700; }
.sidebar a { display: flex; align-items: center; gap: 10px; color: #94a3b8; text-decoration: none; padding: 9px 12px; border-radius: 8px; font-size: 13.5px; font-weight: 500; transition: all .15s; margin-bottom: 2px; }
.sidebar a:hover { background: #1e293b; color: #f1f5f9; }
.sidebar a.active { background: #1d4ed8; color: #fff; }
.sidebar a .ico { font-size: 16px; width: 20px; text-align: center; }

.main { margin-left: 230px; flex: 1; display: flex; flex-direction: column; }
.topbar { background: #fff; border-bottom: 1px solid #e2e8f0; padding: 16px 28px; display: flex; align-items: center; gap: 16px; }
.topbar a { color: #64748b; text-decoration: none; font-size: 13px; }
.topbar h1 { font-size: 20px; font-weight: 800; color: #0f172a; }
.topbar p  { font-size: 12px; color: #64748b; margin-top: 1px; }

.content { padding: 28px; max-width: 560px; }

.cliente-card { background: #fff; border-radius: 14px; padding: 20px 22px; box-shadow: 0 1px 4px rgba(0,0,0,.07); margin-bottom: 20px; display: flex; align-items: center; gap: 16px; }
.avatar { width: 52px; height: 52px; border-radius: 50%; background: #fee2e2; color: #dc2626; font-size: 20px; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.cliente-card h3 { font-size: 17px; font-weight: 800; }
.cliente-card p  { font-size: 12px; color: #64748b; margin-top: 2px; }

.alert { padding: 13px 16px; border-radius: 10px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
.alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
.alert-warn  { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; padding: 14px 16px; border-radius: 10px; margin-bottom: 20px; font-size: 13px; }
.alert-warn strong { display: block; font-size: 14px; margin-bottom: 4px; }

.form-card { background: #fff; border-radius: 14px; box-shadow: 0 1px 4px rgba(0,0,0,.07); overflow: hidden; }
.form-card-header { padding: 16px 22px; border-bottom: 1px solid #f1f5f9; }
.form-card-header h3 { font-size: 14px; font-weight: 700; color: #0f172a; }
.form-card-body { padding: 22px; display: flex; flex-direction: column; gap: 16px; }

.field label { display: block; font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 6px; }
.field label .req { color: #dc2626; }
.field input, .field select, .field textarea {
    width: 100%; border: 2px solid #e2e8f0; border-radius: 9px; padding: 10px 14px;
    font-size: 14px; color: #1e293b; outline: none; transition: border-color .15s; font-family: inherit; background: #fff;
}
.field input:focus, .field select:focus, .field textarea:focus { border-color: #dc2626; }
.field textarea { resize: vertical; min-height: 90px; }
.field .hint { font-size: 11px; color: #94a3b8; margin-top: 4px; }

.estatus-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.radio-estatus { display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border: 2px solid #e2e8f0; border-radius: 10px; cursor: pointer; transition: all .15s; }
.radio-estatus:has(input:checked).bloqueado { border-color: #dc2626; background: #fff1f2; }
.radio-estatus:has(input:checked).mal       { border-color: #d97706; background: #fffbeb; }
.radio-estatus input { margin-top: 2px; }
.radio-estatus .re-label { font-size: 13px; font-weight: 700; }
.radio-estatus .re-desc  { font-size: 11px; color: #64748b; margin-top: 2px; }

.form-actions { display: flex; justify-content: space-between; padding: 20px 22px; border-top: 1px solid #f1f5f9; gap: 12px; }
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 20px; border-radius: 9px; font-size: 14px; font-weight: 700; border: none; cursor: pointer; text-decoration: none; transition: all .15s; font-family: inherit; }
.btn-block  { background: #dc2626; color: #fff; flex: 1; justify-content: center; }
.btn-block:hover { background: #b91c1c; }
.btn-cancel { background: #f1f5f9; color: #475569; }
.btn-cancel:hover { background: #e2e8f0; }
</style>
</head>
<body>
<div class="sidebar">
    <div class="sidebar-brand">
        <h2>💰 Préstamos JE</h2>
        <p><?= htmlspecialchars($_SESSION['usuario'] ?? '') ?> · <?= $_SESSION['rol'] ?? '' ?></p>
    </div>
    <nav>
        <div class="nav-section">Principal</div>
        <a href="index.php"><span class="ico">🏠</span> Inicio</a>
        <div class="nav-section">Operaciones</div>
        <a href="cobranza_diaria.php"><span class="ico">💳</span> Cobranza Diaria</a>
        <a href="clientes.php" class="active"><span class="ico">👥</span> Clientes</a>
        <div class="nav-section">Caja</div>
        <a href="caja.php"><span class="ico">💰</span> Caja General</a>
        <div class="nav-section">Admin</div>
        <a href="empleados.php"><span class="ico">👤</span> Empleados</a>
        <a href="logout.php"><span class="ico">🚪</span> Cerrar Sesión</a>
    </nav>
</div>

<div class="main">
    <div class="topbar">
        <a href="clientes.php">← Volver a Clientes</a>
        <div>
            <h1>🚫 Bloquear Cliente</h1>
            <p>Esta acción restringirá al cliente temporalmente</p>
        </div>
    </div>

    <div class="content">

        <div class="cliente-card">
            <div class="avatar"><?= strtoupper(substr($c['nombre'],0,1)) ?></div>
            <div>
                <h3><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></h3>
                <p>Cliente #<?= $c['id_cliente'] ?> · Estatus actual: <?= $c['estatus'] ?></p>
            </div>
        </div>

        <div class="alert-warn">
            <strong>⚠️ Atención</strong>
            Al bloquear a este cliente no podrá recibir nuevos préstamos hasta la fecha de desbloqueo que establezcas.
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-card">
                <div class="form-card-header">
                    <h3>Detalles del bloqueo</h3>
                </div>
                <div class="form-card-body">

                    <div class="field">
                        <label>Tipo de bloqueo <span class="req">*</span></label>
                        <div class="estatus-grid">
                            <label class="radio-estatus bloqueado">
                                <input type="radio" name="nuevo_estatus" value="BLOQUEADO" checked>
                                <div>
                                    <div class="re-label">🚫 Bloqueado</div>
                                    <div class="re-desc">No recibe préstamos temporalmente</div>
                                </div>
                            </label>
                            <label class="radio-estatus mal">
                                <input type="radio" name="nuevo_estatus" value="MAL_HISTORIAL">
                                <div>
                                    <div class="re-label">⚠️ Mal historial</div>
                                    <div class="re-desc">Antecedente de incumplimiento</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="field">
                        <label>Motivo del bloqueo <span class="req">*</span></label>
                        <textarea name="motivo" placeholder="Describe el motivo del bloqueo..."></textarea>
                    </div>

                    <div class="field">
                        <label>Fecha de desbloqueo <span class="req">*</span></label>
                        <input type="date" name="fecha_desbloqueo" min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                        <p class="hint">A partir de esta fecha el sistema permitirá desbloquear al cliente manualmente.</p>
                    </div>

                </div>
                <div class="form-actions">
                    <a href="clientes.php" class="btn btn-cancel">Cancelar</a>
                    <button type="submit" class="btn btn-block"
                        onclick="return confirm('¿Confirmas bloquear a <?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?>?')">
                        🚫 Confirmar Bloqueo
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
</body>
</html>

<?php
date_default_timezone_set('America/Hermosillo');

$conexion = new mysqli("localhost", "root", "", "prestamos_je");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$conexion->query("SET time_zone = '-07:00'");
?>
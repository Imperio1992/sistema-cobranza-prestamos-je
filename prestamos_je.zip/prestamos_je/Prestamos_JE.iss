[Setup]
AppName=Prestamos JE
AppVersion=1.0
DefaultDirName={pf}\Prestamos JE
DefaultGroupName=Prestamos JE
OutputDir=C:\InnoOutput
OutputBaseFilename=Prestamos_JE_Instalador
Compression=lzma
SolidCompression=yes
SetupIconFile=C:\xampp\htdocs\prestamos_je\img\favicon.ico

[Files]
; Copiar TODO el sistema
Source: "C:\xampp\htdocs\prestamos_je\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

; Copiar el .bat
Source: "C:\Users\Omar Jaramillo\Desktop\prestamos_je.bat"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Prestamos JE"; Filename: "{app}\prestamos_je.bat"; IconFilename: "{app}\img\favicon.ico"
Name: "{userdesktop}\Prestamos JE"; Filename: "{app}\prestamos_je.bat"; IconFilename: "{app}\img\favicon.ico"

[Run]
Filename: "{app}\prestamos_je.bat"; Description: "Iniciar Prestamos JE"; Flags: nowait postinstall

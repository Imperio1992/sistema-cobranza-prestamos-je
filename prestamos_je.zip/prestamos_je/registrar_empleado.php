<?php
// 🔐 SOLO GERENTE
$roles_permitidos = ['GERENTE'];
include("seguridad.php");
include("conexion.php");
include("menu.php");

$mensaje = "";
$tipo = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // DATOS
    $nombre    = trim($_POST['nombre']);
    $apellido  = trim($_POST['apellido']);
    $telefono  = trim($_POST['telefono']);
    $direccion = trim($_POST['direccion']);
    $usuario   = trim($_POST['usuario']);
    $rol       = $_POST['rol'];
    $password  = $_POST['password'];
    $ruta_tipo = $_POST['ruta_tipo']; // 👈 NUEVO

    if ($nombre === "" || $apellido === "" || $usuario === "" || $password === "") {
        $mensaje = "Todos los campos obligatorios deben llenarse";
        $tipo = "danger";
    } else {

        // VERIFICAR USUARIO DUPLICADO
        $check = $conexion->prepare(
            "SELECT id_usuario FROM usuarios WHERE usuario = ?"
        );
        $check->bind_param("s", $usuario);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {

            $mensaje = "El nombre de usuario ya existe";
            $tipo = "danger";
            $check->close();

        } else {

            $check->close();

            // INSERTAR EMPLEADO (👉 agregamos ruta_tipo)
            $stmt = $conexion->prepare("
                INSERT INTO empleados
                (nombre, apellido, telefono, direccion, rol, estatus, ruta_tipo)
                VALUES (?, ?, ?, ?, ?, 'ACTIVO', ?)
            ");
            $stmt->bind_param(
                "ssssss",
                $nombre,
                $apellido,
                $telefono,
                $direccion,
                $rol,
                $ruta_tipo
            );
            $stmt->execute();

            $id_empleado = $conexion->insert_id;
            $stmt->close();

            // INSERTAR USUARIO (RELACIONADO)
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt2 = $conexion->prepare("
                INSERT INTO usuarios
                (usuario, password, rol, id_empleado)
                VALUES (?, ?, ?, ?)
            ");
            $stmt2->bind_param(
                "sssi",
                $usuario,
                $password_hash,
                $rol,
                $id_empleado
            );
            $stmt2->execute();
            $stmt2->close();

            // AUDITORÍA (SI EXISTE)
            @$conexion->query("
                INSERT INTO historial_empleados
                (id_empleado, accion, fecha, realizado_por)
                VALUES (
                    $id_empleado,
                    'ALTA',
                    NOW(),
                    '" . $_SESSION['usuario'] . "'
                )
            ");

            $mensaje = "Empleado y usuario registrados correctamente";
            $tipo = "success";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Empleado</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="card shadow">
        <div class="card-header bg-dark text-white">
            <h4>Registrar Empleado</h4>
        </div>

        <div class="card-body">

            <?php if ($mensaje != "") { ?>
                <div class="alert alert-<?= $tipo ?>">
                    <?= $mensaje ?>
                </div>
            <?php } ?>

            <form method="POST">

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Nombre</label>
                        <input type="text" name="nombre" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Apellido</label>
                        <input type="text" name="apellido" class="form-control" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Teléfono</label>
                        <input type="text" name="telefono" class="form-control">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Dirección</label>
                        <input type="text" name="direccion" class="form-control">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Usuario</label>
                        <input type="text" name="usuario" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Contraseña</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Rol</label>
                    <select name="rol" class="form-select">
                        <option value="ASESOR">ASESOR</option>
                        <option value="SUPERVISOR">SUPERVISOR</option>
                        <option value="GERENTE">GERENTE</option>
                    </select>
                </div>

                <!-- ✅ NUEVO: RUTA DEL ASESOR -->
                <div class="mb-3">
                    <label class="form-label">Ruta de Cobranza</label>
                    <select name="ruta_tipo" class="form-select">
                        <option value="DIARIO">Asesor Diario</option>
                        <option value="SEMANAL">Asesor Semanal</option>
                    </select>
                </div>

                <button class="btn btn-primary w-100">
                    Registrar Empleado
                </button>

            </form>

        </div>
    </div>

    <a href="empleados.php" class="btn btn-secondary mt-3">
        ⬅ Volver a empleados
    </a>

</div>

</body>
</html>

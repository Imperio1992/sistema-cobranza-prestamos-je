<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'];
$user       = $_SESSION['usuario'] ?? 'Usuario';
$id_yo      = intval($_SESSION['id_empleado']);

$mensaje  = '';
$tipo_msg = '';

/* ── ACCIÓN RÁPIDA GET ── */
if (isset($_GET['accion'], $_GET['id'])) {
    $id_target = intval($_GET['id']);
    $accion    = $_GET['accion'];

    if ($id_target === $id_yo) {
        $mensaje = 'No puedes cambiar tu propio estatus.'; $tipo_msg = 'error';
    } elseif ($accion === 'activar') {
        $conexion->query("UPDATE empleados SET estatus='ACTIVO' WHERE id_empleado=$id_target");
        $mensaje = 'Empleado activado correctamente.'; $tipo_msg = 'exito';
    } elseif ($accion === 'desactivar') {
        $conexion->query("UPDATE empleados SET estatus='BAJA' WHERE id_empleado=$id_target");
        $mensaje = 'Empleado dado de baja correctamente.'; $tipo_msg = 'advertencia';
    }
}

/* ── FORMULARIO POST ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_target  = intval($_POST['id_empleado'] ?? 0);
    $nuevo_est  = $_POST['nuevo_estatus'] ?? '';
    $nuevo_rol  = $_POST['nuevo_rol']     ?? '';
    $nueva_ruta = trim($_POST['nueva_ruta'] ?? '');

    if ($id_target === $id_yo && $nuevo_est === 'BAJA') {
        $mensaje = 'No puedes darte de baja a ti mismo.'; $tipo_msg = 'error';
    } elseif ($id_target && $nuevo_est) {
        $ruta_sql = $nueva_ruta ? ", ruta_tipo='".$conexion->real_escape_string($nueva_ruta)."'" : '';
        $rol_sql  = $nuevo_rol  ? ", rol='$nuevo_rol'" : '';
        $conexion->query("UPDATE empleados SET estatus='$nuevo_est' $rol_sql $ruta_sql WHERE id_empleado=$id_target");
        $nombre_e = $conexion->query("SELECT nombre, apellido FROM empleados WHERE id_empleado=$id_target")->fetch_assoc();
        $nomb     = $nombre_e ? htmlspecialchars($nombre_e['nombre'].' '.$nombre_e['apellido']) : 'Empleado';
        $mensaje  = "Cambios guardados para <strong>$nomb</strong>."; $tipo_msg = 'exito';
    }
}

/* ── LISTA DE EMPLEADOS ── */
$empleados = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido, e.rol, e.estatus, e.ruta_tipo,
           (SELECT COUNT(*) FROM clientes c WHERE c.id_asesor=e.id_empleado) AS total_clientes,
           (SELECT COUNT(*) FROM prestamos p
            INNER JOIN clientes c ON p.id_cliente=c.id_cliente
            WHERE c.id_asesor=e.id_empleado AND p.estado='ACTIVO') AS prestamos_activos,
           (SELECT SUM(monto) FROM caja
            WHERE id_empleado=e.id_empleado AND tipo_movimiento='COBRO'
            AND YEARWEEK(fecha,1)=YEARWEEK(CURDATE(),1)) AS cobrado_semana
    FROM empleados e ORDER BY e.estatus DESC, e.rol, e.apellido
");
$filas = [];
while ($r = $empleados->fetch_assoc()) $filas[] = $r;
$activos   = array_filter($filas, fn($r) => $r['estatus'] === 'ACTIVO');
$inactivos = array_filter($filas, fn($r) => $r['estatus'] === 'BAJA');
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Estatus Empleados — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover   { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active  { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; display:flex; flex-direction:column; }
.main-content { padding:24px 28px 80px; flex:1; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right   { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-nuevo {
    display:inline-flex; align-items:center; gap:7px;
    padding:9px 18px; border-radius:10px; font-size:.84rem; font-weight:700;
    background:#16a34a; color:white; text-decoration:none; transition:all .15s;
    box-shadow:0 2px 8px rgba(22,163,74,.3);
}
.btn-nuevo:hover { background:#15803d; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; text-decoration:none; flex-shrink:0;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta {
    border-radius:12px; padding:14px 18px; margin-bottom:20px;
    display:flex; align-items:center; gap:12px; font-size:.84rem; font-weight:500;
}
.alerta.exito       { background:#f0fdf4; border:1.5px solid #bbf7d0; color:#14532d; }
.alerta.error       { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }
.alerta.advertencia { background:#fffbeb; border:1.5px solid #fde68a; color:#78350f; }
.alerta i { font-size:1.1rem; flex-shrink:0; }

/* ── LAYOUT ── */
.layout-cols { display:grid; grid-template-columns:1fr 300px; gap:20px; align-items:start; }

/* ── TABS ── */
.tabs {
    display:flex; gap:4px; background:white; padding:5px; border-radius:12px;
    margin-bottom:16px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    width:fit-content;
}
.tab {
    padding:8px 18px; border-radius:8px; font-size:.82rem; font-weight:700;
    cursor:pointer; border:none; background:transparent; color:#64748b; transition:all .15s;
    font-family:'Inter',sans-serif; display:flex; align-items:center; gap:6px;
}
.tab.activo { background:#0f172a; color:white; }
.tab:hover:not(.activo) { background:#f1f5f9; color:#1e293b; }

/* ── SECTION TITLE ── */
.section-title {
    font-size:.7rem; font-weight:700; text-transform:uppercase;
    letter-spacing:.08em; color:#64748b; margin-bottom:12px;
    display:flex; align-items:center; gap:6px;
}

/* ── GRID DE CARDS ── */
.emp-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(270px,1fr)); gap:12px; }

.emp-card {
    background:white; border-radius:14px; padding:18px;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1.5px solid #f1f5f9;
    display:flex; flex-direction:column; gap:13px; transition:all .2s;
}
.emp-card:hover { box-shadow:0 6px 20px rgba(0,0,0,.09); transform:translateY(-2px); }
.emp-card.inactiva { opacity:.65; border-color:#fecdd3; background:#fffafa; }
.emp-card.inactiva:hover { opacity:.85; }

/* Card header */
.card-header { display:flex; align-items:center; gap:12px; }
.emp-avatar {
    width:44px; height:44px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:.9rem; font-weight:800; color:white; flex-shrink:0;
}
.av-gerente    { background:linear-gradient(135deg,#7c3aed,#5b21b6); }
.av-supervisor { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.av-asesor     { background:linear-gradient(135deg,#16a34a,#15803d); }
.av-cajero     { background:linear-gradient(135deg,#0891b2,#0e7490); }
.av-capturista { background:linear-gradient(135deg,#ea580c,#c2410c); }
.av-inactivo   { background:linear-gradient(135deg,#94a3b8,#64748b); }
.emp-nombre { font-size:.9rem; font-weight:700; color:#0f172a; }
.emp-ruta   { font-size:.72rem; color:#94a3b8; margin-top:2px; display:flex; align-items:center; gap:3px; }

/* Badges */
.badge {
    display:inline-flex; align-items:center; gap:3px;
    padding:3px 8px; border-radius:20px; font-size:.7rem; font-weight:700;
}
.badge-gerente    { background:#f3e8ff; color:#7c3aed; }
.badge-supervisor { background:#dbeafe; color:#1d4ed8; }
.badge-asesor     { background:#dcfce7; color:#16a34a; }
.badge-cajero     { background:#cffafe; color:#0e7490; }
.badge-capturista { background:#ffedd5; color:#c2410c; }
.badge-activo     { background:#dcfce7; color:#15803d; }
.badge-baja       { background:#fee2e2; color:#dc2626; }
.yo-chip {
    display:inline-flex; align-items:center; gap:3px;
    background:#fef3c7; color:#92400e; padding:2px 7px;
    border-radius:20px; font-size:.65rem; font-weight:700; margin-left:5px;
}

/* Métricas */
.metricas-row {
    display:grid; grid-template-columns:repeat(3,1fr); gap:6px;
    background:#f8fafc; border-radius:10px; padding:10px;
}
.met-item { text-align:center; }
.met-val  { font-size:1rem; font-weight:800; color:#0f172a; }
.met-lbl  { font-size:.62rem; text-transform:uppercase; letter-spacing:.03em; color:#94a3b8; margin-top:1px; }

/* Acciones card */
.card-actions { display:flex; gap:7px; }
.btn-card {
    flex:1; padding:8px 6px; border-radius:9px; border:none;
    font-size:.75rem; font-weight:700; cursor:pointer;
    text-decoration:none; text-align:center; transition:all .15s;
    display:inline-flex; align-items:center; justify-content:center; gap:4px;
    font-family:'Inter',sans-serif;
}
.btn-card:hover { filter:brightness(.93); transform:translateY(-1px); }
.btn-card.activar    { background:#dcfce7; color:#15803d; }
.btn-card.desactivar { background:#fee2e2; color:#dc2626; }
.btn-card.editar     { background:#dbeafe; color:#1d4ed8; }
.btn-card.cambiar    { background:#f3e8ff; color:#7c3aed; }

/* ── PANEL EDICIÓN ── */
.panel-edicion {
    background:white; border-radius:14px; padding:20px 22px;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    position:sticky; top:20px;
}
.panel-edicion h3 {
    font-size:.82rem; font-weight:800; color:#0f172a; margin-bottom:16px;
    display:flex; align-items:center; gap:8px;
}
.panel-placeholder { text-align:center; padding:28px 10px; color:#94a3b8; font-size:.82rem; }
.panel-placeholder i { font-size:2rem; display:block; margin-bottom:10px; opacity:.3; }

/* Campos panel */
.field { margin-bottom:14px; }
.field:last-child { margin-bottom:0; }
.field label {
    display:block; font-size:.7rem; font-weight:700;
    color:#374151; margin-bottom:5px;
    text-transform:uppercase; letter-spacing:.04em;
}
.field select, .field input[type=text] {
    width:100%; border:1.5px solid #e2e8f0; border-radius:9px;
    padding:9px 13px; font-size:.84rem; color:#1e293b;
    outline:none; background:#f8fafc; font-family:'Inter',sans-serif;
    transition:border-color .15s;
}
.field select:focus, .field input:focus { border-color:#2563eb; background:white; }
.nombre-display {
    padding:10px 13px; background:#f8fafc; border-radius:9px;
    font-weight:700; color:#0f172a; font-size:.88rem;
    border:1.5px solid #f1f5f9;
}
.btn-guardar {
    width:100%; padding:12px; background:#0f172a; color:white;
    border:none; border-radius:10px; font-size:.88rem; font-weight:700;
    cursor:pointer; font-family:'Inter',sans-serif; transition:background .15s;
    display:flex; align-items:center; justify-content:center; gap:7px; margin-top:6px;
}
.btn-guardar:hover { background:#1e293b; }

/* Empty state */
.empty-state { text-align:center; padding:40px 24px; color:#94a3b8; background:white; border-radius:14px; border:1px solid #f1f5f9; }
.empty-state i { font-size:2.2rem; display:block; margin-bottom:10px; opacity:.3; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .emp-card  { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .emp-card.inactiva { background:#1a1018; border-color:#7f1d1d44; }
[data-theme="dark"] .emp-nombre { color:#f8fafc; }
[data-theme="dark"] .metricas-row { background:#0f172a; }
[data-theme="dark"] .met-val   { color:#f8fafc; }
[data-theme="dark"] .tabs      { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .tab.activo { background:#2563eb; }
[data-theme="dark"] .tab:hover:not(.activo) { background:#334155; color:#e2e8f0; }
[data-theme="dark"] .panel-edicion { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .panel-edicion h3 { color:#f8fafc; }
[data-theme="dark"] .field label { color:#94a3b8; }
[data-theme="dark"] .field select, [data-theme="dark"] .field input { background:#0f172a; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .nombre-display { background:#0f172a; color:#f8fafc; border-color:#334155; }
[data-theme="dark"] .empty-state { background:#1e293b; }
[data-theme="dark"] .alerta.exito       { background:#071f12; border-color:#14532d; color:#86efac; }
[data-theme="dark"] .alerta.error       { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }
[data-theme="dark"] .alerta.advertencia { background:#1c1600; border-color:#92400e; color:#fde68a; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; color:#94a3b8; border-color:#334155; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .layout-cols  { grid-template-columns:1fr; }
    .panel-edicion { position:static; }
}
@media (max-width:600px) {
    .emp-grid { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">
                <i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i>
            </div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Clientes Atrasados</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>

        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="nuevo_empleado.php" class="special"><i class="bi bi-person-plus"></i> Nuevo Empleado</a>
        <a href="estatus_empleado.php" class="active"><i class="bi bi-arrow-left-right"></i> Estatus</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="btn-icon-top" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-arrow-left-right" style="color:#2563eb;"></i> Estatus de Empleados</h1>
                <p>Activa, desactiva o cambia el rol del equipo</p>
            </div>
        </div>
        <div class="topbar-right">
            <a href="nuevo_empleado.php" class="btn-nuevo">
                <i class="bi bi-person-plus-fill"></i> Nuevo Empleado
            </a>
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ALERTA -->
    <?php if ($mensaje): ?>
    <div class="alerta <?= $tipo_msg ?>">
        <?php
        $icon = match($tipo_msg) {
            'exito'       => 'bi-check-circle-fill',
            'error'       => 'bi-x-circle-fill',
            'advertencia' => 'bi-exclamation-triangle-fill',
            default       => 'bi-info-circle-fill'
        };
        ?>
        <i class="bi <?= $icon ?>"></i>
        <div><?= $mensaje ?></div>
    </div>
    <?php endif; ?>

    <div class="layout-cols">

        <!-- ════ COLUMNA IZQUIERDA ════ -->
        <div>

            <!-- TABS -->
            <div class="tabs">
                <button class="tab activo" id="tab-btn-activos" onclick="mostrarTab('activos', this)">
                    <i class="bi bi-person-check-fill"></i>
                    Activos <span style="opacity:.7;">(<?= count($activos) ?>)</span>
                </button>
                <button class="tab" id="tab-btn-inactivos" onclick="mostrarTab('inactivos', this)">
                    <i class="bi bi-person-dash-fill"></i>
                    Baja <span style="opacity:.7;">(<?= count($inactivos) ?>)</span>
                </button>
            </div>

            <!-- ── ACTIVOS ── -->
            <div id="tab-activos">
                <div class="section-title">
                    <i class="bi bi-circle-fill" style="color:#16a34a;font-size:.5rem;"></i>
                    Empleados activos — <?= count($activos) ?> en operación
                </div>
                <div class="emp-grid">
                <?php foreach ($activos as $e):
                    $iniciales = strtoupper(mb_substr($e['nombre'],0,1) . mb_substr($e['apellido'],0,1));
                    $av_class  = 'av-' . strtolower($e['rol']);
                    $badge_rol = 'badge-' . strtolower($e['rol']);
                    $es_yo     = $e['id_empleado'] == $id_yo;
                    $cobrado_s = floatval($e['cobrado_semana']);
                    $rol_icon  = match($e['rol']) {
                        'GERENTE'    => 'bi-star-fill',
                        'SUPERVISOR' => 'bi-shield-fill',
                        'CAJERO'     => 'bi-safe2-fill',
                        'CAPTURISTA' => 'bi-keyboard-fill',
                        default      => 'bi-person-fill'
                    };
                ?>
                <div class="emp-card">
                    <div class="card-header">
                        <div class="emp-avatar <?= $av_class ?>"><?= $iniciales ?></div>
                        <div style="flex:1;min-width:0;">
                            <div class="emp-nombre">
                                <?= htmlspecialchars($e['nombre'] . ' ' . $e['apellido']) ?>
                                <?php if ($es_yo): ?>
                                <span class="yo-chip"><i class="bi bi-person-fill" style="font-size:.6rem;"></i> tú</span>
                                <?php endif; ?>
                            </div>
                            <?php if ($e['ruta_tipo']): ?>
                            <div class="emp-ruta">
                                <i class="bi bi-geo-alt" style="font-size:.65rem;"></i>
                                <?= htmlspecialchars($e['ruta_tipo']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end;">
                            <span class="badge <?= $badge_rol ?>"><i class="bi <?= $rol_icon ?>" style="font-size:.6rem;"></i> <?= $e['rol'] ?></span>
                            <span class="badge badge-activo"><i class="bi bi-check-circle-fill" style="font-size:.6rem;"></i> ACTIVO</span>
                        </div>
                    </div>

                    <div class="metricas-row">
                        <div class="met-item">
                            <div class="met-val"><?= $e['total_clientes'] ?></div>
                            <div class="met-lbl">Clientes</div>
                        </div>
                        <div class="met-item">
                            <div class="met-val"><?= $e['prestamos_activos'] ?></div>
                            <div class="met-lbl">Préstamos</div>
                        </div>
                        <div class="met-item">
                            <div class="met-val">$<?= number_format($cobrado_s, 0) ?></div>
                            <div class="met-lbl">Semana</div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <a href="editar_empleado.php?id=<?= $e['id_empleado'] ?>" class="btn-card editar">
                            <i class="bi bi-pencil-fill"></i> Editar
                        </a>
                        <button class="btn-card cambiar"
                                onclick="abrirPanel(<?= $e['id_empleado'] ?>, '<?= htmlspecialchars(addslashes($e['nombre'].' '.$e['apellido'])) ?>', '<?= $e['rol'] ?>', '<?= $e['estatus'] ?>', '<?= htmlspecialchars(addslashes($e['ruta_tipo'] ?? '')) ?>')">
                            <i class="bi bi-gear-fill"></i> Cambiar
                        </button>
                        <?php if (!$es_yo): ?>
                        <a href="estatus_empleado.php?id=<?= $e['id_empleado'] ?>&accion=desactivar"
                           class="btn-card desactivar"
                           onclick="return confirm('¿Dar de baja a <?= htmlspecialchars(addslashes($e['nombre'])) ?>?')">
                            <i class="bi bi-person-dash-fill"></i> Dar de baja
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            </div>

            <!-- ── BAJA ── -->
            <div id="tab-inactivos" style="display:none;">
                <div class="section-title">
                    <i class="bi bi-circle-fill" style="color:#dc2626;font-size:.5rem;"></i>
                    Empleados de baja — <?= count($inactivos) ?> fuera de operación
                </div>
                <?php if (empty($inactivos)): ?>
                <div class="empty-state">
                    <i class="bi bi-people"></i>
                    <p style="font-weight:600;margin-bottom:4px;">Sin empleados de baja</p>
                    <p style="font-size:.78rem;">Todo el equipo está actualmente en operación.</p>
                </div>
                <?php else: ?>
                <div class="emp-grid">
                <?php foreach ($inactivos as $e):
                    $iniciales = strtoupper(mb_substr($e['nombre'],0,1) . mb_substr($e['apellido'],0,1));
                    $badge_rol = 'badge-' . strtolower($e['rol']);
                ?>
                <div class="emp-card inactiva">
                    <div class="card-header">
                        <div class="emp-avatar av-inactivo"><?= $iniciales ?></div>
                        <div style="flex:1;min-width:0;">
                            <div class="emp-nombre"><?= htmlspecialchars($e['nombre'] . ' ' . $e['apellido']) ?></div>
                            <?php if ($e['ruta_tipo']): ?>
                            <div class="emp-ruta">
                                <i class="bi bi-geo-alt" style="font-size:.65rem;"></i>
                                <?= htmlspecialchars($e['ruta_tipo']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end;">
                            <span class="badge <?= $badge_rol ?>"><?= $e['rol'] ?></span>
                            <span class="badge badge-baja"><i class="bi bi-x-circle-fill" style="font-size:.6rem;"></i> BAJA</span>
                        </div>
                    </div>

                    <div class="metricas-row">
                        <div class="met-item">
                            <div class="met-val"><?= $e['total_clientes'] ?></div>
                            <div class="met-lbl">Clientes</div>
                        </div>
                        <div class="met-item">
                            <div class="met-val"><?= $e['prestamos_activos'] ?></div>
                            <div class="met-lbl">Préstamos</div>
                        </div>
                        <div class="met-item">
                            <div class="met-val" style="color:#94a3b8;">—</div>
                            <div class="met-lbl">Semana</div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <a href="estatus_empleado.php?id=<?= $e['id_empleado'] ?>&accion=activar"
                           class="btn-card activar"
                           onclick="return confirm('¿Reactivar a <?= htmlspecialchars(addslashes($e['nombre'])) ?>?')">
                            <i class="bi bi-person-check-fill"></i> Reactivar
                        </a>
                        <button class="btn-card cambiar"
                                onclick="abrirPanel(<?= $e['id_empleado'] ?>, '<?= htmlspecialchars(addslashes($e['nombre'].' '.$e['apellido'])) ?>', '<?= $e['rol'] ?>', '<?= $e['estatus'] ?>', '<?= htmlspecialchars(addslashes($e['ruta_tipo'] ?? '')) ?>')">
                            <i class="bi bi-gear-fill"></i> Cambiar
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

        </div>

        <!-- ════ COLUMNA DERECHA — panel edición ════ -->
        <div>
            <div class="panel-edicion">
                <h3 id="panel-titulo">
                    <i class="bi bi-gear-fill" style="color:#7c3aed;"></i>
                    Cambiar estatus / rol
                </h3>

                <div id="panel-placeholder" class="panel-placeholder">
                    <i class="bi bi-cursor-fill"></i>
                    Selecciona un empleado haciendo clic en <strong>Cambiar</strong> para editar su estatus o rol.
                </div>

                <form method="POST" id="panel-form" style="display:none;">
                    <input type="hidden" name="id_empleado" id="f-id">

                    <div class="field">
                        <label>Empleado seleccionado</label>
                        <div class="nombre-display" id="f-nombre-display"></div>
                    </div>

                    <div class="field">
                        <label>Nuevo estatus</label>
                        <select name="nuevo_estatus" id="f-estatus">
                            <option value="ACTIVO">✅ ACTIVO</option>
                            <option value="BAJA">❌ BAJA</option>
                        </select>
                    </div>

                    <div class="field">
                        <label>Nuevo rol</label>
                        <select name="nuevo_rol" id="f-rol">
                            <option value="ASESOR">Asesor</option>
                            <option value="CAPTURISTA">Capturista</option>
                            <option value="CAJERO">Cajero / Contador</option>
                            <option value="SUPERVISOR">Supervisor</option>
                            <option value="GERENTE">Gerente</option>
                        </select>
                    </div>

                    <div class="field">
                        <label>Ruta / Tipo</label>
                        <select name="nueva_ruta" id="f-ruta">
                            <option value="">— Sin cambio —</option>
                            <option value="DIARIO">DIARIO</option>
                            <option value="SEMANAL">SEMANAL</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-guardar">
                        <i class="bi bi-floppy-fill"></i> Guardar cambios
                    </button>
                </form>
            </div>
        </div>

    </div>

</div><!-- /main-content -->
</main>
</div><!-- /app -->

<script>
/* ── TEMA ── */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), pad = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = pad(n.getHours())+':'+pad(n.getMinutes())+':'+pad(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── TABS ── */
function mostrarTab(cual, btn) {
    document.getElementById('tab-activos').style.display   = cual === 'activos'   ? 'block' : 'none';
    document.getElementById('tab-inactivos').style.display = cual === 'inactivos' ? 'block' : 'none';
    document.querySelectorAll('.tab').forEach(function(t){ t.classList.remove('activo'); });
    btn.classList.add('activo');
}

/* ── PANEL EDICIÓN ── */
function abrirPanel(id, nombre, rol, estatus, ruta) {
    document.getElementById('panel-placeholder').style.display = 'none';
    document.getElementById('panel-form').style.display        = 'block';
    document.getElementById('panel-titulo').innerHTML =
        '<i class="bi bi-gear-fill" style="color:#7c3aed;"></i> Editando empleado';
    document.getElementById('f-id').value                   = id;
    document.getElementById('f-nombre-display').textContent = nombre;
    document.getElementById('f-estatus').value              = estatus;
    document.getElementById('f-rol').value                  = rol;
    document.getElementById('f-ruta').value                 = ruta;
    document.querySelector('.panel-edicion').scrollIntoView({ behavior:'smooth', block:'start' });
}
</script>
</body>
</html>
<?php
$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR','CAJERO','CAPTURISTA'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol          = $_SESSION['rol']         ?? 'ASESOR';
$user         = $_SESSION['usuario']     ?? 'Usuario';
$id_emp_sesion = intval($_SESSION['id_empleado'] ?? 0);

/* ── PARÁMETROS DE ENTRADA ── */
$id_prestamo  = intval($_GET['id_prestamo']  ?? $_POST['id_prestamo_param'] ?? 0);
$id_empleado  = intval($_GET['id_empleado']  ?? $_POST['id_empleado']       ?? $id_emp_sesion);

if (!$id_prestamo) {
    header('Location: cobro_diario/cobro_diario.php');
    exit;
}

/* ── DATOS DEL PRÉSTAMO ── */
$prestamo = $conexion->query("
    SELECT p.*,
           c.id_cliente, c.nombre AS cli_nombre, c.apellido AS cli_apellido,
           c.telefono AS cli_tel, c.direccion AS cli_dir,
           e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
    FROM prestamos p
    INNER JOIN clientes  c ON c.id_cliente  = p.id_cliente
    LEFT  JOIN empleados e ON e.id_empleado = p.id_empleado
    WHERE p.id_prestamo = $id_prestamo
")->fetch_assoc();

if (!$prestamo || !in_array($prestamo['estado'], ['ACTIVO','ATRASADO'])) {
    header('Location: cobro_diario/cobro_lista.php?id_empleado=' . $id_empleado);
    exit;
}

$hoy = date('Y-m-d');

/* ── PAGO PREVIO HOY ── */
$pago_hoy_q = $conexion->query("
    SELECT SUM(monto_pagado) AS total
    FROM pagos
    WHERE id_prestamo = $id_prestamo
      AND DATE(fecha_pago) = '$hoy'
");
$pago_hoy = floatval($pago_hoy_q->fetch_assoc()['total'] ?? 0);

/* ── TIPO DE PRÉSTAMO ── */
$es_semanal = (floatval($prestamo['pago_diario']) == 0 && intval($prestamo['plazo_semanas']) > 0);
$cuota      = $es_semanal
    ? (floatval($prestamo['plazo_semanas']) > 0 ? floatval($prestamo['total_pagar']) / floatval($prestamo['plazo_semanas']) : 0)
    : floatval($prestamo['pago_diario']);

/* ── PROCESAMIENTO POST ── */
$msg = ''; $msg_tipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pagos'])) {

    $fecha_base = $_POST['fecha_cobro'] ?? $hoy;

    if ($fecha_base > $hoy) {
        $msg = 'No puedes registrar pagos en fechas futuras.';
        $msg_tipo = 'error';
    } else {
        $hora       = date('H:i:s');
        $fecha_full = $fecha_base . ' ' . $hora;
        $asesor_id  = intval($_POST['asesor'] ?? $id_emp_sesion);

        $conexion->begin_transaction();
        try {
            foreach ($_POST['pagos'] as $id_p => $monto) {
                if (empty($monto) || floatval($monto) <= 0) continue;

                $id_p  = intval($id_p);
                $monto = floatval($monto);

                /* Verificar duplicado */
                $dup = $conexion->query("
                    SELECT id_pago FROM pagos
                    WHERE id_prestamo = $id_p
                      AND DATE(fecha_pago) = '$fecha_base'
                    LIMIT 1
                ");
                if ($dup->num_rows > 0) {
                    throw new Exception('Ya existe un pago registrado para este préstamo en esa fecha.');
                }

                /* 1. Insertar pago */
                $stmtPago = $conexion->prepare("
                    INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado)
                    VALUES (?, ?, ?)
                ");
                $stmtPago->bind_param('isd', $id_p, $fecha_full, $monto);
                $stmtPago->execute();
                $stmtPago->close();

                /* 2. Recalcular totales */
                $total_abonado = floatval($conexion->query("
                    SELECT COALESCE(SUM(monto_pagado), 0) AS t FROM pagos WHERE id_prestamo = $id_p
                ")->fetch_assoc()['t']);

                $total_pagar = floatval($conexion->query("
                    SELECT total_pagar FROM prestamos WHERE id_prestamo = $id_p
                ")->fetch_assoc()['total_pagar']);

                $nuevo_saldo = max(0, $total_pagar - $total_abonado);
                $estado      = ($nuevo_saldo <= 0) ? 'PAGADO' : 'ACTIVO';
                $fecha_liq   = ($nuevo_saldo <= 0) ? $fecha_full : null;

                /* 3. Actualizar préstamo */
                $stmtUpd = $conexion->prepare("
                    UPDATE prestamos
                    SET total_pagado      = ?,
                        saldo_actual      = ?,
                        estado            = ?,
                        fecha_liquidacion = ?
                    WHERE id_prestamo = ?
                ");
                $stmtUpd->bind_param('ddssi', $total_abonado, $nuevo_saldo, $estado, $fecha_liq, $id_p);
                $stmtUpd->execute();
                $stmtUpd->close();

                /* 4. Registro en caja */
                $concepto        = 'COBRO PRESTAMO #' . $id_p;
                $tipo_movimiento = 'COBRO';
                $medio           = 'EFECTIVO';
                $stmtCaja = $conexion->prepare("
                    INSERT INTO caja
                        (tipo, tipo_movimiento, medio, monto, concepto, id_empleado, fecha, id_prestamo)
                    VALUES ('ENTRADA', ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtCaja->bind_param('ssdssis',
                    $tipo_movimiento, $medio, $monto, $concepto,
                    $asesor_id, $fecha_full, $id_p
                );
                $stmtCaja->execute();
                $stmtCaja->close();
            }

            $conexion->commit();
            header('Location: cobro_diario/cobro_lista.php?id_empleado=' . $id_empleado . '&ok=1');
            exit;

        } catch (Exception $e) {
            $conexion->rollback();
            $msg      = 'Error al registrar el cobro: ' . $e->getMessage();
            $msg_tipo = 'error';
        }
    }

    /* Recargar datos del préstamo tras el error */
    $prestamo = $conexion->query("
        SELECT p.*,
               c.id_cliente, c.nombre AS cli_nombre, c.apellido AS cli_apellido,
               c.telefono AS cli_tel, c.direccion AS cli_dir,
               e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
        FROM prestamos p
        INNER JOIN clientes  c ON c.id_cliente  = p.id_cliente
        LEFT  JOIN empleados e ON e.id_empleado = p.id_empleado
        WHERE p.id_prestamo = $id_prestamo
    ")->fetch_assoc();

    $pago_hoy_q = $conexion->query("
        SELECT SUM(monto_pagado) AS total FROM pagos
        WHERE id_prestamo = $id_prestamo AND DATE(fecha_pago) = '$hoy'
    ");
    $pago_hoy = floatval($pago_hoy_q->fetch_assoc()['total'] ?? 0);
}

/* ── ÚLTIMOS 10 PAGOS ── */
$ultimos_pagos = [];
$res_pagos = $conexion->query("
    SELECT fecha_pago, monto_pagado, tipo_pago
    FROM pagos
    WHERE id_prestamo = $id_prestamo
    ORDER BY fecha_pago DESC
    LIMIT 10
");
if ($res_pagos) while ($pg = $res_pagos->fetch_assoc()) $ultimos_pagos[] = $pg;

$saldo      = floatval($prestamo['saldo_actual']);
$score_pct  = floatval($prestamo['total_pagar']) > 0
    ? round((floatval($prestamo['total_pagado']) / floatval($prestamo['total_pagar'])) * 100)
    : 0;
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registrar Cobro — <?= htmlspecialchars($prestamo['cli_nombre'] . ' ' . $prestamo['cli_apellido']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-sb { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger       { color:#f87171; }
.sb-nav a.danger.active { background:rgba(239,68,68,.12); color:#fca5a5; border-color:rgba(239,68,68,.2); }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-icon { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; text-decoration:none; }
.btn-icon:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTA ── */
.alerta { border-radius:12px; padding:14px 18px; margin-bottom:20px; display:flex; align-items:center; gap:12px; font-size:.84rem; font-weight:500; }
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }
.alerta i { font-size:1.1rem; flex-shrink:0; }

/* ── LAYOUT ── */
.layout { display:grid; grid-template-columns:1fr 340px; gap:20px; align-items:start; }

/* ── CLIENTE CARD ── */
.cliente-card { background:white; border-radius:16px; padding:20px 24px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-bottom:18px; display:flex; align-items:center; gap:16px; }
.cli-av { width:56px; height:56px; border-radius:50%; background:linear-gradient(135deg,#2563eb,#1d4ed8); display:flex; align-items:center; justify-content:center; font-size:1.25rem; font-weight:800; color:white; flex-shrink:0; }
.cli-nombre { font-size:1.05rem; font-weight:800; color:#0f172a; }
.cli-meta { display:flex; gap:14px; flex-wrap:wrap; margin-top:5px; }
.cli-meta span { font-size:.78rem; color:#64748b; display:flex; align-items:center; gap:4px; }
.badge-estado { display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:20px; font-size:.72rem; font-weight:700; }
.badge-activo  { background:#dcfce7; color:#15803d; }
.badge-atrasado { background:#fef3c7; color:#92400e; }

/* ── DETALLES PRÉSTAMO ── */
.detalle-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(130px,1fr)); gap:10px; margin-bottom:18px; }
.detalle-item { background:white; border-radius:12px; padding:14px; text-align:center; box-shadow:0 2px 6px rgba(0,0,0,.04); border:1px solid #f1f5f9; }
.detalle-val { font-size:1.1rem; font-weight:800; color:#0f172a; }
.detalle-lbl { font-size:.68rem; color:#94a3b8; text-transform:uppercase; letter-spacing:.04em; margin-top:3px; }
.detalle-verde   { color:#16a34a; }
.detalle-rojo    { color:#dc2626; }
.detalle-azul    { color:#2563eb; }
.detalle-naranja { color:#d97706; }

/* ── PROGRESS ── */
.prog-wrap { background:white; border-radius:12px; padding:14px 18px; margin-bottom:18px; box-shadow:0 2px 6px rgba(0,0,0,.04); border:1px solid #f1f5f9; }
.prog-bar  { background:#e2e8f0; border-radius:10px; height:10px; overflow:hidden; margin:8px 0 4px; }
.prog-fill { height:100%; border-radius:10px; background:linear-gradient(90deg,#22c55e,#16a34a); transition:width .6s; }

/* ── TABLA PAGOS ── */
.tabla-wrap { background:white; border-radius:14px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; overflow:hidden; }
.tabla-head { padding:14px 18px; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; gap:8px; font-size:.82rem; font-weight:800; color:#0f172a; }
table.pagos-tbl { width:100%; border-collapse:collapse; font-size:.82rem; }
table.pagos-tbl th { text-align:left; padding:9px 14px; font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; background:#f8fafc; border-bottom:1px solid #f1f5f9; }
table.pagos-tbl td { padding:10px 14px; border-bottom:1px solid #f8fafc; color:#374151; }
table.pagos-tbl tr:last-child td { border-bottom:none; }
table.pagos-tbl tr:hover td { background:#f8fafc; }
.empty-tbl { text-align:center; padding:24px; color:#94a3b8; font-size:.82rem; }

/* ── PANEL COBRO (derecha) ── */
.panel-cobro { background:white; border-radius:16px; padding:22px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; position:sticky; top:20px; }
.panel-cobro h3 { font-size:.9rem; font-weight:800; color:#0f172a; margin-bottom:18px; display:flex; align-items:center; gap:8px; }
.field { margin-bottom:14px; }
.field label { display:block; font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#374151; margin-bottom:5px; }
.field input { width:100%; border:1.5px solid #e2e8f0; border-radius:9px; padding:10px 12px; font-size:.95rem; font-family:'Inter',sans-serif; outline:none; background:#f8fafc; color:#1e293b; transition:border-color .15s; }
.field input:focus { border-color:#2563eb; background:white; }
.monto-sugerido { display:flex; gap:8px; flex-wrap:wrap; margin-top:8px; }
.chip-monto { padding:5px 12px; border-radius:20px; border:1.5px solid #bfdbfe; background:#eff6ff; color:#1d4ed8; font-size:.78rem; font-weight:700; cursor:pointer; transition:all .15s; font-family:'Inter',sans-serif; }
.chip-monto:hover { background:#dbeafe; border-color:#2563eb; }
.chip-monto.semanal { border-color:#fde68a; background:#fffbeb; color:#92400e; }
.chip-monto.semanal:hover { background:#fef3c7; }
.divider { border:none; border-top:1px solid #f1f5f9; margin:16px 0; }
.resumen-cobro { background:#f8fafc; border-radius:10px; padding:12px 14px; margin-bottom:16px; }
.resumen-cobro .r-row { display:flex; justify-content:space-between; align-items:center; font-size:.82rem; padding:3px 0; }
.resumen-cobro .r-row .lbl { color:#64748b; }
.resumen-cobro .r-row .val { font-weight:700; color:#0f172a; }
.resumen-cobro .r-row.total .lbl { font-weight:700; color:#0f172a; font-size:.86rem; }
.resumen-cobro .r-row.total .val { color:#16a34a; font-size:1rem; }
.btn-cobrar { width:100%; padding:13px; background:#2563eb; color:white; border:none; border-radius:11px; font-size:.9rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:background .15s; display:flex; align-items:center; justify-content:center; gap:8px; }
.btn-cobrar:hover { background:#1d4ed8; }
.btn-cobrar:disabled { background:#94a3b8; cursor:not-allowed; }
.pago-hoy-aviso { background:#dcfce7; border:1px solid #bbf7d0; border-radius:10px; padding:12px 14px; font-size:.82rem; font-weight:600; color:#14532d; display:flex; align-items:center; gap:8px; margin-bottom:14px; }

/* ── DARK MODE ── */
[data-theme="dark"] body            { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .btn-icon       { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .cliente-card   { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .cli-nombre     { color:#f8fafc; }
[data-theme="dark"] .detalle-item   { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .detalle-val    { color:#e2e8f0; }
[data-theme="dark"] .prog-wrap      { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .prog-bar       { background:#334155; }
[data-theme="dark"] .tabla-wrap     { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .tabla-head     { color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] table.pagos-tbl th { background:#0f172a; }
[data-theme="dark"] table.pagos-tbl td { color:#94a3b8; border-color:#1e293b; }
[data-theme="dark"] table.pagos-tbl tr:hover td { background:#0f172a; }
[data-theme="dark"] .panel-cobro    { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .panel-cobro h3 { color:#f8fafc; }
[data-theme="dark"] .field label    { color:#94a3b8; }
[data-theme="dark"] .field input    { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .resumen-cobro  { background:#0f172a; }
[data-theme="dark"] .resumen-cobro .r-row .lbl { color:#64748b; }
[data-theme="dark"] .resumen-cobro .r-row .val { color:#e2e8f0; }
[data-theme="dark"] .resumen-cobro .r-row.total .lbl { color:#e2e8f0; }

/* ── RESPONSIVE ── */
@media(max-width:1024px) { .layout { grid-template-columns:1fr; } .panel-cobro { position:static; } }
@media(max-width:900px)  { .sidebar { display:none; } .main { margin-left:0; padding:14px 14px 60px; } }
@media(max-width:600px)  { .detalle-grid { grid-template-columns:1fr 1fr; } }
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger active"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if (in_array($rol, ['GERENTE','SUPERVISOR'])): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <a href="cobro_diario/cobro_lista.php?id_empleado=<?= $id_empleado ?>" class="btn-icon" title="Regresar">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-cash-coin" style="color:#16a34a;"></i> Registrar Cobro</h1>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <?php if ($msg): ?>
    <div class="alerta error">
        <i class="bi bi-x-circle-fill"></i>
        <div><?= htmlspecialchars($msg) ?></div>
    </div>
    <?php endif; ?>

    <!-- CLIENTE -->
    <div class="cliente-card">
        <div class="cli-av">
            <?= strtoupper(mb_substr($prestamo['cli_nombre'],0,1) . mb_substr($prestamo['cli_apellido'],0,1)) ?>
        </div>
        <div style="flex:1;">
            <div class="cli-nombre">
                <?= htmlspecialchars($prestamo['cli_nombre'] . ' ' . $prestamo['cli_apellido']) ?>
                <span class="badge-estado badge-<?= strtolower($prestamo['estado']) ?>" style="margin-left:8px;font-size:.65rem;">
                    <?= $prestamo['estado'] ?>
                </span>
            </div>
            <div class="cli-meta">
                <?php if ($prestamo['cli_tel']): ?>
                <span><i class="bi bi-telephone-fill"></i> <?= htmlspecialchars($prestamo['cli_tel']) ?></span>
                <?php endif; ?>
                <?php if ($prestamo['cli_dir']): ?>
                <span><i class="bi bi-geo-alt-fill"></i> <?= htmlspecialchars($prestamo['cli_dir']) ?></span>
                <?php endif; ?>
                <span><i class="bi bi-hash"></i> Préstamo #<?= $prestamo['id_prestamo'] ?></span>
                <?php if ($prestamo['asesor_nombre']): ?>
                <span><i class="bi bi-person-fill"></i> <?= htmlspecialchars($prestamo['asesor_nombre'].' '.$prestamo['asesor_apellido']) ?></span>
                <?php endif; ?>
            </div>
        </div>
        <a href="historial_cliente.php?id=<?= $prestamo['id_cliente'] ?>" class="btn-icon" title="Ver historial del cliente">
            <i class="bi bi-clock-history"></i>
        </a>
    </div>

    <!-- DETALLES DEL PRÉSTAMO -->
    <div class="detalle-grid">
        <div class="detalle-item">
            <div class="detalle-val detalle-rojo">$<?= number_format($saldo, 2) ?></div>
            <div class="detalle-lbl">Saldo pendiente</div>
        </div>
        <div class="detalle-item">
            <div class="detalle-val detalle-<?= $es_semanal ? 'naranja' : 'azul' ?>">$<?= number_format($cuota, 2) ?></div>
            <div class="detalle-lbl"><?= $es_semanal ? 'Cuota semanal' : 'Cuota diaria' ?></div>
        </div>
        <div class="detalle-item">
            <div class="detalle-val detalle-verde">$<?= number_format($prestamo['total_pagado'], 2) ?></div>
            <div class="detalle-lbl">Total pagado</div>
        </div>
        <div class="detalle-item">
            <div class="detalle-val">$<?= number_format($prestamo['total_pagar'], 2) ?></div>
            <div class="detalle-lbl">Total a pagar</div>
        </div>
        <?php if (!empty($prestamo['fecha_inicio'])): ?>
        <div class="detalle-item">
            <div class="detalle-val" style="font-size:.88rem;"><?= date('d/m/Y', strtotime($prestamo['fecha_inicio'])) ?></div>
            <div class="detalle-lbl">Fecha inicio</div>
        </div>
        <?php endif; ?>
        <?php if (!empty($prestamo['fecha_fin'])): ?>
        <div class="detalle-item">
            <div class="detalle-val" style="font-size:.88rem;"><?= date('d/m/Y', strtotime($prestamo['fecha_fin'])) ?></div>
            <div class="detalle-lbl">Fecha fin</div>
        </div>
        <?php endif; ?>
    </div>

    <!-- PROGRESO -->
    <div class="prog-wrap">
        <div style="display:flex;justify-content:space-between;font-size:.82rem;font-weight:600;">
            <span>Avance del crédito</span>
            <span style="color:#16a34a;"><?= $score_pct ?>%</span>
        </div>
        <div class="prog-bar">
            <div class="prog-fill" style="width:<?= $score_pct ?>%;"></div>
        </div>
        <div style="font-size:.72rem;color:#94a3b8;margin-top:2px;">
            $<?= number_format($prestamo['total_pagado'],2) ?> pagado de $<?= number_format($prestamo['total_pagar'],2) ?>
        </div>
    </div>

    <div class="layout">

        <!-- HISTORIAL DE PAGOS -->
        <div class="tabla-wrap">
            <div class="tabla-head">
                <i class="bi bi-clock-history" style="color:#2563eb;"></i>
                Últimos pagos
            </div>
            <?php if (empty($ultimos_pagos)): ?>
            <div class="empty-tbl">Sin pagos registrados aún.</div>
            <?php else: ?>
            <table class="pagos-tbl">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Monto</th>
                        <th>Tipo</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($ultimos_pagos as $pg): ?>
                <tr>
                    <td><?= date('d/m/Y', strtotime($pg['fecha_pago'])) ?></td>
                    <td style="font-weight:700;color:#16a34a;">$<?= number_format($pg['monto_pagado'],2) ?></td>
                    <td style="font-size:.78rem;color:#64748b;"><?= htmlspecialchars($pg['tipo_pago'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- PANEL REGISTRO DE COBRO -->
        <div class="panel-cobro">
            <h3><i class="bi bi-cash-coin" style="color:#16a34a;"></i> Registrar pago</h3>

            <?php if ($pago_hoy > 0): ?>
            <div class="pago-hoy-aviso">
                <i class="bi bi-check-circle-fill"></i>
                Ya se registró $<?= number_format($pago_hoy,2) ?> hoy para este préstamo.
            </div>
            <?php endif; ?>

            <form method="POST" id="form-cobro">
                <input type="hidden" name="id_prestamo_param" value="<?= $id_prestamo ?>">
                <input type="hidden" name="asesor"            value="<?= $id_empleado ?>">

                <div class="field">
                    <label><i class="bi bi-calendar3" style="margin-right:3px;"></i> Fecha del cobro</label>
                    <input type="date" name="fecha_cobro" id="fecha_cobro"
                           value="<?= $hoy ?>" max="<?= $hoy ?>" required>
                </div>

                <div class="field">
                    <label><i class="bi bi-currency-dollar" style="margin-right:3px;"></i> Monto a cobrar ($)</label>
                    <input type="number" name="pagos[<?= $id_prestamo ?>]" id="monto_pago"
                           step="0.01" min="0.01" max="<?= $saldo ?>"
                           placeholder="<?= number_format($cuota, 2) ?>"
                           oninput="actualizarResumen()" required>
                    <div class="monto-sugerido">
                        <button type="button"
                                class="chip-monto <?= $es_semanal ? 'semanal' : '' ?>"
                                onclick="setMonto(<?= $cuota ?>)">
                            Cuota: $<?= number_format($cuota, 2) ?>
                        </button>
                        <?php if ($saldo > 0 && $saldo != $cuota): ?>
                        <button type="button" class="chip-monto" onclick="setMonto(<?= $saldo ?>)"
                                style="border-color:#fca5a5;background:#fef2f2;color:#991b1b;">
                            Liquidar: $<?= number_format($saldo, 2) ?>
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <hr class="divider">

                <div class="resumen-cobro">
                    <div class="r-row">
                        <span class="lbl">Saldo actual</span>
                        <span class="val">$<?= number_format($saldo, 2) ?></span>
                    </div>
                    <div class="r-row">
                        <span class="lbl">Monto a registrar</span>
                        <span class="val" id="res-monto">$0.00</span>
                    </div>
                    <div class="r-row">
                        <span class="lbl">Saldo resultante</span>
                        <span class="val" id="res-saldo">$<?= number_format($saldo, 2) ?></span>
                    </div>
                    <hr style="border:none;border-top:1px solid #e2e8f0;margin:8px 0;">
                    <div class="r-row total">
                        <span class="lbl" id="res-estado-lbl">Estado</span>
                        <span class="val" id="res-estado">—</span>
                    </div>
                </div>

                <button type="submit" class="btn-cobrar" id="btn-cobrar" disabled>
                    <i class="bi bi-floppy-fill"></i> Guardar cobro
                </button>
            </form>
        </div>

    </div>

</main>
</div>

<script>
/* ── TEMA ── */
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), p = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── RESUMEN EN TIEMPO REAL ── */
var saldoActual = <?= $saldo ?>;

function fmt(n) {
    return '$' + parseFloat(n).toLocaleString('es-MX', {minimumFractionDigits:2, maximumFractionDigits:2});
}

function actualizarResumen() {
    var monto = parseFloat(document.getElementById('monto_pago').value) || 0;
    var nuevo  = Math.max(0, saldoActual - monto);
    document.getElementById('res-monto').textContent  = fmt(monto);
    document.getElementById('res-saldo').textContent  = fmt(nuevo);

    var btn = document.getElementById('btn-cobrar');
    if (monto > 0 && monto <= saldoActual) {
        document.getElementById('res-estado').textContent   = nuevo <= 0 ? 'LIQUIDADO' : 'ACTIVO';
        document.getElementById('res-estado').style.color   = nuevo <= 0 ? '#16a34a'  : '#2563eb';
        btn.disabled = false;
    } else {
        document.getElementById('res-estado').textContent = '—';
        document.getElementById('res-estado').style.color = '';
        btn.disabled = true;
    }
}

function setMonto(val) {
    document.getElementById('monto_pago').value = val.toFixed(2);
    actualizarResumen();
}
</script>
</body>
</html>

<?php
date_default_timezone_set('America/Hermosillo');

$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR'];
include("seguridad.php");
include("conexion.php");

$rol    = $_SESSION['rol']     ?? 'ASESOR';
$user   = $_SESSION['usuario'] ?? 'Usuario';
$hoy    = date('Y-m-d');

$fecha  = $_GET['fecha']  ?? $hoy;
$asesor = intval($_GET['asesor'] ?? $_SESSION['id_empleado'] ?? 0);
$esDomingo = (date('w', strtotime($fecha)) == 0);

/* ── VALIDAR CORTE DEL DÍA ── */
$bloqueado = false;
$check_tabla = $conexion->query("SHOW TABLES LIKE 'cortes_diarios'");
if ($check_tabla && $check_tabla->num_rows > 0) {
    $res_corte = $conexion->query("
        SELECT id FROM cortes_diarios
        WHERE fecha = '$fecha' AND id_empleado = $asesor
    ");
    if ($res_corte && $res_corte->num_rows > 0) $bloqueado = true;
}

/* ── DÍAS HÁBILES ── */
function diasHabiles($inicio, $fin) {
    $i = new DateTime($inicio);
    $f = new DateTime($fin);
    $f->modify('+1 day');
    $d = 0;
    foreach (new DatePeriod($i, new DateInterval('P1D'), $f) as $x) {
        if ($x->format('N') < 7) $d++;
    }
    return $d;
}

/* ── ASESORES (solo para roles superiores) ── */
$asesores = [];
if ($rol !== 'ASESOR') {
    $res = $conexion->query("SELECT id_empleado, nombre, apellido FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
    while ($a = $res->fetch_assoc()) $asesores[] = $a;
}

/* ── KPIs PRINCIPALES ── */
$resumen = $conexion->query("
    SELECT
        SUM(CASE WHEN pago_diario > 0 THEN pago_diario ELSE total_pagar / plazo_semanas END) AS meta,
        SUM(monto_prestado)  AS total_capital,
        SUM(total_pagar)     AS total_con_interes,
        SUM(saldo_actual)    AS saldo_cartera,
        COUNT(*)             AS total_prestamos
    FROM prestamos
    WHERE estado='ACTIVO' AND id_empleado = $asesor
")->fetch_assoc();

$meta             = floatval($resumen['meta']             ?? 0);
$total_capital    = floatval($resumen['total_capital']    ?? 0);
$total_con_interes= floatval($resumen['total_con_interes']?? 0);
$saldo_cartera    = floatval($resumen['saldo_cartera']    ?? 0);
$total_prestamos  = intval($resumen['total_prestamos']    ?? 0);
$total_intereses  = $total_con_interes - $total_capital;

$cobrado = floatval($conexion->query("
    SELECT IFNULL(SUM(monto_pagado),0) AS t
    FROM pagos p
    INNER JOIN prestamos pr ON pr.id_prestamo = p.id_prestamo
    WHERE DATE(fecha_pago) = '$fecha' AND pr.id_empleado = $asesor
")->fetch_assoc()['t'] ?? 0);

$falta       = max(0, $meta - $cobrado);
$efectividad = $meta > 0 ? min(100, round(($cobrado / $meta) * 100)) : 0;
$excedente   = max(0, $cobrado - $meta);

/* ── CONTAR PAGADOS HOY / PENDIENTES / ATRASADOS ── */
$stats_hoy = $conexion->query("
    SELECT
        COUNT(*) AS total_activos,
        SUM(CASE WHEN EXISTS(SELECT 1 FROM pagos WHERE id_prestamo=pr.id_prestamo AND DATE(fecha_pago)='$fecha') THEN 1 ELSE 0 END) AS pagaron_hoy,
        SUM(CASE WHEN fecha_fin < '$fecha' THEN 1 ELSE 0 END) AS vencidos
    FROM prestamos pr
    WHERE pr.estado='ACTIVO' AND pr.id_empleado = $asesor
")->fetch_assoc();
$pagaron_hoy  = intval($stats_hoy['pagaron_hoy']  ?? 0);
$total_activos= intval($stats_hoy['total_activos'] ?? 0);
$vencidos_hoy = intval($stats_hoy['vencidos']      ?? 0);

/* ── CONSULTA PRINCIPAL ── */
$query = $conexion->query("
    SELECT
        pr.*,
        c.nombre AS cli_nombre, c.apellido AS cli_apellido, c.telefono AS cli_telefono,
        c.id_cliente AS cli_id_cliente,
        (SELECT IFNULL(SUM(monto_pagado),0) FROM pagos WHERE id_prestamo=pr.id_prestamo) pagado,
        (SELECT MAX(fecha_pago) FROM pagos WHERE id_prestamo=pr.id_prestamo) ultima,
        (SELECT monto_pagado FROM pagos WHERE id_prestamo=pr.id_prestamo AND DATE(fecha_pago)='$fecha' LIMIT 1) hoy
    FROM prestamos pr
    INNER JOIN clientes c ON c.id_cliente = pr.id_cliente
    WHERE pr.id_empleado = $asesor
    AND DATE(pr.fecha_inicio) < '$fecha'
    AND (
        pr.estado = 'ACTIVO'
        OR (pr.estado = 'PAGADO' AND EXISTS (
            SELECT 1 FROM pagos WHERE id_prestamo=pr.id_prestamo AND DATE(fecha_pago)='$fecha'
        ))
    )
    ORDER BY pr.fecha_inicio DESC
");
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Cobranza Diaria — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 100px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06);
    text-decoration:none;
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── BANNER ── */
.banner {
    display:flex; align-items:center; gap:12px;
    padding:13px 18px; border-radius:12px; margin-bottom:18px;
    font-size:.85rem; font-weight:600; border:1px solid transparent;
}
.banner-corte   { background:#fffbeb; color:#92400e; border-color:#fde68a; }
.banner-domingo { background:#fef3c7; color:#78350f; border-color:#fde68a; }
.banner-icon { font-size:1.5rem; flex-shrink:0; }

/* ── FILTROS ── */
.filtros-bar {
    background:white; border-radius:14px; padding:12px 16px; margin-bottom:20px;
    display:flex; gap:10px; align-items:center; flex-wrap:wrap;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
}
.filtros-bar label { font-size:.76rem; font-weight:700; color:#475569; white-space:nowrap; }
.f-select, .f-date {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 12px;
    font-size:.84rem; font-family:'Inter',sans-serif; color:#1e293b;
    background:#f8fafc; outline:none; cursor:pointer; transition:border-color .15s;
}
.f-select:focus, .f-date:focus { border-color:#2563eb; background:white; }
.nav-fechas { display:flex; gap:6px; margin-left:auto; }
.btn-nav-f {
    display:inline-flex; align-items:center; gap:5px;
    background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:8px;
    padding:6px 12px; font-size:.76rem; font-weight:600; color:#475569;
    text-decoration:none; transition:all .15s;
}
.btn-nav-f:hover { border-color:#2563eb; color:#2563eb; background:#eff6ff; }

/* ── KPI GRID ── */
.kpi-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:16px; }
.kpi-card {
    background:white; border-radius:14px; padding:16px 18px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
    border-left:4px solid transparent;
}
.kpi-card.azul    { border-left-color:#2563eb; }
.kpi-card.verde   { border-left-color:#16a34a; }
.kpi-card.rojo    { border-left-color:#dc2626; }
.kpi-card.amarillo{ border-left-color:#d97706; }
.kpi-lbl { font-size:.68rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:5px; display:flex; align-items:center; gap:5px; }
.kpi-val { font-size:1.5rem; font-weight:800; line-height:1; }
.kpi-card.azul     .kpi-val { color:#2563eb; }
.kpi-card.verde    .kpi-val { color:#16a34a; }
.kpi-card.rojo     .kpi-val { color:#dc2626; }
.kpi-card.amarillo .kpi-val { color:#d97706; }
.kpi-sub  { font-size:.72rem; color:#94a3b8; margin-top:4px; }
.kpi-extra{ font-size:.76rem; color:#16a34a; font-weight:700; margin-top:3px; }

/* ── BARRA DE EFECTIVIDAD ── */
.eff-wrap  { margin-top:6px; }
.eff-track { height:5px; background:#f1f5f9; border-radius:99px; overflow:hidden; margin-bottom:2px; }
.eff-fill  { height:100%; border-radius:99px; transition:width .5s ease; }

/* ── BLOQUE DE CARTERA ── */
.cartera-block {
    background:linear-gradient(135deg,#0f172a,#1e293b); border-radius:16px;
    padding:20px 24px; margin-bottom:20px; color:white;
    box-shadow:0 4px 20px rgba(0,0,0,.15);
    display:grid; grid-template-columns:repeat(4,1fr); gap:20px; align-items:center;
}
.cb-lbl { font-size:.66rem; text-transform:uppercase; letter-spacing:.08em; color:#64748b; font-weight:700; margin-bottom:4px; }
.cb-val { font-size:1.3rem; font-weight:800; line-height:1; }
.cb-val.capital { color:#93c5fd; }
.cb-val.interes { color:#fde68a; }
.cb-val.total   { color:#4ade80; font-size:1.6rem; }
.cb-val.saldo   { color:#f87171; }
.cb-sub { font-size:.7rem; color:#475569; margin-top:3px; }
.cb-divider { width:1px; background:#334155; align-self:stretch; }

/* ── MINI STATS HOY ── */
.mini-stats { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-bottom:20px; }
.ms-card {
    background:white; border-radius:12px; padding:12px 14px;
    border:1px solid #f1f5f9; box-shadow:0 1px 4px rgba(0,0,0,.04);
    display:flex; align-items:center; gap:10px;
}
.ms-icon { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
.ms-icon.verde { background:#dcfce7; color:#16a34a; }
.ms-icon.azul  { background:#dbeafe; color:#2563eb; }
.ms-icon.rojo  { background:#fee2e2; color:#dc2626; }
.ms-lbl { font-size:.7rem; color:#94a3b8; font-weight:600; }
.ms-val { font-size:1.1rem; font-weight:800; color:#0f172a; }

/* ── TABLA ── */
.tabla-cobro-wrap {
    background:white; border-radius:16px; overflow:hidden;
    border:1px solid #f1f5f9; box-shadow:0 2px 10px rgba(0,0,0,.07);
    margin-bottom:24px;
}
.tabla-cobro-head {
    background:#0f172a; color:#e2e8f0;
    padding:14px 20px; display:flex; align-items:center; gap:10px;
}
.tabla-cobro-head strong { font-size:.92rem; font-weight:800; }
.tabla-cobro-head .tc-fecha {
    margin-left:auto; background:#1e293b; padding:4px 12px; border-radius:99px;
    font-size:.76rem; color:#60a5fa; font-weight:700;
}
table { width:100%; border-collapse:collapse; }
thead th {
    background:#1e293b; color:#94a3b8;
    font-size:.68rem; text-transform:uppercase; letter-spacing:.07em;
    padding:11px 14px; font-weight:700; text-align:left;
}
thead th:last-child,
thead th:nth-last-child(2),
thead th:nth-last-child(3) { text-align:center; }
tbody td { padding:11px 14px; border-bottom:1px solid #f8fafc; font-size:.83rem; vertical-align:middle; }
tbody tr:last-child td { border-bottom:none; }

/* Colores de riesgo */
.riesgo-alto  td { background:#fef2f2; }
.riesgo-medio td { background:#fffbeb; }
.riesgo-bajo  td { background:#f8fafc; }
.riesgo-alto:hover  td { background:#fee2e2; }
.riesgo-medio:hover td { background:#fef3c7; }
.riesgo-bajo:hover  td { background:#f0f9ff; }
.riesgo-pagado td   { background:#f0fdf4; opacity:.85; }

/* ── BARRA DE PROGRESO EN TABLA ── */
.prog-mini { height:6px; background:#f1f5f9; border-radius:99px; overflow:hidden; margin-top:4px; }
.prog-mini-fill { height:100%; border-radius:99px; background:#16a34a; }

/* ── BADGE CHIPS ── */
.chip { display:inline-flex; align-items:center; gap:3px; padding:2px 8px; border-radius:99px; font-size:.7rem; font-weight:700; }
.chip-id   { background:#f1f5f9; color:#475569; }
.chip-dias { background:#fee2e2; color:#991b1b; }
.chip-ok   { background:#dcfce7; color:#166534; }
.chip-vence{ background:#fef3c7; color:#92400e; }

/* ── INPUT COBRO ── */
.inp-cobro {
    width:90px; border:1.5px solid #e2e8f0; border-radius:8px;
    padding:7px 9px; font-size:.84rem; font-family:'Inter',sans-serif;
    color:#1e293b; background:#f8fafc; outline:none; text-align:right;
    transition:border-color .15s;
}
.inp-cobro:focus    { border-color:#2563eb; background:white; box-shadow:0 0 0 3px rgba(37,99,235,.1); }
.inp-cobro:disabled { background:#f8fafc; color:#94a3b8; cursor:not-allowed; }

/* ── BOTONES COBRO ── */
.btn-cob {
    display:inline-flex; align-items:center; justify-content:center;
    height:30px; min-width:30px; border-radius:7px; border:none;
    font-size:.78rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif;
    transition:all .15s; padding:0 7px; gap:3px;
}
.btn-cob.full   { background:#dcfce7; color:#166534; }
.btn-cob.full:hover   { background:#16a34a; color:white; }
.btn-cob.half   { background:#fef3c7; color:#92400e; }
.btn-cob.half:hover   { background:#d97706; color:white; }
.btn-cob.zero   { background:#fee2e2; color:#991b1b; }
.btn-cob.zero:hover   { background:#dc2626; color:white; }
.btn-cob.visita { background:#f3e8ff; color:#7c3aed; }
.btn-cob.visita:hover { background:#7c3aed; color:white; }
.btn-cob:disabled { opacity:.35; cursor:not-allowed; }

/* ── BOTÓN GUARDAR STICKY ── */
.sticky-save {
    position:fixed; bottom:28px; right:28px; z-index:500;
    display:flex; align-items:center; gap:9px;
    background:#16a34a; color:white; border:none; border-radius:14px;
    padding:14px 26px; font-size:.95rem; font-weight:800;
    cursor:pointer; font-family:'Inter',sans-serif;
    box-shadow:0 8px 24px rgba(22,163,74,.4); transition:all .2s;
}
.sticky-save:hover { background:#15803d; transform:translateY(-2px); box-shadow:0 12px 30px rgba(22,163,74,.45); }

/* ── BADGES ── */
.badge-liq { display:inline-block; background:#dcfce7; color:#166534; padding:2px 8px; border-radius:99px; font-size:.7rem; font-weight:700; margin-top:3px; }

/* ── FOOTER ── */
.page-footer { text-align:center; color:#cbd5e1; font-size:.72rem; padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px; }

/* ── MODAL VISITA ── */
.modal-overlay {
    display:none; position:fixed; inset:0; background:rgba(0,0,0,.55);
    z-index:1000; align-items:center; justify-content:center;
    backdrop-filter:blur(4px);
}
.modal-overlay.open { display:flex; }
.modal-box {
    background:white; border-radius:18px; padding:28px 28px 24px;
    width:90%; max-width:460px;
    box-shadow:0 20px 60px rgba(0,0,0,.3);
    animation:fadeUp .2s ease;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
.modal-title {
    font-size:1.05rem; font-weight:800; color:#0f172a;
    margin-bottom:4px; display:flex; align-items:center; gap:8px;
}
.modal-sub   { font-size:.8rem; color:#7c3aed; font-weight:700; margin-bottom:18px; }
.modal-field { margin-bottom:14px; }
.modal-field label { font-size:.76rem; font-weight:700; color:#475569; display:block; margin-bottom:5px; }
.modal-select, .modal-textarea {
    width:100%; border:1.5px solid #e2e8f0; border-radius:9px;
    padding:9px 12px; font-size:.85rem; font-family:'Inter',sans-serif;
    color:#1e293b; background:#f8fafc; outline:none; resize:vertical;
    transition:border-color .15s;
}
.modal-select:focus, .modal-textarea:focus { border-color:#7c3aed; background:white; }
.modal-textarea { min-height:80px; }
.modal-actions { display:flex; gap:8px; justify-content:flex-end; margin-top:20px; }
.btn-modal-cancel {
    padding:9px 18px; border-radius:9px; border:1.5px solid #e2e8f0;
    background:white; color:#64748b; font-size:.84rem; font-weight:700;
    font-family:'Inter',sans-serif; cursor:pointer; transition:all .15s;
}
.btn-modal-cancel:hover { border-color:#dc2626; color:#dc2626; }
.btn-modal-save {
    padding:9px 20px; border-radius:9px; border:none;
    background:#7c3aed; color:white; font-size:.84rem; font-weight:700;
    font-family:'Inter',sans-serif; cursor:pointer; transition:all .15s;
    display:flex; align-items:center; gap:6px;
}
.btn-modal-save:hover  { background:#6d28d9; }
.btn-modal-save:disabled { opacity:.5; cursor:not-allowed; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 100px; }
    .kpi-grid { grid-template-columns:1fr 1fr; }
    .cartera-block { grid-template-columns:1fr 1fr; }
    .mini-stats { grid-template-columns:1fr; }
    table thead th:nth-child(3),
    table tbody td:nth-child(3) { display:none; }
    .inp-cobro { width:75px; }
}
@media(max-width:600px){
    .kpi-grid { grid-template-columns:1fr; }
    .cartera-block { grid-template-columns:1fr 1fr; gap:12px; padding:14px 16px; }
}

/* ── MODO OSCURO ── */
[data-theme="dark"] body           { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1{ color:#e2e8f0; }
[data-theme="dark"] .btn-theme     { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover{ color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .banner-corte  { background:rgba(146,64,14,.15); border-color:rgba(253,230,138,.2); color:#fde68a; }
[data-theme="dark"] .banner-domingo{ background:rgba(120,53,15,.15); border-color:rgba(253,230,138,.2); color:#fde68a; }
[data-theme="dark"] .filtros-bar   { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .f-select,
[data-theme="dark"] .f-date        { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .btn-nav-f     { background:#1e293b; border-color:#334155; color:#64748b; }
[data-theme="dark"] .kpi-card      { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .cartera-block { background:linear-gradient(135deg,#020617,#0f172a); }
[data-theme="dark"] .ms-card       { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .ms-val        { color:#e2e8f0; }
[data-theme="dark"] .tabla-cobro-wrap{ background:#111827; border-color:#1e293b; }
[data-theme="dark"] .tabla-cobro-head{ background:#020617; }
[data-theme="dark"] thead th       { background:#0f172a; }
[data-theme="dark"] tbody td       { border-color:#1e293b; }
[data-theme="dark"] .riesgo-alto  td { background:rgba(220,38,38,.06); }
[data-theme="dark"] .riesgo-medio td { background:rgba(217,119,6,.06); }
[data-theme="dark"] .riesgo-bajo  td { background:#111827; }
[data-theme="dark"] .riesgo-pagado td{ background:rgba(22,163,74,.05); }
[data-theme="dark"] .chip-id       { background:#1e293b; color:#64748b; }
[data-theme="dark"] .prog-mini     { background:#1e293b; }
[data-theme="dark"] .inp-cobro     { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .inp-cobro:focus{ background:#1e293b; }
[data-theme="dark"] .btn-cob.full  { background:rgba(22,163,74,.15);  color:#4ade80; }
[data-theme="dark"] .btn-cob.half  { background:rgba(217,119,6,.15);  color:#fde68a; }
[data-theme="dark"] .btn-cob.zero  { background:rgba(220,38,38,.15);  color:#f87171; }
[data-theme="dark"] .btn-cob.visita{ background:rgba(124,58,237,.15); color:#c4b5fd; }
[data-theme="dark"] .page-footer   { color:#334155; border-color:#1e293b; }
[data-theme="dark"] .modal-box     { background:#111827; }
[data-theme="dark"] .modal-title   { color:#f1f5f9; }
[data-theme="dark"] .modal-field label{ color:#94a3b8; }
[data-theme="dark"] .modal-select,
[data-theme="dark"] .modal-textarea{ background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .modal-select:focus,
[data-theme="dark"] .modal-textarea:focus{ background:#1e293b; }
[data-theme="dark"] .btn-modal-cancel{ background:#1e293b; border-color:#334155; color:#94a3b8; }
.td-nombre { color:#0f172a; }
[data-theme="dark"] .td-nombre { color:#f1f5f9; }
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php" class="active"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="btn-theme" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <h1><i class="bi bi-credit-card-fill" style="color:#2563eb;"></i> Cobranza Diaria</h1>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
        </div>
    </div>

    <!-- BANNERS -->
    <?php if ($bloqueado): ?>
    <div class="banner banner-corte">
        <i class="bi bi-lock-fill banner-icon"></i>
        <div>
            <strong>Corte del día ya registrado.</strong>
            La cobranza del <strong><?= date('d/m/Y', strtotime($fecha)) ?></strong> fue cerrada.
            Solo puede visualizarse.
        </div>
    </div>
    <?php endif; ?>
    <?php if ($esDomingo): ?>
    <div class="banner banner-domingo">
        <i class="bi bi-calendar-x-fill banner-icon"></i>
        <div><strong>Domingo.</strong> No se registran cobros los días domingo.</div>
    </div>
    <?php endif; ?>

    <!-- FILTROS -->
    <form method="GET" class="filtros-bar">
        <?php if ($rol !== 'ASESOR'): ?>
        <label><i class="bi bi-person-badge" style="margin-right:3px;"></i>Asesor:</label>
        <select name="asesor" class="f-select" onchange="this.form.submit()">
            <?php foreach ($asesores as $a): ?>
            <option value="<?= $a['id_empleado'] ?>"
                    <?= $asesor == $a['id_empleado'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($a['nombre'].' '.$a['apellido']) ?>
            </option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>
        <label><i class="bi bi-calendar3" style="margin-right:3px;"></i>Fecha:</label>
        <input type="date" name="fecha" value="<?= $fecha ?>" class="f-date" onchange="this.form.submit()">

        <div class="nav-fechas">
            <?php
            $prev = date('Y-m-d', strtotime($fecha.' -1 day'));
            $next = date('Y-m-d', strtotime($fecha.' +1 day'));
            ?>
            <a href="?fecha=<?= $prev ?>&asesor=<?= $asesor ?>" class="btn-nav-f">
                <i class="bi bi-chevron-left"></i> Anterior
            </a>
            <a href="?fecha=<?= $hoy ?>&asesor=<?= $asesor ?>" class="btn-nav-f"
               style="<?= $fecha===$hoy?'border-color:#2563eb;color:#2563eb;':'' ?>">
                <i class="bi bi-calendar-check"></i> Hoy
            </a>
            <?php if ($next <= $hoy): ?>
            <a href="?fecha=<?= $next ?>&asesor=<?= $asesor ?>" class="btn-nav-f">
                Siguiente <i class="bi bi-chevron-right"></i>
            </a>
            <?php endif; ?>
        </div>
    </form>

    <!-- KPIs DEL DÍA -->
    <div class="kpi-grid">
        <div class="kpi-card azul">
            <div class="kpi-lbl"><i class="bi bi-bullseye"></i> Meta del día</div>
            <div class="kpi-val">$<?= number_format($meta, 2) ?></div>
            <div class="kpi-sub">cobro esperado</div>
        </div>
        <div class="kpi-card verde">
            <div class="kpi-lbl"><i class="bi bi-cash-coin"></i> Cobrado hoy</div>
            <div class="kpi-val" id="kpiCobrado">$<?= number_format($cobrado, 2) ?></div>
            <?php if ($excedente > 0): ?>
            <div class="kpi-extra"><i class="bi bi-arrow-up"></i> +$<?= number_format($excedente, 2) ?> extra</div>
            <?php else: ?>
            <div class="kpi-sub"><?= date('d/m/Y', strtotime($fecha)) ?></div>
            <?php endif; ?>
        </div>
        <div class="kpi-card <?= $efectividad >= 100 ? 'verde' : ($efectividad >= 70 ? 'amarillo' : 'rojo') ?>">
            <div class="kpi-lbl"><i class="bi bi-speedometer2"></i> Efectividad</div>
            <div class="kpi-val"><?= $efectividad ?>%</div>
            <div class="eff-wrap">
                <div class="eff-track">
                    <div class="eff-fill"
                         style="width:<?= $efectividad ?>%;background:<?= $efectividad>=100?'#16a34a':($efectividad>=70?'#d97706':'#dc2626') ?>;"></div>
                </div>
            </div>
        </div>
        <div class="kpi-card amarillo">
            <div class="kpi-lbl"><i class="bi bi-hourglass-split"></i> Falta cobrar</div>
            <div class="kpi-val">$<?= number_format($falta, 2) ?></div>
            <div class="kpi-sub">pendiente del día</div>
        </div>
    </div>

    <!-- BLOQUE CARTERA -->
    <div class="cartera-block">
        <div class="cb-item">
            <div class="cb-lbl"><i class="bi bi-cash-stack" style="margin-right:4px;"></i>Capital prestado</div>
            <div class="cb-val capital">$<?= number_format($total_capital, 2) ?></div>
            <div class="cb-sub">monto original entregado</div>
        </div>
        <div class="cb-item">
            <div class="cb-lbl"><i class="bi bi-percent" style="margin-right:4px;"></i>Intereses generados</div>
            <div class="cb-val interes">+$<?= number_format($total_intereses, 2) ?></div>
            <div class="cb-sub">
                <?= $total_capital > 0 ? number_format(($total_intereses / $total_capital) * 100, 1) : 0 ?>% sobre capital
            </div>
        </div>
        <div class="cb-item">
            <div class="cb-lbl"><i class="bi bi-bank" style="margin-right:4px;"></i>Total a recuperar</div>
            <div class="cb-val total">$<?= number_format($total_con_interes, 2) ?></div>
            <div class="cb-sub">capital + intereses</div>
        </div>
        <div class="cb-item">
            <div class="cb-lbl"><i class="bi bi-wallet2" style="margin-right:4px;"></i>Saldo en cartera</div>
            <div class="cb-val saldo">$<?= number_format($saldo_cartera, 2) ?></div>
            <div class="cb-sub">por cobrar actualmente</div>
        </div>
    </div>

    <!-- MINI STATS DEL DÍA -->
    <div class="mini-stats">
        <div class="ms-card">
            <div class="ms-icon verde"><i class="bi bi-check-circle-fill"></i></div>
            <div>
                <div class="ms-lbl">Pagaron hoy</div>
                <div class="ms-val"><?= $pagaron_hoy ?> / <?= $total_activos ?></div>
            </div>
        </div>
        <div class="ms-card">
            <div class="ms-icon azul"><i class="bi bi-file-earmark-text-fill"></i></div>
            <div>
                <div class="ms-lbl">Préstamos activos</div>
                <div class="ms-val"><?= $total_activos ?></div>
            </div>
        </div>
        <div class="ms-card">
            <div class="ms-icon rojo"><i class="bi bi-exclamation-triangle-fill"></i></div>
            <div>
                <div class="ms-lbl">Vencidos</div>
                <div class="ms-val" style="color:<?= $vencidos_hoy>0?'#dc2626':'inherit' ?>"><?= $vencidos_hoy ?></div>
            </div>
        </div>
    </div>

    <!-- TABLA DE COBRANZA -->
    <form method="POST" action="registrar_cobros.php">
        <input type="hidden" name="fecha_cobro" value="<?= $fecha ?>">
        <input type="hidden" name="meta"         value="<?= $resumen['meta'] ?? 0 ?>">
        <input type="hidden" name="asesor"       value="<?= $asesor ?>">

        <div class="tabla-cobro-wrap">
            <div class="tabla-cobro-head">
                <i class="bi bi-credit-card-fill" style="color:#60a5fa;font-size:1.1rem;"></i>
                <strong>Cobranza Inteligente</strong>
                <span class="tc-fecha">
                    <i class="bi bi-calendar3" style="margin-right:4px;"></i><?= date('d/m/Y', strtotime($fecha)) ?>
                </span>
            </div>

            <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Desde</th>
                        <th>Avance</th>
                        <th>Saldo</th>
                        <th>Cuota</th>
                        <th style="text-align:center;">Acciones</th>
                        <th style="text-align:center;">Visita</th>
                        <th style="text-align:center;">Cobrar</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $query->data_seek(0);
                while ($p = $query->fetch_assoc()):
                    $saldo_p = floatval($p['total_pagar']) - floatval($p['pagado']);
                    $cuota   = floatval($p['pago_diario']) > 0
                               ? floatval($p['pago_diario'])
                               : floatval($p['total_pagar']) / max(1, intval($p['plazo_semanas']));
                    $porc    = floatval($p['total_pagar']) > 0
                               ? (floatval($p['pagado']) / floatval($p['total_pagar'])) * 100
                               : 0;
                    $dias    = diasHabiles($p['fecha_inicio'], $fecha);

                    $es_pagado_hoy = ($p['estado'] === 'PAGADO');
                    $es_vencido    = ($p['estado'] === 'ACTIVO' && !empty($p['fecha_fin']) && $p['fecha_fin'] < $fecha);
                    $riesgo        = $es_pagado_hoy ? 'riesgo-pagado'
                                   : ($dias > 24 ? 'riesgo-alto' : ($dias > 15 ? 'riesgo-medio' : 'riesgo-bajo'));
                    $chip_dias_cls = $dias >= 40 ? 'chip-dias' : ($dias >= 15 ? 'chip-vence' : 'chip-id');

                    $id_cliente_row = intval($p['cli_id_cliente'] ?? 0);
                    $nombre_js      = addslashes($p['cli_nombre'].' '.$p['cli_apellido']);
                ?>
                <tr class="<?= $riesgo ?>">
                    <td><span class="chip chip-id"><?= $p['id_prestamo'] ?></span></td>
                    <td>
                        <div class="td-nombre" style="font-weight:700;font-size:.87rem;">
                            <?= htmlspecialchars($p['cli_nombre'].' '.$p['cli_apellido']) ?>
                        </div>
                        <div style="font-size:.72rem;color:#94a3b8;margin-top:2px;">
                            <i class="bi bi-clock" style="margin-right:2px;"></i>
                            Último pago: <?= $p['ultima'] ? date('d/m/Y', strtotime($p['ultima'])) : '—' ?>
                        </div>
                        <?php if (!empty($p['cli_telefono'])): ?>
                        <a href="tel:<?= htmlspecialchars($p['cli_telefono']) ?>"
                           style="font-size:.72rem;color:#2563eb;text-decoration:none;">
                            <i class="bi bi-telephone" style="margin-right:2px;"></i><?= htmlspecialchars($p['cli_telefono']) ?>
                        </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="chip <?= $chip_dias_cls ?>">
                            <?= date('d/m/Y', strtotime($p['fecha_inicio'])) ?>
                        </span>
                        <div style="font-size:.7rem;color:#94a3b8;margin-top:3px;">
                            <?= $dias ?> días hábiles
                        </div>
                    </td>
                    <td style="min-width:100px;">
                        <div style="font-size:.76rem;color:#475569;margin-bottom:3px;font-weight:600;">
                            <?= number_format($porc, 1) ?>%
                        </div>
                        <div class="prog-mini">
                            <div class="prog-mini-fill"
                                 style="width:<?= min(100,$porc) ?>%;background:<?= $porc>=100?'#2563eb':($porc>=50?'#16a34a':'#d97706') ?>;"></div>
                        </div>
                    </td>
                    <td>
                        <strong style="color:<?= $saldo_p <= 0 ? '#16a34a' : '#dc2626' ?>;">
                            $<?= number_format($saldo_p, 2) ?>
                        </strong>
                        <?php if ($saldo_p <= 0): ?>
                        <div><span class="badge-liq"><i class="bi bi-check-circle-fill"></i> Liquidado</span></div>
                        <?php elseif ($es_vencido): ?>
                        <div style="font-size:.7rem;color:#dc2626;font-weight:700;margin-top:2px;">
                            <i class="bi bi-exclamation-triangle"></i> Vencido
                        </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong>$<?= number_format($cuota, 2) ?></strong>
                        <div style="font-size:.7rem;color:#94a3b8;">cuota diaria</div>
                    </td>

                    <!-- ACCIONES RÁPIDAS -->
                    <td style="text-align:center;">
                        <?php if (!$bloqueado && !$esDomingo): ?>
                        <div style="display:flex;gap:4px;justify-content:center;">
                            <button type="button" class="btn-cob full"
                                    onclick="setPago(<?= $p['id_prestamo'] ?>, <?= $cuota ?>)"
                                    title="Pago completo ($<?= number_format($cuota,2) ?>)">
                                <i class="bi bi-check-lg"></i>
                            </button>
                            <button type="button" class="btn-cob half"
                                    onclick="setPago(<?= $p['id_prestamo'] ?>, <?= $cuota/2 ?>)"
                                    title="Medio pago ($<?= number_format($cuota/2,2) ?>)">
                                ½
                            </button>
                            <button type="button" class="btn-cob zero"
                                    onclick="setPago(<?= $p['id_prestamo'] ?>, 0)"
                                    title="Sin pago">
                                <i class="bi bi-x"></i>
                            </button>
                        </div>
                        <?php else: ?>
                        <span style="font-size:.72rem;color:#94a3b8;">—</span>
                        <?php endif; ?>
                    </td>

                    <!-- BOTÓN REGISTRAR VISITA (siempre visible) -->
                    <td style="text-align:center;">
                        <button type="button" class="btn-cob visita"
                                onclick="abrirVisita(<?= $p['id_prestamo'] ?>, <?= $id_cliente_row ?>, '<?= $nombre_js ?>')"
                                title="Registrar visita / comentario"
                                style="min-width:72px;font-size:.72rem;">
                            <i class="bi bi-clipboard-check"></i> Visita
                        </button>
                    </td>

                    <!-- INPUT COBRO -->
                    <td style="text-align:center;">
                        <input type="number" step="0.01" min="0"
                               id="pago_<?= $p['id_prestamo'] ?>"
                               name="pagos[<?= $p['id_prestamo'] ?>]"
                               class="inp-cobro"
                               value="<?= htmlspecialchars($p['hoy'] ?? '') ?>"
                               placeholder="0.00"
                               <?= ($esDomingo || $bloqueado) ? 'disabled' : '' ?>>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            </div>
        </div>

        <?php if (!$esDomingo && !$bloqueado): ?>
        <button type="submit" class="sticky-save">
            <i class="bi bi-floppy-fill"></i> Guardar Cobranza
        </button>
        <?php elseif ($esDomingo): ?>
        <div style="text-align:center;margin-top:16px;">
            <span style="display:inline-flex;align-items:center;gap:8px;background:#fef3c7;color:#92400e;
                         border:1px solid #fde68a;border-radius:10px;padding:10px 20px;font-size:.84rem;font-weight:700;">
                <i class="bi bi-calendar-x-fill"></i> No se puede cobrar en domingo
            </span>
        </div>
        <?php elseif ($bloqueado): ?>
        <div style="text-align:center;margin-top:16px;">
            <span style="display:inline-flex;align-items:center;gap:8px;background:#fffbeb;color:#92400e;
                         border:1px solid #fde68a;border-radius:10px;padding:10px 20px;font-size:.84rem;font-weight:700;">
                <i class="bi bi-lock-fill"></i> Corte ya realizado — Solo lectura
            </span>
        </div>
        <?php endif; ?>

    </form>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Cobranza Diaria
    </div>

</main>
</div>

<!-- ═══════════════════════════════════════════════
     MODAL: REGISTRAR VISITA / NO ABONÓ
════════════════════════════════════════════════ -->
<div class="modal-overlay" id="modalVisita" onclick="cerrarVisitaOverlay(event)">
    <div class="modal-box">
        <div class="modal-title">
            <i class="bi bi-clipboard-check" style="color:#7c3aed;font-size:1.15rem;"></i>
            Registrar Visita
        </div>
        <div class="modal-sub" id="modalClienteNombre">—</div>

        <input type="hidden" id="mIdPrestamo">
        <input type="hidden" id="mIdCliente">

        <div class="modal-field">
            <label><i class="bi bi-flag" style="margin-right:4px;"></i>Resultado de la visita</label>
            <select class="modal-select" id="mResultado">
                <option value="PAGO">✅ Pago recibido</option>
                <option value="PAGO_PARCIAL">🟡 Pago parcial</option>
                <option value="NO_PAGO" selected>❌ No abonó</option>
                <option value="PROMESA_PAGO">🤝 Prometió pagar</option>
                <option value="NO_ENCONTRADO">🔍 No encontrado / no estaba</option>
            </select>
        </div>

        <div class="modal-field">
            <label>
                <i class="bi bi-chat-text" style="margin-right:4px;"></i>Comentario
                <span style="font-weight:400;color:#94a3b8;">(opcional)</span>
            </label>
            <textarea class="modal-textarea" id="mComentario"
                      placeholder="Describe la situación: motivo, acuerdo, próximo cobro..."></textarea>
        </div>

        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;
                    padding:10px 14px;font-size:.76rem;color:#64748b;margin-bottom:4px;">
            <i class="bi bi-info-circle" style="margin-right:4px;color:#7c3aed;"></i>
            Esta visita quedará en el historial del cliente y afectará su
            <strong style="color:#7c3aed;">score crediticio</strong>.
        </div>

        <div class="modal-actions">
            <button class="btn-modal-cancel" onclick="cerrarVisita()">
                <i class="bi bi-x-lg"></i> Cancelar
            </button>
            <button class="btn-modal-save" id="btnGuardarVisita" onclick="guardarVisita()">
                <i class="bi bi-floppy-fill"></i> Guardar Visita
            </button>
        </div>
    </div>
</div>

<script>
/* ── TEMA ── */
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

/* ── RELOJ ── */
function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2, '0');
    const m = String(ahora.getMinutes()).padStart(2, '0');
    const s = String(ahora.getSeconds()).padStart(2, '0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

/* ── PAGO RÁPIDO ── */
function setPago(id, monto) {
    const campo = document.getElementById('pago_' + id);
    if (campo && !campo.disabled) {
        campo.value = monto.toFixed(2);
        actualizarTotales();
    }
}

function actualizarTotales() {
    let sum = 0;
    document.querySelectorAll('.inp-cobro:not(:disabled)').forEach(i => {
        sum += parseFloat(i.value) || 0;
    });
    const el = document.getElementById('kpiCobrado');
    if (el) {
        el.textContent = '$' + sum.toLocaleString('es-MX', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
}

document.querySelectorAll('.inp-cobro').forEach(inp => {
    inp.addEventListener('input', actualizarTotales);
});

window.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.prog-mini-fill').forEach(b => {
        const w = b.style.width;
        b.style.width = '0';
        setTimeout(() => { b.style.width = w; }, 150);
    });
});

/* ══════════════════════════════════════
   MODAL VISITA
══════════════════════════════════════ */
function abrirVisita(idPrestamo, idCliente, nombre) {
    document.getElementById('mIdPrestamo').value          = idPrestamo;
    document.getElementById('mIdCliente').value           = idCliente;
    document.getElementById('modalClienteNombre').textContent = nombre;
    document.getElementById('mResultado').value           = 'NO_PAGO';
    document.getElementById('mComentario').value          = '';
    document.getElementById('modalVisita').classList.add('open');
    setTimeout(() => document.getElementById('mComentario').focus(), 100);
}

function cerrarVisita() {
    document.getElementById('modalVisita').classList.remove('open');
}

function cerrarVisitaOverlay(e) {
    if (e.target === document.getElementById('modalVisita')) cerrarVisita();
}

function guardarVisita() {
    const btn = document.getElementById('btnGuardarVisita');
    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Guardando...';

    const datos = new FormData();
    datos.append('id_prestamo', document.getElementById('mIdPrestamo').value);
    datos.append('id_cliente',  document.getElementById('mIdCliente').value);
    datos.append('resultado',   document.getElementById('mResultado').value);
    datos.append('comentario',  document.getElementById('mComentario').value);
    datos.append('fecha',       '<?= $fecha ?>');

    fetch('guardar_visita.php', { method: 'POST', body: datos })
        .then(r => r.json())
        .then(d => {
            cerrarVisita();
            if (d.ok) {
                const signo = d.delta >= 0 ? '+' : '';
                mostrarToast(
                    'Visita registrada — Score: ' + d.score + ' (' + signo + d.delta + ')',
                    d.delta >= 0 ? 'verde' : 'rojo'
                );
            } else {
                mostrarToast('Error: ' + d.msg, 'rojo');
            }
        })
        .catch(() => mostrarToast('Error de conexión con el servidor', 'rojo'))
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-floppy-fill"></i> Guardar Visita';
        });
}

/* ── TOAST ── */
function mostrarToast(msg, tipo) {
    const prev = document.querySelector('.pje-toast');
    if (prev) prev.remove();

    const color = tipo === 'verde' ? '#16a34a' : '#dc2626';
    const icon  = tipo === 'verde' ? 'check-circle-fill' : 'x-circle-fill';

    const t = document.createElement('div');
    t.className = 'pje-toast';
    t.style.cssText =
        'position:fixed;bottom:90px;right:28px;z-index:9999;' +
        'background:' + color + ';color:white;' +
        'padding:12px 20px;border-radius:12px;font-size:.84rem;font-weight:700;' +
        'box-shadow:0 8px 24px rgba(0,0,0,.25);display:flex;align-items:center;gap:8px;' +
        'animation:fadeUp .3s ease;max-width:340px;word-break:break-word;';
    t.innerHTML = '<i class="bi bi-' + icon + '" style="flex-shrink:0;font-size:1.1rem;"></i> ' + msg;
    document.body.appendChild(t);
    setTimeout(() => { if (t.parentNode) t.remove(); }, 4500);
}
</script>
</body>
</html>

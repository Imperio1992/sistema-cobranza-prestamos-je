<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$errores  = [];
$exito    = false;
$nombre = $apellido = $rol = $puesto = $ruta_tipo = $telefono = $usuario = '';
$fecha_ing = date('Y-m-d');

$puestos_lista = [
    'ASESOR'     => 'Asesor de Credito',
    'CAPTURISTA' => 'Capturista',
    'CONTADOR'   => 'Contador',
    'SUPERVISOR' => 'Supervisor',
    'GERENTE'    => 'Gerente',
];
$rol_actual = $_SESSION['rol'];
$user       = $_SESSION['usuario'] ?? 'Usuario';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre    = trim($_POST['nombre']           ?? '');
    $apellido  = trim($_POST['apellido']         ?? '');
    $rol       = $_POST['rol']                   ?? '';
    $puesto    = trim($_POST['puesto']           ?? '');
    $ruta_tipo = trim($_POST['ruta_tipo']        ?? '');
    $telefono  = trim($_POST['telefono']         ?? '');
    $usuario   = trim($_POST['usuario']          ?? '');
    $password  = trim($_POST['password']         ?? '');
    $pass_conf = trim($_POST['password_confirm'] ?? '');
    $fecha_ing = $_POST['fecha_ingreso']         ?? date('Y-m-d');

    if (!$nombre)   $errores[] = 'El nombre es obligatorio.';
    if (!$apellido) $errores[] = 'El apellido es obligatorio.';
    if (!in_array($rol, ['GERENTE','SUPERVISOR','ASESOR'])) $errores[] = 'Selecciona un rol válido.';
    if (!$puesto || !array_key_exists($puesto, $puestos_lista)) $errores[] = 'Selecciona un puesto válido.';
    if (!$usuario)  $errores[] = 'El usuario es obligatorio.';
    if (!$password) $errores[] = 'La contraseña es obligatoria.';
    if ($password !== $pass_conf) $errores[] = 'Las contraseñas no coinciden.';
    if (strlen($password) < 6)   $errores[] = 'La contraseña debe tener al menos 6 caracteres.';

    /* Verificar duplicado en tabla USUARIOS (no en empleados) */
    if ($usuario) {
        $stmt_chk = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE usuario = ?");
        $stmt_chk->bind_param("s", $usuario);
        $stmt_chk->execute();
        $stmt_chk->store_result();
        if ($stmt_chk->num_rows > 0) $errores[] = "El usuario '$usuario' ya está registrado.";
        $stmt_chk->close();
    }

    if (empty($errores)) {
        /* Paso 1: insertar en empleados (sin usuario/password, no existen ahí) */
        $ruta_val = in_array($ruta_tipo, ['DIARIO','SEMANAL']) ? $ruta_tipo : 'DIARIO';
        $stmt = $conexion->prepare("
            INSERT INTO empleados (nombre, apellido, rol, puesto, ruta_tipo, telefono, estatus)
            VALUES (?, ?, ?, ?, ?, ?, 'ACTIVO')
        ");
        $stmt->bind_param("ssssss", $nombre, $apellido, $rol, $puesto, $ruta_val, $telefono);

        if ($stmt->execute()) {
            $nuevo_id = $stmt->insert_id;
            $stmt->close();

            /* Paso 2: crear credenciales en tabla usuarios */
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt2 = $conexion->prepare("
                INSERT INTO usuarios (usuario, password, rol, id_empleado, estatus)
                VALUES (?, ?, ?, ?, 'ACTIVO')
            ");
            $stmt2->bind_param("sssi", $usuario, $hash, $rol, $nuevo_id);

            if ($stmt2->execute()) {
                $stmt2->close();
                $exito = true;
                $nombre = $apellido = $rol = $puesto = $ruta_tipo = $telefono = $usuario = '';
            } else {
                /* Si falla usuarios, revertir el empleado recién creado */
                $conexion->query("DELETE FROM empleados WHERE id_empleado = $nuevo_id");
                $errores[] = 'Error al crear acceso: ' . $conexion->error;
            }
        } else {
            $stmt->close();
            $errores[] = 'Error al guardar empleado: ' . $conexion->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Nuevo Empleado — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active  { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; display:flex; flex-direction:column; }
.main-content { padding:24px 28px 80px; flex:1; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-back {
    display:inline-flex; align-items:center; gap:6px;
    padding:8px 16px; border-radius:10px; font-size:.82rem; font-weight:600;
    background:white; color:#64748b; border:1.5px solid #e2e8f0; text-decoration:none;
    transition:all .15s;
}
.btn-back:hover { border-color:#0f172a; color:#0f172a; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; text-decoration:none;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta {
    border-radius:12px; padding:14px 18px; margin-bottom:20px;
    display:flex; align-items:flex-start; gap:12px; font-size:.85rem;
}
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }
.alerta.exito { background:#f0fdf4; border:1.5px solid #bbf7d0; color:#14532d; }
.alerta i     { font-size:1.2rem; flex-shrink:0; margin-top:1px; }
.alerta ul    { margin:5px 0 0; padding-left:16px; }
.alerta ul li { margin-bottom:3px; }
.alerta-links { margin-top:10px; display:flex; gap:14px; flex-wrap:wrap; }
.alerta-links a { font-size:.8rem; font-weight:700; text-decoration:none; }
.alerta.exito .alerta-links a { color:#15803d; }
.alerta.exito .alerta-links a:last-child { color:#64748b; }

/* ── LAYOUT ── */
.form-layout { display:grid; grid-template-columns:1fr 300px; gap:20px; align-items:start; }

/* ── CARD ── */
.card {
    background:white; border-radius:14px; padding:20px 22px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-bottom:16px;
}
.card h3 {
    font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em;
    color:#64748b; margin-bottom:16px; display:flex; align-items:center; gap:7px;
}
.card-dark { background:#0f172a; border-radius:14px; padding:20px 22px; margin-bottom:16px; }
.card-dark h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#475569; margin-bottom:16px; display:flex; align-items:center; gap:7px; }

/* ── VISTA PREVIA ── */
.preview-wrap {
    display:flex; align-items:center; gap:14px;
    padding:14px 16px; background:#f8fafc;
    border-radius:12px; border:1.5px dashed #cbd5e1;
}
.avatar-lg {
    width:52px; height:52px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:1.1rem; font-weight:800; color:white; flex-shrink:0; transition:background .2s;
}
.av-asesor     { background:linear-gradient(135deg,#16a34a,#15803d); }
.av-supervisor { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.av-gerente    { background:linear-gradient(135deg,#7c3aed,#5b21b6); }
.av-default    { background:linear-gradient(135deg,#94a3b8,#64748b); }
.prev-nombre   { font-weight:700; font-size:.95rem; color:#0f172a; }
.prev-sub      { font-size:.78rem; color:#94a3b8; margin-top:3px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.prev-ruta     { font-size:.72rem; color:#94a3b8; margin-top:4px; display:none; }

/* Badges */
.badge {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 10px; border-radius:20px; font-size:.72rem; font-weight:700;
}
.badge-asesor     { background:#dcfce7; color:#16a34a; }
.badge-supervisor { background:#dbeafe; color:#1d4ed8; }
.badge-gerente    { background:#f3e8ff; color:#7c3aed; }
.badge-default    { background:#f1f5f9; color:#64748b; }

/* ── SELECTOR DE ROL ── */
.rol-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.rol-card {
    display:flex; flex-direction:column; align-items:center; gap:6px;
    padding:16px 8px; border:2px solid #e2e8f0; border-radius:12px;
    cursor:pointer; transition:all .15s; text-align:center;
}
.rol-card:has(input:checked).r-asesor     { border-color:#16a34a; background:#f0fdf4; }
.rol-card:has(input:checked).r-supervisor { border-color:#2563eb; background:#eff6ff; }
.rol-card:has(input:checked).r-gerente    { border-color:#7c3aed; background:#faf5ff; }
.rol-card:hover { border-color:#94a3b8; }
.rol-card input { display:none; }
.rol-ico-wrap { font-size:1.5rem; line-height:1; }
.rol-title { font-size:.82rem; font-weight:700; color:#1e293b; }
.rol-desc  { font-size:.7rem; color:#94a3b8; line-height:1.35; }

/* ── CAMPOS ── */
.field { margin-bottom:15px; }
.field:last-child { margin-bottom:0; }
.field label {
    display:block; font-size:.72rem; font-weight:700;
    color:#374151; margin-bottom:5px;
    text-transform:uppercase; letter-spacing:.04em;
}
.field label .opc { font-weight:400; color:#94a3b8; text-transform:none; letter-spacing:0; }
.inp-wrap { position:relative; }
.field input[type=text],
.field input[type=password],
.field input[type=tel],
.field input[type=date],
.field select {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.88rem; color:#1e293b;
    outline:none; transition:border-color .15s, box-shadow .15s;
    background:#f8fafc; font-family:'Inter',sans-serif;
}
.field input:focus, .field select:focus {
    border-color:#2563eb; background:white;
    box-shadow:0 0 0 3px rgba(37,99,235,.08);
}
.field .hint { margin-top:5px; font-size:.72rem; color:#94a3b8; display:flex; align-items:center; gap:4px; }
.input-row  { display:grid; grid-template-columns:1fr 1fr; gap:12px; }

/* Pass-eye */
.pass-eye {
    position:absolute; right:12px; top:50%; transform:translateY(-50%);
    background:none; border:none; cursor:pointer;
    font-size:.9rem; color:#94a3b8; padding:0; line-height:1;
    display:flex; align-items:center;
}
.pass-eye:hover { color:#475569; }

/* Sugerencia usuario */
.sug-badge {
    display:none; align-items:center; gap:6px; margin-top:6px;
    background:#eff6ff; border:1px solid #bfdbfe;
    border-radius:7px; padding:5px 10px;
    font-size:.75rem; color:#1d4ed8; font-weight:600;
    cursor:pointer; width:fit-content; transition:background .15s;
}
.sug-badge:hover { background:#dbeafe; }

/* Fortaleza */
.strength-bar  { height:4px; background:#e2e8f0; border-radius:2px; margin-top:7px; overflow:hidden; }
.strength-fill { height:100%; border-radius:2px; width:0; transition:all .3s; }
.strength-txt  { font-size:.72rem; font-weight:700; margin-top:4px; color:#94a3b8; }

/* Requisitos */
.req-list { list-style:none; margin-top:12px; display:flex; flex-direction:column; gap:6px; }
.req-list li { display:flex; align-items:center; gap:8px; font-size:.78rem; color:#94a3b8; transition:color .2s; }
.req-dot {
    width:16px; height:16px; border-radius:50%;
    background:#e2e8f0; display:flex; align-items:center; justify-content:center;
    font-size:.55rem; flex-shrink:0; transition:background .2s; color:transparent;
}
.req-list li.ok { color:#374151; }
.req-list li.ok .req-dot { background:#16a34a; color:white; }

/* ── SUBMIT ── */
.btn-submit {
    width:100%; padding:14px; background:#0f172a; color:white;
    border:none; border-radius:12px; font-size:.95rem; font-weight:700;
    cursor:pointer; transition:background .15s; margin-top:4px;
    display:flex; align-items:center; justify-content:center; gap:8px;
    font-family:'Inter',sans-serif;
}
.btn-submit:hover { background:#1e293b; }

/* Info dark */
.info-item { display:flex; align-items:flex-start; gap:11px; padding:11px 0; border-bottom:1px solid #1e293b; }
.info-item:last-child { border-bottom:none; padding-bottom:0; }
.ii-ico   { font-size:1.1rem; flex-shrink:0; margin-top:2px; }
.ii-title { font-weight:700; color:#f1f5f9; font-size:.85rem; margin-bottom:2px; }
.ii-desc  { color:#64748b; font-size:.72rem; line-height:1.4; }

/* Consejos */
.tip { display:flex; align-items:flex-start; gap:10px; padding:9px 0; border-bottom:1px solid #f1f5f9; font-size:.78rem; color:#64748b; }
.tip:last-child { border-bottom:none; padding-bottom:0; }
.tip i { flex-shrink:0; font-size:.9rem; margin-top:1px; color:#94a3b8; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .card { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .card h3 { color:#64748b; }
[data-theme="dark"] .card-dark { background:#020617; }
[data-theme="dark"] .btn-back  { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; color:#94a3b8; border-color:#334155; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .preview-wrap { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .prev-nombre { color:#f8fafc; }
[data-theme="dark"] .field input, [data-theme="dark"] .field select { background:#0f172a; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .field input:focus, [data-theme="dark"] .field select:focus { background:#1e293b; border-color:#2563eb; }
[data-theme="dark"] .field label { color:#94a3b8; }
[data-theme="dark"] .rol-card { border-color:#334155; }
[data-theme="dark"] .rol-title { color:#e2e8f0; }
[data-theme="dark"] .strength-bar  { background:#334155; }
[data-theme="dark"] .req-list li.ok { color:#e2e8f0; }
[data-theme="dark"] .alerta.error { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }
[data-theme="dark"] .alerta.exito { background:#071f12; border-color:#14532d; color:#86efac; }
[data-theme="dark"] .sug-badge    { background:#1e3a6e; border-color:#1d4ed8; color:#93c5fd; }
[data-theme="dark"] .tip { border-color:#334155; color:#64748b; }

/* Accesos rapidos */
.acceso-links { display:flex; flex-direction:column; gap:8px; }
.btn-acceso-dark {
    display:flex; align-items:center; justify-content:center; gap:7px;
    padding:10px 14px; border-radius:10px; background:#0f172a;
    color:white; font-size:.82rem; font-weight:700; text-decoration:none; transition:background .15s;
}
.btn-acceso-dark:hover { background:#1e293b; }
.btn-acceso-light {
    display:flex; align-items:center; gap:7px;
    padding:10px 14px; border-radius:10px; background:#f8fafc;
    border:1.5px solid #e2e8f0; color:#374151; font-size:.82rem; font-weight:600;
    text-decoration:none; transition:background .15s;
}
.btn-acceso-light:hover { background:#f1f5f9; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .form-layout { grid-template-columns:1fr; }
    .input-row { grid-template-columns:1fr; }
    .rol-grid { grid-template-columns:repeat(3,1fr); }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Clientes Atrasados</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>

        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="nuevo_empleado.php" class="active special"><i class="bi bi-person-plus"></i> Nuevo Empleado</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="bi bi-person-plus-fill" style="color:#16a34a;"></i> Nuevo Empleado</h1>
            <p>Registra un nuevo integrante del equipo &nbsp;·&nbsp; <?= date('d/m/Y') ?></p>
        </div>
        <div class="topbar-right">
            <a href="empleados.php" class="btn-back">
                <i class="bi bi-arrow-left"></i> Volver a empleados
            </a>
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ALERTAS -->
    <?php if ($exito): ?>
    <div class="alerta exito">
        <i class="bi bi-check-circle-fill"></i>
        <div>
            <strong>¡Empleado registrado con éxito!</strong>
            <p style="margin:4px 0 0;font-size:.78rem;">Ya puede ingresar al sistema con su usuario y contraseña.</p>
            <div class="alerta-links">
                <a href="nuevo_empleado.php"><i class="bi bi-person-plus"></i> Registrar otro</a>
                <a href="empleados.php"><i class="bi bi-people"></i> Ver todos los empleados</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($errores)): ?>
    <div class="alerta error">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div>
            <strong>Revisa los siguientes campos:</strong>
            <ul>
                <?php foreach ($errores as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <form method="POST" id="formEmp" onsubmit="return validarForm()">
    <div class="form-layout">

        <!-- ── COLUMNA PRINCIPAL ── -->
        <div>

            <!-- Vista previa -->
            <div class="card">
                <h3><i class="bi bi-eye"></i> Vista previa</h3>
                <div class="preview-wrap">
                    <div class="avatar-lg av-default" id="avPreview">?</div>
                    <div style="flex:1;min-width:0;">
                        <div class="prev-nombre" id="prevNombre">Nombre Apellido</div>
                        <div class="prev-sub">
                            <span class="badge badge-default" id="prevRol">Sin rol</span>
                            <span id="prevUsuario" style="color:#94a3b8;font-size:.78rem;">@usuario</span>
                        </div>
                        <div class="prev-ruta" id="prevRuta">
                            <i class="bi bi-geo-alt" style="font-size:.7rem;"></i>
                            <span id="prevRutaTxt"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rol -->
            <div class="card">
                <h3><i class="bi bi-person-gear"></i> Rol del empleado *</h3>
                <div class="rol-grid">
                    <label class="rol-card r-asesor" onclick="updatePreview()">
                        <input type="radio" name="rol" value="ASESOR" required
                               <?= $rol === 'ASESOR' ? 'checked' : '' ?>>
                        <div class="rol-ico-wrap"><i class="bi bi-person-workspace" style="color:#16a34a;font-size:1.4rem;"></i></div>
                        <div class="rol-title">Asesor</div>
                        <div class="rol-desc">Cobra en campo y gestiona clientes asignados</div>
                    </label>
                    <label class="rol-card r-supervisor" onclick="updatePreview()">
                        <input type="radio" name="rol" value="SUPERVISOR"
                               <?= $rol === 'SUPERVISOR' ? 'checked' : '' ?>>
                        <div class="rol-ico-wrap"><i class="bi bi-shield-fill-check" style="color:#2563eb;font-size:1.4rem;"></i></div>
                        <div class="rol-title">Supervisor</div>
                        <div class="rol-desc">Supervisa asesores y aprueba operaciones</div>
                    </label>
                    <label class="rol-card r-gerente" onclick="updatePreview()">
                        <input type="radio" name="rol" value="GERENTE"
                               <?= $rol === 'GERENTE' ? 'checked' : '' ?>>
                        <div class="rol-ico-wrap"><i class="bi bi-star-fill" style="color:#7c3aed;font-size:1.4rem;"></i></div>
                        <div class="rol-title">Gerente</div>
                        <div class="rol-desc">Acceso total al sistema y configuración</div>
                    </label>
                </div>
            </div>

            <!-- Datos personales -->
            <div class="card">
                <h3><i class="bi bi-person-lines-fill"></i> Datos personales</h3>

                <div class="input-row">
                    <div class="field">
                        <label>Nombre *</label>
                        <input type="text" name="nombre" id="inpNombre"
                               value="<?= htmlspecialchars($nombre) ?>"
                               placeholder="Ej: Carlos" required
                               oninput="updatePreview(); sugerirUsuario()">
                    </div>
                    <div class="field">
                        <label>Apellido *</label>
                        <input type="text" name="apellido" id="inpApellido"
                               value="<?= htmlspecialchars($apellido) ?>"
                               placeholder="Ej: García" required
                               oninput="updatePreview(); sugerirUsuario()">
                    </div>
                </div>

                <div class="input-row">
                    <div class="field">
                        <label>Teléfono <span class="opc">(opcional)</span></label>
                        <input type="tel" name="telefono" id="inpTelefono"
                               value="<?= htmlspecialchars($telefono) ?>"
                               placeholder="Ej: 6441234567" maxlength="15">
                    </div>
                </div>

                <div class="input-row">
                    <div class="field">
                        <label>Puesto *</label>
                        <select name="puesto" id="inpPuesto" required>
                            <option value="">— Selecciona un puesto —</option>
                            <?php foreach ($puestos_lista as $val => $label): ?>
                            <option value="<?= $val ?>" <?= $puesto === $val ? 'selected' : '' ?>>
                                <?= htmlspecialchars($label) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="hint"><i class="bi bi-briefcase"></i> Cargo o título del empleado dentro de la empresa.</p>
                    </div>
                    <div class="field">
                        <label>Tipo de ruta *</label>
                        <select name="ruta_tipo" id="inpRuta" onchange="updatePreview()" required>
                            <option value="DIARIO"  <?= $ruta_tipo === 'DIARIO'  ? 'selected' : '' ?>>Diario</option>
                            <option value="SEMANAL" <?= $ruta_tipo === 'SEMANAL' ? 'selected' : '' ?>>Semanal</option>
                        </select>
                        <p class="hint"><i class="bi bi-geo-alt"></i> Indica si el asesor cobra de forma diaria o semanal.</p>
                    </div>
                </div>
            </div>

            <!-- Acceso al sistema -->
            <div class="card">
                <h3><i class="bi bi-lock"></i> Acceso al sistema</h3>

                <div class="field">
                    <label>Usuario *</label>
                    <div class="inp-wrap">
                        <input type="text" name="usuario" id="inpUsuario"
                               value="<?= htmlspecialchars($usuario) ?>"
                               placeholder="Ej: cgarcia" required autocomplete="off"
                               oninput="updatePreview()"
                               pattern="[a-zA-Z0-9_]+" title="Solo letras, números y guión bajo">
                    </div>
                    <p class="hint"><i class="bi bi-info-circle"></i> Solo letras, números y guión bajo. Sin espacios.</p>
                    <div class="sug-badge" id="sugBadge" onclick="aplicarSugerencia()">
                        <i class="bi bi-lightbulb-fill"></i>
                        Usar sugerencia: <strong id="sugTexto"></strong>
                    </div>
                </div>

                <div class="input-row">
                    <div class="field">
                        <label>Contraseña *</label>
                        <div class="inp-wrap">
                            <input type="password" name="password" id="pass"
                                   placeholder="Mínimo 6 caracteres" required
                                   oninput="checkPass()">
                            <button type="button" class="pass-eye" onclick="togglePass('pass','eyePass')" title="Mostrar/ocultar">
                                <i id="eyePass" class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
                        <div class="strength-txt" id="strengthTxt"></div>
                    </div>
                    <div class="field">
                        <label>Confirmar contraseña *</label>
                        <div class="inp-wrap">
                            <input type="password" name="password_confirm" id="pass2"
                                   placeholder="Repite la contraseña" required
                                   oninput="checkPass2()">
                            <button type="button" class="pass-eye" onclick="togglePass('pass2','eyePass2')" title="Mostrar/ocultar">
                                <i id="eyePass2" class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="strength-txt" id="matchTxt"></div>
                    </div>
                </div>

                <ul class="req-list">
                    <li id="reqLen"><span class="req-dot">✓</span> Al menos 6 caracteres</li>
                    <li id="reqNum"><span class="req-dot">✓</span> Contiene al menos un número</li>
                    <li id="reqMatch"><span class="req-dot">✓</span> Las contraseñas coinciden</li>
                </ul>
            </div>

            <button type="submit" class="btn-submit">
                <i class="bi bi-person-check-fill"></i> Registrar Empleado
            </button>

        </div>

        <!-- ── COLUMNA DERECHA ── -->
        <div>

            <!-- Permisos por rol -->
            <div class="card-dark">
                <h3><i class="bi bi-shield-lock" style="color:#60a5fa;"></i> Permisos por rol</h3>
                <div class="info-item">
                    <i class="bi bi-person-workspace ii-ico" style="color:#4ade80;"></i>
                    <div>
                        <div class="ii-title">Asesor</div>
                        <div class="ii-desc">Cobranza diaria, clientes asignados, su caja personal e historial de pagos.</div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="bi bi-shield-fill-check ii-ico" style="color:#60a5fa;"></i>
                    <div>
                        <div class="ii-title">Supervisor</div>
                        <div class="ii-desc">Todo lo del Asesor + caja general, empleados, reportes y aprobaciones.</div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="bi bi-star-fill ii-ico" style="color:#c4b5fd;"></i>
                    <div>
                        <div class="ii-title">Gerente</div>
                        <div class="ii-desc">Acceso completo: configuración, migración, eliminación y auditoría total.</div>
                    </div>
                </div>
            </div>

            <!-- Consejos -->
            <div class="card">
                <h3><i class="bi bi-lightbulb"></i> Consejos</h3>
                <div class="tip"><i class="bi bi-person-badge"></i><span>Usa el <strong>nombre real</strong> del empleado para identificarlo en reportes.</span></div>
                <div class="tip"><i class="bi bi-key"></i><span>El usuario debe ser <strong>único</strong>. Prueba con iniciales: <em>cgarcia</em>, <em>jlopez</em>.</span></div>
                <div class="tip"><i class="bi bi-lock-fill"></i><span>La contraseña se guarda <strong>cifrada</strong>. Ni el gerente puede verla.</span></div>
                <div class="tip"><i class="bi bi-geo-alt-fill"></i><span>Asigna una <strong>ruta o zona</strong> para organizar mejor los cobros del día.</span></div>
                <div class="tip"><i class="bi bi-telephone-fill"></i><span>Agrega el <strong>teléfono</strong> para contacto rápido desde el listado de empleados.</span></div>
            </div>

            <!-- Accesos rápidos -->
            <div class="card">
                <h3><i class="bi bi-lightning-charge"></i> Accesos rápidos</h3>
                <div class="acceso-links">
                    <a href="empleados.php" class="btn-acceso-dark">
                        <i class="bi bi-people-fill"></i> Ver todos los empleados
                    </a>
                    <a href="estatus_empleado.php" class="btn-acceso-light">
                        <i class="bi bi-arrow-left-right"></i> Cambiar estatus de empleado
                    </a>
                </div>
            </div>

        </div>

    </div>
    </form>

</div><!-- /main-content -->
</main>
</div><!-- /app -->

<script>
/* ── TEMA ── */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), pad = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = pad(n.getHours())+':'+pad(n.getMinutes())+':'+pad(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── VISTA PREVIA ── */
function updatePreview() {
    var nombre   = document.getElementById('inpNombre').value.trim();
    var apellido = document.getElementById('inpApellido').value.trim();
    var usuario  = document.getElementById('inpUsuario').value.trim();
    var ruta     = document.getElementById('inpRuta').value.trim();
    var rol      = document.querySelector('input[name="rol"]:checked');

    var av  = document.getElementById('avPreview');
    var ini = (nombre ? nombre[0] : '') + (apellido ? apellido[0] : '');
    av.textContent = ini.toUpperCase() || '?';

    av.className = 'avatar-lg av-default';
    if (rol) {
        var clases = { ASESOR:'av-asesor', SUPERVISOR:'av-supervisor', GERENTE:'av-gerente' };
        av.className = 'avatar-lg ' + (clases[rol.value] || 'av-default');
    }

    document.getElementById('prevNombre').textContent = (nombre || 'Nombre') + ' ' + (apellido || 'Apellido');
    document.getElementById('prevUsuario').textContent = '@' + (usuario || 'usuario');

    var badge = document.getElementById('prevRol');
    if (rol) {
        var labels = { ASESOR:'Asesor', SUPERVISOR:'Supervisor', GERENTE:'Gerente' };
        var clsBadge = { ASESOR:'badge badge-asesor', SUPERVISOR:'badge badge-supervisor', GERENTE:'badge badge-gerente' };
        badge.textContent = labels[rol.value];
        badge.className = clsBadge[rol.value] || 'badge badge-default';
    } else {
        badge.textContent = 'Sin rol';
        badge.className = 'badge badge-default';
    }

    var divRuta = document.getElementById('prevRuta');
    if (ruta) {
        document.getElementById('prevRutaTxt').textContent = ruta;
        divRuta.style.display = 'flex';
        divRuta.style.alignItems = 'center';
        divRuta.style.gap = '4px';
    } else {
        divRuta.style.display = 'none';
    }
}

/* ── SUGERENCIA USUARIO ── */
function sugerirUsuario() {
    var nombre   = document.getElementById('inpNombre').value.trim();
    var apellido = document.getElementById('inpApellido').value.trim();
    var campo    = document.getElementById('inpUsuario');
    var badge    = document.getElementById('sugBadge');
    var span     = document.getElementById('sugTexto');

    if (nombre && apellido) {
        var quitar = function(s) {
            return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
        };
        span.textContent = quitar(nombre[0]) + quitar(apellido);
        badge.style.display = campo.value ? 'none' : 'flex';
    } else {
        badge.style.display = 'none';
    }
}
function aplicarSugerencia() {
    var sug = document.getElementById('sugTexto').textContent;
    document.getElementById('inpUsuario').value = sug;
    document.getElementById('sugBadge').style.display = 'none';
    updatePreview();
}

/* ── FORTALEZA CONTRASEÑA ── */
function checkPass() {
    var p    = document.getElementById('pass').value;
    var fill = document.getElementById('strengthFill');
    var txt  = document.getElementById('strengthTxt');
    var score = 0;
    if (p.length >= 6)           score++;
    if (p.length >= 10)          score++;
    if (/[0-9]/.test(p))         score++;
    if (/[^a-zA-Z0-9]/.test(p)) score++;
    var colores = ['#dc2626','#ea580c','#eab308','#16a34a'];
    var labels  = ['Muy débil','Débil','Regular','Fuerte'];
    if (p.length > 0) {
        fill.style.width      = (score * 25) + '%';
        fill.style.background = colores[score - 1] || '#dc2626';
        txt.textContent       = labels[score - 1]  || 'Muy débil';
        txt.style.color       = colores[score - 1] || '#dc2626';
    } else {
        fill.style.width = '0'; txt.textContent = '';
    }
    document.getElementById('reqLen').classList.toggle('ok', p.length >= 6);
    document.getElementById('reqNum').classList.toggle('ok', /[0-9]/.test(p));
    checkPass2();
}
function checkPass2() {
    var p1 = document.getElementById('pass').value;
    var p2 = document.getElementById('pass2').value;
    var txt = document.getElementById('matchTxt');
    var req = document.getElementById('reqMatch');
    if (p2.length > 0) {
        if (p1 === p2) {
            txt.textContent = '✓ Coinciden'; txt.style.color = '#16a34a'; req.classList.add('ok');
        } else {
            txt.textContent = '✕ No coinciden'; txt.style.color = '#dc2626'; req.classList.remove('ok');
        }
    } else {
        txt.textContent = ''; req.classList.remove('ok');
    }
}

/* ── MOSTRAR/OCULTAR PASS ── */
function togglePass(inputId, eyeId) {
    var input = document.getElementById(inputId);
    var eye   = document.getElementById(eyeId);
    if (input.type === 'password') {
        input.type = 'text';
        eye.className = 'bi bi-eye-slash';
    } else {
        input.type = 'password';
        eye.className = 'bi bi-eye';
    }
}

/* ── VALIDACIÓN SUBMIT ── */
function validarForm() {
    var p1 = document.getElementById('pass').value;
    var p2 = document.getElementById('pass2').value;
    if (p1 !== p2)    { alert('Las contraseñas no coinciden.'); return false; }
    if (p1.length < 6){ alert('La contraseña debe tener al menos 6 caracteres.'); return false; }
    return true;
}

updatePreview();
</script>
</body>
</html>

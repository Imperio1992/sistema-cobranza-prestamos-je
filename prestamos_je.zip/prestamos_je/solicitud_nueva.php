<?php
include("seguridad.php");
include("conexion.php");
date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';
$id_empleado_sesion = $_SESSION['id_empleado'] ?? 1;

// ── AJAX: calcular score (misma lógica que estado_cuenta.php) ───
if (isset($_GET['score']) && isset($_GET['id_cliente'])) {
    header('Content-Type: application/json');
    $id_c = (int)$_GET['id_cliente'];

    $rc = $conexion->query("SELECT * FROM clientes WHERE id_cliente = $id_c")->fetch_assoc();
    $score_base = max(0, min(100, intval($rc['score_crediticio'] ?? 100)));

    $rp = $conexion->query("
        SELECT id_prestamo, monto_prestado, total_pagar, total_pagado,
               saldo_actual, pago_diario, fecha_inicio, estado
        FROM prestamos WHERE id_cliente = $id_c
    ");
    $prestamos = [];
    while ($pp = $rp->fetch_assoc()) $prestamos[] = $pp;

    $prestamos_pagados   = 0;
    $prestamos_atrasados = 0;
    $capital_max_previo  = 0;
    foreach ($prestamos as $pp) {
        if ($pp['estado'] === 'PAGADO')   $prestamos_pagados++;
        if ($pp['estado'] === 'ATRASADO') $prestamos_atrasados++;
        if ((float)$pp['monto_prestado'] > $capital_max_previo) $capital_max_previo = (float)$pp['monto_prestado'];
    }

    $bono_historial = min(20, $prestamos_pagados * 5);
    $pen_atraso     = min(40, $prestamos_atrasados * 15);

    $cuotas_atrasadas_total = 0;
    foreach ($prestamos as $pp) {
        if ($pp['estado'] !== 'ACTIVO' && $pp['estado'] !== 'ATRASADO') continue;
        if (empty($pp['fecha_inicio']) || empty($pp['pago_diario']) || $pp['pago_diario'] <= 0) continue;
        $ini = strtotime($pp['fecha_inicio']);
        $hoy = strtotime(date('Y-m-d'));
        if ($ini > $hoy) continue;
        $cuotas_venc = 0;
        for ($d = $ini; $d <= $hoy; $d += 86400) {
            if ((int)date('w', $d) !== 0) $cuotas_venc++;
        }
        $cuotas_pagadas = floor(((float)$pp['total_pagado']) / ((float)$pp['pago_diario']));
        $cuotas_atrasadas_total += max(0, $cuotas_venc - $cuotas_pagadas);
    }
    $pen_cuotas = min(30, $cuotas_atrasadas_total * 2);

    $score = max(0, min(100, $score_base + $bono_historial - $pen_atraso - $pen_cuotas));

    if      ($score >= 80) { $nivel='APROBADO';  $color='#16a34a'; $bg='#dcfce7'; $borde='#86efac'; }
    elseif  ($score >= 50) { $nivel='REVISAR';   $color='#d97706'; $bg='#fef3c7'; $borde='#fcd34d'; }
    else                   { $nivel='RECHAZADO'; $color='#dc2626'; $bg='#fee2e2'; $borde='#fca5a5'; }

    $prestamo_recomendado = 0;
    if ($score >= 70) {
        $base = $capital_max_previo > 0 ? $capital_max_previo : 2000;
        if      ($score >= 95) $factor = 2.5;
        elseif  ($score >= 90) $factor = 2.0;
        elseif  ($score >= 85) $factor = 1.5;
        elseif  ($score >= 80) $factor = 1.25;
        elseif  ($score >= 75) $factor = 1.0;
        else                   $factor = 0.75;
        $prestamo_recomendado = max(1000, floor(($base * $factor) / 1000) * 1000);
    }

    $cli = $conexion->query("
        SELECT c.*,
               COUNT(DISTINCT pr.id_prestamo)                          AS total_prestamos,
               SUM(CASE WHEN pr.estado='ACTIVO'   THEN 1 ELSE 0 END)   AS activos,
               SUM(CASE WHEN pr.estado='ATRASADO' THEN 1 ELSE 0 END)   AS atrasados,
               SUM(CASE WHEN pr.estado='PAGADO'   THEN 1 ELSE 0 END)   AS pagados_total,
               COALESCE(SUM(pr.saldo_actual),0)                        AS saldo_pendiente
        FROM clientes c
        LEFT JOIN prestamos pr ON pr.id_cliente = c.id_cliente
        WHERE c.id_cliente = $id_c
        GROUP BY c.id_cliente
    ")->fetch_assoc();

    echo json_encode([
        'score'=>$score, 'nivel'=>$nivel, 'color'=>$color, 'bg'=>$bg, 'borde'=>$borde,
        'f1'=>$score_base,
        'f2'=>$bono_historial,
        'f3'=>-$pen_atraso,
        'f4'=>-$pen_cuotas,
        'prestamo_recomendado'=>$prestamo_recomendado,
        'cuotas_atrasadas'=>$cuotas_atrasadas_total,
        'cliente'=>$cli
    ]);
    exit;
}

// ── AJAX: buscar clientes ─────────────────────────────────────────
if (isset($_GET['buscar'])) {
    header('Content-Type: application/json');
    $q = '%' . $conexion->real_escape_string($_GET['buscar']) . '%';
    $res = $conexion->query("
        SELECT id_cliente, CONCAT(nombre,' ',apellido) AS nombre_completo,
               telefono, direccion, estatus
        FROM clientes
        WHERE (nombre LIKE '$q' OR apellido LIKE '$q' OR telefono LIKE '$q')
          AND estatus != 'BLOQUEADO'
        ORDER BY nombre LIMIT 10
    ");
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    echo json_encode($rows);
    exit;
}

// ── POST: guardar solicitud ───────────────────────────────────────
$msg = ''; $msg_tipo = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente  = (int)$_POST['id_cliente'];
    $monto       = (float)str_replace(',', '', $_POST['monto_solicitado']);
    $tipo_plazo  = $_POST['tipo_plazo'] === 'SEMANAL' ? 'SEMANAL' : 'DIARIO';
    $plazo_valor = (int)$_POST['plazo_valor'];
    $motivo      = $conexion->real_escape_string(trim($_POST['motivo'] ?? ''));
    $score_cl    = (float)$_POST['score_guardado'];

    if ($id_cliente <= 0 || $monto <= 0 || $plazo_valor <= 0) {
        $msg = 'Completa todos los campos obligatorios.';
        $msg_tipo = 'error';
    } else {
        $conexion->query("
            INSERT INTO solicitudes
              (id_cliente, id_empleado, monto_solicitado, tipo_plazo, plazo_valor, motivo, score_cliente, estado)
            VALUES
              ($id_cliente, $id_empleado_sesion, $monto, '$tipo_plazo', $plazo_valor, '$motivo', $score_cl, 'PENDIENTE')
        ");
        $id_nueva = $conexion->insert_id;
        $conexion->query("INSERT INTO bitacora (usuario, accion) VALUES
            ('{$user}', 'Nueva solicitud #$id_nueva para cliente #$id_cliente por \$$monto')");
        $msg = "Solicitud #$id_nueva registrada. Queda pendiente de aprobación.";
        $msg_tipo = 'ok';
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Nueva Solicitud de Préstamo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}
.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;box-shadow:0 4px 14px rgba(37,99,235,.4);flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;letter-spacing:-.3px;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-sb{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}
.main{margin-left:240px;padding:24px 28px 60px;}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.3rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.btn-icon{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;text-decoration:none;}
.btn-icon:hover{color:#0f172a;border-color:#2563eb;}
.btn-back{display:inline-flex;align-items:center;gap:7px;background:white;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 14px;color:#64748b;text-decoration:none;font-size:.82rem;font-weight:600;transition:all .15s;}
.btn-back:hover{background:#f8fafc;color:#0f172a;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;}
.card{background:white;border-radius:14px;padding:22px;box-shadow:0 2px 10px rgba(0,0,0,.07);border:1px solid #f1f5f9;}
.card-title{font-size:.9rem;font-weight:800;color:#0f172a;margin-bottom:16px;padding-bottom:12px;border-bottom:2px solid #f1f5f9;display:flex;align-items:center;gap:8px;}
.card-title i{color:#2563eb;}
.fgroup{margin-bottom:14px;}
.fgroup label{display:block;font-size:.78rem;font-weight:700;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em;}
.fgroup input,.fgroup select,.fgroup textarea{width:100%;border:1.5px solid #e2e8f0;border-radius:9px;padding:9px 12px;font-size:.88rem;font-family:'Inter',sans-serif;color:#1e293b;background:white;transition:border .15s,box-shadow .15s;outline:none;}
.fgroup input:focus,.fgroup select:focus,.fgroup textarea:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.1);}
.fgroup textarea{resize:vertical;min-height:80px;}
.search-wrap{position:relative;}
.search-results{position:absolute;top:calc(100% + 4px);left:0;right:0;background:white;border:1.5px solid #bfdbfe;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.12);z-index:100;max-height:220px;overflow-y:auto;display:none;}
.sr-item{padding:10px 14px;cursor:pointer;font-size:.85rem;border-bottom:1px solid #f1f5f9;transition:background .1s;}
.sr-item:hover{background:#eff6ff;}
.sr-item .sr-nombre{font-weight:700;color:#1e293b;}
.sr-item .sr-meta{font-size:.75rem;color:#64748b;margin-top:2px;}
.cliente-sel{background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:10px;padding:12px 14px;display:none;align-items:center;gap:12px;margin-top:8px;}
.cs-avatar{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#1d4ed8);display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:800;color:white;flex-shrink:0;}
.cs-info .cs-nombre{font-size:.9rem;font-weight:700;color:#1e293b;}
.cs-info .cs-meta{font-size:.75rem;color:#64748b;margin-top:2px;}
.btn-clear-cli{background:none;border:none;color:#94a3b8;cursor:pointer;font-size:1rem;margin-left:auto;padding:4px;border-radius:6px;transition:color .15s;}
.btn-clear-cli:hover{color:#dc2626;}
.plazo-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.btn-calcular{width:100%;background:linear-gradient(135deg,#7c3aed,#5b21b6);color:white;border:none;border-radius:10px;padding:11px;font-size:.9rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .15s;box-shadow:0 4px 12px rgba(124,58,237,.25);margin-bottom:14px;}
.btn-calcular:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(124,58,237,.35);}
.btn-calcular:disabled{opacity:.5;cursor:not-allowed;transform:none;}
.score-box{border-radius:12px;padding:16px;border:1.5px solid #e2e8f0;display:none;}
.score-num{font-size:3rem;font-weight:900;text-align:center;line-height:1;}
.score-nivel{text-align:center;font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;margin-top:4px;}
.score-barra-wrap{background:#e2e8f0;border-radius:20px;height:8px;margin:12px 0;}
.score-barra-fill{height:100%;border-radius:20px;transition:width .6s;}
.score-factores{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:12px;}
.sf-item{background:rgba(255,255,255,.6);border-radius:8px;padding:7px 10px;font-size:.75rem;}
.sf-item .sf-lbl{color:#64748b;font-weight:600;}
.sf-item .sf-val{font-weight:800;font-size:.9rem;margin-top:1px;}
.score-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:10px;}
.ss-item{text-align:center;background:rgba(255,255,255,.7);border-radius:8px;padding:7px 4px;}
.ss-item .ss-num{font-size:1.1rem;font-weight:800;}
.ss-item .ss-lbl{font-size:.65rem;color:#64748b;margin-top:1px;}
.score-loading{text-align:center;padding:20px;color:#64748b;font-size:.85rem;display:none;}
.prest-reco-box{margin-top:14px;padding:14px;border-radius:11px;background:linear-gradient(135deg,#0f172a,#1e3a8a);color:#fff;display:flex;align-items:center;gap:14px;box-shadow:0 4px 14px rgba(37,99,235,.25);}
.prest-reco-box.no-aprob{background:linear-gradient(135deg,#7f1d1d,#991b1b);}
.prb-icon{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#fde68a;flex-shrink:0;}
.prest-reco-box.no-aprob .prb-icon{color:#fecaca;}
.prb-info{flex:1;min-width:0;}
.prb-lbl{font-size:.65rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#cbd5e1;}
.prb-val{font-size:1.4rem;font-weight:900;color:#fde68a;font-variant-numeric:tabular-nums;line-height:1.1;margin-top:2px;}
.prest-reco-box.no-aprob .prb-val{color:#fecaca;font-size:1rem;}
.prb-help{font-size:.72rem;color:#93c5fd;margin-top:3px;}
.prest-reco-box.no-aprob .prb-help{color:#fca5a5;}
.btn-submit{width:100%;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:white;border:none;border-radius:10px;padding:13px;font-size:.95rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:9px;transition:all .15s;box-shadow:0 4px 14px rgba(37,99,235,.3);margin-top:6px;}
.btn-submit:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(37,99,235,.4);}
.btn-limpiar{width:100%;background:white;color:#64748b;border:1.5px solid #e2e8f0;border-radius:10px;padding:10px;font-size:.88rem;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .15s;margin-top:8px;}
.btn-limpiar:hover{background:#f8fafc;border-color:#94a3b8;color:#0f172a;}
.btn-pendientes{display:inline-flex;align-items:center;gap:8px;background:white;border:1.5px solid #fbbf24;border-radius:10px;padding:9px 16px;color:#92400e;font-size:.85rem;font-weight:700;text-decoration:none;transition:all .15s;}
.btn-pendientes:hover{background:#fffbeb;border-color:#f59e0b;}
.btn-historial{display:inline-flex;align-items:center;gap:7px;background:white;border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 13px;color:#475569;font-size:.8rem;font-weight:600;text-decoration:none;transition:all .15s;margin-top:10px;}
.btn-historial:hover{background:#f8fafc;border-color:#94a3b8;}
.alerta{padding:12px 16px;border-radius:10px;font-size:.85rem;font-weight:600;display:flex;align-items:center;gap:9px;margin-bottom:16px;}
.alerta.ok{background:#f0fdf4;border:1.5px solid #86efac;color:#166534;}
.alerta.error{background:#fef2f2;border:1.5px solid #fca5a5;color:#991b1b;}
.preview-monto{background:#eff6ff;border-radius:10px;padding:14px;margin-top:12px;border:1.5px solid #bfdbfe;display:none;}
.pm-row{display:flex;justify-content:space-between;font-size:.85rem;padding:4px 0;border-bottom:1px solid #dbeafe;}
.pm-row:last-child{border-bottom:none;font-weight:800;font-size:.9rem;color:#1d4ed8;}
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .card{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .card-title{color:#e2e8f0;border-color:#1e293b;}
[data-theme="dark"] .fgroup input,[data-theme="dark"] .fgroup select,[data-theme="dark"] .fgroup textarea{background:#1e293b;border-color:#334155;color:#e2e8f0;}
[data-theme="dark"] .search-results{background:#111827;border-color:#334155;}
[data-theme="dark"] .sr-item{border-color:#1e293b;}
[data-theme="dark"] .sr-item:hover{background:#1e3a8a;}
[data-theme="dark"] .sr-item .sr-nombre{color:#e2e8f0;}
[data-theme="dark"] .cliente-sel{background:rgba(37,99,235,.1);border-color:rgba(37,99,235,.3);}
[data-theme="dark"] .btn-back,[data-theme="dark"] .btn-icon{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .btn-limpiar{background:#1e293b;border-color:#334155;color:#94a3b8;}
[data-theme="dark"] .btn-historial{background:#1e293b;border-color:#334155;color:#94a3b8;}
[data-theme="dark"] .btn-pendientes{background:#1e293b;}
[data-theme="dark"] .preview-monto{background:rgba(37,99,235,.1);border-color:rgba(37,99,235,.3);}
[data-theme="dark"] .pm-row{border-color:rgba(37,99,235,.2);color:#e2e8f0;}
[data-theme="dark"] .pm-row:last-child{color:#93c5fd;}
[data-theme="dark"] .sf-item{background:rgba(0,0,0,.2);}
[data-theme="dark"] .ss-item{background:rgba(0,0,0,.2);}
@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@media(max-width:900px){.sidebar{display:none;}.main{margin-left:0;padding:14px 14px 50px;}.grid2{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="app">
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div><div class="brand-name">Préstamos J.E.</div><div class="brand-sub">Sistema Financiero</div></div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div><div class="u-name"><?= htmlspecialchars($user) ?></div><div class="u-rol"><?= htmlspecialchars($rol) ?></div></div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="solicitud_nueva.php" class="active"><i class="bi bi-file-earmark-plus"></i> Nueva Solicitud</a>
        <a href="solicitudes_pendientes.php"><i class="bi bi-hourglass-split"></i> Solicitudes Pendientes</a>
        <a href="historial_solicitudes.php"><i class="bi bi-clock-history"></i> Historial Solicitudes</a>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="cobro_diario/cobro_diario.php"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <a href="index.php" class="btn-back"><i class="bi bi-arrow-left"></i> Inicio</a>
            <div>
                <div class="topbar-title">Nueva Solicitud de Préstamo</div>
                <div class="topbar-sub">Captura y evaluación crediticia automática</div>
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
            <a href="solicitudes_pendientes.php" class="btn-pendientes">
                <i class="bi bi-hourglass-split"></i> Ver Pendientes
            </a>
            <a href="historial_solicitudes.php" class="btn-icon" title="Historial">
                <i class="bi bi-clock-history"></i>
            </a>
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <?php if ($msg): ?>
    <div class="alerta <?= $msg_tipo ?>">
        <i class="bi bi-<?= $msg_tipo === 'ok' ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
        <?= htmlspecialchars($msg) ?>
        <?php if ($msg_tipo === 'ok'): ?>
        &nbsp; <a href="solicitudes_pendientes.php" style="color:inherit;font-weight:800;text-decoration:underline;">Ver solicitudes pendientes →</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <form method="POST" id="formSolicitud">
    <input type="hidden" name="id_cliente"     id="hid_cliente" value="">
    <input type="hidden" name="score_guardado" id="hid_score"   value="0">

    <div class="grid2">

        <!-- COLUMNA IZQUIERDA -->
        <div>
            <div class="card">
                <div class="card-title"><i class="bi bi-person-check"></i> Datos del Cliente</div>
                <div class="fgroup">
                    <label>Buscar cliente <span style="color:#dc2626;">*</span></label>
                    <div class="search-wrap">
                        <input type="text" id="inputBuscar" placeholder="Nombre, apellido o teléfono..."
                               autocomplete="off" oninput="buscarCliente(this.value)">
                        <div class="search-results" id="searchResults"></div>
                    </div>
                </div>

                <div class="cliente-sel" id="clienteSel">
                    <div class="cs-avatar" id="csAvatar">?</div>
                    <div class="cs-info">
                        <div class="cs-nombre" id="csNombre">—</div>
                        <div class="cs-meta"   id="csMeta">—</div>
                    </div>
                    <button type="button" class="btn-clear-cli" onclick="limpiarCliente()" title="Quitar cliente">
                        <i class="bi bi-x-circle-fill"></i>
                    </button>
                </div>

                <a href="#" id="btnVerHistorial" class="btn-historial" target="_blank" style="display:none;">
                    <i class="bi bi-clock-history"></i> Ver historial del cliente
                </a>
            </div>

            <div class="card" style="margin-top:16px;">
                <div class="card-title"><i class="bi bi-cash-coin"></i> Detalle del Préstamo</div>

                <div class="fgroup">
                    <label>Monto solicitado <span style="color:#dc2626;">*</span></label>
                    <input type="number" name="monto_solicitado" id="inputMonto" min="100" step="50"
                           placeholder="Ej. 3000" oninput="calcularPreview()">
                </div>

                <div class="plazo-row">
                    <div class="fgroup">
                        <label>Tipo de plazo</label>
                        <select name="tipo_plazo" id="selectTipo" onchange="calcularPreview()">
                            <option value="DIARIO">Cobro diario</option>
                            <option value="SEMANAL">Cobro semanal</option>
                        </select>
                    </div>
                    <div class="fgroup">
                        <label>Número de días/semanas <span style="color:#dc2626;">*</span></label>
                        <input type="number" name="plazo_valor" id="inputPlazo" min="1" step="1"
                               placeholder="Ej. 60" oninput="calcularPreview()">
                    </div>
                </div>

                <div class="preview-monto" id="previewMonto">
                    <div class="pm-row"><span>Capital solicitado</span><span id="pm_capital">—</span></div>
                    <div class="pm-row"><span>Interés (20%)</span><span id="pm_interes">—</span></div>
                    <div class="pm-row"><span id="pm_cuota_lbl">Pago diario estimado</span><span id="pm_cuota">—</span></div>
                    <div class="pm-row"><span>Total a pagar</span><span id="pm_total">—</span></div>
                </div>

                <div class="fgroup" style="margin-top:14px;">
                    <label>Motivo del préstamo</label>
                    <textarea name="motivo" placeholder="Ej. Capital de trabajo, emergencia médica, compra de mercancía..."></textarea>
                </div>

                <button type="button" class="btn-limpiar" onclick="limpiarFormulario()">
                    <i class="bi bi-arrow-counterclockwise"></i> Limpiar formulario
                </button>
            </div>
        </div>

        <!-- COLUMNA DERECHA: score + envío -->
        <div>
            <div class="card">
                <div class="card-title"><i class="bi bi-graph-up-arrow"></i> Score Crediticio</div>
                <p style="font-size:.82rem;color:#64748b;margin-bottom:14px;">
                    El score se calcula con base en el historial interno del cliente: puntualidad de pagos,
                    préstamos liquidados, atrasos actuales y antigüedad.
                </p>

                <button type="button" class="btn-calcular" id="btnCalcular" onclick="calcularScore()" disabled>
                    <i class="bi bi-calculator"></i> Calcular Score del Cliente
                </button>

                <div class="score-loading" id="scoreLoading">
                    <i class="bi bi-arrow-repeat" style="animation:spin .8s linear infinite;display:inline-block;"></i>
                    &nbsp; Calculando...
                </div>

                <div class="score-box" id="scoreBox">
                    <div class="score-num"   id="scoreNum">—</div>
                    <div class="score-nivel" id="scoreNivel">—</div>
                    <div class="score-barra-wrap">
                        <div class="score-barra-fill" id="scoreBarraFill" style="width:0%;background:#2563eb;"></div>
                    </div>
                    <div class="score-factores">
                        <div class="sf-item"><div class="sf-lbl">Score base</div><div class="sf-val" id="sf1">—</div></div>
                        <div class="sf-item"><div class="sf-lbl">Bono créditos pagados</div><div class="sf-val" id="sf2">—</div></div>
                        <div class="sf-item"><div class="sf-lbl">Penal. créditos atrasados</div><div class="sf-val" id="sf3">—</div></div>
                        <div class="sf-item"><div class="sf-lbl">Penal. cuotas atrasadas</div><div class="sf-val" id="sf4">—</div></div>
                    </div>
                    <div class="score-stats" id="scoreStats"></div>
                    <div class="prest-reco-box" id="prestRecoBox" style="display:none;">
                        <div class="prb-icon"><i class="bi bi-cash-stack"></i></div>
                        <div class="prb-info">
                            <div class="prb-lbl">Préstamo recomendado</div>
                            <div class="prb-val" id="prestRecoVal">—</div>
                            <div class="prb-help" id="prestRecoHelp">Monto sugerido según score e historial</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:16px;">
                <div class="card-title"><i class="bi bi-send-check"></i> Registrar Solicitud</div>
                <p style="font-size:.82rem;color:#64748b;margin-bottom:16px;">
                    La solicitud quedará en estado <strong>PENDIENTE</strong> hasta que un supervisor
                    o gerente la apruebe o rechace.
                </p>
                <button type="submit" class="btn-submit" id="btnSubmit">
                    <i class="bi bi-file-earmark-check"></i> Enviar Solicitud
                </button>
                <a href="solicitudes_pendientes.php" class="btn-limpiar" style="text-decoration:none;margin-top:10px;">
                    <i class="bi bi-list-ul"></i> Ver solicitudes pendientes
                </a>
                <a href="clientes.php" class="btn-limpiar" style="text-decoration:none;margin-top:8px;">
                    <i class="bi bi-people"></i> Ir a Clientes
                </a>
            </div>
        </div>

    </div>
    </form>
</main>
</div>

<script>
var clienteSeleccionado = null;
var buscarTimer = null;
var _cacheClientes = [];

// ─ Tema ─────────────────────────────────────────────────────────
function toggleTema(){
    var c=document.documentElement.getAttribute('data-theme')||'light';
    var n=c==='dark'?'light':'dark';
    localStorage.setItem('pje_tema',n);
    document.documentElement.setAttribute('data-theme',n);
    document.getElementById('themeIcon').className=n==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';
}
(function(){
    var t=localStorage.getItem('pje_tema')||'light';
    document.getElementById('themeIcon').className=t==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';
})();

// ─ Reloj ────────────────────────────────────────────────────────
function actualizarReloj(){
    var n=new Date(),p=function(x){return String(x).padStart(2,'0');};
    var el=document.getElementById('reloj');
    if(el) el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj,1000);

// ─ Buscar cliente ───────────────────────────────────────────────
function buscarCliente(val){
    clearTimeout(buscarTimer);
    var box=document.getElementById('searchResults');
    if(val.length < 2){ box.style.display='none'; return; }
    buscarTimer = setTimeout(function(){
        fetch('solicitud_nueva.php?buscar='+encodeURIComponent(val))
            .then(function(r){ return r.json(); })
            .then(function(data){
                _cacheClientes = data;
                if(!data.length){
                    box.innerHTML='<div style="padding:10px 14px;font-size:.82rem;color:#94a3b8;"><i class="bi bi-inbox"></i> Sin resultados</div>';
                } else {
                    box.innerHTML = data.map(function(c, idx){
                        var dir = (c.direccion||'Sin dirección').substring(0,35);
                        var tel = c.telefono||'Sin tel';
                        return '<div class="sr-item" onclick="seleccionarCliente('+idx+')">'
                            +'<div class="sr-nombre">'+c.nombre_completo+'</div>'
                            +'<div class="sr-meta"><i class="bi bi-telephone"></i> '+tel
                            +' &nbsp;<i class="bi bi-geo-alt"></i> '+dir+'</div>'
                            +'</div>';
                    }).join('');
                }
                box.style.display='block';
            })
            .catch(function(){ box.style.display='none'; });
    }, 280);
}

function seleccionarCliente(idx){
    var c = _cacheClientes[idx];
    if(!c) return;
    clienteSeleccionado = c;
    document.getElementById('hid_cliente').value = c.id_cliente;
    document.getElementById('inputBuscar').value = c.nombre_completo;
    document.getElementById('searchResults').style.display='none';

    document.getElementById('csAvatar').textContent = c.nombre_completo.charAt(0).toUpperCase();
    document.getElementById('csNombre').textContent = c.nombre_completo;
    document.getElementById('csMeta').innerHTML =
        '<i class="bi bi-telephone"></i> '+(c.telefono||'—')
        +' &nbsp;<i class="bi bi-circle-fill" style="font-size:.5rem;color:'
        +(c.estatus==='ACTIVO'?'#22c55e':'#f59e0b')+'"></i> '+c.estatus;
    document.getElementById('clienteSel').style.display='flex';
    document.getElementById('btnVerHistorial').href='historial_cliente.php?id='+c.id_cliente;
    document.getElementById('btnVerHistorial').style.display='inline-flex';
    document.getElementById('btnCalcular').disabled=false;
    document.getElementById('scoreBox').style.display='none';
}

function limpiarCliente(){
    clienteSeleccionado=null;
    _cacheClientes=[];
    document.getElementById('hid_cliente').value='';
    document.getElementById('inputBuscar').value='';
    document.getElementById('clienteSel').style.display='none';
    document.getElementById('btnVerHistorial').style.display='none';
    document.getElementById('btnCalcular').disabled=true;
    document.getElementById('scoreBox').style.display='none';
    document.getElementById('hid_score').value='0';
}

// ─ Score ────────────────────────────────────────────────────────
function calcularScore(){
    if(!clienteSeleccionado) return;
    document.getElementById('scoreLoading').style.display='block';
    document.getElementById('scoreBox').style.display='none';
    document.getElementById('btnCalcular').disabled=true;

    fetch('solicitud_nueva.php?score=1&id_cliente='+clienteSeleccionado.id_cliente)
        .then(function(r){ return r.json(); })
        .then(function(d){
            document.getElementById('scoreLoading').style.display='none';
            document.getElementById('scoreBox').style.display='block';
            document.getElementById('btnCalcular').disabled=false;

            var box=document.getElementById('scoreBox');
            box.style.background=d.bg;
            box.style.borderColor=d.borde;

            document.getElementById('scoreNum').textContent=d.score;
            document.getElementById('scoreNum').style.color=d.color;
            document.getElementById('scoreNivel').textContent=d.nivel;
            document.getElementById('scoreNivel').style.color=d.color;

            var fill=document.getElementById('scoreBarraFill');
            fill.style.width=d.score+'%';
            fill.style.background=d.color;

            document.getElementById('sf1').textContent=d.f1+' pts';
            document.getElementById('sf1').style.color='#2563eb';
            document.getElementById('sf2').textContent=(d.f2>0?'+':'')+d.f2+' pts';
            document.getElementById('sf2').style.color=d.f2>0?'#16a34a':'#64748b';
            document.getElementById('sf3').textContent=d.f3+' pts';
            document.getElementById('sf3').style.color=d.f3<0?'#dc2626':'#64748b';
            document.getElementById('sf4').textContent=d.f4+' pts'+(d.cuotas_atrasadas>0?' ('+d.cuotas_atrasadas+' atrasos)':'');
            document.getElementById('sf4').style.color=d.f4<0?'#dc2626':'#64748b';

            // Préstamo recomendado
            var prb=document.getElementById('prestRecoBox');
            var prv=document.getElementById('prestRecoVal');
            var prh=document.getElementById('prestRecoHelp');
            prb.style.display='flex';
            if (d.prestamo_recomendado > 0) {
                prb.classList.remove('no-aprob');
                prv.textContent='$'+Number(d.prestamo_recomendado).toLocaleString('en-US');
                prh.textContent='Monto sugerido segun score e historial';
            } else {
                prb.classList.add('no-aprob');
                prv.textContent='NO APROBABLE';
                prh.textContent='Score insuficiente (minimo 70 para recomendar monto)';
            }

            document.getElementById('hid_score').value=d.score;

            var c=d.cliente;
            document.getElementById('scoreStats').innerHTML=
                '<div class="ss-item"><div class="ss-num" style="color:#2563eb;">'+(c.total_prestamos||0)+'</div><div class="ss-lbl">Préstamos</div></div>'
               +'<div class="ss-item"><div class="ss-num" style="color:#16a34a;">'+(c.pagados_total||0)+'</div><div class="ss-lbl">Liquidados</div></div>'
               +'<div class="ss-item"><div class="ss-num" style="color:'+(c.atrasados>0?'#dc2626':'#16a34a')+'">'+(c.atrasados||0)+'</div><div class="ss-lbl">Atrasados</div></div>';
        });
}

// ─ Preview monto ────────────────────────────────────────────────
function calcularPreview(){
    var monto=parseFloat(document.getElementById('inputMonto').value)||0;
    var plazo=parseInt(document.getElementById('inputPlazo').value)||0;
    var tipo=document.getElementById('selectTipo').value;
    var box=document.getElementById('previewMonto');
    if(monto<=0||plazo<=0){ box.style.display='none'; return; }
    var interes=monto*0.20;
    var total=monto+interes;
    var cuota=total/plazo;
    box.style.display='block';
    document.getElementById('pm_capital').textContent='$'+monto.toLocaleString('es-MX',{minimumFractionDigits:2});
    document.getElementById('pm_interes').textContent='$'+interes.toLocaleString('es-MX',{minimumFractionDigits:2});
    document.getElementById('pm_cuota_lbl').textContent=tipo==='DIARIO'?'Pago diario estimado':'Pago semanal estimado';
    document.getElementById('pm_cuota').textContent='$'+cuota.toLocaleString('es-MX',{minimumFractionDigits:2});
    document.getElementById('pm_total').textContent='$'+total.toLocaleString('es-MX',{minimumFractionDigits:2});
}

// ─ Limpiar formulario ───────────────────────────────────────────
function limpiarFormulario(){
    document.getElementById('formSolicitud').reset();
    limpiarCliente();
    document.getElementById('previewMonto').style.display='none';
}

// ─ Cerrar resultados al clic fuera ──────────────────────────────
document.addEventListener('click',function(e){
    if(!e.target.closest('.search-wrap')){
        document.getElementById('searchResults').style.display='none';
    }
});
</script>
</body>
</html>
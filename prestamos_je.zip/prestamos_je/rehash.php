<?php
include("conexion.php");

$nuevoPassword = password_hash("123456", PASSWORD_DEFAULT);

$conexion->query("
    UPDATE usuarios
    SET password = '$nuevoPassword'
");

echo "Passwords corregidos";

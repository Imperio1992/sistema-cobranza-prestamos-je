<?php
include("seguridad.php");
include("conexion.php");

/*********************************
 OBTENER ASESORES
**********************************/
$empleados = $conexion->query("
SELECT 
id_empleado,
nombre,
apellido
FROM empleados
WHERE estatus='ACTIVO'
AND rol='ASESOR'
ORDER BY apellido,nombre
");

$id_empleado = $_GET['id_empleado'] ?? '';

/*********************************
 CALCULAR SALDOS
**********************************/
$saldo_total = 0;
$saldo_efectivo = 0;
$saldo_banco = 0;

if($id_empleado){

$res = $conexion->query("
SELECT
SUM(CASE WHEN tipo='ENTRADA' THEN monto WHEN tipo='SALIDA' THEN -monto END) saldo,
SUM(CASE WHEN medio='EFECTIVO' AND tipo='ENTRADA' THEN monto 
         WHEN medio='EFECTIVO' AND tipo='SALIDA' THEN -monto END) efectivo,
SUM(CASE WHEN medio='BANCO' AND tipo='ENTRADA' THEN monto 
         WHEN medio='BANCO' AND tipo='SALIDA' THEN -monto END) banco
FROM caja
WHERE id_empleado = $id_empleado
");

$row = $res->fetch_assoc();

$saldo_total = $row['saldo'] ?? 0;
$saldo_efectivo = $row['efectivo'] ?? 0;
$saldo_banco = $row['banco'] ?? 0;

}

/*********************************
 REGISTRAR RETIRO
**********************************/
if($_SERVER['REQUEST_METHOD']=='POST'){

$id_empleado = $_POST['id_empleado'];

$efectivo = $_POST['efectivo'] ?? 0;
$banco = $_POST['banco'] ?? 0;

if($efectivo > 0){

$stmt = $conexion->prepare("
INSERT INTO caja(tipo,concepto,medio,monto,id_empleado)
VALUES('SALIDA','RETIRO GERENCIA','EFECTIVO',?,?)
");

$stmt->bind_param("di",$efectivo,$id_empleado);
$stmt->execute();

}

if($banco > 0){

$stmt = $conexion->prepare("
INSERT INTO caja(tipo,concepto,medio,monto,id_empleado)
VALUES('SALIDA','RETIRO GERENCIA','BANCO',?,?)
");

$stmt->bind_param("di",$banco,$id_empleado);
$stmt->execute();

}

header("Location:caja.php");
exit;

}
?>

<!DOCTYPE html>
<html>
<head>

<title>Retiro de Asesor</title>

<style>

body{
font-family:Arial;
background:#f4f6f9;
}

.container{
width:500px;
margin:auto;
margin-top:40px;
}

.card{
background:white;
padding:25px;
border-radius:10px;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
}

select,input{
width:100%;
padding:10px;
margin-top:10px;
border:1px solid #ccc;
border-radius:5px;
}

button{
padding:10px 20px;
border:none;
border-radius:5px;
cursor:pointer;
margin-top:15px;
}

.btn{
background:#007bff;
color:white;
}

.btn-back{
background:#6c757d;
color:white;
}

.saldo{
background:#f1f3f5;
padding:10px;
border-radius:5px;
margin-top:10px;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<h2>💰 Retirar dinero a asesor</h2>

<form method="GET">

Seleccionar asesor

<select name="id_empleado" onchange="this.form.submit()">

<option value="">Seleccione asesor</option>

<?php while($e = $empleados->fetch_assoc()){ ?>

<option value="<?php echo $e['id_empleado']; ?>"
<?php if($id_empleado == $e['id_empleado']) echo "selected"; ?>>

<?php echo $e['nombre']." ".$e['apellido']; ?>

</option>

<?php } ?>

</select>

</form>

<?php if($id_empleado){ ?>

<div class="saldo">

💰 Total: $<?php echo number_format($saldo_total,2); ?><br>
💵 Efectivo: $<?php echo number_format($saldo_efectivo,2); ?><br>
🏦 Banco: $<?php echo number_format($saldo_banco,2); ?>

</div>

<br>

<form method="POST">

<input type="hidden" name="id_empleado" value="<?php echo $id_empleado; ?>">

Retirar efectivo

<input type="number" step="0.01" name="efectivo" placeholder="0.00">

Retirar banco

<input type="number" step="0.01" name="banco" placeholder="0.00">

<button class="btn">Registrar retiro</button>

</form>

<?php } ?>

<br>

<button class="btn-back" onclick="location.href='caja.php'">
⬅ Volver a Caja
</button>

</div>

</div>

</body>
</html>
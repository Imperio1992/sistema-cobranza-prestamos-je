<?php
$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'];
$id_yo      = intval($_SESSION['id_empleado']);
$usuario_yo = $_SESSION['usuario'] ?? 'Usuario';

if ($rol_actual === 'ASESOR') {
    $id_preseleccionado = $id_yo;
} else {
    $id_preseleccionado = isset($_GET['id']) ? intval($_GET['id']) : 0;
}

/* ── REGISTRAR EGRESO ── */
$msg_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $monto           = floatval($_POST['monto'] ?? 0);
    $concepto        = trim($_POST['concepto'] ?? '');
    $medio           = in_array($_POST['medio'] ?? '', ['EFECTIVO','BANCO']) ? $_POST['medio'] : 'EFECTIVO';
    $id_empleado     = $rol_actual === 'ASESOR' ? $id_yo : intval($_POST['id_empleado'] ?? 0);
    $tipo_movimiento = $_POST['tipo_movimiento'] ?? 'GASTO';
    $referencia      = trim($_POST['referencia'] ?? '');

    if ($monto <= 0) {
        $msg_error = 'El monto debe ser mayor a $0.00';
    } else {
        if ($referencia) $concepto = $concepto ? "$concepto | Comp: $referencia" : "Comp: $referencia";

        if ($tipo_movimiento === 'RETIRO') {
            $medio = 'EFECTIVO';
            if (empty($concepto)) $concepto = 'Retiro de efectivo para cobros en campo';
            $stmt = $conexion->prepare("INSERT INTO caja(tipo,concepto,medio,monto,id_empleado,tipo_movimiento) VALUES('SALIDA',?,'EFECTIVO',?,?,'RETIRO')");
            $stmt->bind_param("sdi", $concepto, $monto, $id_empleado);
            $stmt->execute(); $stmt->close();

        } elseif ($tipo_movimiento === 'BONO') {
            $monto_asesor  = $monto * 0.20;
            $monto_empresa = $monto * 0.80;
            $stmt = $conexion->prepare("INSERT INTO caja(tipo,concepto,medio,monto,id_empleado,tipo_movimiento) VALUES('SALIDA','Bono asesor (20%)',?,?,?,'BONO')");
            $stmt->bind_param("sdi", $medio, $monto_asesor, $id_empleado);
            $stmt->execute(); $stmt->close();
            $stmt = $conexion->prepare("INSERT INTO caja(tipo,concepto,medio,monto,id_empleado,tipo_movimiento) VALUES('SALIDA','Ganancia empresa (80%)',?,?,?,'BONO')");
            $stmt->bind_param("sdi", $medio, $monto_empresa, $id_empleado);
            $stmt->execute(); $stmt->close();

        } else {
            if (empty($concepto)) $concepto = $tipo_movimiento;
            $stmt = $conexion->prepare("INSERT INTO caja(tipo,concepto,medio,monto,id_empleado,tipo_movimiento) VALUES('SALIDA',?,?,?,?,?)");
            $stmt->bind_param("ssdis", $concepto, $medio, $monto, $id_empleado, $tipo_movimiento);
            $stmt->execute(); $stmt->close();
        }

        header("Location: caja_asesor.php" . ($rol_actual !== 'ASESOR' && $id_empleado ? "?id=$id_empleado" : ''));
        exit;
    }
}

/* ── SALDO ── */
$filtro_saldo   = $id_preseleccionado ? "WHERE id_empleado=$id_preseleccionado" : '';
$etiqueta_saldo = $id_preseleccionado ? 'Saldo del asesor' : 'Saldo General';

$saldo_total    = $conexion->query("SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total FROM caja $filtro_saldo")->fetch_assoc()['total'] ?? 0;
$saldo_efectivo = $conexion->query("SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total FROM caja " . ($filtro_saldo ? $filtro_saldo." AND medio='EFECTIVO'" : "WHERE medio='EFECTIVO'"))->fetch_assoc()['total'] ?? 0;
$saldo_banco    = $conexion->query("SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total FROM caja " . ($filtro_saldo ? $filtro_saldo." AND medio='BANCO'" : "WHERE medio='BANCO'"))->fetch_assoc()['total'] ?? 0;

/* ── ASESORES ── */
$empleados_array = [];
if ($rol_actual !== 'ASESOR') {
    $emp = $conexion->query("SELECT id_empleado, nombre, apellido, ruta_tipo FROM empleados WHERE rol='ASESOR' AND estatus='ACTIVO' ORDER BY apellido, nombre");
    while ($e = $emp->fetch_assoc()) $empleados_array[] = $e;
}

$nombre_yo_display = '';
if ($rol_actual === 'ASESOR') {
    $row = $conexion->query("SELECT nombre, apellido FROM empleados WHERE id_empleado=$id_yo")->fetch_assoc();
    $nombre_yo_display = $row ? htmlspecialchars($row['nombre'].' '.$row['apellido']) : 'Tú';
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Registrar Egreso — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb { width:34px; height:34px; background:linear-gradient(135deg,#dc2626,#b91c1c); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(220,38,38,.15); color:#fca5a5; border:1px solid rgba(220,38,38,.2); }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.btn-back { display:inline-flex; align-items:center; gap:6px; padding:8px 16px; border-radius:10px; font-size:.82rem; font-weight:600; background:white; color:#64748b; border:1.5px solid #e2e8f0; text-decoration:none; transition:all .15s; }
.btn-back:hover { border-color:#0f172a; color:#0f172a; }
.btn-icon-top { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; }
.btn-icon-top:hover { color:#0f172a; border-color:#dc2626; }

/* ── SALDO BAR ── */
.saldo-bar { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:22px; }
.saldo-item { background:white; border-radius:14px; padding:16px 18px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; }
.saldo-item .lbl { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; }
.saldo-item .val { font-size:1.4rem; font-weight:800; color:#0f172a; margin-top:5px; }
.saldo-item.banco .val { color:#2563eb; }

/* ── FORM ── */
.form-layout { display:grid; grid-template-columns:1fr 340px; gap:20px; align-items:start; }
.seccion { background:white; border-radius:14px; padding:22px; margin-bottom:16px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; }
.seccion h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#64748b; margin-bottom:16px; display:flex; align-items:center; gap:7px; }

/* ── RADIO TIPO EGRESO ── */
.radio-group { display:flex; flex-direction:column; gap:10px; }
.radio-tipo { display:flex; align-items:flex-start; gap:14px; padding:14px 16px; border:2px solid #e2e8f0; border-radius:12px; cursor:pointer; transition:all .15s; }
.radio-tipo:has(input:checked).t-retiro  { border-color:#ea580c; background:#fff7ed; }
.radio-tipo:has(input:checked).t-gasto   { border-color:#dc2626; background:#fff1f2; }
.radio-tipo:has(input:checked).t-bono    { border-color:#9333ea; background:#faf5ff; }
.radio-tipo:has(input:checked).t-ajuste  { border-color:#64748b; background:#f8fafc; }
.radio-tipo input { margin-top:3px; accent-color:#dc2626; }
.radio-tipo .rt-label { font-size:.88rem; font-weight:700; color:#1e293b; }
.radio-tipo .rt-desc  { font-size:.75rem; color:#64748b; margin-top:3px; }

/* ── RADIO MEDIO ── */
.medio-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.radio-medio { display:flex; align-items:center; gap:10px; padding:12px 14px; border:2px solid #e2e8f0; border-radius:12px; cursor:pointer; transition:all .15s; }
.radio-medio:has(input:checked).ef { border-color:#ea580c; background:#fff7ed; }
.radio-medio:has(input:checked).bk { border-color:#2563eb; background:#eff6ff; }
.radio-medio input { accent-color:#dc2626; }
.radio-medio .rm-icon  { font-size:1.1rem; }
.radio-medio .rm-label { font-size:.85rem; font-weight:700; color:#1e293b; }
.radio-medio .rm-sub   { font-size:.72rem; color:#64748b; margin-top:1px; }

/* ── CAMPOS ── */
.field { margin-bottom:14px; }
.field:last-child { margin-bottom:0; }
.field label { display:block; font-size:.72rem; font-weight:700; color:#374151; text-transform:uppercase; letter-spacing:.04em; margin-bottom:6px; }
.field input, .field select, .field textarea {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.9rem; color:#1e293b; background:#f8fafc;
    outline:none; font-family:'Inter',sans-serif; transition:border-color .15s;
}
.field input:focus, .field select:focus { border-color:#dc2626; background:white; box-shadow:0 0 0 3px rgba(220,38,38,.08); }
.field input[readonly] { background:#f1f5f9; color:#94a3b8; }
#ref-wrap   { display:none; }
#medio-wrap { display:block; }

/* ── SUBMIT ── */
.btn-submit { width:100%; padding:14px; background:#dc2626; color:white; border:none; border-radius:12px; font-size:.95rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:background .15s; display:flex; align-items:center; justify-content:center; gap:8px; margin-top:4px; }
.btn-submit:hover { background:#b91c1c; }

/* ── RESUMEN LATERAL ── */
.resumen-card { background:#0f172a; border-radius:14px; padding:20px 22px; }
.resumen-card h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#475569; margin-bottom:16px; display:flex; align-items:center; gap:7px; }
.r-item { display:flex; align-items:center; gap:10px; padding:10px 0; border-bottom:1px solid #1e293b; }
.r-item:last-child { border-bottom:none; padding-bottom:0; }
.r-title { font-size:.78rem; font-weight:700; color:#e2e8f0; }
.r-val   { font-size:.75rem; color:#64748b; margin-top:2px; }
.aviso-rojo { padding:12px 14px; background:#fff1f2; border:1.5px solid #fecdd3; border-radius:10px; font-size:.78rem; color:#9f1239; margin-top:14px; }
.bono-info  { padding:12px 14px; background:#faf5ff; border:1.5px solid #ddd6fe; border-radius:10px; font-size:.78rem; color:#5b21b6; margin-top:14px; display:none; }

/* ── ALERTA ── */
.alerta { border-radius:12px; padding:13px 16px; margin-bottom:18px; display:flex; align-items:center; gap:10px; font-size:.85rem; font-weight:600; }
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .btn-back  { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .saldo-item { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .saldo-item .val { color:#e2e8f0; }
[data-theme="dark"] .seccion { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .radio-tipo  { border-color:#334155; }
[data-theme="dark"] .radio-medio { border-color:#334155; }
[data-theme="dark"] .radio-tipo .rt-label, [data-theme="dark"] .radio-medio .rm-label { color:#e2e8f0; }
[data-theme="dark"] .field input, [data-theme="dark"] .field select { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .field label { color:#94a3b8; }
[data-theme="dark"] .aviso-rojo { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }
[data-theme="dark"] .bono-info  { background:#2e1065; border-color:#5b21b6; color:#c4b5fd; }

@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; padding:16px 14px 80px; }
    .form-layout { grid-template-columns:1fr; }
    .saldo-bar   { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">

<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div><div class="brand-name">Préstamos J.E.</div><div class="brand-sub">Sistema de Gestión</div></div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($usuario_yo, 0, 1)) ?></div>
        <div><div class="u-name"><?= htmlspecialchars($usuario_yo) ?></div><div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div></div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja General</a>
        <a href="caja_asesor.php"><i class="bi bi-wallet2"></i> Caja Asesor</a>
        <a href="ingreso_caja.php"><i class="bi bi-plus-circle"></i> Registrar Ingreso</a>
        <a href="egreso_caja.php" class="active"><i class="bi bi-dash-circle"></i> Retiro / Gasto</a>
        <?php if ($rol_actual !== 'ASESOR'): ?>
        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="bi bi-dash-circle-fill" style="color:#dc2626;"></i> Retiro / Gasto</h1>
            <p><?= $etiqueta_saldo ?> &nbsp;·&nbsp; <?= $rol_actual === 'ASESOR' ? $nombre_yo_display : 'Selecciona asesor' ?></p>
        </div>
        <div class="topbar-right">
            <a href="caja_asesor.php<?= $id_preseleccionado ? '?id='.$id_preseleccionado : '' ?>" class="btn-back">
                <i class="bi bi-arrow-left"></i> Volver
            </a>
            <button class="btn-icon-top" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <?php if ($msg_error): ?>
    <div class="alerta error"><i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($msg_error) ?></div>
    <?php endif; ?>

    <!-- SALDO BAR -->
    <div class="saldo-bar">
        <div class="saldo-item">
            <div class="lbl"><i class="bi bi-calculator"></i> <?= $etiqueta_saldo ?></div>
            <div class="val">$<?= number_format($saldo_total, 2) ?></div>
        </div>
        <div class="saldo-item">
            <div class="lbl"><i class="bi bi-cash"></i> Efectivo</div>
            <div class="val">$<?= number_format($saldo_efectivo, 2) ?></div>
        </div>
        <div class="saldo-item banco">
            <div class="lbl"><i class="bi bi-bank"></i> Banco</div>
            <div class="val">$<?= number_format($saldo_banco, 2) ?></div>
        </div>
    </div>

    <form method="POST" onsubmit="return confirmar()">
    <div class="form-layout">
        <div>

            <!-- TIPO EGRESO -->
            <div class="seccion">
                <h3><i class="bi bi-tags"></i> Tipo de egreso</h3>
                <div class="radio-group">
                    <label class="radio-tipo t-retiro" onclick="tipoChanged('RETIRO')">
                        <input type="radio" name="tipo_movimiento" value="RETIRO" checked>
                        <div>
                            <div class="rt-label"><i class="bi bi-cash-stack" style="color:#ea580c;"></i> Retiro de efectivo</div>
                            <div class="rt-desc">El asesor recibe efectivo para trabajar en campo — siempre en efectivo</div>
                        </div>
                    </label>
                    <label class="radio-tipo t-gasto" onclick="tipoChanged('GASTO')">
                        <input type="radio" name="tipo_movimiento" value="GASTO">
                        <div>
                            <div class="rt-label"><i class="bi bi-receipt" style="color:#dc2626;"></i> Gasto operativo</div>
                            <div class="rt-desc">Gastos de operación como gasolina, papelería, comidas</div>
                        </div>
                    </label>
                    <label class="radio-tipo t-bono" onclick="tipoChanged('BONO')">
                        <input type="radio" name="tipo_movimiento" value="BONO">
                        <div>
                            <div class="rt-label"><i class="bi bi-gift" style="color:#9333ea;"></i> Pago de bono</div>
                            <div class="rt-desc">Se divide automáticamente: 20% asesor · 80% empresa</div>
                        </div>
                    </label>
                    <label class="radio-tipo t-ajuste" onclick="tipoChanged('AJUSTE')">
                        <input type="radio" name="tipo_movimiento" value="AJUSTE">
                        <div>
                            <div class="rt-label"><i class="bi bi-sliders" style="color:#64748b;"></i> Ajuste de saldo</div>
                            <div class="rt-desc">Corrección manual de saldo</div>
                        </div>
                    </label>
                </div>
            </div>

            <!-- MEDIO DE PAGO -->
            <div id="medio-wrap">
                <div class="seccion">
                    <h3><i class="bi bi-credit-card"></i> Medio de pago</h3>
                    <div class="medio-grid">
                        <label class="radio-medio ef">
                            <input type="radio" name="medio" value="EFECTIVO" checked onchange="toggleRef(this)">
                            <div class="rm-icon"><i class="bi bi-cash-coin" style="color:#ea580c;"></i></div>
                            <div>
                                <div class="rm-label">Efectivo</div>
                                <div class="rm-sub">Pago en mano</div>
                            </div>
                        </label>
                        <label class="radio-medio bk">
                            <input type="radio" name="medio" value="BANCO" onchange="toggleRef(this)">
                            <div class="rm-icon"><i class="bi bi-bank" style="color:#2563eb;"></i></div>
                            <div>
                                <div class="rm-label">Banco</div>
                                <div class="rm-sub">Transferencia</div>
                            </div>
                        </label>
                    </div>
                    <div id="ref-wrap" style="margin-top:14px;">
                        <div class="field">
                            <label><i class="bi bi-hash"></i> Comprobante / referencia <span style="font-weight:400;color:#94a3b8;">(opcional)</span></label>
                            <input type="text" name="referencia" placeholder="Ej: Folio 001, referencia bancaria...">
                        </div>
                    </div>
                </div>
            </div>

            <!-- DATOS -->
            <div class="seccion">
                <h3><i class="bi bi-pencil-square"></i> Detalles del egreso</h3>

                <?php if ($rol_actual !== 'ASESOR' && !empty($empleados_array)): ?>
                <div class="field">
                    <label><i class="bi bi-person-fill"></i> Asesor *</label>
                    <select name="id_empleado" required>
                        <option value="">— Selecciona asesor —</option>
                        <?php foreach ($empleados_array as $e): ?>
                        <option value="<?= $e['id_empleado'] ?>" <?= $e['id_empleado'] == $id_preseleccionado ? 'selected' : '' ?>>
                            <?= htmlspecialchars($e['nombre'].' '.$e['apellido']) ?> — <?= htmlspecialchars($e['ruta_tipo']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                <div class="field">
                    <label><i class="bi bi-person-fill"></i> Asesor</label>
                    <input type="text" value="<?= $nombre_yo_display ?>" readonly>
                </div>
                <?php endif; ?>

                <div class="field">
                    <label><i class="bi bi-currency-dollar"></i> Monto *</label>
                    <input type="number" name="monto" step="0.01" min="0.01" placeholder="0.00" required>
                </div>

                <div class="field" id="concepto-wrap">
                    <label><i class="bi bi-chat-left-text"></i> Concepto <span style="font-weight:400;color:#94a3b8;">(opcional)</span></label>
                    <input type="text" name="concepto" placeholder="Ej: Gasolina semanal, retiro de efectivo...">
                </div>

                <div class="bono-info" id="bono-info">
                    <i class="bi bi-info-circle-fill"></i>
                    El monto ingresado se dividirá automáticamente: <strong>20% para el asesor</strong> y <strong>80% para la empresa</strong>. Se registrarán 2 movimientos separados.
                </div>

                <button type="submit" class="btn-submit">
                    <i class="bi bi-check-circle-fill"></i> Registrar Egreso
                </button>
            </div>

        </div>

        <!-- RESUMEN LATERAL -->
        <div>
            <div class="resumen-card">
                <h3><i class="bi bi-bar-chart-line" style="color:#60a5fa;"></i> Saldo actual</h3>
                <div class="r-item">
                    <i class="bi bi-wallet2" style="color:#60a5fa;"></i>
                    <div><div class="r-title">Total</div><div class="r-val">$<?= number_format($saldo_total, 2) ?></div></div>
                </div>
                <div class="r-item">
                    <i class="bi bi-cash" style="color:#4ade80;"></i>
                    <div><div class="r-title">Efectivo</div><div class="r-val">$<?= number_format($saldo_efectivo, 2) ?></div></div>
                </div>
                <div class="r-item">
                    <i class="bi bi-bank" style="color:#60a5fa;"></i>
                    <div><div class="r-title">Banco</div><div class="r-val">$<?= number_format($saldo_banco, 2) ?></div></div>
                </div>
            </div>
            <div class="aviso-rojo" style="margin-top:14px;">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <strong> Egreso</strong> — Este movimiento se registrará como <strong>SALIDA</strong> y restará del saldo del asesor.
            </div>
        </div>

    </div>
    </form>

</main>
</div>

<script>
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    const n = new Date(), pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

function toggleRef(el) {
    document.getElementById('ref-wrap').style.display = el.value === 'BANCO' ? 'block' : 'none';
}
function tipoChanged(tipo) {
    const medioWrap = document.getElementById('medio-wrap');
    const bonoInfo  = document.getElementById('bono-info');
    medioWrap.style.display = tipo === 'RETIRO' ? 'none' : 'block';
    bonoInfo.style.display  = tipo === 'BONO'   ? 'block' : 'none';
}
function confirmar() {
    const tipo = document.querySelector('input[name="tipo_movimiento"]:checked')?.value;
    const msgs = {
        RETIRO:'¿Confirmas el retiro de efectivo para el asesor?',
        GASTO: '¿Confirmas registrar este gasto?',
        BONO:  '¿Confirmas el pago de bono? Se dividirá 20% asesor / 80% empresa.',
        AJUSTE:'¿Confirmas el ajuste de saldo?'
    };
    return confirm(msgs[tipo] || '¿Confirmas registrar este egreso?');
}
</script>
</body>
</html>

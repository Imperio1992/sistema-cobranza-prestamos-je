<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'];
$usuario_yo = $_SESSION['usuario'] ?? 'Usuario';

$asesores = $conexion->query("
    SELECT id_empleado, nombre, apellido, ruta_tipo
    FROM empleados
    WHERE rol='ASESOR' AND estatus='ACTIVO'
    ORDER BY apellido, nombre
");

$datos = [];
while ($a = $asesores->fetch_assoc()) {
    $id = $a['id_empleado'];
    $r  = $conexion->query("
        SELECT
            SUM(CASE WHEN tipo='ENTRADA' THEN monto WHEN tipo='SALIDA' THEN -monto END) AS saldo,
            SUM(CASE WHEN medio='EFECTIVO' AND tipo='ENTRADA' THEN monto WHEN medio='EFECTIVO' AND tipo='SALIDA' THEN -monto END) AS efectivo,
            SUM(CASE WHEN medio='BANCO'    AND tipo='ENTRADA' THEN monto WHEN medio='BANCO'    AND tipo='SALIDA' THEN -monto END) AS banco,
            SUM(CASE WHEN tipo_movimiento='INVERSION' AND tipo='ENTRADA' THEN monto ELSE 0 END) AS invertido,
            SUM(CASE WHEN tipo_movimiento='COBRO' AND DATE(fecha)=CURDATE() THEN monto ELSE 0 END) AS cobrado_hoy
        FROM caja WHERE id_empleado='$id'
    ")->fetch_assoc();

    $datos[] = [
        'id'          => $id,
        'nombre'      => $a['nombre'].' '.$a['apellido'],
        'ruta_tipo'   => $a['ruta_tipo'] ?? '',
        'saldo'       => floatval($r['saldo']      ?? 0),
        'efectivo'    => floatval($r['efectivo']   ?? 0),
        'banco'       => floatval($r['banco']      ?? 0),
        'invertido'   => floatval($r['invertido']  ?? 0),
        'cobrado_hoy' => floatval($r['cobrado_hoy']?? 0),
    ];
}

/* Totales */
$total_saldo     = array_sum(array_column($datos, 'saldo'));
$total_efectivo  = array_sum(array_column($datos, 'efectivo'));
$total_banco     = array_sum(array_column($datos, 'banco'));
$total_invertido = array_sum(array_column($datos, 'invertido'));
$total_hoy       = array_sum(array_column($datos, 'cobrado_hoy'));
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Caja por Asesores — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; letter-spacing:-.3px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.btn-back { display:inline-flex; align-items:center; gap:6px; padding:8px 16px; border-radius:10px; font-size:.82rem; font-weight:600; background:white; color:#64748b; border:1.5px solid #e2e8f0; text-decoration:none; transition:all .15s; }
.btn-back:hover { border-color:#0f172a; color:#0f172a; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── RESUMEN TOTAL ── */
.totales-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; margin-bottom:24px; }
.total-card {
    background:white; border-radius:14px; padding:18px 16px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); text-align:center; border:1px solid #f1f5f9;
}
.total-card .tc-label { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#64748b; }
.total-card .tc-val   { font-size:1.25rem; font-weight:800; color:#0f172a; margin-top:6px; }
.total-card.oscuro { background:#0f172a; }
.total-card.oscuro .tc-label, .total-card.oscuro .tc-val { color:white; }
.total-card.verde  { background:#16a34a; }
.total-card.verde  .tc-label, .total-card.verde  .tc-val { color:white; }
.total-card.azul   { background:#2563eb; }
.total-card.azul   .tc-label, .total-card.azul   .tc-val { color:white; }
.total-card.morado { background:#7c3aed; }
.total-card.morado .tc-label, .total-card.morado .tc-val { color:white; }

/* ── CARDS ASESORES ── */
.asesores-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px; }
.asesor-card {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 8px rgba(0,0,0,.06); overflow:hidden; transition:box-shadow .2s;
}
.asesor-card:hover { box-shadow:0 6px 20px rgba(0,0,0,.1); }
.asesor-card-header {
    padding:16px 18px 12px; display:flex; align-items:center; gap:12px;
    border-bottom:1px solid #f1f5f9;
}
.av-card {
    width:44px; height:44px; border-radius:50%;
    background:linear-gradient(135deg,#16a34a,#15803d);
    display:flex; align-items:center; justify-content:center;
    font-size:1rem; font-weight:800; color:white; flex-shrink:0;
}
.av-card.ruta-s { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.ac-nombre { font-size:.95rem; font-weight:800; color:#0f172a; }
.ac-ruta   { font-size:.72rem; color:#64748b; margin-top:3px; display:flex; align-items:center; gap:4px; }
.ac-ver    { margin-left:auto; display:inline-flex; align-items:center; gap:5px; padding:6px 12px; background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:8px; font-size:.75rem; font-weight:700; color:#374151; text-decoration:none; transition:all .15s; }
.ac-ver:hover { background:#0f172a; color:white; border-color:#0f172a; }
.asesor-card-body { padding:16px 18px; display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.ac-stat { text-align:center; padding:10px; border-radius:10px; background:#f8fafc; }
.ac-stat .acs-label { font-size:.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#94a3b8; }
.ac-stat .acs-val   { font-size:1.1rem; font-weight:800; margin-top:4px; }
.ac-stat.positivo .acs-val { color:#16a34a; }
.ac-stat.negativo .acs-val { color:#dc2626; }
.ac-stat.neutral  .acs-val { color:#0f172a; }
.asesor-card-footer { padding:10px 18px; background:#f8fafc; border-top:1px solid #f1f5f9; display:flex; align-items:center; gap:8px; font-size:.75rem; color:#64748b; }
.badge-ruta { padding:3px 10px; border-radius:20px; font-size:.68rem; font-weight:700; }
.badge-diario  { background:#dcfce7; color:#15803d; }
.badge-semanal { background:#dbeafe; color:#1d4ed8; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .btn-back { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .total-card { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .total-card .tc-label, [data-theme="dark"] .total-card .tc-val { color:#e2e8f0; }
[data-theme="dark"] .total-card.oscuro .tc-label, [data-theme="dark"] .total-card.oscuro .tc-val,
[data-theme="dark"] .total-card.verde .tc-label,  [data-theme="dark"] .total-card.verde .tc-val,
[data-theme="dark"] .total-card.azul .tc-label,   [data-theme="dark"] .total-card.azul .tc-val,
[data-theme="dark"] .total-card.morado .tc-label, [data-theme="dark"] .total-card.morado .tc-val { color:white; }
[data-theme="dark"] .asesor-card { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .asesor-card-header { border-color:#334155; }
[data-theme="dark"] .ac-nombre { color:#f1f5f9; }
[data-theme="dark"] .ac-ver { background:#0f172a; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .ac-stat { background:#0f172a; }
[data-theme="dark"] .ac-stat.neutral .acs-val { color:#e2e8f0; }
[data-theme="dark"] .asesor-card-footer { background:#162032; border-color:#334155; }

@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; padding:16px 14px 80px; }
    .asesores-grid { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($usuario_yo, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($usuario_yo) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja General</a>
        <a href="caja_asesor.php"><i class="bi bi-wallet2"></i> Caja Asesor</a>
        <a href="caja_asesores.php" class="active"><i class="bi bi-people-fill"></i> Resumen Asesores</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial</a>
        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="bi bi-people-fill" style="color:#2563eb;"></i> Caja por Asesores</h1>
            <p>Resumen de saldos y movimientos de todos los asesores activos</p>
        </div>
        <div class="topbar-right">
            <a href="caja.php" class="btn-back"><i class="bi bi-arrow-left"></i> Caja General</a>
            <button class="btn-icon-top" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- TOTALES -->
    <div class="totales-grid">
        <div class="total-card oscuro">
            <div class="tc-label"><i class="bi bi-calculator"></i> Saldo Total</div>
            <div class="tc-val">$<?= number_format($total_saldo, 2) ?></div>
        </div>
        <div class="total-card">
            <div class="tc-label"><i class="bi bi-cash"></i> Total Efectivo</div>
            <div class="tc-val">$<?= number_format($total_efectivo, 2) ?></div>
        </div>
        <div class="total-card azul">
            <div class="tc-label"><i class="bi bi-bank"></i> Total Banco</div>
            <div class="tc-val">$<?= number_format($total_banco, 2) ?></div>
        </div>
        <div class="total-card morado">
            <div class="tc-label"><i class="bi bi-bank2"></i> Total Invertido</div>
            <div class="tc-val">$<?= number_format($total_invertido, 2) ?></div>
        </div>
        <div class="total-card verde">
            <div class="tc-label"><i class="bi bi-calendar-day"></i> Cobrado Hoy</div>
            <div class="tc-val">$<?= number_format($total_hoy, 2) ?></div>
        </div>
    </div>

    <!-- CARDS ASESORES -->
    <?php if (empty($datos)): ?>
    <div style="text-align:center;padding:60px;color:#94a3b8;">
        <i class="bi bi-people" style="font-size:2rem;display:block;margin-bottom:10px;"></i>
        No hay asesores activos registrados.
    </div>
    <?php else: ?>
    <div class="asesores-grid">
        <?php foreach ($datos as $d):
            $ini = strtoupper(substr($d['nombre'], 0, 1));
            $av_cls = strtolower($d['ruta_tipo']) === 'semanal' ? 'av-card ruta-s' : 'av-card';
            $s_cls  = $d['saldo']    >= 0 ? 'positivo' : 'negativo';
            $e_cls  = $d['efectivo'] >= 0 ? 'positivo' : 'negativo';
            $b_cls  = $d['banco']    >= 0 ? 'positivo' : 'negativo';
            $ruta_badge = strtolower($d['ruta_tipo']) === 'semanal' ? 'badge-semanal' : 'badge-diario';
        ?>
        <div class="asesor-card">
            <div class="asesor-card-header">
                <div class="<?= $av_cls ?>"><?= $ini ?></div>
                <div>
                    <div class="ac-nombre"><?= htmlspecialchars($d['nombre']) ?></div>
                    <div class="ac-ruta">
                        <i class="bi bi-geo-alt-fill"></i>
                        <?= htmlspecialchars($d['ruta_tipo'] ?: '—') ?>
                    </div>
                </div>
                <a href="caja_asesor.php?id=<?= $d['id'] ?>" class="ac-ver">
                    <i class="bi bi-eye"></i> Ver
                </a>
            </div>
            <div class="asesor-card-body">
                <div class="ac-stat <?= $s_cls ?>">
                    <div class="acs-label">Saldo Total</div>
                    <div class="acs-val">$<?= number_format($d['saldo'], 2) ?></div>
                </div>
                <div class="ac-stat neutral">
                    <div class="acs-label">Cobrado Hoy</div>
                    <div class="acs-val" style="color:#16a34a;">$<?= number_format($d['cobrado_hoy'], 2) ?></div>
                </div>
                <div class="ac-stat <?= $e_cls ?>">
                    <div class="acs-label">Efectivo</div>
                    <div class="acs-val">$<?= number_format($d['efectivo'], 2) ?></div>
                </div>
                <div class="ac-stat <?= $b_cls ?>">
                    <div class="acs-label">Banco</div>
                    <div class="acs-val">$<?= number_format($d['banco'], 2) ?></div>
                </div>
            </div>
            <div class="asesor-card-footer">
                <span class="badge-ruta <?= $ruta_badge ?>"><?= htmlspecialchars($d['ruta_tipo'] ?: 'SIN RUTA') ?></span>
                <span style="margin-left:auto;">
                    Invertido: <strong style="color:#7c3aed;">$<?= number_format($d['invertido'], 2) ?></strong>
                </span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</main>
</div>

<script>
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    const n = new Date(), pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj(); setInterval(actualizarReloj, 1000);
</script>
</body>
</html>

<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'];
$user       = $_SESSION['usuario'] ?? 'Usuario';
$buscar     = trim($_GET['q'] ?? '');
$filtro_rol = $_GET['rol'] ?? '';
$filtro_est = $_GET['estatus'] ?? 'ACTIVO';

/* ── RESUMEN ── */
$total_emp    = $conexion->query("SELECT COUNT(*) c FROM empleados")->fetch_assoc()['c'] ?? 0;
$activos      = $conexion->query("SELECT COUNT(*) c FROM empleados WHERE estatus='ACTIVO'")->fetch_assoc()['c'] ?? 0;
$inactivos    = $total_emp - $activos;
$asesores     = $conexion->query("SELECT COUNT(*) c FROM empleados WHERE rol='ASESOR' AND estatus='ACTIVO'")->fetch_assoc()['c'] ?? 0;
$supervisores = $conexion->query("SELECT COUNT(*) c FROM empleados WHERE rol='SUPERVISOR' AND estatus='ACTIVO'")->fetch_assoc()['c'] ?? 0;
$cobros_hoy   = $conexion->query("SELECT IFNULL(SUM(monto_pagado),0) total FROM pagos WHERE DATE(fecha_pago)=CURDATE()")->fetch_assoc()['total'] ?? 0;

/* ── CONSULTA CON FILTROS ── */
$where = "WHERE 1";
if ($buscar) {
    $b = $conexion->real_escape_string($buscar);
    $where .= " AND (e.nombre LIKE '%$b%' OR e.apellido LIKE '%$b%' OR e.ruta_tipo LIKE '%$b%' OR e.telefono LIKE '%$b%')";
}
if ($filtro_rol) {
    $fr = $conexion->real_escape_string($filtro_rol);
    $where .= " AND e.rol='$fr'";
}
if ($filtro_est) {
    $fe = $conexion->real_escape_string($filtro_est);
    $where .= " AND e.estatus='$fe'";
}

$empleados_q = $conexion->query("
    SELECT
        e.id_empleado, e.nombre, e.apellido, e.rol, e.estatus, e.ruta_tipo, e.telefono,
        (SELECT COUNT(*) FROM clientes c WHERE c.id_asesor=e.id_empleado) AS total_clientes,
        (SELECT COUNT(*) FROM prestamos p INNER JOIN clientes c ON p.id_cliente=c.id_cliente
         WHERE c.id_asesor=e.id_empleado AND p.estado='ACTIVO') AS prestamos_activos,
        (SELECT IFNULL(SUM(pa.monto_pagado),0) FROM pagos pa
         INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo
         WHERE pr.id_empleado=e.id_empleado AND DATE(pa.fecha_pago)=CURDATE()) AS cobrado_hoy,
        (SELECT IFNULL(SUM(pa.monto_pagado),0) FROM pagos pa
         INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo
         WHERE pr.id_empleado=e.id_empleado
         AND YEARWEEK(pa.fecha_pago,1)=YEARWEEK(CURDATE(),1)) AS cobrado_semana
    FROM empleados e
    $where
    ORDER BY e.estatus DESC, e.rol, e.apellido, e.nombre
");

$filas = [];
$max_semana = 1;
while ($e = $empleados_q->fetch_assoc()) {
    $filas[] = $e;
    if (floatval($e['cobrado_semana']) > $max_semana) $max_semana = floatval($e['cobrado_semana']);
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Empleados — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; display:flex; flex-direction:column; }
.main-content { padding:24px 28px 80px; flex:1; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06); text-decoration:none;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }
.btn-nuevo {
    display:inline-flex; align-items:center; gap:7px;
    padding:9px 18px; border-radius:10px; font-size:.84rem; font-weight:700;
    background:#16a34a; color:white; text-decoration:none; transition:all .15s;
    box-shadow:0 2px 8px rgba(22,163,74,.3);
}
.btn-nuevo:hover { background:#15803d; }

/* ── KPI GRID ── */
.kpi-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:12px; margin-bottom:20px; }
.kpi-card {
    background:white; border-radius:14px; padding:16px 18px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
    border-left:4px solid transparent; position:relative; overflow:hidden;
    transition:transform .2s, box-shadow .2s;
}
.kpi-card:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,.08); }
.kpi-card.oscuro  { border-left-color:#0f172a; }
.kpi-card.verde   { border-left-color:#16a34a; }
.kpi-card.rojo    { border-left-color:#dc2626; }
.kpi-card.azul    { border-left-color:#2563eb; }
.kpi-card.naranja { border-left-color:#ea580c; }
.kpi-lbl { font-size:.67rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:5px; }
.kpi-val { font-size:1.6rem; font-weight:800; line-height:1; }
.kpi-card.oscuro  .kpi-val { color:#0f172a; }
.kpi-card.verde   .kpi-val { color:#16a34a; }
.kpi-card.rojo    .kpi-val { color:#dc2626; }
.kpi-card.azul    .kpi-val { color:#2563eb; }
.kpi-card.naranja .kpi-val { color:#ea580c; font-size:1.2rem; }
.kpi-bg { position:absolute; right:14px; top:12px; font-size:1.8rem; opacity:.07; }
.kpi-sub { font-size:.72rem; color:#94a3b8; margin-top:4px; }

/* ── BUSCADOR Y FILTROS ── */
.filtros-card {
    background:white; border-radius:14px; padding:14px 18px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
    margin-bottom:18px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;
}
.f-search {
    flex:1; min-width:200px; padding:9px 14px;
    border:1.5px solid #e2e8f0; border-radius:9px;
    font-size:.84rem; font-family:'Inter',sans-serif; color:#1e293b;
    outline:none; background:#f8fafc; transition:border-color .15s;
}
.f-search:focus { border-color:#2563eb; background:white; }
.f-select {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:9px 12px;
    font-size:.84rem; font-family:'Inter',sans-serif; color:#1e293b;
    background:#f8fafc; outline:none; cursor:pointer; transition:border-color .15s;
}
.f-select:focus { border-color:#2563eb; background:white; }
.btn-buscar {
    display:inline-flex; align-items:center; gap:6px;
    padding:9px 16px; border-radius:9px; font-size:.82rem; font-weight:700;
    background:#0f172a; color:white; border:none; cursor:pointer;
    font-family:'Inter',sans-serif; transition:all .15s;
}
.btn-buscar:hover { background:#1e293b; }
.btn-limpiar {
    display:inline-flex; align-items:center; gap:5px;
    padding:9px 14px; border-radius:9px; font-size:.82rem; font-weight:600;
    background:white; color:#64748b; border:1.5px solid #e2e8f0; text-decoration:none; transition:all .15s;
}
.btn-limpiar:hover { border-color:#ef4444; color:#ef4444; }

/* ── TABLA ── */
.tabla-wrap {
    background:white; border-radius:14px; overflow:hidden;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
}
.tabla-header {
    padding:14px 18px; background:#f8fafc; border-bottom:1px solid #f1f5f9;
    display:flex; justify-content:space-between; align-items:center;
}
.tabla-header strong { font-size:.84rem; color:#475569; }
.tabla-wrap table { width:100%; border-collapse:collapse; }
.tabla-wrap thead th {
    background:#0f172a; color:white; padding:12px 14px;
    font-size:.72rem; font-weight:700; text-align:left;
    text-transform:uppercase; letter-spacing:.05em; white-space:nowrap;
}
.tabla-wrap tbody td { padding:12px 14px; border-bottom:1px solid #f1f5f9; font-size:.84rem; vertical-align:middle; }
.tabla-wrap tbody tr:last-child td { border-bottom:none; }
.tabla-wrap tbody tr:hover td { background:#f8fafc; }

/* Empleado info */
.emp-info { display:flex; align-items:center; gap:10px; }
.emp-avatar {
    width:40px; height:40px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:.88rem; font-weight:800; color:white; flex-shrink:0;
}
.av-gerente    { background:linear-gradient(135deg,#7c3aed,#5b21b6); }
.av-supervisor { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.av-asesor     { background:linear-gradient(135deg,#16a34a,#15803d); }
.av-inactivo   { background:linear-gradient(135deg,#94a3b8,#64748b); }
.emp-nombre { font-weight:700; color:#0f172a; font-size:.88rem; }
.emp-tel    { font-size:.72rem; color:#94a3b8; margin-top:2px; }

/* Badges */
.badge {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 10px; border-radius:20px; font-size:.72rem; font-weight:700; white-space:nowrap;
}
.badge-gerente    { background:#f3e8ff; color:#7c3aed; }
.badge-supervisor { background:#dbeafe; color:#1d4ed8; }
.badge-asesor     { background:#dcfce7; color:#16a34a; }
.badge-activo     { background:#dcfce7; color:#15803d; }
.badge-inactivo   { background:#fee2e2; color:#dc2626; }

/* Mini metric */
.mini-metric { display:flex; flex-direction:column; align-items:center; text-align:center; }
.mm-val { font-size:1rem; font-weight:800; color:#0f172a; }
.mm-lbl { font-size:.65rem; color:#94a3b8; text-transform:uppercase; letter-spacing:.03em; }

/* Perf bar */
.perf-wrap { min-width:90px; }
.perf-lbl  { font-size:.8rem; font-weight:700; color:#0f172a; }
.perf-bar  { height:5px; border-radius:3px; background:#f1f5f9; overflow:hidden; margin-top:3px; }
.perf-fill { height:100%; border-radius:3px; transition:width .4s; }

/* Acciones */
.acciones { display:flex; gap:6px; }
.btn-accion {
    display:inline-flex; align-items:center; justify-content:center;
    width:32px; height:32px; border-radius:8px; font-size:.9rem;
    text-decoration:none; border:none; cursor:pointer; transition:all .15s;
}
.btn-accion:hover { transform:scale(1.1); }
.btn-editar    { background:#eff6ff; color:#2563eb; }
.btn-desact    { background:#fff1f2; color:#dc2626; }
.btn-act-on    { background:#f0fdf4; color:#16a34a; }
.btn-historial { background:#f5f3ff; color:#7c3aed; }

/* Sin resultados */
.sin-resultados { text-align:center; padding:50px 24px; color:#94a3b8; }
.sin-resultados i { font-size:2.5rem; display:block; margin-bottom:10px; opacity:.4; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .kpi-card, [data-theme="dark"] .filtros-card,
[data-theme="dark"] .tabla-wrap { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .kpi-lbl, [data-theme="dark"] .kpi-sub { color:#64748b; }
[data-theme="dark"] .kpi-card.oscuro .kpi-val { color:#e2e8f0; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; color:#94a3b8; border-color:#334155; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .f-search, [data-theme="dark"] .f-select { background:#0f172a; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .btn-limpiar { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .tabla-header { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .tabla-header strong { color:#64748b; }
[data-theme="dark"] .tabla-wrap tbody td { border-color:#334155; }
[data-theme="dark"] .tabla-wrap tbody tr:hover td { background:#0f172a; }
[data-theme="dark"] .emp-nombre { color:#f8fafc; }
[data-theme="dark"] .mm-val { color:#f8fafc; }
[data-theme="dark"] .perf-lbl { color:#e2e8f0; }
[data-theme="dark"] .perf-bar { background:#334155; }
[data-theme="dark"] .btn-editar    { background:#1e3a6e; color:#93c5fd; }
[data-theme="dark"] .btn-desact    { background:#3b0a0a; color:#fca5a5; }
[data-theme="dark"] .btn-act-on    { background:#0a2a1a; color:#86efac; }
[data-theme="dark"] .btn-historial { background:#2e1b5e; color:#c4b5fd; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .kpi-grid { grid-template-columns:repeat(2,1fr); }
}
@media (max-width:700px) {
    .tabla-wrap { overflow-x:auto; }
    .tabla-wrap table { min-width:700px; }
}
</style>
</head>
<body>
<div class="app">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
                <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Clientes Atrasados</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>

        <div class="sb-section">Administración</div>
        <a href="empleados.php" class="active"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="nuevo_empleado.php" class="special"><i class="bi bi-person-plus"></i> Nuevo Empleado</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">         
               <a href="index.php" class="btn-icon-top" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-person-badge" style="color:#2563eb;"></i> Empleados</h1>
                <p>Gestión del equipo &nbsp;·&nbsp; <?= date('d/m/Y') ?></p>
            </div>
        </div>
        <div class="topbar-right">
            <a href="nuevo_empleado.php" class="btn-nuevo">
                <i class="bi bi-person-plus-fill"></i> Nuevo Empleado
            </a>
            <button class="btn-icon-top" id="btnTema" title="Cambiar tema" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid">
        <div class="kpi-card oscuro">
            <i class="bi bi-people kpi-bg"></i>
            <div class="kpi-lbl">Total empleados</div>
            <div class="kpi-val"><?= $total_emp ?></div>
            <div class="kpi-sub"><?= $inactivos ?> inactivo<?= $inactivos != 1 ? 's' : '' ?></div>
        </div>
        <div class="kpi-card verde">
            <i class="bi bi-person-check kpi-bg"></i>
            <div class="kpi-lbl">Activos</div>
            <div class="kpi-val"><?= $activos ?></div>
            <div class="kpi-sub">en operación</div>
        </div>
        <div class="kpi-card rojo">
            <i class="bi bi-person-x kpi-bg"></i>
            <div class="kpi-lbl">Inactivos</div>
            <div class="kpi-val"><?= $inactivos ?></div>
            <div class="kpi-sub">fuera de operación</div>
        </div>
        <div class="kpi-card azul">
            <i class="bi bi-person-workspace kpi-bg"></i>
            <div class="kpi-lbl">Asesores</div>
            <div class="kpi-val"><?= $asesores ?></div>
            <div class="kpi-sub"><?= $supervisores ?> supervisor<?= $supervisores != 1 ? 'es' : '' ?></div>
        </div>
        <div class="kpi-card naranja">
            <i class="bi bi-cash-coin kpi-bg"></i>
            <div class="kpi-lbl">Cobrado hoy</div>
            <div class="kpi-val">$<?= number_format($cobros_hoy, 0) ?></div>
            <div class="kpi-sub">todos los asesores</div>
        </div>
    </div>

    <!-- FILTROS -->
    <form method="GET" class="filtros-card">
        <i class="bi bi-search" style="color:#94a3b8;font-size:.9rem;"></i>
        <input type="text" name="q" class="f-search"
               value="<?= htmlspecialchars($buscar) ?>"
               placeholder="Buscar por nombre, ruta o teléfono...">

        <select name="rol" class="f-select">
            <option value="">Todos los roles</option>
            <option value="ASESOR"      <?= $filtro_rol === 'ASESOR'      ? 'selected' : '' ?>>Asesor</option>
            <option value="SUPERVISOR"  <?= $filtro_rol === 'SUPERVISOR'  ? 'selected' : '' ?>>Supervisor</option>
            <option value="GERENTE"     <?= $filtro_rol === 'GERENTE'     ? 'selected' : '' ?>>Gerente</option>
        </select>

        <select name="estatus" class="f-select">
            <option value=""        <?= $filtro_est === ''        ? 'selected' : '' ?>>Todos</option>
            <option value="ACTIVO"  <?= $filtro_est === 'ACTIVO'  ? 'selected' : '' ?>>Solo activos</option>
            <option value="INACTIVO"<?= $filtro_est === 'INACTIVO'? 'selected' : '' ?>>Solo inactivos</option>
        </select>

        <button type="submit" class="btn-buscar">
            <i class="bi bi-funnel"></i> Filtrar
        </button>

        <?php if ($buscar || $filtro_rol || $filtro_est !== 'ACTIVO'): ?>
        <a href="empleados.php" class="btn-limpiar">
            <i class="bi bi-x-circle"></i> Limpiar
        </a>
        <?php endif; ?>
    </form>

    <!-- TABLA -->
    <div class="tabla-wrap">
        <div class="tabla-header">
            <strong><?= count($filas) ?> empleado<?= count($filas) != 1 ? 's' : '' ?> encontrado<?= count($filas) != 1 ? 's' : '' ?></strong>
            <span style="font-size:.78rem;color:#94a3b8;">
                <?php if ($buscar): ?>Búsqueda: "<?= htmlspecialchars($buscar) ?>"<?php endif; ?>
            </span>
        </div>

        <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>Empleado</th>
                    <th>Rol</th>
                    <th>Ruta / Zona</th>
                    <th style="text-align:center;">Clientes</th>
                    <th style="text-align:center;">Préstamos activos</th>
                    <th>Cobrado hoy</th>
                    <th>Rendimiento semanal</th>
                    <th>Estatus</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>

            <?php if (empty($filas)): ?>
            <tr>
                <td colspan="9">
                    <div class="sin-resultados">
                        <i class="bi bi-person-x"></i>
                        <p style="font-weight:600;margin-bottom:4px;">No se encontraron empleados</p>
                        <p style="font-size:.82rem;">Prueba con otros filtros o términos de búsqueda.</p>
                    </div>
                </td>
            </tr>
            <?php endif; ?>

            <?php foreach ($filas as $e):
                $iniciales  = strtoupper(mb_substr($e['nombre'],0,1) . mb_substr($e['apellido'],0,1));
                $activo     = $e['estatus'] === 'ACTIVO';
                $av_class   = $activo ? 'av-' . strtolower($e['rol']) : 'av-inactivo';
                $badge_rol  = 'badge-' . strtolower($e['rol']);
                $badge_est  = $activo ? 'badge-activo' : 'badge-inactivo';
                $cobrado_h  = floatval($e['cobrado_hoy']);
                $cobrado_s  = floatval($e['cobrado_semana']);
                $pct        = min(100, round($cobrado_s / $max_semana * 100));
                $bar_color  = $pct >= 70 ? '#16a34a' : ($pct >= 35 ? '#d97706' : '#ef4444');
                $rol_icon   = $e['rol'] === 'GERENTE' ? 'bi-star-fill' : ($e['rol'] === 'SUPERVISOR' ? 'bi-shield-fill' : 'bi-person-fill');
            ?>
            <tr>

                <td>
                    <div class="emp-info">
                        <div class="emp-avatar <?= $av_class ?>"><?= $iniciales ?></div>
                        <div>
                            <div class="emp-nombre"><?= htmlspecialchars($e['nombre'] . ' ' . $e['apellido']) ?></div>
                            <?php if ($e['telefono']): ?>
                            <div class="emp-tel">
                                <i class="bi bi-telephone" style="font-size:.65rem;"></i>
                                <?= htmlspecialchars($e['telefono']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </td>


                <td>
                    <span class="badge <?= $badge_rol ?>">
                        <i class="bi <?= $rol_icon ?>" style="font-size:.65rem;"></i>
                        <?= $e['rol'] ?>
                    </span>
                </td>


                <td style="color:#64748b;font-size:.82rem;">
                    <?php if ($e['ruta_tipo']): ?>
                    <i class="bi bi-geo-alt" style="font-size:.75rem;color:#94a3b8;"></i>
                    <?= htmlspecialchars($e['ruta_tipo']) ?>
                    <?php else: ?>
                    <span style="color:#cbd5e1;">—</span>
                    <?php endif; ?>
                </td>

                <td style="text-align:center;">
                    <div class="mini-metric">
                        <span class="mm-val"><?= $e['total_clientes'] ?></span>
                        <span class="mm-lbl">clientes</span>
                    </div>
                </td>

                <td style="text-align:center;">
                    <div class="mini-metric">
                        <span class="mm-val" style="color:<?= intval($e['prestamos_activos']) > 0 ? '#2563eb' : '#94a3b8' ?>">
                            <?= $e['prestamos_activos'] ?>
                        </span>
                        <span class="mm-lbl">activos</span>
                    </div>
                </td>


                <td>
                    <?php if ($cobrado_h > 0): ?>
                    <strong style="color:#16a34a;">$<?= number_format($cobrado_h, 2) ?></strong>
                    <?php else: ?>
                    <span style="color:#cbd5e1;">—</span>
                    <?php endif; ?>
                </td>


                <td>
                    <div class="perf-wrap">
                        <div class="perf-lbl">$<?= number_format($cobrado_s, 0) ?></div>
                        <div class="perf-bar">
                            <div class="perf-fill" style="width:<?= $pct ?>%; background:<?= $bar_color ?>;"></div>
                        </div>
                    </div>
                </td>


                <td>
                    <span class="badge <?= $badge_est ?>">
                        <i class="bi bi-<?= $activo ? 'check-circle-fill' : 'x-circle-fill' ?>" style="font-size:.65rem;"></i>
                        <?= $e['estatus'] ?>
                    </span>
                </td>

                <td>
                    <div class="acciones">
                        <a href="editar_empleado.php?id=<?= $e['id_empleado'] ?>"
                           class="btn-accion btn-editar" title="Editar empleado">
                            <i class="bi bi-pencil-fill"></i>
                        </a>
                        <a href="historial_cliente.php?id_empleado=<?= $e['id_empleado'] ?>"
                           class="btn-accion btn-historial" title="Ver historial">
                            <i class="bi bi-folder2-open"></i>
                        </a>
                        <?php if ($activo): ?>
                        <a href="estatus_empleado.php?id=<?= $e['id_empleado'] ?>&accion=desactivar"
                           class="btn-accion btn-desact" title="Desactivar"
                           onclick="return confirm('¿Desactivar a <?= htmlspecialchars(addslashes($e['nombre'])) ?>?')">
                            <i class="bi bi-person-dash-fill"></i>
                        </a>
                        <?php else: ?>
                        <a href="estatus_empleado.php?id=<?= $e['id_empleado'] ?>&accion=activar"
                           class="btn-accion btn-act-on" title="Activar"
                           onclick="return confirm('¿Activar a <?= htmlspecialchars(addslashes($e['nombre'])) ?>?')">
                            <i class="bi bi-person-check-fill"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>

            </tbody>
        </table>
        </div>
    </div>

</div>
</main>
</div>

<script>
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    const n = new Date();
    const pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);
</script>
</body>
</html>

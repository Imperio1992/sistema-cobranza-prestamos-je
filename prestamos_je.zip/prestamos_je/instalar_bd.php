<?php
include("conexion.php");

echo "<h2>Instalando base de datos...</h2>";

// TABLA caja_entrega
$sql1 = "CREATE TABLE IF NOT EXISTS caja_entrega (
    id_entrega INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado INT NOT NULL,
    fecha DATE NOT NULL,
    efectivo_nuevo DECIMAL(10,2) NOT NULL DEFAULT 0,
    banca_nueva DECIMAL(10,2) NOT NULL DEFAULT 0,
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unico_dia (id_empleado, fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conexion->query($sql1)) {
    echo "✅ Tabla caja_entrega creada correctamente<br>";
} else {
    echo "❌ Error: " . $conexion->error . "<br>";
}

// TABLA caja_gastos
$sql2 = "CREATE TABLE IF NOT EXISTS caja_gastos (
    id_gasto INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado INT NOT NULL,
    fecha DATE NOT NULL,
    tipo_gasto ENUM(
        'GASOLINA',
        'TIEMPO_AIRE',
        'REPARACION_MOTO',
        'ACCESORIO_MOTO',
        'SERVICIO_MOTO',
        'CONSUMO_GENERAL'
    ) NOT NULL DEFAULT 'CONSUMO_GENERAL',
    monto DECIMAL(10,2) NOT NULL DEFAULT 0,
    descripcion VARCHAR(200),
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conexion->query($sql2)) {
    echo "✅ Tabla caja_gastos creada correctamente<br>";
} else {
    echo "❌ Error: " . $conexion->error . "<br>";
}

// TABLA caja_corte
$sql3 = "CREATE TABLE IF NOT EXISTS caja_corte (
    id_corte INT AUTO_INCREMENT PRIMARY KEY,
    id_empleado INT NOT NULL,
    fecha DATE NOT NULL,
    cobrado DECIMAL(10,2) DEFAULT 0,
    efectivo_llevado DECIMAL(10,2) DEFAULT 0,
    banca_llevada DECIMAL(10,2) DEFAULT 0,
    prestamos_dia DECIMAL(10,2) DEFAULT 0,
    banca_actual DECIMAL(10,2) DEFAULT 0,
    total_gastos DECIMAL(10,2) DEFAULT 0,
    resultado DECIMAL(10,2) DEFAULT 0,
    notas TEXT,
    creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unico_corte (id_empleado, fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conexion->query($sql3)) {
    echo "✅ Tabla caja_corte creada correctamente<br>";
} else {
    echo "❌ Error: " . $conexion->error . "<br>";
}

echo "<br><strong>🎉 Instalación terminada</strong>";
?>
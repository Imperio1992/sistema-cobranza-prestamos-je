<?php
// SOLO GERENTE
$roles_permitidos = ['GERENTE'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

if (!isset($_GET['id'])) { header("Location: empleados.php"); exit; }

$id_empleado = (int)$_GET['id'];
$rol_actual  = $_SESSION['rol'];
$user        = $_SESSION['usuario'] ?? 'Usuario';

/* ── Datos del empleado ── */
$stmt = $conexion->prepare("SELECT * FROM empleados WHERE id_empleado = ?");
$stmt->bind_param("i", $id_empleado);
$stmt->execute();
$empleado = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$empleado) { header("Location: empleados.php"); exit; }

/* ── Usuario vinculado ── */
$stmt2 = $conexion->prepare("SELECT * FROM usuarios WHERE rol = ? LIMIT 1");
$stmt2->bind_param("s", $empleado['rol']);
$stmt2->execute();
$usr = $stmt2->get_result()->fetch_assoc();
$stmt2->close();

$errores = [];
$exito   = false;

/* ── GUARDAR CAMBIOS ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre    = trim($_POST['nombre']    ?? '');
    $apellido  = trim($_POST['apellido']  ?? '');
    $telefono  = trim($_POST['telefono']  ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $rol       = $_POST['rol']            ?? '';
    $ruta_tipo = $_POST['ruta_tipo']      ?? '';
    $usuario   = trim($_POST['usuario']   ?? '');
    $password  = $_POST['password']       ?? '';

    if (!$nombre)  $errores[] = 'El nombre es obligatorio.';
    if (!$apellido) $errores[] = 'El apellido es obligatorio.';
    if (!in_array($rol, ['GERENTE','SUPERVISOR','ASESOR'])) $errores[] = 'Rol no válido.';
    if (!$usuario) $errores[] = 'El usuario es obligatorio.';
    if ($password && strlen($password) < 6) $errores[] = 'La contraseña debe tener al menos 6 caracteres.';

    if (empty($errores)) {
        $upd_emp = $conexion->prepare("
            UPDATE empleados SET nombre=?, apellido=?, telefono=?, direccion=?, rol=?, ruta_tipo=?
            WHERE id_empleado=?
        ");
        $upd_emp->bind_param("ssssssi", $nombre, $apellido, $telefono, $direccion, $rol, $ruta_tipo, $id_empleado);
        $upd_emp->execute();
        $upd_emp->close();

        if (!empty($password)) {
            $hash    = password_hash($password, PASSWORD_DEFAULT);
            $upd_usr = $conexion->prepare("UPDATE usuarios SET usuario=?, password=?, rol=? WHERE usuario=?");
            $upd_usr->bind_param("ssss", $usuario, $hash, $rol, $usr['usuario']);
        } else {
            $upd_usr = $conexion->prepare("UPDATE usuarios SET usuario=?, rol=? WHERE usuario=?");
            $upd_usr->bind_param("sss", $usuario, $rol, $usr['usuario']);
        }
        $upd_usr->execute();
        $upd_usr->close();

        $stmt3 = $conexion->prepare("SELECT * FROM empleados WHERE id_empleado=?");
        $stmt3->bind_param("i", $id_empleado);
        $stmt3->execute();
        $empleado = $stmt3->get_result()->fetch_assoc();
        $stmt3->close();

        $exito = true;
    }
}

/* ── Avatar ── */
$iniciales = strtoupper(mb_substr($empleado['nombre'],0,1) . mb_substr($empleado['apellido'],0,1));
$av_clases = ['ASESOR'=>'av-asesor','SUPERVISOR'=>'av-supervisor','GERENTE'=>'av-gerente'];
$av_clase  = $av_clases[$empleado['rol']] ?? 'av-default';
$activo    = ($empleado['estatus'] ?? 'ACTIVO') === 'ACTIVO';
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Editar Empleado — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover   { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active  { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; display:flex; flex-direction:column; }
.main-content { padding:24px 28px 80px; flex:1; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:18px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-back {
    display:inline-flex; align-items:center; gap:6px;
    padding:8px 16px; border-radius:10px; font-size:.82rem; font-weight:600;
    background:white; color:#64748b; border:1.5px solid #e2e8f0; text-decoration:none; transition:all .15s;
}
.btn-back:hover { border-color:#0f172a; color:#0f172a; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTA RESTRICCION ── */
.warning-banner {
    display:flex; align-items:center; gap:10px;
    padding:11px 16px; background:#fffbeb; border:1.5px solid #fde68a;
    border-radius:10px; margin-bottom:18px; font-size:.8rem; color:#92400e; font-weight:500;
}

/* ── ALERTAS ── */
.alerta {
    border-radius:12px; padding:14px 18px; margin-bottom:18px;
    display:flex; align-items:flex-start; gap:12px; font-size:.85rem;
}
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }
.alerta.exito { background:#f0fdf4; border:1.5px solid #bbf7d0; color:#14532d; }
.alerta i { font-size:1.1rem; flex-shrink:0; margin-top:1px; }
.alerta ul { margin:5px 0 0; padding-left:16px; }
.alerta ul li { margin-bottom:3px; }
.alerta-links { margin-top:8px; }
.alerta-links a { font-size:.8rem; font-weight:700; text-decoration:none; color:#15803d; }

/* ── LAYOUT ── */
.form-layout { display:grid; grid-template-columns:1fr 300px; gap:20px; align-items:start; }

/* ── CARD ── */
.card {
    background:white; border-radius:14px; padding:20px 22px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-bottom:16px;
}
.card h3 {
    font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em;
    color:#64748b; margin-bottom:16px; display:flex; align-items:center; gap:7px;
}
.card-dark { background:#0f172a; border-radius:14px; padding:20px 22px; margin-bottom:16px; }
.card-dark h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#475569; margin-bottom:16px; display:flex; align-items:center; gap:7px; }

/* ── PERFIL ── */
.perfil-wrap {
    display:flex; align-items:center; gap:16px;
    padding:14px 16px; background:#f8fafc;
    border-radius:12px; border:1.5px solid #e2e8f0;
}
.avatar {
    width:56px; height:56px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:1.15rem; font-weight:800; color:white; flex-shrink:0; transition:all .2s;
}
.av-asesor     { background:linear-gradient(135deg,#16a34a,#15803d); }
.av-supervisor { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.av-gerente    { background:linear-gradient(135deg,#7c3aed,#5b21b6); }
.av-default    { background:linear-gradient(135deg,#94a3b8,#64748b); }
.perfil-nombre { font-weight:800; font-size:1rem; color:#0f172a; }
.perfil-id     { font-size:.7rem; color:#94a3b8; margin-top:4px; }
.badges-row    { display:flex; align-items:center; gap:6px; flex-wrap:wrap; margin-top:5px; }

/* Badges */
.badge {
    display:inline-flex; align-items:center; gap:3px;
    padding:3px 9px; border-radius:20px; font-size:.7rem; font-weight:700;
}
.badge-gerente    { background:#f3e8ff; color:#7c3aed; }
.badge-supervisor { background:#dbeafe; color:#1d4ed8; }
.badge-asesor     { background:#dcfce7; color:#16a34a; }
.badge-activo     { background:#dcfce7; color:#15803d; }
.badge-inactivo   { background:#fee2e2; color:#dc2626; }
.badge-default    { background:#f1f5f9; color:#64748b; }

/* ── ROL SELECTOR ── */
.rol-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.rol-card {
    display:flex; flex-direction:column; align-items:center; gap:5px;
    padding:14px 8px; border:2px solid #e2e8f0; border-radius:12px;
    cursor:pointer; transition:all .15s; text-align:center;
}
.rol-card:has(input:checked).r-asesor     { border-color:#16a34a; background:#f0fdf4; }
.rol-card:has(input:checked).r-supervisor { border-color:#2563eb; background:#eff6ff; }
.rol-card:has(input:checked).r-gerente    { border-color:#7c3aed; background:#faf5ff; }
.rol-card:hover { border-color:#94a3b8; }
.rol-card input { display:none; }
.rol-ico-w  { font-size:1.4rem; line-height:1; }
.rol-title  { font-size:.82rem; font-weight:700; color:#1e293b; }
.rol-desc   { font-size:.7rem; color:#94a3b8; line-height:1.35; }

/* ── RUTA SELECTOR ── */
.ruta-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:4px; }
.ruta-card {
    display:flex; flex-direction:column; align-items:center; gap:4px;
    padding:14px 10px; border:2px solid #e2e8f0; border-radius:12px;
    cursor:pointer; transition:all .15s; text-align:center;
}
.ruta-card:has(input:checked) { border-color:#0d9488; background:#f0fdfa; }
.ruta-card:hover { border-color:#94a3b8; }
.ruta-card input { display:none; }
.ruta-ico   { font-size:1.3rem; line-height:1; }
.ruta-title { font-size:.82rem; font-weight:700; color:#1e293b; }
.ruta-desc  { font-size:.7rem; color:#94a3b8; line-height:1.35; }

/* ── CAMPOS ── */
.field { margin-bottom:15px; }
.field:last-child { margin-bottom:0; }
.field label {
    display:block; font-size:.72rem; font-weight:700;
    color:#374151; margin-bottom:5px; text-transform:uppercase; letter-spacing:.04em;
}
.field label .opc { font-weight:400; color:#94a3b8; text-transform:none; letter-spacing:0; }
.inp-wrap { position:relative; }
.field input[type=text],
.field input[type=password],
.field input[type=tel] {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.88rem; color:#1e293b;
    outline:none; transition:border-color .15s, box-shadow .15s;
    background:#f8fafc; font-family:'Inter',sans-serif;
}
.field input:focus { border-color:#2563eb; background:white; box-shadow:0 0 0 3px rgba(37,99,235,.08); }
.field .hint { margin-top:5px; font-size:.72rem; color:#94a3b8; display:flex; align-items:center; gap:4px; }
.input-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.divider   { height:1px; background:#f1f5f9; margin:16px 0; }
.pass-eye {
    position:absolute; right:12px; top:50%; transform:translateY(-50%);
    background:none; border:none; cursor:pointer;
    font-size:.9rem; color:#94a3b8; padding:0; line-height:1;
    display:flex; align-items:center;
}
.pass-eye:hover { color:#475569; }

/* Fortaleza */
.strength-bar  { height:4px; background:#e2e8f0; border-radius:2px; margin-top:7px; overflow:hidden; }
.strength-fill { height:100%; border-radius:2px; width:0; transition:all .3s; }
.strength-txt  { font-size:.72rem; font-weight:700; margin-top:4px; color:#94a3b8; }

/* ── SUBMIT ── */
.btn-submit {
    width:100%; padding:14px; background:#d97706; color:white;
    border:none; border-radius:12px; font-size:.95rem; font-weight:700;
    cursor:pointer; font-family:'Inter',sans-serif; transition:background .15s; margin-top:4px;
    display:flex; align-items:center; justify-content:center; gap:8px;
}
.btn-submit:hover { background:#b45309; }
.cancelar-link { text-align:center; margin-top:10px; }
.cancelar-link a { color:#94a3b8; font-size:.8rem; text-decoration:none; }
.cancelar-link a:hover { color:#64748b; }

/* ── INFO DARK ── */
.info-item { display:flex; align-items:flex-start; gap:11px; padding:11px 0; border-bottom:1px solid #1e293b; }
.info-item:last-child { border-bottom:none; padding-bottom:0; }
.ii-ico   { font-size:1rem; flex-shrink:0; margin-top:2px; }
.ii-title { font-weight:700; color:#f1f5f9; font-size:.82rem; margin-bottom:2px; }
.ii-desc  { color:#64748b; font-size:.75rem; line-height:1.4; }

/* ── ACCIONES ── */
.accion-links { display:flex; flex-direction:column; gap:8px; }
.btn-accion-toggle {
    display:flex; align-items:center; gap:8px;
    padding:11px 14px; border-radius:10px;
    text-decoration:none; font-size:.82rem; font-weight:700; transition:all .15s;
}
.btn-accion-dark {
    display:flex; align-items:center; justify-content:center; gap:7px;
    padding:10px 14px; border-radius:10px; background:#0f172a;
    color:white; font-size:.82rem; font-weight:700; text-decoration:none; transition:background .15s;
}
.btn-accion-dark:hover { background:#1e293b; }
.btn-accion-light {
    display:flex; align-items:center; gap:7px;
    padding:10px 14px; border-radius:10px; background:#f8fafc;
    border:1.5px solid #e2e8f0; color:#374151; font-size:.82rem; font-weight:600;
    text-decoration:none; transition:background .15s;
}
.btn-accion-light:hover { background:#f1f5f9; }

/* Aviso rol */
.aviso-rol {
    padding:12px 14px; background:#fffbeb;
    border:1.5px solid #fde68a; border-radius:10px;
    font-size:.75rem; color:#92400e; line-height:1.5;
}

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .card { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .card h3 { color:#64748b; }
[data-theme="dark"] .card-dark { background:#020617; }
[data-theme="dark"] .perfil-wrap { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .perfil-nombre { color:#f8fafc; }
[data-theme="dark"] .field input { background:#0f172a; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .field input:focus { background:#1e293b; border-color:#2563eb; }
[data-theme="dark"] .field label { color:#94a3b8; }
[data-theme="dark"] .rol-card  { border-color:#334155; }
[data-theme="dark"] .ruta-card { border-color:#334155; }
[data-theme="dark"] .rol-title, [data-theme="dark"] .ruta-title { color:#e2e8f0; }
[data-theme="dark"] .divider   { background:#334155; }
[data-theme="dark"] .strength-bar { background:#334155; }
[data-theme="dark"] .btn-back  { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; color:#94a3b8; border-color:#334155; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .alerta.error { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }
[data-theme="dark"] .alerta.exito { background:#071f12; border-color:#14532d; color:#86efac; }
[data-theme="dark"] .warning-banner { background:#1c1600; border-color:#92400e; color:#fde68a; }
[data-theme="dark"] .aviso-rol { background:#1c1600; border-color:#92400e; color:#fde68a; }
[data-theme="dark"] .btn-accion-light { background:#1e293b; border-color:#334155; color:#94a3b8; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .form-layout { grid-template-columns:1fr; }
    .input-row  { grid-template-columns:1fr; }
    .rol-grid   { grid-template-columns:repeat(3,1fr); }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Clientes Atrasados</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>

        <div class="sb-section">Administración</div>
        <a href="empleados.php" class="active"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="nuevo_empleado.php" class="special"><i class="bi bi-person-plus"></i> Nuevo Empleado</a>
        <a href="estatus_empleado.php"><i class="bi bi-arrow-left-right"></i> Estatus</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="bi bi-pencil-square" style="color:#d97706;"></i> Editar Empleado</h1>
            <p>Modificando: <strong><?= htmlspecialchars($empleado['nombre'] . ' ' . $empleado['apellido']) ?></strong> &nbsp;·&nbsp; Solo Gerente</p>
        </div>
        <div class="topbar-right">
            <a href="empleados.php" class="btn-back">
                <i class="bi bi-arrow-left"></i> Volver
            </a>
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- BANNER RESTRICCIÓN -->
    <div class="warning-banner">
        <i class="bi bi-shield-lock-fill" style="font-size:1rem;flex-shrink:0;"></i>
        <span>Esta sección es exclusiva del <strong>Gerente</strong>. Los cambios afectan el acceso al sistema del empleado.</span>
    </div>

    <!-- ALERTAS -->
    <?php if ($exito): ?>
    <div class="alerta exito">
        <i class="bi bi-check-circle-fill"></i>
        <div>
            <strong>¡Cambios guardados correctamente!</strong>
            <p style="margin:4px 0 6px;font-size:.78rem;">La información del empleado ha sido actualizada.</p>
            <div class="alerta-links">
                <a href="empleados.php"><i class="bi bi-people-fill"></i> Ver lista de empleados</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($errores)): ?>
    <div class="alerta error">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div>
            <strong>Revisa los siguientes campos:</strong>
            <ul>
                <?php foreach ($errores as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <form method="POST" onsubmit="return validarForm()">
    <div class="form-layout">

        <!-- ── COLUMNA PRINCIPAL ── -->
        <div>

            <!-- Perfil actual -->
            <div class="card">
                <h3><i class="bi bi-person-circle"></i> Perfil actual</h3>
                <div class="perfil-wrap">
                    <div class="avatar <?= $av_clase ?>" id="avPreview"><?= $iniciales ?></div>
                    <div style="flex:1;min-width:0;">
                        <div class="perfil-nombre" id="prevNombre">
                            <?= htmlspecialchars($empleado['nombre'] . ' ' . $empleado['apellido']) ?>
                        </div>
                        <div class="badges-row">
                            <span class="badge badge-<?= strtolower($empleado['rol']) ?>" id="prevRol">
                                <?= $empleado['rol'] ?>
                            </span>
                            <span class="badge badge-<?= strtolower($empleado['estatus'] ?? 'activo') ?>">
                                <i class="bi bi-<?= $activo ? 'check-circle-fill' : 'x-circle-fill' ?>" style="font-size:.6rem;"></i>
                                <?= $empleado['estatus'] ?? 'ACTIVO' ?>
                            </span>
                        </div>
                        <div class="perfil-id">
                            <i class="bi bi-hash" style="font-size:.65rem;"></i><?= $id_empleado ?>
                            &nbsp;·&nbsp;
                            <i class="bi bi-calendar3" style="font-size:.65rem;"></i>
                            <?= date('d/m/Y', strtotime($empleado['fecha_ingreso'] ?? 'now')) ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rol -->
            <div class="card">
                <h3><i class="bi bi-person-gear"></i> Rol del empleado</h3>
                <div class="rol-grid">
                    <label class="rol-card r-asesor" onclick="updateAvatar()">
                        <input type="radio" name="rol" value="ASESOR"
                               <?= $empleado['rol'] === 'ASESOR' ? 'checked' : '' ?>>
                        <div class="rol-ico-w"><i class="bi bi-person-workspace" style="color:#16a34a;font-size:1.3rem;"></i></div>
                        <div class="rol-title">Asesor</div>
                        <div class="rol-desc">Cobra en campo y gestiona clientes</div>
                    </label>
                    <label class="rol-card r-supervisor" onclick="updateAvatar()">
                        <input type="radio" name="rol" value="SUPERVISOR"
                               <?= $empleado['rol'] === 'SUPERVISOR' ? 'checked' : '' ?>>
                        <div class="rol-ico-w"><i class="bi bi-shield-fill-check" style="color:#2563eb;font-size:1.3rem;"></i></div>
                        <div class="rol-title">Supervisor</div>
                        <div class="rol-desc">Supervisa y aprueba operaciones</div>
                    </label>
                    <label class="rol-card r-gerente" onclick="updateAvatar()">
                        <input type="radio" name="rol" value="GERENTE"
                               <?= $empleado['rol'] === 'GERENTE' ? 'checked' : '' ?>>
                        <div class="rol-ico-w"><i class="bi bi-star-fill" style="color:#7c3aed;font-size:1.3rem;"></i></div>
                        <div class="rol-title">Gerente</div>
                        <div class="rol-desc">Acceso total al sistema</div>
                    </label>
                </div>
            </div>

            <!-- Datos personales -->
            <div class="card">
                <h3><i class="bi bi-person-lines-fill"></i> Datos personales</h3>

                <div class="input-row">
                    <div class="field">
                        <label>Nombre *</label>
                        <input type="text" name="nombre" id="inpNombre"
                               value="<?= htmlspecialchars($empleado['nombre']) ?>"
                               required oninput="updateAvatar()">
                    </div>
                    <div class="field">
                        <label>Apellido *</label>
                        <input type="text" name="apellido" id="inpApellido"
                               value="<?= htmlspecialchars($empleado['apellido']) ?>"
                               required oninput="updateAvatar()">
                    </div>
                </div>

                <div class="input-row">
                    <div class="field">
                        <label>Teléfono <span class="opc">(opcional)</span></label>
                        <input type="tel" name="telefono"
                               value="<?= htmlspecialchars($empleado['telefono'] ?? '') ?>"
                               placeholder="Ej: 6441234567" maxlength="15">
                    </div>
                    <div class="field">
                        <label>Dirección <span class="opc">(opcional)</span></label>
                        <input type="text" name="direccion"
                               value="<?= htmlspecialchars($empleado['direccion'] ?? '') ?>"
                               placeholder="Ej: Calle Juárez 123">
                    </div>
                </div>

                <div class="field" style="margin-top:4px;">
                    <label>Tipo de ruta de cobranza</label>
                    <div class="ruta-grid">
                        <label class="ruta-card">
                            <input type="radio" name="ruta_tipo" value="DIARIO"
                                   <?= ($empleado['ruta_tipo'] ?? '') === 'DIARIO' ? 'checked' : '' ?>>
                            <div class="ruta-ico"><i class="bi bi-calendar-day" style="color:#0d9488;font-size:1.2rem;"></i></div>
                            <div class="ruta-title">Diario</div>
                            <div class="ruta-desc">Cobra todos los días en su ruta asignada</div>
                        </label>
                        <label class="ruta-card">
                            <input type="radio" name="ruta_tipo" value="SEMANAL"
                                   <?= ($empleado['ruta_tipo'] ?? '') === 'SEMANAL' ? 'checked' : '' ?>>
                            <div class="ruta-ico"><i class="bi bi-calendar-week" style="color:#0d9488;font-size:1.2rem;"></i></div>
                            <div class="ruta-title">Semanal</div>
                            <div class="ruta-desc">Cobra una vez por semana en su zona</div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Acceso al sistema -->
            <div class="card">
                <h3><i class="bi bi-lock"></i> Acceso al sistema</h3>

                <div class="field">
                    <label>Usuario *</label>
                    <input type="text" name="usuario"
                           value="<?= htmlspecialchars($usr['usuario'] ?? '') ?>"
                           placeholder="Ej: cgarcia" required autocomplete="off"
                           pattern="[a-zA-Z0-9_]+" title="Solo letras, números y guión bajo">
                    <p class="hint"><i class="bi bi-info-circle"></i> Solo letras, números y guión bajo. Sin espacios.</p>
                </div>

                <div class="divider"></div>

                <div class="field">
                    <label>Nueva contraseña <span class="opc">(dejar vacío para no cambiar)</span></label>
                    <div class="inp-wrap">
                        <input type="password" name="password" id="pass"
                               placeholder="Mínimo 6 caracteres si desea cambiarla"
                               oninput="checkPass()">
                        <button type="button" class="pass-eye" onclick="togglePass()" title="Mostrar/ocultar">
                            <i id="eyeIcon" class="bi bi-eye"></i>
                        </button>
                    </div>
                    <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
                    <div class="strength-txt" id="strengthTxt"></div>
                    <p class="hint"><i class="bi bi-lock-fill"></i> Si no escribes nada, la contraseña actual se conserva.</p>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <i class="bi bi-floppy-fill"></i> Guardar Cambios
            </button>

            <div class="cancelar-link">
                <a href="empleados.php">
                    <i class="bi bi-x"></i> Cancelar y volver
                </a>
            </div>

        </div>

        <!-- ── COLUMNA DERECHA ── -->
        <div>

            <!-- Info del empleado -->
            <div class="card-dark">
                <h3><i class="bi bi-bar-chart-line" style="color:#60a5fa;"></i> Información</h3>
                <div class="info-item">
                    <i class="bi bi-hash ii-ico" style="color:#60a5fa;"></i>
                    <div>
                        <div class="ii-title">ID del empleado</div>
                        <div class="ii-desc">#<?= $id_empleado ?></div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="bi bi-calendar3 ii-ico" style="color:#60a5fa;"></i>
                    <div>
                        <div class="ii-title">Fecha de ingreso</div>
                        <div class="ii-desc"><?= isset($empleado['fecha_ingreso']) ? date('d/m/Y', strtotime($empleado['fecha_ingreso'])) : '—' ?></div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="bi bi-circle-fill ii-ico" style="color:<?= $activo ? '#4ade80' : '#f87171' ?>;font-size:.7rem;margin-top:4px;"></i>
                    <div>
                        <div class="ii-title">Estatus actual</div>
                        <div class="ii-desc"><?= $empleado['estatus'] ?? 'ACTIVO' ?></div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="bi bi-geo-alt ii-ico" style="color:#60a5fa;"></i>
                    <div>
                        <div class="ii-title">Ruta actual</div>
                        <div class="ii-desc"><?= htmlspecialchars($empleado['ruta_tipo'] ?? '—') ?></div>
                    </div>
                </div>
            </div>

            <!-- Acciones rápidas -->
            <div class="card">
                <h3><i class="bi bi-lightning-charge"></i> Acciones rápidas</h3>
                <div class="accion-links">
                    <a href="estatus_empleado.php?id=<?= $id_empleado ?>&accion=<?= $activo ? 'desactivar' : 'activar' ?>"
                       class="btn-accion-toggle"
                       style="background:<?= $activo ? '#fff1f2' : '#f0fdf4' ?>;
                              border:1.5px solid <?= $activo ? '#fecdd3' : '#bbf7d0' ?>;
                              color:<?= $activo ? '#dc2626' : '#16a34a' ?>;"
                       onclick="return confirm('¿Confirmas cambiar el estatus de <?= htmlspecialchars(addslashes($empleado['nombre'])) ?>?')">
                        <i class="bi bi-<?= $activo ? 'person-dash-fill' : 'person-check-fill' ?>"></i>
                        <?= $activo ? 'Desactivar empleado' : 'Activar empleado' ?>
                    </a>
                    <a href="empleados.php" class="btn-accion-dark">
                        <i class="bi bi-people-fill"></i> Ver todos los empleados
                    </a>
                    <a href="nuevo_empleado.php" class="btn-accion-light">
                        <i class="bi bi-person-plus"></i> Registrar nuevo empleado
                    </a>
                </div>
            </div>

            <!-- Aviso rol -->
            <div class="aviso-rol">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <strong> Cambiar el rol</strong> afecta los permisos inmediatamente. El empleado verá las nuevas secciones en su próximo inicio de sesión.
            </div>

        </div>

    </div>
    </form>

</div><!-- /main-content -->
</main>
</div><!-- /app -->

<script>
/* ── TEMA ── */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), pad = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = pad(n.getHours())+':'+pad(n.getMinutes())+':'+pad(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── AVATAR EN TIEMPO REAL ── */
function updateAvatar() {
    var nombre   = document.getElementById('inpNombre').value.trim();
    var apellido = document.getElementById('inpApellido').value.trim();
    var rol      = document.querySelector('input[name="rol"]:checked');

    var av  = document.getElementById('avPreview');
    var ini = (nombre ? nombre[0] : '') + (apellido ? apellido[0] : '');
    av.textContent = ini.toUpperCase() || '?';

    av.className = 'avatar av-default';
    if (rol) {
        var clases = { ASESOR:'av-asesor', SUPERVISOR:'av-supervisor', GERENTE:'av-gerente' };
        av.className = 'avatar ' + (clases[rol.value] || 'av-default');
    }

    document.getElementById('prevNombre').textContent = (nombre || '—') + ' ' + (apellido || '');

    var badge = document.getElementById('prevRol');
    if (rol) {
        var clsBadge = { ASESOR:'badge badge-asesor', SUPERVISOR:'badge badge-supervisor', GERENTE:'badge badge-gerente' };
        badge.textContent = rol.value;
        badge.className = clsBadge[rol.value] || 'badge badge-default';
    }
}

/* ── FORTALEZA CONTRASEÑA ── */
function checkPass() {
    var p    = document.getElementById('pass').value;
    var fill = document.getElementById('strengthFill');
    var txt  = document.getElementById('strengthTxt');
    if (p.length === 0) { fill.style.width = '0'; txt.textContent = ''; return; }
    var score = 0;
    if (p.length >= 6)           score++;
    if (p.length >= 10)          score++;
    if (/[0-9]/.test(p))         score++;
    if (/[^a-zA-Z0-9]/.test(p)) score++;
    var colores = ['#dc2626','#ea580c','#eab308','#16a34a'];
    var labels  = ['Muy débil','Débil','Regular','Fuerte'];
    fill.style.width      = (score * 25) + '%';
    fill.style.background = colores[score - 1] || '#dc2626';
    txt.textContent       = labels[score - 1]  || 'Muy débil';
    txt.style.color       = colores[score - 1] || '#dc2626';
}

/* ── MOSTRAR/OCULTAR PASS ── */
function togglePass() {
    var input = document.getElementById('pass');
    var eye   = document.getElementById('eyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        eye.className = 'bi bi-eye-slash';
    } else {
        input.type = 'password';
        eye.className = 'bi bi-eye';
    }
}

/* ── VALIDACIÓN SUBMIT ── */
function validarForm() {
    var p = document.getElementById('pass').value;
    if (p && p.length < 6) {
        alert('Si ingresas una nueva contraseña, debe tener al menos 6 caracteres.');
        return false;
    }
    return true;
}
</script>
</body>
</html>

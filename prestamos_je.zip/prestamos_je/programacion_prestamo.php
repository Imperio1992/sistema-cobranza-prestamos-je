<?php
include("seguridad.php");
include("conexion.php");

$mes               = $_GET['mes']    ?? date('m');
$anio              = $_GET['anio']   ?? date('Y');
$asesor_seleccionado = $_GET['asesor'] ?? '';
$vista             = $_GET['vista']  ?? 'calendario';

$meses_es = [
    "01"=>"Enero","02"=>"Febrero","03"=>"Marzo","04"=>"Abril",
    "05"=>"Mayo","06"=>"Junio","07"=>"Julio","08"=>"Agosto",
    "09"=>"Septiembre","10"=>"Octubre","11"=>"Noviembre","12"=>"Diciembre"
];

$colores_asesores = [
    "#3b82f6","#10b981","#ef4444","#8b5cf6","#f59e0b",
    "#06b6d4","#84cc16","#ec4899","#f97316","#6366f1"
];

$hoy = date("Y-m-d");
$LIMITE_TOLERANCIA = 24;

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';

function esDomingo($fecha) {
    return date('N', strtotime($fecha)) == 7;
}
function ajustarNoDomingo($fecha) {
    if (esDomingo($fecha)) return date("Y-m-d", strtotime("$fecha +1 day"));
    return $fecha;
}
function contarDiasHabiles($fecha_inicio, $fecha_fin) {
    $inicio = new DateTime($fecha_inicio);
    $fin    = new DateTime($fecha_fin);
    $fin->modify('+1 day');
    $dias_habiles = 0;
    foreach (new DatePeriod($inicio, new DateInterval('P1D'), $fin) as $dia) {
        if ($dia->format('N') < 7) $dias_habiles++;
    }
    return $dias_habiles;
}
function calcularAbonosFaltantes($total_pagar, $total_pagado, $pago_diario) {
    if ($pago_diario <= 0) return 0;
    $restante = $total_pagar - $total_pagado;
    if ($restante <= 0) return 0;
    return (int) ceil($restante / $pago_diario);
}
function recalcularFechaRenovacion($fecha_base, $abonos_faltantes, $es_semanal = false) {
    if ($abonos_faltantes <= 0) return $fecha_base;
    $dias_extra = $es_semanal ? ($abonos_faltantes * 7) : $abonos_faltantes;
    return ajustarNoDomingo(date("Y-m-d", strtotime("$fecha_base + $dias_extra days")));
}
function calcularPrestamo($f, $total_pagado, $hoy, $LIMITE_TOLERANCIA) {
    $dias_habiles     = contarDiasHabiles($f['fecha_inicio'], $hoy);
    $fecha_base       = ajustarNoDomingo($f['fecha_final']);
    $abonos_faltantes = calcularAbonosFaltantes($f['total_pagar'], $total_pagado, $f['pago_diario']);
    $es_semanal       = ($f['pago_diario'] == 0);

    if (strtotime($fecha_base) < strtotime($hoy) && $abonos_faltantes > 0) {
        $fecha_prog = recalcularFechaRenovacion($fecha_base, $abonos_faltantes, $es_semanal);
    } else {
        $fecha_prog = $fecha_base;
    }

    if ($abonos_faltantes == 0) {
        $estatus = 'RENOVAR'; $estatus_clase = 'renovar';
    } elseif ($f['pago_diario'] > 0 && $total_pagado >= ($f['pago_diario'] * 20)) {
        $estatus = 'RENOVAR'; $estatus_clase = 'renovar';
    } elseif ($fecha_prog == $hoy) {
        $estatus = 'VENCE HOY'; $estatus_clase = 'hoy';
    } elseif ($dias_habiles <= $LIMITE_TOLERANCIA) {
        $estatus = "TOLERANCIA (D.H. $dias_habiles)"; $estatus_clase = 'tolerancia';
    } elseif ($abonos_faltantes > 0 && strtotime($fecha_prog) < strtotime($hoy)) {
        $estatus = "ATRASADO +{$abonos_faltantes}"; $estatus_clase = 'atraso';
    } else {
        $estatus = 'PROGRAMADO'; $estatus_clase = 'programado';
    }

    $dias_restantes = (int) ceil((strtotime($fecha_prog) - strtotime($hoy)) / 86400);

    return [
        'fecha_prog'       => $fecha_prog,
        'abonos_faltantes' => $abonos_faltantes,
        'dias_habiles'     => $dias_habiles,
        'dias_restantes'   => $dias_restantes,
        'estatus'          => $estatus,
        'estatus_clase'    => $estatus_clase,
        'saldo_restante'   => max(0, $f['total_pagar'] - $total_pagado),
    ];
}

$sql_base = "
    SELECT pr.id_prestamo, pr.id_cliente, pr.id_empleado, pr.pago_diario,
           pr.total_pagar, pr.fecha_inicio, pr.dias,
           c.nombre AS cliente_nombre, c.apellido AS cliente_apellido,
           e.nombre AS asesor_nombre, e.apellido AS asesor_apellido,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_final
    FROM prestamos pr
    INNER JOIN clientes  c ON pr.id_cliente  = c.id_cliente
    INNER JOIN empleados e ON pr.id_empleado = e.id_empleado
    WHERE pr.estado = 'ACTIVO'
";
if ($asesor_seleccionado != '') $sql_base .= " AND pr.id_empleado = " . (int)$asesor_seleccionado;
$sql_base .= " ORDER BY pr.fecha_inicio ASC";

$result_base = $conexion->query($sql_base);

$asesor_color_map = [];
$color_index      = 0;
$prestamos_data   = [];

while ($f = $result_base->fetch_assoc()) {
    $idp = $f['id_prestamo'];
    if (!isset($asesor_color_map[$f['id_empleado']])) {
        $asesor_color_map[$f['id_empleado']] = $colores_asesores[$color_index % count($colores_asesores)];
        $color_index++;
    }
    $pagos_q      = $conexion->query("SELECT IFNULL(SUM(monto_pagado),0) AS total_pagado FROM pagos WHERE id_prestamo = $idp");
    $total_pagado = (float) $pagos_q->fetch_assoc()['total_pagado'];
    $calc         = calcularPrestamo($f, $total_pagado, $hoy, $LIMITE_TOLERANCIA);
    $prestamos_data[] = array_merge($f, $calc, [
        'total_pagado' => $total_pagado,
        'color'        => $asesor_color_map[$f['id_empleado']],
    ]);
}

usort($prestamos_data, fn($a, $b) => strcmp($a['fecha_prog'], $b['fecha_prog']));

$fecha_min = $prestamos_data ? $prestamos_data[0]['fecha_inicio'] : $hoy;
$fecha_max = $prestamos_data ? max(array_column($prestamos_data, 'fecha_prog')) : $hoy;

$stats = ['total'=>0,'renovar'=>0,'programado'=>0,'atraso'=>0,'hoy'=>0,'monto'=>0];
foreach ($prestamos_data as $p) {
    if (substr($p['fecha_prog'], 0, 7) === "$anio-$mes") {
        $stats['total']++;
        $stats['monto'] += $p['total_pagar'];
        if ($p['estatus_clase'] === 'renovar')    $stats['renovar']++;
        if ($p['estatus_clase'] === 'programado') $stats['programado']++;
        if ($p['estatus_clase'] === 'atraso')     $stats['atraso']++;
        if ($p['estatus_clase'] === 'hoy')        $stats['hoy']++;
    }
}

$asesores_q   = $conexion->query("SELECT id_empleado, nombre, apellido FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
$asesores_list = [];
while ($a = $asesores_q->fetch_assoc()) $asesores_list[] = $a;

$mes_anterior  = date("m", strtotime("$anio-$mes-01 -1 month"));
$anio_anterior = date("Y", strtotime("$anio-$mes-01 -1 month"));
$mes_siguiente = date("m", strtotime("$anio-$mes-01 +1 month"));
$anio_siguiente= date("Y", strtotime("$anio-$mes-01 +1 month"));

if (isset($_GET['excel'])) {
    header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
    header("Content-Disposition: attachment; filename=Programacion_Prestamos_{$mes}_{$anio}.xls");
    $mes_nombre = $meses_es[$mes] ?? $mes;
    $fecha_hora = date("d/m/Y H:i:s");
    echo "<meta charset='UTF-8'>";
    echo "<table border='1' cellpadding='4' cellspacing='0'>";
    echo "<tr><td colspan='8' style='text-align:center;font-size:18px;font-weight:bold;background:#1e293b;color:white;padding:10px;'>PROGRAMACION DE PRESTAMOS</td></tr>";
    echo "<tr><td colspan='8' style='background:#f1f5f9;font-weight:bold;text-align:center;'>Mes: $mes_nombre $anio | Generado: $fecha_hora</td></tr>";
    echo "<tr style='background:#3b82f6;color:white;font-weight:bold;text-align:center;'>
            <td>FECHA PROG.</td><td>CLIENTE</td><td>MONTO TOTAL</td>
            <td>SALDO REST.</td><td>ABONOS FALT.</td><td>ASESOR</td>
            <td>ESTATUS</td><td>ID PRESTAMO</td></tr>";
    $total_monto = 0; $total_saldo = 0; $contador = 0;
    foreach ($prestamos_data as $p) {
        if (substr($p['fecha_prog'], 0, 7) !== "$anio-$mes") continue;
        $cliente = htmlspecialchars($p['cliente_nombre'] . " " . $p['cliente_apellido']);
        $asesorx = htmlspecialchars($p['asesor_nombre']  . " " . $p['asesor_apellido']);
        $monto   = number_format($p['total_pagar'], 2);
        $saldo   = number_format($p['saldo_restante'], 2);
        $total_monto += $p['total_pagar'];
        $total_saldo += $p['saldo_restante'];
        $contador++;
        echo "<tr><td>{$p['fecha_prog']}</td><td>$cliente</td>
              <td style='text-align:right;'>$$monto</td>
              <td style='text-align:right;'>$$saldo</td>
              <td style='text-align:center;'>{$p['abonos_faltantes']}</td>
              <td>$asesorx</td><td>{$p['estatus']}</td><td>{$p['id_prestamo']}</td></tr>";
    }
    echo "<tr style='background:#f1f5f9;font-weight:bold;'>
            <td colspan='2'>TOTALES</td>
            <td style='text-align:right;'>$" . number_format($total_monto,2) . "</td>
            <td style='text-align:right;'>$" . number_format($total_saldo,2) . "</td>
            <td colspan='4'>Registros: $contador</td></tr>";
    echo "</table>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Programación de Préstamos — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger       { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; min-height:100vh; display:flex; flex-direction:column; }
.main-content { padding:24px 28px 80px; flex:1; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }

.btn-icon { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06); text-decoration:none; }
.btn-icon:hover { color:#0f172a; border-color:#2563eb; }
.btn-sm-act { display:inline-flex; align-items:center; gap:6px; padding:8px 14px; border-radius:10px; font-size:.8rem; font-weight:600; border:1.5px solid #e2e8f0; background:white; color:#475569; text-decoration:none; cursor:pointer; transition:all .15s; }
.btn-sm-act:hover { border-color:#2563eb; color:#2563eb; background:#eff6ff; }
.btn-sm-act.primary { background:#2563eb; color:white; border-color:#2563eb; }
.btn-sm-act.primary:hover { background:#1d4ed8; }

/* ── KPI GRID ── */
.kpi-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:12px; margin-bottom:18px; }
.kpi-card { background:white; border-radius:14px; padding:16px 18px; border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05); border-left:4px solid transparent; position:relative; overflow:hidden; transition:transform .2s, box-shadow .2s; }
.kpi-card:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,.08); }
.kpi-card.azul    { border-left-color:#3b82f6; } .kpi-card.verde   { border-left-color:#10b981; }
.kpi-card.rojo    { border-left-color:#ef4444; } .kpi-card.amarillo{ border-left-color:#f59e0b; }
.kpi-card.morado  { border-left-color:#8b5cf6; }
.kpi-lbl { font-size:.67rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:5px; }
.kpi-val { font-size:1.6rem; font-weight:800; line-height:1; }
.kpi-card.azul    .kpi-val { color:#2563eb; } .kpi-card.verde   .kpi-val { color:#10b981; }
.kpi-card.rojo    .kpi-val { color:#ef4444; } .kpi-card.amarillo .kpi-val { color:#f59e0b; }
.kpi-card.morado  .kpi-val { color:#8b5cf6; font-size:1.1rem; }
.kpi-bg-icon { position:absolute; right:14px; top:12px; font-size:1.8rem; opacity:.08; }

/* ── FILTROS ── */
.filtros-card { background:white; border-radius:14px; padding:18px 20px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-bottom:18px; }
.filtros-form { display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap; }
.f-group { display:flex; flex-direction:column; gap:5px; }
.f-group label { font-size:.72rem; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:.05em; }
.f-select, .f-input { border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 12px; font-size:.84rem; font-family:'Inter',sans-serif; color:#1e293b; background:#f8fafc; outline:none; transition:border-color .15s; }
.f-select:focus, .f-input:focus { border-color:#2563eb; background:white; }
.btn-filtrar { display:inline-flex; align-items:center; gap:6px; background:#2563eb; color:white; border:none; border-radius:9px; padding:8px 16px; font-size:.82rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:all .15s; }
.btn-filtrar:hover { background:#1d4ed8; }
.btn-limpiar { display:inline-flex; align-items:center; gap:6px; background:white; color:#64748b; border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 14px; font-size:.82rem; font-weight:600; text-decoration:none; transition:all .15s; }
.btn-limpiar:hover { border-color:#ef4444; color:#ef4444; }
.asesor-chips { display:flex; flex-wrap:wrap; gap:8px; margin-top:14px; padding-top:14px; border-top:1px solid #f1f5f9; }
.asesor-chip { display:inline-flex; align-items:center; gap:5px; padding:4px 12px; border-radius:20px; font-size:.76rem; font-weight:600; color:white; text-decoration:none; transition:opacity .15s; }
.asesor-chip:hover { opacity:.85; }
.asesor-chip.seleccionado { box-shadow:0 0 0 3px rgba(255,255,255,.4), 0 0 0 5px rgba(0,0,0,.2); }

/* ── NAV MES + VISTA ── */
.barra-mes { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px; }
.nav-mes { display:flex; align-items:center; gap:8px; }
.btn-mes { width:34px; height:34px; border-radius:9px; background:white; border:1.5px solid #e2e8f0; display:flex; align-items:center; justify-content:center; color:#475569; text-decoration:none; font-size:.9rem; transition:all .15s; }
.btn-mes:hover { background:#2563eb; color:white; border-color:#2563eb; }
.mes-label { font-size:1rem; font-weight:700; color:#0f172a; min-width:130px; text-align:center; }
.btn-hoy { padding:5px 12px; border-radius:8px; font-size:.76rem; font-weight:600; background:#f1f5f9; border:1.5px solid #e2e8f0; color:#475569; text-decoration:none; transition:all .15s; }
.btn-hoy:hover { background:#2563eb; color:white; border-color:#2563eb; }
.vista-toggle { display:flex; background:#f1f5f9; border-radius:10px; padding:4px; gap:4px; }
.vista-toggle a { padding:6px 14px; border-radius:7px; font-size:.8rem; font-weight:600; text-decoration:none; color:#64748b; transition:all .2s; display:flex; align-items:center; gap:5px; }
.vista-toggle a.active { background:white; color:#1e293b; box-shadow:0 2px 8px rgba(0,0,0,.08); }

/* ── CALENDARIO ── */
.calendario-wrap { background:white; border-radius:14px; padding:16px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; }
.calendario-grid { display:grid; grid-template-columns:repeat(7,1fr); gap:6px; }
.cal-head { background:#1e293b; color:white; text-align:center; padding:9px 4px; font-size:.72rem; font-weight:700; border-radius:9px; letter-spacing:.4px; text-transform:uppercase; }
.cal-head.domingo { background:#334155; }
.cal-dia { background:#f8fafc; border-radius:10px; padding:8px; min-height:120px; border:1.5px solid #f1f5f9; transition:border-color .2s; position:relative; }
.cal-dia:hover { border-color:#cbd5e1; }
.cal-dia.hoy    { border-color:#3b82f6; background:#eff6ff; }
.cal-dia.domingo { background:#f8fafc; opacity:.7; }
.cal-dia.vacio  { background:transparent; box-shadow:none; border:none; }
.cal-num { font-size:.8rem; font-weight:700; color:#94a3b8; margin-bottom:4px; }
.cal-dia.hoy .cal-num { color:#2563eb; }
.cal-dia.hoy .cal-num::after { content:''; display:inline-block; width:5px; height:5px; background:#2563eb; border-radius:50%; margin-left:4px; vertical-align:middle; }
.cal-evento { font-size:10.5px; padding:3px 6px; border-radius:6px; margin-top:3px; color:white; cursor:pointer; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; transition:opacity .15s, transform .15s; border:none; text-align:left; width:100%; display:block; font-weight:500; font-family:'Inter',sans-serif; }
.cal-evento:hover { opacity:.85; transform:translateX(2px); }
.sin-prog { font-size:9px; color:#cbd5e1; text-align:center; margin-top:8px; }
.est-dot { display:inline-block; width:5px; height:5px; border-radius:50%; margin-right:3px; vertical-align:middle; }
.est-renovar    { background:#10b981; } .est-hoy        { background:#f59e0b; }
.est-programado { background:#3b82f6; } .est-tolerancia { background:#06b6d4; }
.est-atraso     { background:#ef4444; }

/* ── LEYENDA ── */
.leyenda { background:white; border-radius:12px; padding:14px 18px; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-top:14px; }
.leyenda-title { font-size:.72rem; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:.05em; margin-bottom:8px; }
.leyenda-items { display:flex; flex-wrap:wrap; gap:8px; }
.badge-est { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:20px; font-size:.72rem; font-weight:600; white-space:nowrap; }
.badge-est.renovar    { background:#dcfce7; color:#15803d; } .badge-est.hoy        { background:#fef3c7; color:#92400e; }
.badge-est.programado { background:#dbeafe; color:#1d4ed8; } .badge-est.tolerancia { background:#cffafe; color:#0e7490; }
.badge-est.atraso     { background:#fee2e2; color:#991b1b; }

/* ── TABLA LISTA ── */
.tabla-wrapper { background:white; border-radius:14px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; }
.tabla-header { padding:14px 18px; background:#f8fafc; border-bottom:1px solid #f1f5f9; display:flex; justify-content:space-between; align-items:center; }
.tabla-header strong { font-size:.84rem; color:#475569; }
.tabla-prestamos { width:100%; border-collapse:collapse; font-size:.85rem; }
.tabla-prestamos thead th { background:#1e293b; color:white; padding:12px 14px; font-weight:600; font-size:.72rem; text-transform:uppercase; letter-spacing:.05em; white-space:nowrap; }
.tabla-prestamos tbody tr { border-bottom:1px solid #f1f5f9; transition:background .15s; }
.tabla-prestamos tbody tr:hover { background:#f8fafc; }
.tabla-prestamos tbody td { padding:11px 14px; vertical-align:middle; }
.tabla-prestamos tfoot td { padding:12px 14px; background:#f8fafc; font-size:.82rem; font-weight:700; color:#475569; }
.prog-bar { height:5px; background:#f1f5f9; border-radius:5px; overflow:hidden; margin-top:3px; }
.prog-bar-fill { height:100%; border-radius:5px; background:linear-gradient(90deg,#3b82f6,#10b981); }
.chip-asesor { display:inline-flex; align-items:center; gap:5px; padding:3px 10px; border-radius:20px; font-size:.74rem; font-weight:600; color:white; }
.dias-tag { font-size:.75rem; font-weight:600; padding:2px 8px; border-radius:7px; }
.dias-tag.positivo { background:#f0fdf4; color:#15803d; } .dias-tag.negativo { background:#fef2f2; color:#b91c1c; }
.dias-tag.neutro   { background:#fffbeb; color:#92400e; }
.empty-state { text-align:center; padding:48px 24px; color:#94a3b8; }
.empty-state i { font-size:2.5rem; display:block; margin-bottom:10px; opacity:.4; }

/* ── FAB ── */
.fab { position:fixed; bottom:24px; right:24px; z-index:9999; display:none; animation:fabIn .3s ease; }
@keyframes fabIn { from { transform:scale(.7); opacity:0; } to { transform:scale(1); opacity:1; } }
.fab-btn { border-radius:14px; padding:12px 20px; font-weight:600; box-shadow:0 8px 24px rgba(37,99,235,.4); border:none; background:linear-gradient(135deg,#3b82f6,#1d4ed8); color:white; font-size:.88rem; cursor:pointer; font-family:'Inter',sans-serif; display:flex; align-items:center; gap:8px; }

/* ── DARK MODE ── */
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .main-content { background:#0f172a; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .kpi-card, [data-theme="dark"] .filtros-card,
[data-theme="dark"] .leyenda, [data-theme="dark"] .tabla-wrapper,
[data-theme="dark"] .calendario-wrap { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .kpi-lbl { color:#64748b; }
[data-theme="dark"] .f-select, [data-theme="dark"] .f-input { background:#0f172a; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .btn-sm-act, [data-theme="dark"] .btn-icon { background:#1e293b; color:#94a3b8; border-color:#334155; }
[data-theme="dark"] .btn-sm-act:hover, [data-theme="dark"] .btn-icon:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .vista-toggle { background:#0f172a; }
[data-theme="dark"] .vista-toggle a.active { background:#1e293b; color:#e2e8f0; }
[data-theme="dark"] .btn-mes, [data-theme="dark"] .btn-hoy { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .mes-label { color:#f8fafc; }
[data-theme="dark"] .cal-dia   { background:#0f172a; border-color:#1e293b; }
[data-theme="dark"] .cal-dia.hoy { background:#1e3a6e; border-color:#3b82f6; }
[data-theme="dark"] .tabla-header { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .tabla-prestamos tbody tr:hover { background:#0f172a; }
[data-theme="dark"] .tabla-prestamos tbody tr { border-color:#334155; }
[data-theme="dark"] .tabla-prestamos tfoot td { background:#0f172a; }
[data-theme="dark"] .leyenda-title { color:#64748b; }
[data-theme="dark"] .filtros-card { border-color:#334155; }
[data-theme="dark"] .asesor-chips { border-color:#334155; }
[data-theme="dark"] .prog-bar { background:#334155; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; } .main { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .kpi-grid { grid-template-columns:repeat(2,1fr); }
    .calendario-grid { gap:3px; }
    .cal-dia { min-height:70px; padding:5px 3px; }
    .cal-evento { font-size:9px; } .cal-head { font-size:.62rem; padding:6px 2px; }
}
@media (max-width:600px) {
    .kpi-grid { grid-template-columns:repeat(2,1fr); }
    .barra-mes { flex-direction:column; align-items:flex-start; }
}
@media print {
    .sidebar, .filtros-card, .fab, .btn-icon { display:none !important; }
    .main { margin-left:0; } body { background:white; }
    .cal-dia { box-shadow:none; border:1px solid #e2e8f0; }
}
</style>
</head>
<body>
<div class="app">

<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if (in_array($rol, ['GERENTE','SUPERVISOR'])): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php" class="active"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="btn-icon" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-calendar3-range" style="color:#2563eb;"></i> Programación de Préstamos</h1>
                <p>Rango: <?= date('d/m/Y', strtotime($fecha_min)) ?> &rarr; <?= date('d/m/Y', strtotime($fecha_max)) ?> &nbsp;&middot;&nbsp; <?= count($prestamos_data) ?> préstamos activos</p>
            </div>
        </div>
        <div class="topbar-right">
            <a href="?mes=<?= $mes ?>&anio=<?= $anio ?>&asesor=<?= $asesor_seleccionado ?>&vista=<?= $vista ?>&excel=1"
               class="btn-sm-act" title="Exportar Excel">
                <i class="bi bi-file-earmark-excel" style="color:#16a34a;"></i> Excel
            </a>
            <button onclick="window.print()" class="btn-sm-act" title="Imprimir">
                <i class="bi bi-printer"></i> Imprimir
            </button>
            <button class="btn-icon" id="btnTema" title="Cambiar tema" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid">
        <div class="kpi-card azul">
            <i class="bi bi-list-check kpi-bg-icon"></i>
            <div class="kpi-lbl">Este mes</div>
            <div class="kpi-val"><?= $stats['total'] ?></div>
        </div>
        <div class="kpi-card verde">
            <i class="bi bi-arrow-repeat kpi-bg-icon"></i>
            <div class="kpi-lbl">Listos a renovar</div>
            <div class="kpi-val"><?= $stats['renovar'] ?></div>
        </div>
        <div class="kpi-card amarillo">
            <i class="bi bi-alarm kpi-bg-icon"></i>
            <div class="kpi-lbl">Vencen hoy</div>
            <div class="kpi-val"><?= $stats['hoy'] ?></div>
        </div>
        <div class="kpi-card rojo">
            <i class="bi bi-exclamation-triangle kpi-bg-icon"></i>
            <div class="kpi-lbl">Con atraso</div>
            <div class="kpi-val"><?= $stats['atraso'] ?></div>
        </div>
        <div class="kpi-card morado">
            <i class="bi bi-cash-stack kpi-bg-icon"></i>
            <div class="kpi-lbl">Monto del mes</div>
            <div class="kpi-val">$<?= number_format($stats['monto'], 2) ?></div>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <input type="hidden" name="vista" value="<?= htmlspecialchars($vista) ?>">
            <div class="f-group">
                <label>Mes</label>
                <select name="mes" class="f-select">
                    <?php foreach ($meses_es as $num => $nombre): ?>
                    <option value="<?= $num ?>" <?= ($mes == $num) ? 'selected' : '' ?>><?= $nombre ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="f-group">
                <label>Año</label>
                <input type="number" name="anio" class="f-input" value="<?= $anio ?>" min="2020" max="2035" style="width:80px;">
            </div>
            <div class="f-group" style="min-width:200px;">
                <label>Asesor</label>
                <select name="asesor" class="f-select">
                    <option value="">— Todos los asesores —</option>
                    <?php foreach ($asesores_list as $a): ?>
                    <option value="<?= $a['id_empleado'] ?>"
                        <?= ($asesor_seleccionado == $a['id_empleado']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a['nombre'] . ' ' . $a['apellido']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="f-group" style="justify-content:flex-end;">
                <label>&nbsp;</label>
                <button type="submit" class="btn-filtrar"><i class="bi bi-funnel"></i> Filtrar</button>
            </div>
            <?php if ($asesor_seleccionado): ?>
            <div class="f-group" style="justify-content:flex-end;">
                <label>&nbsp;</label>
                <a href="?mes=<?= $mes ?>&anio=<?= $anio ?>&vista=<?= $vista ?>" class="btn-limpiar">
                    <i class="bi bi-x-circle"></i> Limpiar
                </a>
            </div>
            <?php endif; ?>
        </form>
        <?php if ($asesor_color_map): ?>
        <div class="asesor-chips">
            <?php foreach ($asesores_list as $a): ?>
                <?php if (isset($asesor_color_map[$a['id_empleado']])): ?>
                <a href="?mes=<?= $mes ?>&anio=<?= $anio ?>&vista=<?= $vista ?>&asesor=<?= $a['id_empleado'] ?>"
                   class="asesor-chip <?= ($asesor_seleccionado == $a['id_empleado']) ? 'seleccionado' : '' ?>"
                   style="background:<?= $asesor_color_map[$a['id_empleado']] ?>;">
                    <i class="bi bi-person-fill" style="font-size:.7rem;"></i>
                    <?= htmlspecialchars($a['nombre'] . ' ' . $a['apellido']) ?>
                </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- BARRA MES + VISTA -->
    <div class="barra-mes">
        <div class="nav-mes">
            <a href="?mes=<?= $mes_anterior ?>&anio=<?= $anio_anterior ?>&asesor=<?= $asesor_seleccionado ?>&vista=<?= $vista ?>" class="btn-mes">
                <i class="bi bi-chevron-left"></i>
            </a>
            <span class="mes-label"><?= $meses_es[$mes] ?? $mes ?> <?= $anio ?></span>
            <a href="?mes=<?= $mes_siguiente ?>&anio=<?= $anio_siguiente ?>&asesor=<?= $asesor_seleccionado ?>&vista=<?= $vista ?>" class="btn-mes">
                <i class="bi bi-chevron-right"></i>
            </a>
            <a href="?mes=<?= date('m') ?>&anio=<?= date('Y') ?>&asesor=<?= $asesor_seleccionado ?>&vista=<?= $vista ?>" class="btn-hoy">
                Hoy
            </a>
        </div>
        <div class="vista-toggle">
            <a href="?mes=<?= $mes ?>&anio=<?= $anio ?>&asesor=<?= $asesor_seleccionado ?>&vista=calendario"
               class="<?= $vista === 'calendario' ? 'active' : '' ?>">
                <i class="bi bi-grid-3x3-gap"></i> Calendario
            </a>
            <a href="?mes=<?= $mes ?>&anio=<?= $anio ?>&asesor=<?= $asesor_seleccionado ?>&vista=lista"
               class="<?= $vista === 'lista' ? 'active' : '' ?>">
                <i class="bi bi-table"></i> Lista
            </a>
        </div>
    </div>

    <!-- ══════════════ VISTA CALENDARIO ══════════════ -->
    <?php if ($vista === 'calendario'):
        $dias_mes   = cal_days_in_month(CAL_GREGORIAN, $mes, $anio);
        $primer_dia = date('N', strtotime("$anio-$mes-01"));
        $por_fecha  = [];
        foreach ($prestamos_data as $p) {
            $fp = $p['fecha_prog'];
            if (substr($fp, 0, 7) === "$anio-$mes") $por_fecha[$fp][] = $p;
        }
    ?>
    <div class="calendario-wrap">
        <div class="calendario-grid">
            <?php
            $dias_nombres = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];
            foreach ($dias_nombres as $i => $dn):
            ?>
            <div class="cal-head <?= ($i === 6) ? 'domingo' : '' ?>"><?= $dn ?></div>
            <?php endforeach; ?>

            <?php for ($i = 1; $i < $primer_dia; $i++): ?>
            <div class="cal-dia vacio"></div>
            <?php endfor; ?>

            <?php for ($d = 1; $d <= $dias_mes; $d++):
                $fecha   = "$anio-$mes-" . str_pad($d, 2, '0', STR_PAD_LEFT);
                $es_dom  = esDomingo($fecha);
                $es_hoy  = ($fecha === $hoy);
                $clases  = 'cal-dia' . ($es_hoy ? ' hoy' : '') . ($es_dom ? ' domingo' : '');
                $eventos = $por_fecha[$fecha] ?? [];
            ?>
            <div class="<?= $clases ?>">
                <div class="cal-num"><?= $d ?></div>
                <?php if (empty($eventos)): ?>
                    <div class="sin-prog"><?= $es_dom ? '—' : 'Sin venc.' ?></div>
                <?php else: ?>
                    <?php foreach ($eventos as $ev):
                        $nombre = htmlspecialchars($ev['cliente_nombre'] . ' ' . substr($ev['cliente_apellido'], 0, 1) . '.');
                    ?>
                    <button class="cal-evento" style="background:<?= $ev['color'] ?>;"
                        onclick="seleccionarCliente(<?= (int)$ev['id_cliente'] ?>, <?= (int)$ev['id_prestamo'] ?>, '<?= htmlspecialchars($ev['cliente_nombre'].' '.$ev['cliente_apellido']) ?>')">
                        <span class="est-dot est-<?= $ev['estatus_clase'] ?>"></span>
                        <?= $nombre ?>
                        <span style="opacity:.85;"> $<?= number_format($ev['total_pagar'], 2) ?></span>
                    </button>
                    <?php endforeach; ?>
                    <?php if (count($eventos) > 1): ?>
                    <div style="font-size:9px;color:#94a3b8;text-align:right;margin-top:2px;">
                        <?= count($eventos) ?> vencimientos
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endfor; ?>
        </div>
    </div>

    <div class="leyenda">
        <div class="leyenda-title">Leyenda de estados</div>
        <div class="leyenda-items">
            <span class="badge-est renovar"><span class="est-dot est-renovar"></span> Renovar</span>
            <span class="badge-est hoy"><span class="est-dot est-hoy"></span> Vence hoy</span>
            <span class="badge-est programado"><span class="est-dot est-programado"></span> Programado</span>
            <span class="badge-est tolerancia"><span class="est-dot est-tolerancia"></span> Tolerancia (&lt;<?= $LIMITE_TOLERANCIA ?> d.h.)</span>
            <span class="badge-est atraso"><span class="est-dot est-atraso"></span> Atrasado</span>
        </div>
    </div>

    <?php endif; ?>

    <!-- ══════════════ VISTA LISTA ══════════════ -->
    <?php if ($vista === 'lista'):
        $prestamos_mes = array_filter($prestamos_data, fn($p) => substr($p['fecha_prog'], 0, 7) === "$anio-$mes");
    ?>
    <div class="tabla-wrapper">
        <?php if (empty($prestamos_mes)): ?>
        <div class="empty-state">
            <i class="bi bi-calendar-x"></i>
            <p style="font-weight:600;margin-bottom:4px;">No hay préstamos programados para <?= $meses_es[$mes] ?> <?= $anio ?></p>
            <p style="font-size:.84rem;color:#94a3b8;">Intenta con otro mes o revisa el filtro de asesor.</p>
        </div>
        <?php else: ?>
        <div class="tabla-header">
            <strong><?= count($prestamos_mes) ?> préstamos en <?= $meses_es[$mes] ?> <?= $anio ?></strong>
            <span style="font-size:.8rem;color:#64748b;">
                Total: <strong style="color:#0f172a;">$<?= number_format(array_sum(array_column($prestamos_mes,'total_pagar')),2) ?></strong>
            </span>
        </div>
        <div style="overflow-x:auto;">
        <table class="tabla-prestamos">
            <thead>
                <tr>
                    <th>Fecha prog.</th><th>Días</th><th>Cliente</th>
                    <th>Monto total</th><th>Avance</th><th>Abonos falt.</th>
                    <th>Asesor</th><th>Estatus</th><th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($prestamos_mes as $p):
                $cliente  = htmlspecialchars($p['cliente_nombre'] . ' ' . $p['cliente_apellido']);
                $asesorx  = htmlspecialchars($p['asesor_nombre']  . ' ' . $p['asesor_apellido']);
                $pct      = min(100, ($p['total_pagado'] / max(1, $p['total_pagar'])) * 100);
                $dr       = $p['dias_restantes'];
                $dr_clase = ($dr > 5) ? 'positivo' : (($dr < 0) ? 'negativo' : 'neutro');
                $dr_txt   = ($dr == 0) ? 'Hoy' : (($dr > 0) ? "+$dr días" : "$dr días");
            ?>
            <tr>
                <td>
                    <strong><?= date('d/m/Y', strtotime($p['fecha_prog'])) ?></strong>
                    <?php if ($p['fecha_prog'] !== $p['fecha_final']): ?>
                    <div style="font-size:.7rem;color:#94a3b8;margin-top:2px;">
                        <i class="bi bi-arrow-right-short"></i> Reprogramado
                    </div>
                    <?php endif; ?>
                </td>
                <td><span class="dias-tag <?= $dr_clase ?>"><?= $dr_txt ?></span></td>
                <td>
                    <strong><?= $cliente ?></strong>
                    <div style="font-size:.72rem;color:#94a3b8;">ID: <?= $p['id_prestamo'] ?></div>
                </td>
                <td>
                    <strong>$<?= number_format($p['total_pagar'], 2) ?></strong>
                    <?php if ($p['saldo_restante'] > 0): ?>
                    <div style="font-size:.72rem;color:#ef4444;">Saldo: $<?= number_format($p['saldo_restante'], 2) ?></div>
                    <?php endif; ?>
                </td>
                <td style="min-width:90px;">
                    <div style="font-size:.72rem;color:#64748b;margin-bottom:2px;"><?= round($pct) ?>%</div>
                    <div class="prog-bar"><div class="prog-bar-fill" style="width:<?= $pct ?>%;"></div></div>
                </td>
                <td style="text-align:center;">
                    <?php if ($p['abonos_faltantes'] > 0): ?>
                    <strong style="color:#ef4444;"><?= $p['abonos_faltantes'] ?></strong>
                    <?php else: ?>
                    <i class="bi bi-check-circle-fill" style="color:#10b981;"></i>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="chip-asesor" style="background:<?= $p['color'] ?>;">
                        <i class="bi bi-person-fill" style="font-size:.7rem;"></i> <?= $asesorx ?>
                    </span>
                </td>
                <td><span class="badge-est <?= $p['estatus_clase'] ?>"><?= htmlspecialchars($p['estatus']) ?></span></td>
                <td>
                    <a href="historial_cliente.php?id=<?= (int)$p['id_cliente'] ?>&prestamo=<?= (int)$p['id_prestamo'] ?>"
                       target="_blank"
                       style="display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:8px;
                              background:#eff6ff;color:#2563eb;font-size:.76rem;font-weight:600;
                              text-decoration:none;border:1px solid #bfdbfe;transition:all .15s;"
                       onmouseover="this.style.background='#dbeafe'"
                       onmouseout="this.style.background='#eff6ff'">
                        <i class="bi bi-folder2-open"></i> Ver
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">TOTALES — <?= count($prestamos_mes) ?> registros</td>
                    <td>$<?= number_format(array_sum(array_column($prestamos_mes,'total_pagar')),2) ?></td>
                    <td colspan="5"></td>
                </tr>
            </tfoot>
        </table>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>
</main>
</div>

<div class="fab" id="fab">
    <button class="fab-btn" onclick="abrirClienteSeleccionado()">
        <i class="bi bi-folder2-open"></i>
        Ver: <span id="nombreSeleccionado"></span>
    </button>
</div>

<script>
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html   = document.documentElement;
    var actual = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', actual);
    localStorage.setItem('pje_tema', actual);
    document.getElementById('themeIcon').className = actual === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    var n = new Date(), p = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

var _idCliente = null, _idPrestamo = null;
function seleccionarCliente(idCliente, idPrestamo, nombre) {
    _idCliente  = idCliente;
    _idPrestamo = idPrestamo;
    document.getElementById('nombreSeleccionado').innerText = nombre;
    document.getElementById('fab').style.display = 'block';
}
function abrirClienteSeleccionado() {
    if (_idCliente) window.open('historial_cliente.php?id=' + _idCliente + '&prestamo=' + _idPrestamo, '_blank');
}
</script>
</body>
</html>

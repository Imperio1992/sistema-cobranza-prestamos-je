<?php
$roles_permitidos = ['GERENTE'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'];
$user       = $_SESSION['usuario'] ?? 'Usuario';

$clientes = $conexion->query("
    SELECT id_cliente, nombre, apellido FROM clientes
    WHERE estatus='ACTIVO' ORDER BY nombre, apellido
");
$clientes_array = [];
while ($c = $clientes->fetch_assoc()) $clientes_array[] = $c;

$empleados = $conexion->query("
    SELECT id_empleado, nombre, apellido FROM empleados
    WHERE estatus='ACTIVO' ORDER BY nombre
");
$empleados_array = [];
while ($e = $empleados->fetch_assoc()) $empleados_array[] = $e;

$alerta      = '';
$alerta_tipo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_cliente'])) {

    $id_cliente   = intval($_POST['id_cliente']);
    $id_empleado  = intval($_POST['id_empleado']);
    $monto        = floatval($_POST['monto']);
    $interes      = floatval($_POST['interes']);
    $total_pagar  = floatval($_POST['total_pagar']);
    $pago_diario  = floatval($_POST['pago_diario']);
    $fecha_inicio = $_POST['fecha_inicio'];
    $dias         = intval($_POST['dias'] ?? 20);
    $pagos_data   = $_POST['pagos'] ?? [];

    if ($id_cliente <= 0 || $id_empleado <= 0 || $monto <= 0 || $total_pagar <= 0) {
        $alerta      = 'Datos del préstamo incompletos o inválidos.';
        $alerta_tipo = 'error';
    } else {
        $r        = $conexion->query("SELECT MAX(numero_credito_asesor) AS u FROM prestamos WHERE id_empleado = $id_empleado")->fetch_assoc();
        $nuevo_num = (intval($r['u']) >= 99) ? 1 : (intval($r['u']) + 1);

        $conexion->begin_transaction();
        try {
            $stmt = $conexion->prepare("
                INSERT INTO prestamos
                    (id_cliente, id_empleado, numero_credito_asesor,
                     monto_prestado, interes, total_pagar, pago_diario,
                     fecha_inicio, dias, estado, saldo_actual, total_pagado)
                VALUES (?,?,?,?,?,?,?,?,?,'ACTIVO',?,0)
            ");
            $stmt->bind_param("iiiddddsis",
                $id_cliente, $id_empleado, $nuevo_num,
                $monto, $interes, $total_pagar, $pago_diario,
                $fecha_inicio, $dias, $total_pagar);
            $stmt->execute();
            $id_prestamo_nuevo = $conexion->insert_id;

            $num_fmt  = str_pad($nuevo_num, 2, '0', STR_PAD_LEFT);
            $concepto = "PRESTAMO MIGRACION #$num_fmt";
            $stmtCaja = $conexion->prepare("
                INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, fecha, id_prestamo, tipo_movimiento)
                VALUES ('SALIDA', ?, 'BANCO', ?, ?, NOW(), ?, 'PRESTAMO')
            ");
            $stmtCaja->bind_param("sdii", $concepto, $monto, $id_empleado, $id_prestamo_nuevo);
            $stmtCaja->execute();

            $total_abonado = 0;
            $cuota_num     = 1;
            $fecha_ref     = new DateTime($fecha_inicio);
            $fecha_ref->modify('+1 day');

            foreach ($pagos_data as $idx => $pago) {
                $monto_p = floatval($pago['monto'] ?? 0);
                if ($monto_p <= 0) continue;

                $fecha_p = trim($pago['fecha'] ?? '');
                if (empty($fecha_p)) {
                    $fecha_calc = clone $fecha_ref;
                    $pasos      = intval($idx) - 1;
                    for ($s = 0; $s < $pasos; $s++) {
                        $fecha_calc->modify('+1 day');
                        while ($fecha_calc->format('N') == 7) $fecha_calc->modify('+1 day');
                    }
                    while ($fecha_calc->format('N') == 7) $fecha_calc->modify('+1 day');
                    $fecha_p = $fecha_calc->format('Y-m-d');
                }

                $stmtPago = $conexion->prepare("
                    INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado, cuota_numero, tipo_pago)
                    VALUES (?, ?, ?, ?, 'MIGRACION')
                ");
                $stmtPago->bind_param("isdi", $id_prestamo_nuevo, $fecha_p, $monto_p, $cuota_num);
                $stmtPago->execute();

                $concepto_pago = "COBRO PRESTAMO MIGRACION #$num_fmt - CUOTA $cuota_num";
                $stmtCajaPago  = $conexion->prepare("
                    INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, fecha, id_prestamo, tipo_movimiento)
                    VALUES ('ENTRADA', ?, 'EFECTIVO', ?, ?, ?, ?, 'COBRO')
                ");
                $stmtCajaPago->bind_param("sdisi", $concepto_pago, $monto_p, $id_empleado, $fecha_p, $id_prestamo_nuevo);
                $stmtCajaPago->execute();

                $total_abonado += $monto_p;
                $cuota_num++;
            }

            $nuevo_saldo = max(0, $total_pagar - $total_abonado);
            $estado      = ($nuevo_saldo <= 0) ? 'PAGADO' : 'ACTIVO';
            $fecha_liq   = ($nuevo_saldo <= 0) ? date('Y-m-d') : null;

            $stmtUpd = $conexion->prepare("
                UPDATE prestamos SET total_pagado=?, saldo_actual=?, estado=?, fecha_liquidacion=?
                WHERE id_prestamo=?
            ");
            $stmtUpd->bind_param("ddssi", $total_abonado, $nuevo_saldo, $estado, $fecha_liq, $id_prestamo_nuevo);
            $stmtUpd->execute();

            $conexion->commit();
            $alerta      = "Préstamo de migración #$num_fmt registrado. ID: $id_prestamo_nuevo — Cuotas: " . ($cuota_num - 1) . " — Total abonado: $" . number_format($total_abonado, 2);
            $alerta_tipo = 'ok';

        } catch (Exception $ex) {
            $conexion->rollback();
            $alerta      = 'Error al guardar: ' . $ex->getMessage();
            $alerta_tipo = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Préstamo Migración — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
/* ═══ VARIABLES CLARO / OSCURO ═══ */
:root {
    --bg:           #f0f4f8;
    --surface:      #ffffff;
    --surface2:     #f8fafc;
    --border:       #e2e8f0;
    --border2:      #f1f5f9;
    --text:         #1a1a2e;
    --text-muted:   #64748b;
    --text-label:   #374151;
    --input-bg:     #f8fafc;
    --input-focus:  #ffffff;
    --card-shadow:  0 2px 14px rgba(0,0,0,0.07);
    --je-border:    #1e3a8a;
    --je-bg:        #ffffff;
    --je-num-bg:    #1e3a8a;
    --row-hover:    #fafbff;
    --row-filled:   #f0fdf4;
    --resumen-bg:   #f8fafc;
}
[data-theme="dark"] {
    --bg:           #0f172a;
    --surface:      #1e293b;
    --surface2:     #162032;
    --border:       #334155;
    --border2:      #253347;
    --text:         #e2e8f0;
    --text-muted:   #94a3b8;
    --text-label:   #cbd5e1;
    --input-bg:     #162032;
    --input-focus:  #1e293b;
    --card-shadow:  0 2px 14px rgba(0,0,0,0.35);
    --je-border:    #3b82f6;
    --je-bg:        #1e293b;
    --je-num-bg:    #1d4ed8;
    --row-hover:    #1a2540;
    --row-filled:   #14261e;
    --resumen-bg:   #162032;
}

*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:var(--bg); color:var(--text); transition:background .25s, color .25s; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR (estándar plataforma) ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(124,58,237,.15); color:#c4b5fd; border:1px solid rgba(124,58,237,.25); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; padding:28px 28px 60px; }

/* ── TOPBAR ── */
.topbar {
    display:flex; align-items:center; justify-content:space-between;
    margin-bottom:24px; gap:14px; flex-wrap:wrap;
}
.topbar-left { display:flex; align-items:center; gap:14px; }
.page-icon {
    width:50px; height:50px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:14px; display:flex; align-items:center; justify-content:center;
    font-size:1.4rem; box-shadow:0 4px 14px rgba(124,58,237,.35); flex-shrink:0;
}
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:var(--text); letter-spacing:-.3px; }
.topbar-left p  { font-size:.82rem; color:var(--text-muted); margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.tz-badge {
    display:inline-flex; align-items:center; gap:6px;
    background:var(--surface); border:1px solid var(--border);
    border-radius:99px; padding:5px 13px;
    font-size:.75rem; font-weight:600; color:var(--text-muted);
}
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid var(--border); background:var(--surface); color:var(--text-muted);
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s;
}
.btn-icon-top:hover { color:var(--text); border-color:#7c3aed; }

/* ── BADGE MIGRACIÓN ── */
.badge-migracion {
    display:inline-flex; align-items:center; gap:4px;
    background:#7c3aed; color:#fff; font-size:.68rem; font-weight:700;
    border-radius:99px; padding:3px 10px; letter-spacing:.06em;
    text-transform:uppercase; margin-left:8px; vertical-align:middle;
}

/* ── AVISO ── */
.aviso-migracion {
    background:linear-gradient(135deg,#fdf4ff,#ede9fe);
    border:1.5px solid #c4b5fd; border-radius:12px;
    padding:14px 18px; margin-bottom:22px;
    font-size:.84rem; color:#4c1d95;
    display:flex; align-items:flex-start; gap:12px;
}
[data-theme="dark"] .aviso-migracion { background:#1e0a3c; color:#c4b5fd; border-color:#5b21b6; }
.aviso-migracion i { font-size:1.1rem; flex-shrink:0; margin-top:1px; }

/* ── ALERTAS ── */
.alerta-ok {
    background:#f0fdf4; border:1.5px solid #86efac; color:#166534;
    border-radius:12px; padding:14px 18px; font-size:.88rem; font-weight:600;
    margin-bottom:22px; display:flex; align-items:center; gap:10px;
}
.alerta-error {
    background:#fef2f2; border:1.5px solid #fca5a5; color:#991b1b;
    border-radius:12px; padding:14px 18px; font-size:.88rem; font-weight:600;
    margin-bottom:22px; display:flex; align-items:center; gap:10px;
}

/* ── CARD ── */
.card {
    background:var(--surface); border-radius:16px;
    box-shadow:var(--card-shadow); overflow:hidden;
    margin-bottom:24px; border:1px solid var(--border2);
    transition:background .25s, border-color .25s;
}
.card-header {
    padding:16px 22px; display:flex; align-items:center; gap:10px;
    border-bottom:1px solid var(--border2);
}
.card-header.morado { background:linear-gradient(135deg,#1e293b,#0f172a); color:#fff; }
.card-header.azul   { background:linear-gradient(135deg,#1e40af,#1d4ed8); color:#fff; }
.card-header i      { font-size:1.1rem; }
.card-header h2     { font-size:1rem; font-weight:700; }
.card-header small  { font-size:.78rem; opacity:.75; margin-left:auto; }
.card-body { padding:22px; }

/* ── FORM ── */
.form-row {
    display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:16px; margin-bottom:18px;
}
.form-group { display:flex; flex-direction:column; gap:6px; }
.form-group label {
    font-size:.75rem; font-weight:700; color:var(--text-label);
    text-transform:uppercase; letter-spacing:.04em;
    display:flex; align-items:center; gap:5px;
}
.form-group input,
.form-group select {
    border:1.5px solid var(--border); border-radius:10px;
    padding:10px 14px; font-size:.9rem; color:var(--text);
    background:var(--input-bg); outline:none; font-family:'Inter',sans-serif;
    transition:border-color .2s, box-shadow .2s, background .25s; appearance:none;
}
.form-group input:focus,
.form-group select:focus {
    border-color:#7c3aed; background:var(--input-focus);
    box-shadow:0 0 0 3px rgba(124,58,237,0.1);
}
.form-group input[readonly] { background:var(--surface2); color:var(--text-muted); }

/* ── RESUMEN ── */
.resumen-grid {
    display:grid; grid-template-columns:repeat(auto-fit,minmax(130px,1fr));
    gap:12px; margin-bottom:10px;
}
.resumen-item {
    background:var(--resumen-bg); border:1.5px solid var(--border);
    border-radius:12px; padding:13px 14px; text-align:center;
    transition:background .25s;
}
.resumen-item small {
    display:block; font-size:.68rem; font-weight:700;
    text-transform:uppercase; letter-spacing:.06em; color:var(--text-muted); margin-bottom:5px;
}
.resumen-item strong { font-size:1.05rem; font-weight:800; color:var(--text); }
.resumen-item.morado { border-color:#c4b5fd; background:#faf5ff; }
.resumen-item.morado strong { color:#7c3aed; }
.resumen-item.verde  { border-color:#86efac; background:#f0fdf4; }
.resumen-item.verde  strong { color:#166534; }
.resumen-item.azul   { border-color:#93c5fd; background:#eff6ff; }
.resumen-item.azul   strong { color:#1d4ed8; }
[data-theme="dark"] .resumen-item.morado { background:#2e1065; }
[data-theme="dark"] .resumen-item.verde  { background:#052e16; }
[data-theme="dark"] .resumen-item.azul   { background:#0c1a3a; }

/* ── TARJETA J.E. ── */
.tarjeta-je {
    background:var(--je-bg); border:2px solid var(--je-border);
    border-radius:12px; overflow:hidden;
    box-shadow:0 2px 12px rgba(30,58,138,0.12);
    transition:background .25s, border-color .25s;
}
.tarjeta-je-header {
    background:var(--je-bg); padding:14px 18px 10px;
    border-bottom:2px solid var(--je-border);
    display:flex; align-items:center; justify-content:space-between; gap:12px;
    transition:background .25s;
}
.tarjeta-je-brand { font-size:2rem; font-weight:900; color:var(--je-border); letter-spacing:-1px; }
.tarjeta-je-brand small { display:block; font-size:.7rem; font-weight:500; color:var(--text-muted); letter-spacing:.04em; }
.tarjeta-je-monto {
    border:2px solid var(--je-border); border-radius:8px; padding:6px 16px;
    font-size:1.05rem; font-weight:700; color:var(--je-border); min-width:130px; text-align:center;
}
.tarjeta-info { display:grid; grid-template-columns:1fr 1fr 1fr; border-bottom:1.5px solid var(--je-border); }
.tarjeta-info-item { padding:8px 14px; border-right:1px solid var(--border); }
.tarjeta-info-item:last-child { border-right:none; }
.tarjeta-info-item label {
    display:block; font-size:.66rem; font-weight:700; text-transform:uppercase;
    color:var(--text-muted); margin-bottom:4px; letter-spacing:.04em;
}
.tarjeta-info-item span { font-size:.88rem; font-weight:600; color:var(--text); }

/* ── CABECERA COLUMNAS ── */
.cuotas-cols-header { display:grid; grid-template-columns:1fr 1fr; border-bottom:1.5px solid var(--je-border); }
.col-header {
    display:grid; grid-template-columns:36px 1fr 130px;
    background:var(--je-num-bg); color:#fff;
    font-size:.68rem; font-weight:700; text-align:center;
}
.col-header.right { border-left:2px solid #fff; }
.col-header div { padding:7px 4px; border-right:1px solid rgba(255,255,255,.3); }
.col-header div:last-child { border-right:none; }

/* ── GRID DOS COLUMNAS ── */
.cuotas-wrapper { display:grid; grid-template-columns:1fr 1fr; }
.cuota-col { display:flex; flex-direction:column; }
.cuota-col.right { border-left:2px solid var(--je-border); }

/* ── FILA CUOTA ── */
.cuota-row {
    display:grid; grid-template-columns:36px 1fr 130px;
    border-bottom:1px solid var(--border);
    align-items:center; transition:background .15s;
}
.cuota-row:hover { background:var(--row-hover); }
.cuota-row.cuota-filled { background:var(--row-filled); }
.cuota-num {
    font-size:.76rem; font-weight:700; color:#fff;
    background:var(--je-num-bg); text-align:center; padding:6px 4px;
    height:100%; display:flex; align-items:center; justify-content:center;
    min-width:36px; transition:background .2s;
}
.cuota-num.pagado { background:#16a34a; }
.cuota-fecha { border-left:1px solid var(--border); position:relative; }
.cuota-fecha input.fecha-display {
    width:100%; border:none; padding:6px 8px; font-size:.8rem;
    color:var(--text); background:transparent; outline:none;
    height:36px; text-align:center; letter-spacing:.04em; font-family:'Inter',sans-serif;
}
.cuota-fecha input.fecha-display:focus { background:var(--row-hover); }
.cuota-fecha input.fecha-display::placeholder { color:var(--text-muted); opacity:.7; }
.cuota-monto { border-left:1px solid var(--border); }
.cuota-monto input {
    width:100%; border:none; padding:6px 10px 6px 8px; font-size:.8rem;
    color:var(--text); background:transparent; outline:none;
    height:36px; text-align:right; font-family:'Inter',sans-serif;
}
.cuota-monto input:focus { background:var(--row-hover); }
.cuota-monto input::placeholder { color:var(--text-muted); opacity:.7; }

/* ── PROGRESO ── */
.progreso-bar-wrap { background:var(--border); border-radius:99px; height:10px; overflow:hidden; margin-top:12px; }
.progreso-bar { height:100%; background:linear-gradient(90deg,#16a34a,#22c55e); border-radius:99px; transition:width .3s; width:0%; }
.progreso-label { display:flex; justify-content:space-between; margin-top:6px; font-size:.78rem; color:var(--text-muted); }
.progreso-label strong { color:#16a34a; }

/* ── BOTONES ── */
.btn-primary {
    background:linear-gradient(135deg,#7c3aed,#5b21b6); color:#fff;
    border:none; border-radius:12px; padding:14px 28px;
    font-size:.95rem; font-weight:700; cursor:pointer; width:100%; margin-top:22px;
    transition:opacity .2s, transform .1s; font-family:'Inter',sans-serif;
    box-shadow:0 4px 14px rgba(124,58,237,.35);
    display:flex; align-items:center; justify-content:center; gap:8px;
}
.btn-primary:hover { opacity:.92; transform:translateY(-1px); }
.btn-secondary {
    background:var(--surface2); color:var(--text-label);
    border:1.5px solid var(--border); border-radius:10px;
    padding:8px 16px; font-size:.82rem; font-weight:600;
    cursor:pointer; transition:all .15s; font-family:'Inter',sans-serif;
    display:inline-flex; align-items:center; gap:6px;
}
.btn-secondary:hover { background:var(--border); }
.btn-row { display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:12px; }

/* ── PIE TARJETA ── */
.tarjeta-pie {
    background:var(--je-num-bg); color:#fff; text-align:center;
    padding:8px; font-size:.72rem; font-weight:700; letter-spacing:.06em;
}

/* ── RESPONSIVE ── */
@media (max-width:960px) {
    .sidebar { display:none; }
    .main    { margin-left:0; padding:16px 14px 50px; }
    .cuotas-wrapper       { grid-template-columns:1fr; }
    .cuotas-cols-header   { grid-template-columns:1fr; }
    .col-header.right     { border-left:none; border-top:2px solid var(--je-border); }
    .cuota-col.right      { border-left:none; border-top:2px solid var(--je-border); }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="nuevo_prestamo_especial.php" class="active"><i class="bi bi-stars"></i> Préstamo Migración</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>

        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <div class="page-icon"><i class="bi bi-stars" style="color:#fff;font-size:1.4rem;"></i></div>
            <div>
                <h1>Préstamo Migración <span class="badge-migracion"><i class="bi bi-lightning-charge-fill" style="font-size:.65rem;"></i> Especial</span></h1>
                <p>Registra un préstamo con historial de pagos para migración al sistema</p>
            </div>
        </div>
        <div class="topbar-right">
            <div class="tz-badge"><i class="bi bi-geo-alt-fill"></i> Hermosillo, Sonora (MST)</div>
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- AVISO MIGRACIÓN -->
    <div class="aviso-migracion">
        <i class="bi bi-info-circle-fill"></i>
        <div>
            <strong>Modo Migración:</strong> Este formulario permite ingresar hasta <strong>40 cuotas</strong> con pagos ya realizados. Los pagos se guardan con <code>tipo_pago = 'MIGRACION'</code>. La fecha se ingresa como <strong>DD/MM</strong> y el año se toma automáticamente de la fecha del préstamo. <strong>Basta con ingresar el monto</strong> para que el pago quede registrado — la fila se marcará en verde automáticamente.
        </div>
    </div>

    <!-- ALERTA -->
    <?php if ($alerta): ?>
    <div class="alerta-<?= $alerta_tipo ?>">
        <i class="bi bi-<?= $alerta_tipo === 'ok' ? 'check-circle-fill' : 'x-circle-fill' ?>"></i>
        <?= htmlspecialchars($alerta) ?>
    </div>
    <?php endif; ?>

    <form method="POST" id="formMigracion" onsubmit="return confirmarEnvio()">

        <!-- ═══ DATOS DEL PRÉSTAMO ═══ -->
        <div class="card">
            <div class="card-header morado">
                <i class="bi bi-clipboard-data-fill"></i>
                <h2>Datos del Préstamo</h2>
                <small>Campos requeridos *</small>
            </div>
            <div class="card-body">

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="bi bi-person-fill"></i> Cliente *</label>
                        <select name="id_cliente" id="id_cliente" required>
                            <option value="">— Selecciona cliente —</option>
                            <?php foreach ($clientes_array as $cl): ?>
                            <option value="<?= $cl['id_cliente'] ?>">
                                <?= htmlspecialchars($cl['nombre'] . ' ' . $cl['apellido']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-person-workspace"></i> Asesor *</label>
                        <select name="id_empleado" id="id_empleado" required>
                            <option value="">— Selecciona asesor —</option>
                            <?php foreach ($empleados_array as $em): ?>
                            <option value="<?= $em['id_empleado'] ?>">
                                <?= htmlspecialchars($em['nombre'] . ' ' . $em['apellido']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-calendar3"></i> Fecha de Inicio *</label>
                        <input type="date" name="fecha_inicio" id="fecha_inicio"
                               value="<?= date('Y-m-d') ?>" required max="<?= date('Y-m-d') ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="bi bi-cash-coin"></i> Monto Prestado *</label>
                        <input type="number" name="monto" id="monto" step="0.01" min="1"
                               placeholder="Ej: 5000.00" required oninput="calcularTotales()">
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-percent"></i> % Interés</label>
                        <select name="pct_interes" id="pct_interes" onchange="calcularTotales()">
                            <option value="0.20" selected>20% — Diario (20 días)</option>
                            <option value="0.30">30% — Semanal (6 semanas)</option>
                            <option value="0.40">40% — Semanal (8 semanas)</option>
                            <option value="custom">Personalizado</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-currency-dollar"></i> Interés $ (calculado)</label>
                        <input type="number" name="interes" id="interes" step="0.01"
                               placeholder="0.00" oninput="calcularTotalManual()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="bi bi-check-circle"></i> Total a Pagar</label>
                        <input type="number" name="total_pagar" id="total_pagar"
                               step="0.01" placeholder="0.00" required oninput="calcularPagoDiario()">
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-calendar-day"></i> Cuota por Cobro</label>
                        <input type="number" name="pago_diario" id="pago_diario" step="0.01" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label><i class="bi bi-123"></i> Total Cuotas (máx 40)</label>
                        <input type="number" name="dias" id="dias" min="1" max="40"
                               value="20" placeholder="20" oninput="ajustarCuotas()">
                    </div>
                </div>

                <div class="resumen-grid" id="resumenGrid" style="display:none;">
                    <div class="resumen-item morado">
                        <small>Monto Prestado</small>
                        <strong id="r_monto">$0.00</strong>
                    </div>
                    <div class="resumen-item">
                        <small>Interés</small>
                        <strong id="r_interes">$0.00</strong>
                    </div>
                    <div class="resumen-item azul">
                        <small>Total a Pagar</small>
                        <strong id="r_total">$0.00</strong>
                    </div>
                    <div class="resumen-item">
                        <small>Cuota</small>
                        <strong id="r_cuota">$0.00</strong>
                    </div>
                    <div class="resumen-item verde">
                        <small>Saldo Pendiente</small>
                        <strong id="r_saldo">$0.00</strong>
                    </div>
                </div>

            </div>
        </div>

        <!-- ═══ TARJETA J.E. ═══ -->
        <div class="card">
            <div class="card-header azul">
                <i class="bi bi-calendar2-week-fill"></i>
                <h2>Registro de Pagos — Tarjeta J.E.</h2>
                <small>Fecha en formato DD/MM — máx. 40 cuotas</small>
            </div>
            <div class="card-body" style="padding:0;">

                <div class="tarjeta-je" id="tarjetaJE">

                    <!-- Encabezado tarjeta -->
                    <div class="tarjeta-je-header">
                        <div>
                            <div class="tarjeta-je-brand">J.E.</div>
                            <small>SU MEJOR OPCIÓN EN PRÉSTAMOS</small>
                        </div>
                        <div style="flex:1;padding:0 20px;">
                            <div style="font-size:.68rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px;">Nombre del Cliente</div>
                            <div style="font-size:.92rem;font-weight:700;color:var(--text);" id="nombre_display">—</div>
                        </div>
                        <div class="tarjeta-je-monto" id="monto_display">$ 0.00</div>
                    </div>

                    <!-- Info resumen tarjeta -->
                    <div class="tarjeta-info">
                        <div class="tarjeta-info-item">
                            <label>Fecha de Inicio</label>
                            <span id="fi_display">—</span>
                        </div>
                        <div class="tarjeta-info-item">
                            <label>Cuota Diaria</label>
                            <span id="cuota_display">$0.00</span>
                        </div>
                        <div class="tarjeta-info-item">
                            <label>Total a Pagar</label>
                            <span id="total_display">$0.00</span>
                        </div>
                    </div>

                    <!-- Cabecera columnas -->
                    <div class="cuotas-cols-header">
                        <div class="col-header">
                            <div>No.</div>
                            <div>FECHA (DD/MM)</div>
                            <div>CUOTA ($)</div>
                        </div>
                        <div class="col-header right">
                            <div>No.</div>
                            <div>FECHA (DD/MM)</div>
                            <div>CUOTA ($)</div>
                        </div>
                    </div>

                    <!-- Cuotas: izquierda 1-20, derecha 21-40 -->
                    <div class="cuotas-wrapper">

                        <!-- COLUMNA IZQUIERDA: 1 → 20 -->
                        <div class="cuota-col left" id="colIzq">
                        <?php for ($i = 1; $i <= 20; $i++): ?>
                            <div class="cuota-row" id="cuotaRow<?= $i ?>" data-cuota="<?= $i ?>">
                                <div class="cuota-num" id="cuotaNum<?= $i ?>"><?= $i ?></div>
                                <div class="cuota-fecha">
                                    <input type="text" class="fecha-display"
                                           id="fechaDisplay<?= $i ?>" placeholder="DD/MM" maxlength="5"
                                           oninput="formatFechaInput(this, <?= $i ?>)"
                                           onblur="parseFechaInput(<?= $i ?>)" autocomplete="off">
                                    <input type="hidden" name="pagos[<?= $i ?>][fecha]" id="fechaPago<?= $i ?>">
                                </div>
                                <div class="cuota-monto">
                                    <input type="number" name="pagos[<?= $i ?>][monto]"
                                           id="montoPago<?= $i ?>" step="0.01" min="0" placeholder="0.00"
                                           oninput="cuotaCambiada(<?= $i ?>)" autocomplete="off">
                                </div>
                            </div>
                        <?php endfor; ?>
                        </div>

                        <!-- COLUMNA DERECHA: 21 → 40 -->
                        <div class="cuota-col right" id="colDer">
                        <?php for ($i = 21; $i <= 40; $i++): ?>
                            <div class="cuota-row" id="cuotaRow<?= $i ?>" data-cuota="<?= $i ?>">
                                <div class="cuota-num" id="cuotaNum<?= $i ?>"><?= $i ?></div>
                                <div class="cuota-fecha">
                                    <input type="text" class="fecha-display"
                                           id="fechaDisplay<?= $i ?>" placeholder="DD/MM" maxlength="5"
                                           oninput="formatFechaInput(this, <?= $i ?>)"
                                           onblur="parseFechaInput(<?= $i ?>)" autocomplete="off">
                                    <input type="hidden" name="pagos[<?= $i ?>][fecha]" id="fechaPago<?= $i ?>">
                                </div>
                                <div class="cuota-monto">
                                    <input type="number" name="pagos[<?= $i ?>][monto]"
                                           id="montoPago<?= $i ?>" step="0.01" min="0" placeholder="0.00"
                                           oninput="cuotaCambiada(<?= $i ?>)" autocomplete="off">
                                </div>
                            </div>
                        <?php endfor; ?>
                        </div>

                    </div><!-- /cuotas-wrapper -->

                    <div class="tarjeta-pie">
                        ATENCIÓN AL CLIENTE &nbsp;|&nbsp; 6442 22 8720
                    </div>

                </div><!-- /tarjeta-je -->

                <!-- Progreso -->
                <div style="padding:20px 22px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;flex-wrap:wrap;gap:10px;">
                        <span style="font-size:.84rem;font-weight:700;color:var(--text-label);">
                            <i class="bi bi-graph-up-arrow" style="color:#16a34a;"></i>
                            Progreso de pagos ingresados
                        </span>
                        <div class="btn-row" style="margin-top:0;">
                            <button type="button" class="btn-secondary" onclick="llenarCuotaAutomatica()">
                                <i class="bi bi-lightning-charge-fill"></i> Llenar cuotas completas
                            </button>
                            <button type="button" class="btn-secondary" onclick="limpiarCuotas()">
                                <i class="bi bi-x-circle"></i> Limpiar todo
                            </button>
                        </div>
                    </div>
                    <div class="progreso-bar-wrap">
                        <div class="progreso-bar" id="progresoBar"></div>
                    </div>
                    <div class="progreso-label">
                        <span>Cuotas llenadas: <strong id="cuotasLlenadas">0</strong> / <span id="totalCuotas">40</span></span>
                        <span>Total abonado: <strong id="totalAbonado">$0.00</strong> &nbsp;|&nbsp; Saldo: <strong id="saldoCalc" style="color:#dc2626;">$0.00</strong></span>
                    </div>
                </div>

            </div>
        </div>

        <button type="submit" class="btn-primary">
            <i class="bi bi-check-circle-fill"></i>
            Registrar Préstamo de Migración
        </button>

    </form>
</main>
</div><!-- /app -->

<script>
/* ═══ DATOS PHP → JS ═══ */
const clientes = {
<?php foreach ($clientes_array as $cl): ?>
    <?= $cl['id_cliente'] ?>: "<?= addslashes($cl['nombre'] . ' ' . $cl['apellido']) ?>",
<?php endforeach; ?>
};

/* ═══ TEMA (sincronizado con pje_tema) ═══ */
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ═══ RELOJ ═══ */
function actualizarReloj() {
    const n = new Date(), pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ═══ FORMATO DD/MM ═══ */
function formatFechaInput(el, idx) {
    let raw = el.value.replace(/\D/g, '');
    if (raw.length > 4) raw = raw.substring(0, 4);
    el.value = raw.length > 2 ? raw.substring(0, 2) + '/' + raw.substring(2) : raw;
    if (el.value.length === 5) parseFechaInput(idx);
}
function parseFechaInput(idx) {
    const display = document.getElementById('fechaDisplay' + idx);
    const hidden  = document.getElementById('fechaPago'   + idx);
    const val     = display ? display.value.trim() : '';
    if (!val || val.length < 5) { if (hidden) hidden.value = ''; cuotaCambiada(idx); return; }
    const parts = val.split('/');
    if (parts.length !== 2) { if (hidden) hidden.value = ''; cuotaCambiada(idx); return; }
    const dd = parts[0].padStart(2,'0'), mm = parts[1].padStart(2,'0');
    const d = parseInt(dd), m = parseInt(mm);
    if (d < 1 || d > 31 || m < 1 || m > 12) { if (hidden) hidden.value = ''; cuotaCambiada(idx); return; }
    hidden.value = `${getAnioReferencia()}-${mm}-${dd}`;
    cuotaCambiada(idx);
}
function getAnioReferencia() {
    const fi = document.getElementById('fecha_inicio').value;
    return fi ? new Date(fi + 'T00:00:00').getFullYear() : new Date().getFullYear();
}

/* ═══ UTILIDADES ═══ */
function fmt(n) { return '$' + parseFloat(n||0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,','); }
function formatFechaLarga(f) {
    if (!f) return '—';
    const [y,m,d] = f.split('-');
    return `${d}/${m}/${y}`;
}

/* ═══ CÁLCULOS ═══ */
const DIAS_SUGERIDOS = { '0.20':20, '0.30':20, '0.40':20 };
function calcularTotales() {
    const monto  = parseFloat(document.getElementById('monto').value) || 0;
    const pctSel = document.getElementById('pct_interes').value;
    if (pctSel === 'custom' || monto <= 0) return;
    const pct     = parseFloat(pctSel);
    const interes = parseFloat((monto * pct).toFixed(2));
    const total   = parseFloat((monto + interes).toFixed(2));
    const diasActual = parseInt(document.getElementById('dias').value) || 0;
    const diasSug    = DIAS_SUGERIDOS[pctSel] || 20;
    const diasUsar   = diasActual > 0 ? diasActual : diasSug;
    const cuota      = diasUsar > 0 ? parseFloat((total / diasUsar).toFixed(2)) : 0;
    document.getElementById('interes').value     = interes.toFixed(2);
    document.getElementById('total_pagar').value = total.toFixed(2);
    document.getElementById('dias').value        = diasUsar;
    document.getElementById('pago_diario').value = cuota.toFixed(2);
    recalcularFilasNecesarias(); actualizarResumen(); actualizarTarjeta();
}
function calcularTotalManual() {
    const monto   = parseFloat(document.getElementById('monto').value) || 0;
    const interes = parseFloat(document.getElementById('interes').value) || 0;
    const total   = parseFloat((monto + interes).toFixed(2));
    const dias    = parseInt(document.getElementById('dias').value) || 20;
    const cuota   = dias > 0 ? parseFloat((total / dias).toFixed(2)) : 0;
    document.getElementById('total_pagar').value = total.toFixed(2);
    document.getElementById('pago_diario').value = cuota.toFixed(2);
    recalcularFilasNecesarias(); actualizarResumen(); actualizarTarjeta();
}
function calcularPagoDiario() {
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    const dias  = parseInt(document.getElementById('dias').value) || 20;
    document.getElementById('pago_diario').value = (dias > 0 ? parseFloat((total / dias).toFixed(2)) : 0).toFixed(2);
    recalcularFilasNecesarias(); actualizarResumen(); actualizarTarjeta();
}
function ajustarCuotas() {
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    const dias  = parseInt(document.getElementById('dias').value) || 20;
    document.getElementById('pago_diario').value = (dias > 0 ? parseFloat((total / dias).toFixed(2)) : 0).toFixed(2);
    recalcularFilasNecesarias(); actualizarResumen(); actualizarTarjeta();
}
function ajustarDesdeCuota() {
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    const cuota = parseFloat(document.getElementById('pago_diario').value) || 0;
    if (cuota > 0 && total > 0) document.getElementById('dias').value = Math.min(Math.ceil(total/cuota), 40);
    recalcularFilasNecesarias(); actualizarResumen(); actualizarTarjeta();
}

/* ═══ RESUMEN Y TARJETA ═══ */
function actualizarResumen() {
    const monto   = parseFloat(document.getElementById('monto').value) || 0;
    const interes = parseFloat(document.getElementById('interes').value) || 0;
    const total   = parseFloat(document.getElementById('total_pagar').value) || 0;
    const cuota   = parseFloat(document.getElementById('pago_diario').value) || 0;
    if (monto > 0) {
        document.getElementById('resumenGrid').style.display = 'grid';
        document.getElementById('r_monto').textContent   = fmt(monto);
        document.getElementById('r_interes').textContent = fmt(interes);
        document.getElementById('r_total').textContent   = fmt(total);
        document.getElementById('r_cuota').textContent   = fmt(cuota);
    }
    actualizarProgreso();
}
function actualizarTarjeta() {
    const monto = parseFloat(document.getElementById('monto').value) || 0;
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    const cuota = parseFloat(document.getElementById('pago_diario').value) || 0;
    const fecha = document.getElementById('fecha_inicio').value;
    const idCli = document.getElementById('id_cliente').value;
    document.getElementById('monto_display').textContent  = fmt(monto);
    document.getElementById('total_display').textContent  = fmt(total);
    document.getElementById('cuota_display').textContent  = fmt(cuota);
    document.getElementById('fi_display').textContent     = fecha ? formatFechaLarga(fecha) : '—';
    document.getElementById('nombre_display').textContent = (idCli && clientes[idCli]) ? clientes[idCli] : '—';
}

/* ═══ FILAS DINÁMICAS ═══ */
let filasVisibles = 1;
function recalcularFilasNecesarias() {
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    const cuota = parseFloat(document.getElementById('pago_diario').value) || 0;
    if (total <= 0 || cuota <= 0) {
        const dias = parseInt(document.getElementById('dias').value) || 20;
        mostrarFilas(Math.min(dias, 40)); return;
    }
    let abonado = 0, ultimaFila = 0;
    for (let i = 1; i <= 40; i++) {
        const m = parseFloat(document.getElementById('montoPago' + i)?.value) || 0;
        if (m > 0) { abonado += m; ultimaFila = i; }
    }
    const restante = total - abonado;
    let necesarias;
    if (restante <= 0.009)   necesarias = ultimaFila;
    else if (ultimaFila===0) necesarias = parseInt(document.getElementById('dias').value) || Math.ceil(total/cuota);
    else                     necesarias = ultimaFila + Math.ceil(restante/cuota);
    necesarias = Math.min(Math.max(necesarias,1),40);
    if (ultimaFila === 0) document.getElementById('dias').value = necesarias;
    mostrarFilas(necesarias);
}
function mostrarFilas(n) {
    n = Math.min(Math.max(parseInt(n)||1,1),40);
    filasVisibles = n;
    for (let i = 1; i <= 20; i++) {
        const row = document.getElementById('cuotaRow'+i);
        if (row) row.style.display = (i<=n) ? 'grid' : 'none';
    }
    const colDer  = document.getElementById('colDer');
    const colHDer = document.querySelector('.col-header.right');
    if (n > 20) {
        if (colDer) colDer.style.display = ''; if (colHDer) colHDer.style.display = '';
        for (let i = 21; i <= 40; i++) {
            const row = document.getElementById('cuotaRow'+i);
            if (row) row.style.display = (i<=n) ? 'grid' : 'none';
        }
    } else {
        if (colDer) colDer.style.display = 'none'; if (colHDer) colHDer.style.display = 'none';
    }
    document.getElementById('totalCuotas').textContent = n;
    actualizarProgreso();
}

/* ═══ PROGRESO ═══ */
function actualizarProgreso() {
    const total = parseFloat(document.getElementById('total_pagar').value) || 0;
    let abonado = 0, llenas = 0;
    for (let i = 1; i <= 40; i++) {
        const m = parseFloat(document.getElementById('montoPago'+i)?.value) || 0;
        if (m > 0) { abonado += m; llenas++; }
    }
    const saldo = total - abonado;
    const pct   = total > 0 ? Math.min((abonado/total)*100,100) : 0;
    document.getElementById('progresoBar').style.width    = pct + '%';
    document.getElementById('cuotasLlenadas').textContent = llenas;
    document.getElementById('totalAbonado').textContent   = fmt(abonado);
    document.getElementById('saldoCalc').textContent      = fmt(Math.max(saldo,0));
    document.getElementById('saldoCalc').style.color      = saldo<=0 ? '#16a34a' : '#dc2626';
    if (document.getElementById('r_saldo'))
        document.getElementById('r_saldo').textContent = fmt(Math.max(saldo,0));
}

/* ═══ EVENTO CUOTA ═══ */
function cuotaCambiada(idx) {
    const m   = parseFloat(document.getElementById('montoPago'+idx)?.value) || 0;
    const row = document.getElementById('cuotaRow'+idx);
    const num = document.getElementById('cuotaNum'+idx);
    if (m > 0) {
        row?.classList.add('cuota-filled');
        if (num) { num.style.background = '#16a34a'; num.classList.add('pagado'); }
        const fechaHidden  = document.getElementById('fechaPago'   +idx);
        const fechaDisplay = document.getElementById('fechaDisplay'+idx);
        if (fechaHidden && !fechaHidden.value) {
            const fechaCalc = calcularFechaCuota(idx);
            if (fechaCalc) {
                fechaHidden.value = fechaCalc;
                const partes = fechaCalc.split('-');
                if (partes.length===3 && fechaDisplay) fechaDisplay.value = partes[2]+'/'+partes[1];
            }
        }
    } else {
        row?.classList.remove('cuota-filled');
        if (num) { num.style.background=''; num.classList.remove('pagado'); }
    }
    recalcularFilasNecesarias();
}
function calcularFechaCuota(idx) {
    const fi = document.getElementById('fecha_inicio').value;
    if (!fi) return null;
    let fecha = new Date(fi+'T00:00:00');
    fecha.setDate(fecha.getDate()+1);
    let contador = 1;
    while (contador < idx) {
        while (fecha.getDay()===0) fecha.setDate(fecha.getDate()+1);
        if (contador===idx-1) break;
        fecha.setDate(fecha.getDate()+1);
        contador++;
    }
    while (fecha.getDay()===0) fecha.setDate(fecha.getDate()+1);
    const dd=fecha.getDate().toString().padStart(2,'0');
    const mm=(fecha.getMonth()+1).toString().padStart(2,'0');
    return `${fecha.getFullYear()}-${mm}-${dd}`;
}

/* ═══ AUTO-FILL FECHAS ═══ */
function autoFillFechas() {
    const fechaInicio = document.getElementById('fecha_inicio').value;
    if (!fechaInicio) return;
    const n   = filasVisibles || parseInt(document.getElementById('dias').value) || 20;
    let fecha = new Date(fechaInicio+'T00:00:00');
    fecha.setDate(fecha.getDate()+1);
    for (let i = 1; i <= Math.min(n,40); i++) {
        while (fecha.getDay()===0) fecha.setDate(fecha.getDate()+1);
        const dd=fecha.getDate().toString().padStart(2,'0');
        const mm=(fecha.getMonth()+1).toString().padStart(2,'0');
        const yyyy=fecha.getFullYear();
        const displayEl=document.getElementById('fechaDisplay'+i);
        const hiddenEl =document.getElementById('fechaPago'+i);
        if (displayEl) displayEl.value=`${dd}/${mm}`;
        if (hiddenEl)  hiddenEl.value =`${yyyy}-${mm}-${dd}`;
        cuotaCambiada(i);
        fecha.setDate(fecha.getDate()+1);
    }
}

/* ═══ LLENAR / LIMPIAR ═══ */
function llenarCuotaAutomatica() {
    const fechaInicio = document.getElementById('fecha_inicio').value;
    const cuota       = parseFloat(document.getElementById('pago_diario').value) || 0;
    if (!fechaInicio || cuota<=0) { alert('Primero completa la Fecha de Inicio y la Cuota por cobro.'); return; }
    const n   = filasVisibles || parseInt(document.getElementById('dias').value) || 20;
    const hoy = new Date().toISOString().split('T')[0];
    let fecha = new Date(fechaInicio+'T00:00:00');
    fecha.setDate(fecha.getDate()+1);
    let asignadas = 0;
    for (let i = 1; i <= Math.min(n,40); i++) {
        while (fecha.getDay()===0) fecha.setDate(fecha.getDate()+1);
        const dd=fecha.getDate().toString().padStart(2,'0');
        const mm=(fecha.getMonth()+1).toString().padStart(2,'0');
        const yyyy=fecha.getFullYear();
        const fechaStr=`${yyyy}-${mm}-${dd}`;
        const displayEl=document.getElementById('fechaDisplay'+i);
        const hiddenEl =document.getElementById('fechaPago'+i);
        const montoEl  =document.getElementById('montoPago'+i);
        if (displayEl) displayEl.value=`${dd}/${mm}`;
        if (hiddenEl)  hiddenEl.value =fechaStr;
        if (fechaStr<=hoy) { if (montoEl) montoEl.value=cuota.toFixed(2); asignadas++; }
        cuotaCambiada(i);
        fecha.setDate(fecha.getDate()+1);
    }
    alert(`Fechas llenadas. ${asignadas} cuota(s) con monto asignado hasta hoy (sin domingos).`);
}
function limpiarCuotas() {
    if (!confirm('¿Deseas limpiar todos los cuadros de pagos?')) return;
    for (let i=1; i<=40; i++) {
        const di=document.getElementById('fechaDisplay'+i);
        const fi=document.getElementById('fechaPago'+i);
        const mi=document.getElementById('montoPago'+i);
        if (di) di.value=''; if (fi) fi.value=''; if (mi) mi.value='';
        cuotaCambiada(i);
    }
    recalcularFilasNecesarias();
}

/* ═══ CONFIRMACIÓN ═══ */
function confirmarEnvio() {
    let tieneAlguno = false;
    for (let i=1; i<=40; i++) {
        if ((parseFloat(document.getElementById('montoPago'+i)?.value)||0)>0) { tieneAlguno=true; break; }
    }
    return tieneAlguno
        ? confirm('¿Confirmas el registro del préstamo con los pagos de migración?')
        : confirm('No has ingresado ningún pago.\n¿Guardar el préstamo sin pagos?');
}

/* ═══ EVENTOS GLOBALES ═══ */
document.getElementById('id_cliente').addEventListener('change', actualizarTarjeta);
document.getElementById('fecha_inicio').addEventListener('change', function() {
    actualizarTarjeta();
    if (this.value) autoFillFechas();
});
document.getElementById('pct_interes').addEventListener('change', function() {
    if (this.value !== 'custom') calcularTotales();
});
document.getElementById('pago_diario').addEventListener('input', ajustarDesdeCuota);

document.addEventListener('DOMContentLoaded', function() {
    recalcularFilasNecesarias();
    actualizarProgreso();
    const fi = document.getElementById('fecha_inicio').value;
    if (fi) autoFillFechas();
});
</script>
</body>
</html>

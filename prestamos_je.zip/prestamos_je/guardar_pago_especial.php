<?php
date_default_timezone_set('America/Hermosillo');

include("seguridad.php");
include("conexion.php");

/* =========================
   RECIBIR DATOS
========================= */
$id_prestamo = $_POST['id_prestamo'] ?? 0;
$monto = $_POST['monto'] ?? 0;
$interes = $_POST['interes'] ?? 0;

$fecha = date("Y-m-d H:i:s");

/* VALIDAR */
if($id_prestamo == 0 || $monto <= 0){
    die("Error: Datos inválidos");
}

/* =========================
   OBTENER SALDO ACTUAL
========================= */
$prestamo = $conexion->query("
SELECT saldo_actual
FROM prestamos
WHERE id_prestamo = '$id_prestamo'
");

$p = $prestamo->fetch_assoc();

if(!$p){
    die("Error: Préstamo no encontrado");
}

$saldo_actual = $p['saldo_actual'];

/* =========================
   SEPARAR CAPITAL E INTERES
========================= */
$monto_interes = min($interes, $monto);
$monto_capital = $monto - $monto_interes;

/* =========================
   CALCULAR NUEVO SALDO
========================= */
$nuevo_saldo = $saldo_actual - $monto_capital;

if($nuevo_saldo < 0){
    $nuevo_saldo = 0;
}

/* =========================
   GUARDAR PAGO
========================= */
$conexion->query("
INSERT INTO pagos
(
id_prestamo,
fecha_pago,
monto_pagado,
interes
)
VALUES
(
'$id_prestamo',
'$fecha',
'$monto',
'$monto_interes'
)
");

/* =========================
   ACTUALIZAR PRESTAMO
========================= */
$conexion->query("
UPDATE prestamos
SET saldo_actual='$nuevo_saldo'
WHERE id_prestamo='$id_prestamo'
");

/* =========================
   SI YA LIQUIDÓ
========================= */
if($nuevo_saldo <= 0){

    $conexion->query("
    UPDATE prestamos
    SET estado='PAGADO',
    fecha_liquidacion=CURDATE()
    WHERE id_prestamo='$id_prestamo'
    ");

}

/* =========================
   REDIRECCION
========================= */
header("Location: clientes_atrasados.php");
exit;
?>
<?php
include("seguridad.php");
include("conexion.php");

$rol    = $_SESSION['rol']        ?? 'ASESOR';
$user   = $_SESSION['usuario']    ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);
$hoy    = date("Y-m-d");

$id_prestamo = intval($_GET['id_prestamo'] ?? 0);
if ($id_prestamo <= 0) { header("Location: index.php"); exit; }

// Datos del préstamo + cliente + asesor
$rp = $conexion->query("
    SELECT pr.*,
           c.nombre   AS c_nombre,  c.apellido   AS c_apellido,
           c.telefono AS c_tel,     c.direccion  AS c_dir,
           c.curp     AS c_curp,    c.rfc        AS c_rfc,
           e.nombre   AS asesor,    e.telefono   AS asesor_tel,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_fin
    FROM   prestamos pr
    INNER JOIN clientes  c ON c.id_cliente  = pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado = pr.id_empleado
    WHERE  pr.id_prestamo = $id_prestamo
    LIMIT 1
");
if (!$rp || $rp->num_rows === 0) { echo "Préstamo no encontrado."; exit; }
$p = $rp->fetch_assoc();

// Control de acceso
if ($rol === 'ASESOR' && intval($p['id_empleado']) !== $id_emp) { echo "Sin acceso."; exit; }

// Total pagado
$rq = $conexion->query("SELECT COALESCE(SUM(monto_pagado),0) AS t FROM pagos WHERE id_prestamo=$id_prestamo");
$total_pagado = (float)$rq->fetch_assoc()['t'];
$saldo        = max(0, (float)$p['total_pagar'] - $total_pagado);

// ── Tabla de amortización ─────────────────────────────────────────
// Detecta frecuencia: si el préstamo tiene campo 'frecuencia' se usa, sino se calcula semanal
$dias_total   = intval($p['dias']);
$frecuencia   = isset($p['frecuencia']) ? intval($p['frecuencia']) : 7; // días entre cuotas (7=semanal por defecto)
if ($frecuencia <= 0) $frecuencia = 7;
$num_cuotas   = (int)ceil($dias_total / $frecuencia);
if ($num_cuotas < 1) $num_cuotas = 1;
$cuota_base   = floor(((float)$p['total_pagar'] / $num_cuotas) * 100) / 100;
$cuota_ultima = round((float)$p['total_pagar'] - $cuota_base * ($num_cuotas - 1), 2);

$lbl_frecuencia = match($frecuencia) {
    1  => 'Diario',
    7  => 'Semanal',
    14 => 'Quincenal',
    15 => 'Quincenal',
    30 => 'Mensual',
    default => "Cada $frecuencia días",
};

// Generar tabla de amortización
$cuotas_tabla = [];
$saldo_restante = (float)$p['total_pagar'];
$fecha_cuota = new DateTime($p['fecha_inicio']);
for ($i = 1; $i <= $num_cuotas; $i++) {
    $fecha_cuota->modify("+{$frecuencia} days");
    $monto_cuota = ($i === $num_cuotas) ? $cuota_ultima : $cuota_base;
    $saldo_restante = max(0, round($saldo_restante - $monto_cuota, 2));
    $cuotas_tabla[] = [
        'num'    => $i,
        'fecha'  => $fecha_cuota->format('Y-m-d'),
        'cuota'  => $monto_cuota,
        'saldo'  => $saldo_restante,
    ];
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contrato #<?= $id_prestamo ?> | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}

/* ── SIDEBAR ── */
.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,0.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;line-height:1.2;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;background:#0f172a;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-hoy{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}

/* ── MAIN ── */
.main{margin-left:240px;flex:1;padding:24px 28px 48px;}

/* ── CONTROLES ── */
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.35rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:10px;}
.btn-theme{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;}
.btn-theme:hover{color:#0f172a;border-color:#2563eb;}
.btn-print{display:inline-flex;align-items:center;gap:7px;background:#0f172a;color:white;border:none;border-radius:10px;padding:9px 18px;font-size:.84rem;font-weight:600;cursor:pointer;transition:background .15s;}
.btn-print:hover{background:#1e293b;}
.btn-back{display:inline-flex;align-items:center;gap:7px;background:white;color:#64748b;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 16px;font-size:.84rem;font-weight:600;text-decoration:none;transition:all .15s;}
.btn-back:hover{border-color:#2563eb;color:#2563eb;}

/* ── CONTRATO (hoja imprimible) ── */
.contrato{
    background:white;
    max-width:820px;
    margin:0 auto;
    border-radius:16px;
    border:1px solid #e2e8f0;
    box-shadow:0 4px 20px rgba(0,0,0,.08);
    overflow:hidden;
}

/* Cabecera del contrato */
.contrato-header{
    background:linear-gradient(135deg,#0f172a,#1e3a8a);
    padding:28px 36px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
}
.ch-brand{color:white;}
.ch-brand h1{font-size:1.4rem;font-weight:800;letter-spacing:-.3px;margin-bottom:3px;}
.ch-brand p{font-size:.75rem;color:#93c5fd;letter-spacing:.06em;}
.ch-folio{text-align:right;color:white;}
.ch-folio .folio-num{font-size:1.8rem;font-weight:800;letter-spacing:1px;line-height:1;}
.ch-folio .folio-lbl{font-size:.68rem;color:#93c5fd;text-transform:uppercase;letter-spacing:.08em;margin-top:3px;}

.contrato-titulo{
    background:#eff6ff;
    border-bottom:2px solid #bfdbfe;
    padding:14px 36px;
    text-align:center;
}
.contrato-titulo h2{font-size:1rem;font-weight:800;color:#1d4ed8;text-transform:uppercase;letter-spacing:.12em;}

.contrato-body{padding:28px 36px;}

/* Secciones */
.seccion{margin-bottom:22px;}
.seccion-titulo{
    font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;
    color:#64748b;border-bottom:1.5px solid #e2e8f0;padding-bottom:6px;margin-bottom:12px;
    display:flex;align-items:center;gap:6px;
}
.seccion-titulo i{font-size:.8rem;}

/* Grilla de datos */
.datos-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 24px;}
.dato{display:flex;flex-direction:column;gap:2px;}
.dato-lbl{font-size:.68rem;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.06em;}
.dato-val{font-size:.9rem;font-weight:600;color:#0f172a;border-bottom:1px dotted #e2e8f0;padding-bottom:3px;}

/* Resumen financiero en cajas */
.resumen-fin{
    display:grid;grid-template-columns:repeat(4,1fr);gap:12px;
    background:#f8fafc;border-radius:12px;padding:16px;
    margin-bottom:22px;border:1px solid #e2e8f0;
}
.rf-item{text-align:center;}
.rf-val{font-size:1.1rem;font-weight:800;color:#0f172a;line-height:1;margin-bottom:3px;}
.rf-lbl{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;}
.rf-item.azul  .rf-val{color:#2563eb;}
.rf-item.verde .rf-val{color:#16a34a;}
.rf-item.rojo  .rf-val{color:#dc2626;}

/* Tabla de amortización */
.tabla-amort{width:100%;border-collapse:collapse;font-size:.8rem;margin-top:4px;}
.tabla-amort thead th{padding:9px 12px;text-align:left;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#64748b;background:#f8fafc;border-bottom:2px solid #e2e8f0;}
.tabla-amort thead th:last-child,.tabla-amort tbody td:last-child{text-align:right;}
.tabla-amort thead th:not(:first-child),.tabla-amort tbody td:not(:first-child){text-align:right;}
.tabla-amort thead th:first-child,.tabla-amort tbody td:first-child{text-align:center;}
.tabla-amort tbody td{padding:8px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle;}
.tabla-amort tbody tr:nth-child(even){background:#fafbfc;}
.tabla-amort tbody tr:last-child td{font-weight:700;color:#dc2626;}
.tabla-amort tfoot td{padding:10px 12px;font-weight:700;border-top:2px solid #0f172a;font-size:.82rem;}
.num-badge{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;background:#eff6ff;color:#2563eb;border-radius:6px;font-size:.7rem;font-weight:700;}

/* Cláusulas */
.clausulas{font-size:.78rem;color:#475569;line-height:1.65;}
.clausulas ol{padding-left:18px;margin-top:6px;}
.clausulas li{margin-bottom:6px;}

/* Firmas */
.firmas{
    display:grid;grid-template-columns:1fr 1fr;gap:40px;
    margin-top:36px;
}
.firma{text-align:center;}
.firma-linea{border-top:1.5px solid #0f172a;padding-top:8px;margin-top:40px;}
.firma-nombre{font-size:.82rem;font-weight:700;color:#0f172a;}
.firma-cargo{font-size:.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.07em;margin-top:2px;}

/* Pie de contrato */
.contrato-footer{
    border-top:2px solid #e2e8f0;padding:12px 36px;
    display:flex;justify-content:space-between;align-items:center;
    background:#f8fafc;
}
.contrato-footer span{font-size:.68rem;color:#94a3b8;}

/* ── DARK MODE (solo pantalla) ── */
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .topbar-sub{color:#94a3b8;}
[data-theme="dark"] .btn-theme{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .btn-back{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .contrato{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .contrato-titulo{background:#172554;border-bottom-color:#1e3a8a;}
[data-theme="dark"] .seccion-titulo{border-bottom-color:#1e293b;color:#475569;}
[data-theme="dark"] .dato-val{color:#e2e8f0;border-bottom-color:#1e293b;}
[data-theme="dark"] .resumen-fin{background:#0f172a;border-color:#1e293b;}
[data-theme="dark"] .rf-val{color:#e2e8f0;}
[data-theme="dark"] .tabla-amort thead th{background:#0f172a;border-bottom-color:#1e293b;}
[data-theme="dark"] .tabla-amort tbody td{border-bottom-color:#1a2235;}
[data-theme="dark"] .tabla-amort tbody tr:nth-child(even){background:#0d1526;}
[data-theme="dark"] .tabla-amort tfoot td{border-top-color:#e2e8f0;}
[data-theme="dark"] .contrato-footer{background:#0f172a;border-top-color:#1e293b;}
[data-theme="dark"] .clausulas{color:#94a3b8;}
[data-theme="dark"] .firma-linea{border-top-color:#e2e8f0;}
[data-theme="dark"] .firma-nombre{color:#e2e8f0;}

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar{display:none;}
    .main{margin-left:0;padding:14px 14px 40px;}
    .datos-grid{grid-template-columns:1fr;}
    .resumen-fin{grid-template-columns:1fr 1fr;}
    .firmas{grid-template-columns:1fr;}
}

/* ── PRINT ── */
@media print{
    .sidebar,.topbar,.btn-print,.btn-back,.btn-theme{display:none!important;}
    .main{margin-left:0!important;padding:0!important;}
    .app{display:block;}
    .contrato{box-shadow:none!important;border:none!important;max-width:100%;}
    body{background:white!important;}
    [data-theme="dark"] .contrato{background:white!important;}
    [data-theme="dark"] .dato-val{color:#0f172a!important;}
    [data-theme="dark"] .tabla-amort thead th{background:#f8fafc!important;color:#64748b!important;}
    [data-theme="dark"] .tabla-amort tbody td{color:#0f172a!important;}
    [data-theme="dark"] .contrato-footer{background:#f8fafc!important;}
    [data-theme="dark"] .resumen-fin{background:#f8fafc!important;}
    .tabla-amort tbody tr{break-inside:avoid;}
}
</style>
</head>
<body>
<div class="app">

<!-- ══════════ SIDEBAR ══════════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d/m/Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check-fill"></i> Cobranza</a>
        <div class="sb-section">Clientes</div>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus-fill"></i> Nuevo Cliente</a>
        <div class="sb-section">Préstamos</div>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus-fill"></i> Nuevo Préstamo</a>
        <?php if (in_array($rol, ['GERENTE','SUPERVISOR','ADMIN'])): ?>
        <div class="sb-section">Reportes</div>
        <a href="reporte_cartera.php"><i class="bi bi-bar-chart-fill"></i> Cartera</a>
        <a href="corte_caja.php"><i class="bi bi-safe2-fill"></i> Corte de Caja</a>
        <?php endif; ?>
        <?php if ($rol === 'GERENTE'): ?>
        <div class="sb-section">Administración</div>
        <a href="caja.php"><i class="bi bi-safe-fill"></i> Caja</a>
        <a href="empleados.php"><i class="bi bi-people-fill"></i> Empleados</a>
        <?php endif; ?>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══════════ MAIN ══════════ -->
<main class="main">

    <!-- Controles pantalla -->
    <div class="topbar">
        <div>
            <div class="topbar-title"><i class="bi bi-file-earmark-text-fill" style="color:#7c3aed;font-size:1.1rem;"></i> Contrato de Préstamo</div>
            <div class="topbar-sub">Folio #<?= str_pad($id_prestamo,6,'0',STR_PAD_LEFT) ?> — <?= htmlspecialchars($p['c_nombre'].' '.$p['c_apellido']) ?></div>
        </div>
        <div class="topbar-right">
            <a href="estado_cuenta.php?id_prestamo=<?= $id_prestamo ?>" class="btn-back">
                <i class="bi bi-file-text"></i> Estado de Cuenta
            </a>
            <button class="btn-print" onclick="window.print()">
                <i class="bi bi-printer-fill"></i> Imprimir / PDF
            </button>
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ════ DOCUMENTO CONTRATO ════ -->
    <div class="contrato">

        <!-- Cabecera -->
        <div class="contrato-header">
            <div class="ch-brand">
                <h1>💰 Préstamos J.E.</h1>
                <p>Sistema Financiero Interno · <?= date('d/m/Y') ?></p>
            </div>
            <div class="ch-folio">
                <div class="folio-num">#<?= str_pad($id_prestamo,6,'0',STR_PAD_LEFT) ?></div>
                <div class="folio-lbl">Folio de contrato</div>
            </div>
        </div>

        <!-- Título -->
        <div class="contrato-titulo">
            <h2>Contrato de Préstamo Personal</h2>
        </div>

        <div class="contrato-body">

            <!-- Sección: Datos del cliente -->
            <div class="seccion">
                <div class="seccion-titulo"><i class="bi bi-person-fill"></i> Datos del Acreditado (Cliente)</div>
                <div class="datos-grid">
                    <div class="dato">
                        <span class="dato-lbl">Nombre completo</span>
                        <span class="dato-val"><?= htmlspecialchars($p['c_nombre'].' '.$p['c_apellido']) ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Teléfono</span>
                        <span class="dato-val"><?= htmlspecialchars($p['c_tel'] ?: '___________________') ?></span>
                    </div>
                    <div class="dato" style="grid-column:1/-1">
                        <span class="dato-lbl">Dirección</span>
                        <span class="dato-val"><?= htmlspecialchars($p['c_dir'] ?: '_______________________________________________') ?></span>
                    </div>
                    <?php if (!empty($p['c_curp'])): ?>
                    <div class="dato">
                        <span class="dato-lbl">CURP</span>
                        <span class="dato-val"><?= htmlspecialchars($p['c_curp']) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($p['c_rfc'])): ?>
                    <div class="dato">
                        <span class="dato-lbl">RFC</span>
                        <span class="dato-val"><?= htmlspecialchars($p['c_rfc']) ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="dato">
                        <span class="dato-lbl">Asesor responsable</span>
                        <span class="dato-val"><?= htmlspecialchars($p['asesor']) ?></span>
                    </div>
                </div>
            </div>

            <!-- Sección: Condiciones del préstamo -->
            <div class="seccion">
                <div class="seccion-titulo"><i class="bi bi-cash-coin"></i> Condiciones del Préstamo</div>
                <div class="resumen-fin">
                    <div class="rf-item azul">
                        <div class="rf-val">$<?= number_format($p['monto'],2) ?></div>
                        <div class="rf-lbl">Capital</div>
                    </div>
                    <div class="rf-item">
                        <div class="rf-val"><?= isset($p['interes']) ? number_format($p['interes'],1).'%' : '—' ?></div>
                        <div class="rf-lbl">Interés</div>
                    </div>
                    <div class="rf-item verde">
                        <div class="rf-val">$<?= number_format($p['total_pagar'],2) ?></div>
                        <div class="rf-lbl">Total a pagar</div>
                    </div>
                    <div class="rf-item">
                        <div class="rf-val"><?= $dias_total ?> días</div>
                        <div class="rf-lbl">Plazo</div>
                    </div>
                </div>
                <div class="datos-grid">
                    <div class="dato">
                        <span class="dato-lbl">Fecha de inicio</span>
                        <span class="dato-val"><?= date('d/m/Y', strtotime($p['fecha_inicio'])) ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Fecha de vencimiento</span>
                        <span class="dato-val"><?= date('d/m/Y', strtotime($p['fecha_fin'])) ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Frecuencia de pago</span>
                        <span class="dato-val"><?= $lbl_frecuencia ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Número de cuotas</span>
                        <span class="dato-val"><?= $num_cuotas ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Cuota ordinaria</span>
                        <span class="dato-val">$<?= number_format($cuota_base,2) ?></span>
                    </div>
                    <div class="dato">
                        <span class="dato-lbl">Última cuota</span>
                        <span class="dato-val">$<?= number_format($cuota_ultima,2) ?></span>
                    </div>
                </div>
            </div>

            <!-- Sección: Tabla de amortización -->
            <div class="seccion">
                <div class="seccion-titulo"><i class="bi bi-table"></i> Tabla de Amortización</div>
                <table class="tabla-amort">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Fecha de Pago</th>
                            <th>Cuota</th>
                            <th>Saldo Restante</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cuotas_tabla as $ct): ?>
                        <tr>
                            <td><span class="num-badge"><?= $ct['num'] ?></span></td>
                            <td><?= date('d/m/Y', strtotime($ct['fecha'])) ?></td>
                            <td>$<?= number_format($ct['cuota'],2) ?></td>
                            <td>$<?= number_format($ct['saldo'],2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2">TOTAL</td>
                            <td>$<?= number_format($p['total_pagar'],2) ?></td>
                            <td>$0.00</td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Sección: Cláusulas -->
            <div class="seccion">
                <div class="seccion-titulo"><i class="bi bi-file-text"></i> Términos y Condiciones</div>
                <div class="clausulas">
                    <ol>
                        <li>El acreditado se compromete a pagar puntualmente las cuotas indicadas en la tabla de amortización en las fechas establecidas.</li>
                        <li>En caso de mora, se aplicará un cargo adicional por cada día de atraso conforme a las políticas vigentes de la empresa.</li>
                        <li>El acreditado autoriza a Préstamos J.E. a gestionar el cobro de las cuotas mediante el asesor asignado.</li>
                        <li>El incumplimiento reiterado de pago podrá resultar en acciones de recuperación legales conforme a la legislación aplicable.</li>
                        <li>El cliente podrá liquidar anticipadamente el préstamo sin penalización, pagando el saldo pendiente.</li>
                        <li>El presente contrato tiene validez una vez firmado por ambas partes.</li>
                    </ol>
                </div>
            </div>

            <!-- Firmas -->
            <div class="firmas">
                <div class="firma">
                    <div class="firma-linea">
                        <div class="firma-nombre"><?= htmlspecialchars($p['c_nombre'].' '.$p['c_apellido']) ?></div>
                        <div class="firma-cargo">Acreditado — Cliente</div>
                    </div>
                </div>
                <div class="firma">
                    <div class="firma-linea">
                        <div class="firma-nombre"><?= htmlspecialchars($p['asesor']) ?></div>
                        <div class="firma-cargo">Asesor Responsable</div>
                    </div>
                </div>
            </div>

        </div><!-- /contrato-body -->

        <div class="contrato-footer">
            <span>Préstamos J.E. © <?= date('Y') ?> — Sistema Financiero Interno</span>
            <span>Generado: <?= date('d/m/Y H:i') ?> · Folio: <?= str_pad($id_prestamo,6,'0',STR_PAD_LEFT) ?></span>
        </div>

    </div><!-- /contrato -->

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const ic = document.getElementById('themeIcon');
    if (ic) ic.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const a = new Date();
    const el = document.getElementById('reloj');
    if (el) el.textContent = String(a.getHours()).padStart(2,'0')+':'+String(a.getMinutes()).padStart(2,'0')+':'+String(a.getSeconds()).padStart(2,'0');
}
actualizarReloj(); setInterval(actualizarReloj,1000);
</script>
</body>
</html>

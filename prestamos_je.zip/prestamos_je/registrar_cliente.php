<?php
$roles_permitidos = ['GERENTE', 'SUPERVISOR', 'ASESOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol    = $_SESSION['rol']     ?? 'ASESOR';
$user   = $_SESSION['usuario'] ?? 'Usuario';
$error  = '';
$es_asesor = ($rol === 'ASESOR');

$asesor_propio = null;
if ($es_asesor) {
    $id_emp = intval($_SESSION['id_empleado'] ?? 0);
    $res = $conexion->prepare("SELECT id_empleado, nombre, apellido FROM empleados WHERE id_empleado = ? LIMIT 1");
    $res->bind_param("i", $id_emp);
    $res->execute();
    $asesor_propio = $res->get_result()->fetch_assoc();
    $res->close();
}

$asesores = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido
    FROM empleados e
    INNER JOIN usuarios u ON u.id_empleado = e.id_empleado
    WHERE u.rol = 'ASESOR' AND e.estatus = 'ACTIVO'
    ORDER BY e.apellido, e.nombre
");

// ── TIPOS DE DOCUMENTO ──
$tipos_doc = [
    'ine_frente'  => 'INE_FRENTE',
    'ine_reverso' => 'INE_REVERSO',
    'comprobante' => 'COMPROBANTE'
];
$ext_permitidas = ['jpg','jpeg','png','pdf','webp'];
$max_bytes = 5 * 1024 * 1024; // 5 MB

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $curp_ine      = trim($_POST['curp_ine']        ?? '');
    $nombre        = trim($_POST['nombre']           ?? '');
    $apellido      = trim($_POST['apellido']         ?? '');
    $fecha_nac     = $_POST['fecha_nacimiento']      ?: null;
    $direccion     = trim($_POST['direccion']        ?? '');
    $num_exterior  = trim($_POST['numero_exterior']  ?? '') ?: 'S/N';
    $colonia       = trim($_POST['colonia']          ?? '');
    $telefono      = trim($_POST['telefono']         ?? '');
    $negocio       = trim($_POST['negocio']          ?? '');
    $observaciones = trim($_POST['observaciones']    ?? '');
    $autoriza      = $_POST['autoriza_credito']      ?? 'SI';
    $id_asesor     = intval($_POST['id_asesor']      ?? 0);
    $id_usuario    = intval($_SESSION['id_usuario']  ?? 0);

    if (!$nombre || !$apellido || !$direccion || !$colonia || !$telefono || !$id_asesor) {
        $error = 'Por favor completa todos los campos obligatorios (*)';
    } else {
        if ($curp_ine !== '') {
            $chk = $conexion->prepare("SELECT id_cliente FROM clientes WHERE curp_ine = ? LIMIT 1");
            $chk->bind_param("s", $curp_ine);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows > 0) {
                $error = 'Ya existe un cliente registrado con ese CURP / INE.';
            }
            $chk->close();
        }

        // Validar archivos antes de insertar
        $errores_archivo = [];
        foreach ($tipos_doc as $campo => $tipo_enum) {
            if (!empty($_FILES[$campo]['name']) && $_FILES[$campo]['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($_FILES[$campo]['error'] !== UPLOAD_ERR_OK) {
                    $errores_archivo[] = "Error al subir $campo.";
                } elseif ($_FILES[$campo]['size'] > $max_bytes) {
                    $errores_archivo[] = strtoupper($campo) . " supera los 5 MB.";
                } else {
                    $ext = strtolower(pathinfo($_FILES[$campo]['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, $ext_permitidas)) {
                        $errores_archivo[] = strtoupper($campo) . ": formato no permitido (JPG, PNG, PDF).";
                    }
                }
            }
        }
        if ($errores_archivo) {
            $error = implode(' ', $errores_archivo);
        }

        if (!$error) {
            $stmt = $conexion->prepare("
                INSERT INTO clientes
                (curp_ine, nombre, apellido, fecha_nacimiento, direccion, numero_exterior,
                 colonia, telefono, negocio, observaciones, autoriza_credito, estatus, id_asesor, id_usuario)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVO', ?, ?)
            ");
            $stmt->bind_param("sssssssssssii",
                $curp_ine, $nombre, $apellido, $fecha_nac, $direccion, $num_exterior,
                $colonia, $telefono, $negocio, $observaciones, $autoriza, $id_asesor, $id_usuario
            );
            if ($stmt->execute()) {
                $nuevo_id = $stmt->insert_id;
                $stmt->close();

                // ── SUBIR DOCUMENTOS ──
                $dir_base = __DIR__ . "/uploads/clientes/$nuevo_id/";
                if (!is_dir($dir_base)) {
                    mkdir($dir_base, 0755, true);
                }

                foreach ($tipos_doc as $campo => $tipo_enum) {
                    if (isset($_FILES[$campo]) &&
                        $_FILES[$campo]['error'] === UPLOAD_ERR_OK &&
                        $_FILES[$campo]['size'] > 0)
                    {
                        $ext = strtolower(pathinfo($_FILES[$campo]['name'], PATHINFO_EXTENSION));
                        $nombre_archivo = $tipo_enum . '_' . time() . '.' . $ext;
                        $ruta_relativa  = "uploads/clientes/$nuevo_id/$nombre_archivo";
                        if (move_uploaded_file($_FILES[$campo]['tmp_name'], $dir_base . $nombre_archivo)) {
                            $sdoc = $conexion->prepare("
                                INSERT INTO documentos_cliente
                                (id_cliente, tipo, nombre_archivo, ruta_archivo, id_empleado)
                                VALUES (?, ?, ?, ?, ?)
                            ");
                            $sdoc->bind_param("isssi", $nuevo_id, $tipo_enum, $nombre_archivo, $ruta_relativa, $id_usuario);
                            $sdoc->execute();
                            $sdoc->close();
                        }
                    }
                }

                header("Location: clientes.php?ok=1");
                exit;
            } else {
                $error = 'Error al guardar. Intenta de nuevo.';
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Nuevo Cliente — Préstamos J.E.</title>
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app  { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user {
    padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-title { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:1px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.back-btn {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 14px; color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,.05);
}
.back-btn:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTA ── */
.alerta {
    display:flex; align-items:center; gap:10px;
    padding:13px 16px; border-radius:12px; font-size:.85rem; font-weight:600;
    margin-bottom:20px; border:1px solid transparent;
}
.alerta-error  { background:#fef2f2; color:#991b1b; border-color:#fca5a5; }

/* ── TARJETAS ── */
.form-card {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06); margin-bottom:16px; overflow:hidden;
}
.fc-head {
    padding:16px 22px; border-bottom:1px solid #f8fafc;
    display:flex; align-items:center; gap:10px;
}
.fc-head-icon {
    width:36px; height:36px; border-radius:10px;
    display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0;
}
.fc-head h3  { font-size:.92rem; font-weight:700; color:#0f172a; }
.fc-head p   { font-size:.76rem; color:#94a3b8; margin-top:1px; }
.fc-body { padding:22px; }

/* ── GRID CAMPOS ── */
.fg-row   { display:grid; gap:16px; margin-bottom:16px; }
.fg-row:last-child { margin-bottom:0; }
.fg-row.c2 { grid-template-columns:1fr 1fr; }
.fg-row.c3 { grid-template-columns:1fr 1fr 1fr; }
.fg-row.c4 { grid-template-columns:2fr 1fr 2fr 1fr; }
.fg-row.c1 { grid-template-columns:1fr; }

.fg label {
    display:block; font-size:.72rem; font-weight:700; color:#475569;
    text-transform:uppercase; letter-spacing:.05em; margin-bottom:6px;
}
.fg label .req { color:#dc2626; }
.fg label .opc { font-weight:400; text-transform:none; color:#94a3b8; letter-spacing:0; font-size:.75rem; }
.fg input, .fg select, .fg textarea {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.88rem; color:#1e293b; font-family:'Inter',sans-serif;
    background:#f8fafc; outline:none; transition:border-color .15s, background .15s;
}
.fg input:focus, .fg select:focus, .fg textarea:focus {
    border-color:#2563eb; background:white;
    box-shadow:0 0 0 3px rgba(37,99,235,0.08);
}
.fg textarea  { resize:vertical; min-height:80px; }
.fg .ayuda    { font-size:.72rem; color:#94a3b8; margin-top:4px; display:block; }
.fg-span2     { grid-column:span 2; }

/* ── ASESOR AUTOASIGNADO ── */
.asesor-auto {
    background:#f0fdf4; border:1.5px solid #86efac; border-radius:10px;
    padding:10px 14px; display:flex; align-items:center; gap:10px;
}
.asesor-auto i { color:#16a34a; font-size:1.1rem; }
.asesor-auto .a-nom { font-size:.9rem; font-weight:700; color:#166534; }
.asesor-auto .a-sub { font-size:.72rem; color:#16a34a; margin-top:1px; }

/* ── DOCUMENTOS ── */
.doc-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }
.doc-slot {
    border:2px dashed #e2e8f0; border-radius:12px; padding:16px 14px;
    display:flex; flex-direction:column; align-items:center; gap:8px;
    background:#fafafa; transition:border-color .15s, background .15s; cursor:pointer;
    position:relative; text-align:center;
}
.doc-slot:hover { border-color:#2563eb; background:#eff6ff; }
.doc-slot.tiene-archivo { border-color:#22c55e; border-style:solid; background:#f0fdf4; }
.doc-slot-icon { font-size:2rem; color:#94a3b8; }
.doc-slot.tiene-archivo .doc-slot-icon { color:#16a34a; }
.doc-slot-label { font-size:.78rem; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:.04em; }
.doc-slot-sub   { font-size:.7rem; color:#94a3b8; }
.doc-slot.tiene-archivo .doc-slot-sub { color:#16a34a; font-weight:600; }
.doc-slot input[type="file"] {
    position:absolute; inset:0; opacity:0; cursor:pointer; width:100%; height:100%;
}
.doc-preview {
    width:100%; max-height:90px; object-fit:cover;
    border-radius:6px; margin-top:4px; display:none;
}
.doc-preview.visible { display:block; }
.doc-badge-pdf {
    background:#fee2e2; color:#b91c1c; border-radius:6px;
    font-size:.7rem; font-weight:700; padding:3px 8px;
    display:none; margin-top:4px;
}
.doc-badge-pdf.visible { display:inline-block; }

/* ── ACCIONES ── */
.form-actions {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06);
    padding:18px 22px; display:flex; justify-content:space-between; align-items:center;
}
.btn-guardar {
    display:inline-flex; align-items:center; gap:8px;
    background:#2563eb; color:white; border:none; border-radius:10px;
    padding:11px 24px; font-size:.9rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:all .15s;
    box-shadow:0 4px 12px rgba(37,99,235,.3);
}
.btn-guardar:hover { background:#1d4ed8; transform:translateY(-1px); }
.btn-cancelar {
    display:inline-flex; align-items:center; gap:8px;
    background:#f1f5f9; color:#475569; border:1.5px solid #e2e8f0;
    border-radius:10px; padding:11px 20px; font-size:.88rem; font-weight:600;
    text-decoration:none; transition:all .15s; font-family:'Inter',sans-serif;
}
.btn-cancelar:hover { background:#e2e8f0; color:#1e293b; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .fg-row.c2, .fg-row.c3, .fg-row.c4 { grid-template-columns:1fr; }
    .fg-span2 { grid-column:span 1; }
    .doc-grid { grid-template-columns:1fr; }
}

/* ── MODO OSCURO ── */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-title { color:#e2e8f0; }
[data-theme="dark"] .topbar-sub   { color:#94a3b8; }
[data-theme="dark"] .back-btn  { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .back-btn:hover { background:#1e293b; color:#e2e8f0; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .alerta-error { background:rgba(153,27,27,0.15); color:#fca5a5; border-color:rgba(252,165,165,0.3); }
[data-theme="dark"] .form-card  { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .fc-head    { border-color:#1e293b; }
[data-theme="dark"] .fc-head h3 { color:#e2e8f0; }
[data-theme="dark"] .fg label   { color:#94a3b8; }
[data-theme="dark"] .fg input,
[data-theme="dark"] .fg select,
[data-theme="dark"] .fg textarea { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .fg input:focus,
[data-theme="dark"] .fg select:focus,
[data-theme="dark"] .fg textarea:focus { border-color:#3b82f6; background:#1e293b; box-shadow:0 0 0 3px rgba(59,130,246,0.1); }
[data-theme="dark"] .asesor-auto { background:rgba(22,163,74,0.1); border-color:rgba(134,239,172,0.3); }
[data-theme="dark"] .asesor-auto .a-nom { color:#4ade80; }
[data-theme="dark"] .asesor-auto .a-sub { color:#86efac; }
[data-theme="dark"] .form-actions { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .btn-cancelar { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-cancelar:hover { background:#334155; color:#e2e8f0; }
[data-theme="dark"] .doc-slot { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .doc-slot:hover { border-color:#3b82f6; background:#1e293b; }
[data-theme="dark"] .doc-slot.tiene-archivo { border-color:#22c55e; background:rgba(22,163,74,0.1); }
[data-theme="dark"] .doc-slot-label { color:#94a3b8; }
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php" class="active"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <a href="clientes.php" class="back-btn">
                <i class="bi bi-arrow-left"></i> Clientes
            </a>
            <div>
                <div class="topbar-title">Nuevo Cliente</div>
                <div class="topbar-sub">Completa los datos para registrar al cliente</div>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="alerta alerta-error">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" onsubmit="return validar()">

        <!-- Identificación personal -->
        <div class="form-card">
            <div class="fc-head">
                <div class="fc-head-icon" style="background:#eff6ff;">
                    <i class="bi bi-person-vcard-fill" style="color:#2563eb;"></i>
                </div>
                <div>
                    <h3>Identificación personal</h3>
                    <p>Datos básicos del cliente</p>
                </div>
            </div>
            <div class="fc-body">
                <div class="fg-row c3">
                    <div class="fg">
                        <label>Nombre <span class="req">*</span></label>
                        <input type="text" name="nombre" required placeholder="Juan"
                               value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
                    </div>
                    <div class="fg">
                        <label>Apellido <span class="req">*</span></label>
                        <input type="text" name="apellido" required placeholder="García"
                               value="<?= htmlspecialchars($_POST['apellido'] ?? '') ?>">
                    </div>
                    <div class="fg">
                        <label>Fecha de nacimiento <span class="opc">(opcional)</span></label>
                        <input type="date" name="fecha_nacimiento"
                               value="<?= htmlspecialchars($_POST['fecha_nacimiento'] ?? '') ?>">
                    </div>
                </div>
                <div class="fg-row c2">
                    <div class="fg">
                        <label>CURP / INE <span class="opc">(opcional)</span></label>
                        <input type="text" name="curp_ine" placeholder="Para evitar duplicados"
                               value="<?= htmlspecialchars($_POST['curp_ine'] ?? '') ?>">
                        <span class="ayuda">Si se captura, evita registros duplicados</span>
                    </div>
                    <div class="fg">
                        <label>Teléfono <span class="req">*</span></label>
                        <input type="tel" name="telefono" required placeholder="6621234567"
                               value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Domicilio -->
        <div class="form-card">
            <div class="fc-head">
                <div class="fc-head-icon" style="background:#fef3c7;">
                    <i class="bi bi-house-fill" style="color:#d97706;"></i>
                </div>
                <div>
                    <h3>Domicilio</h3>
                    <p>Dirección del cliente para localización</p>
                </div>
            </div>
            <div class="fc-body">
                <div class="fg-row c4">
                    <div class="fg">
                        <label>Calle / Dirección <span class="req">*</span></label>
                        <input type="text" name="direccion" required placeholder="Av. Sonora"
                               value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>">
                    </div>
                    <div class="fg">
                        <label>Núm. exterior</label>
                        <input type="text" name="numero_exterior" placeholder="S/N"
                               value="<?= htmlspecialchars($_POST['numero_exterior'] ?? '') ?>">
                    </div>
                    <div class="fg fg-span2">
                        <label>Colonia <span class="req">*</span></label>
                        <input type="text" name="colonia" required placeholder="Centro"
                               value="<?= htmlspecialchars($_POST['colonia'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Información adicional -->
        <div class="form-card">
            <div class="fc-head">
                <div class="fc-head-icon" style="background:#f0fdf4;">
                    <i class="bi bi-info-circle-fill" style="color:#16a34a;"></i>
                </div>
                <div>
                    <h3>Información adicional</h3>
                    <p>Datos complementarios del cliente</p>
                </div>
            </div>
            <div class="fc-body">
                <div class="fg-row c2">
                    <div class="fg">
                        <label>Negocio donde trabaja <span class="opc">(opcional)</span></label>
                        <input type="text" name="negocio" placeholder="Tienda, mercado..."
                               value="<?= htmlspecialchars($_POST['negocio'] ?? '') ?>">
                    </div>
                    <div class="fg">
                        <label>¿Autoriza crédito?</label>
                        <select name="autoriza_credito">
                            <option value="SI"  <?= ($_POST['autoriza_credito']??'SI')==='SI'  ? 'selected':'' ?>>Sí</option>
                            <option value="NO"  <?= ($_POST['autoriza_credito']??'')==='NO'  ? 'selected':'' ?>>No</option>
                        </select>
                    </div>
                </div>
                <div class="fg-row c1">
                    <div class="fg">
                        <label>Observaciones <span class="opc">(opcional)</span></label>
                        <textarea name="observaciones" placeholder="Notas internas sobre el cliente..."><?= htmlspecialchars($_POST['observaciones'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Documentos -->
        <div class="form-card">
            <div class="fc-head">
                <div class="fc-head-icon" style="background:#faf5ff;">
                    <i class="bi bi-file-earmark-image-fill" style="color:#7c3aed;"></i>
                </div>
                <div>
                    <h3>Documentos del cliente</h3>
                    <p>JPG, PNG o PDF · Máx. 5 MB por archivo · Opcional al registrar</p>
                </div>
            </div>
            <div class="fc-body">
                <div class="doc-grid">

                    <!-- INE Frente -->
                    <div class="doc-slot" id="slot-ine_frente">
                        <input type="file" name="ine_frente" accept=".jpg,.jpeg,.png,.pdf,.webp"
                               onchange="previewDoc(this,'slot-ine_frente','prev-ine_frente','pdf-ine_frente')">
                        <i class="bi bi-person-vcard doc-slot-icon"></i>
                        <div class="doc-slot-label">INE Frente</div>
                        <div class="doc-slot-sub" id="sub-ine_frente">Haz clic o arrastra el archivo</div>
                        <img class="doc-preview" id="prev-ine_frente" alt="Vista previa">
                        <span class="doc-badge-pdf" id="pdf-ine_frente"><i class="bi bi-file-pdf-fill"></i> PDF</span>
                    </div>

                    <!-- INE Reverso -->
                    <div class="doc-slot" id="slot-ine_reverso">
                        <input type="file" name="ine_reverso" accept=".jpg,.jpeg,.png,.pdf,.webp"
                               onchange="previewDoc(this,'slot-ine_reverso','prev-ine_reverso','pdf-ine_reverso')">
                        <i class="bi bi-person-vcard-fill doc-slot-icon"></i>
                        <div class="doc-slot-label">INE Reverso</div>
                        <div class="doc-slot-sub" id="sub-ine_reverso">Haz clic o arrastra el archivo</div>
                        <img class="doc-preview" id="prev-ine_reverso" alt="Vista previa">
                        <span class="doc-badge-pdf" id="pdf-ine_reverso"><i class="bi bi-file-pdf-fill"></i> PDF</span>
                    </div>

                    <!-- Comprobante de domicilio -->
                    <div class="doc-slot" id="slot-comprobante">
                        <input type="file" name="comprobante" accept=".jpg,.jpeg,.png,.pdf,.webp"
                               onchange="previewDoc(this,'slot-comprobante','prev-comprobante','pdf-comprobante')">
                        <i class="bi bi-house-door doc-slot-icon"></i>
                        <div class="doc-slot-label">Comprobante de domicilio</div>
                        <div class="doc-slot-sub" id="sub-comprobante">Haz clic o arrastra el archivo</div>
                        <img class="doc-preview" id="prev-comprobante" alt="Vista previa">
                        <span class="doc-badge-pdf" id="pdf-comprobante"><i class="bi bi-file-pdf-fill"></i> PDF</span>
                    </div>

                </div>
            </div>
        </div>

        <!-- Asesor asignado -->
        <div class="form-card">
            <div class="fc-head">
                <div class="fc-head-icon" style="background:#faf5ff;">
                    <i class="bi bi-person-badge-fill" style="color:#7c3aed;"></i>
                </div>
                <div>
                    <h3>Asesor asignado</h3>
                    <p>El asesor responsable de este cliente</p>
                </div>
            </div>
            <div class="fc-body">
                <?php if ($es_asesor && $asesor_propio): ?>
                <div class="asesor-auto">
                    <i class="bi bi-check-circle-fill"></i>
                    <div>
                        <div class="a-nom"><?= htmlspecialchars($asesor_propio['nombre'].' '.$asesor_propio['apellido']) ?></div>
                        <div class="a-sub">El cliente quedará asignado a tu nombre automáticamente</div>
                    </div>
                </div>
                <input type="hidden" name="id_asesor" value="<?= $asesor_propio['id_empleado'] ?>">
                <?php else: ?>
                <div class="fg" style="max-width:420px;">
                    <label>Selecciona el asesor <span class="req">*</span></label>
                    <select name="id_asesor" required>
                        <option value="">Seleccionar asesor...</option>
                        <?php while ($a = $asesores->fetch_assoc()): ?>
                        <option value="<?= $a['id_empleado'] ?>">
                            <?= htmlspecialchars($a['nombre'].' '.$a['apellido']) ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Acciones -->
        <div class="form-actions">
            <a href="clientes.php" class="btn-cancelar">
                <i class="bi bi-x-circle"></i> Cancelar
            </a>
            <button type="submit" class="btn-guardar">
                <i class="bi bi-person-check-fill"></i> Registrar Cliente
            </button>
        </div>

    </form>

</main>
</div>

<script>
(function(){
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    var icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();

function toggleTheme() {
    var cur  = document.documentElement.getAttribute('data-theme') || 'light';
    var next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem('pje_tema', next);
    document.documentElement.setAttribute('data-theme', next);
    var icon = document.getElementById('themeIcon');
    if (icon) icon.className = next === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

function actualizarReloj() {
    var ahora = new Date();
    var h = String(ahora.getHours()).padStart(2,'0');
    var m = String(ahora.getMinutes()).padStart(2,'0');
    var s = String(ahora.getSeconds()).padStart(2,'0');
    var el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

function previewDoc(input, slotId, prevId, pdfId) {
    var slot  = document.getElementById(slotId);
    var prev  = document.getElementById(prevId);
    var pdf   = document.getElementById(pdfId);
    var sub   = document.getElementById('sub-' + slotId.replace('slot-',''));

    if (!input.files || !input.files[0]) return;

    var file = input.files[0];
    var nombre = file.name.length > 22 ? file.name.substring(0,20)+'...' : file.name;

    slot.classList.add('tiene-archivo');
    if (sub) sub.textContent = nombre;

    if (file.type.startsWith('image/')) {
        var reader = new FileReader();
        reader.onload = function(e) {
            prev.src = e.target.result;
            prev.classList.add('visible');
            pdf.classList.remove('visible');
        };
        reader.readAsDataURL(file);
    } else {
        prev.classList.remove('visible');
        pdf.classList.add('visible');
    }
}

function validar() {
    var campos = {
        'nombre'    : document.querySelector('[name="nombre"]'),
        'apellido'  : document.querySelector('[name="apellido"]'),
        'telefono'  : document.querySelector('[name="telefono"]'),
        'colonia'   : document.querySelector('[name="colonia"]'),
        'direccion' : document.querySelector('[name="direccion"]'),
    };
    for (var k in campos) {
        var el = campos[k];
        if (el && !el.value.trim()) {
            el.focus();
            el.style.borderColor = '#dc2626';
            setTimeout(function(e){ return function(){ e.style.borderColor=''; }; }(el), 2000);
            return false;
        }
    }
    var asesorEl = document.querySelector('[name="id_asesor"]');
    if (asesorEl && asesorEl.tagName === 'SELECT' && !asesorEl.value) {
        asesorEl.focus();
        return false;
    }
    return true;
}
</script>
</body>
</html>

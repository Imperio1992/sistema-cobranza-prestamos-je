<?php
$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR','CAJERO','CAPTURISTA'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol'] ?? '';
$user       = $_SESSION['usuario'] ?? 'Usuario';
$id_emp     = intval($_SESSION['id_empleado'] ?? 0);
$es_gerente = ($rol_actual === 'GERENTE');

$id_cliente = intval($_GET['id'] ?? 0);
if (!$id_cliente) { header('Location: buscar_cliente.php'); exit; }

/* ── DATOS DEL CLIENTE ── */
$cliente = $conexion->query("
    SELECT c.*, e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
    FROM clientes c
    LEFT JOIN empleados e ON e.id_empleado = c.id_asesor
    WHERE c.id_cliente = $id_cliente
")->fetch_assoc();
if (!$cliente) { header('Location: clientes.php'); exit; }

$msg = ''; $msg_tipo = '';

/* ── GUARDAR VISITA ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'comentario') {
    $id_prestamo  = intval($_POST['id_prestamo']    ?? 0);
    $resultado    = $_POST['resultado']             ?? 'NO_PAGO';
    $motivo       = $_POST['motivo']               ?? '';
    $comentario   = trim($_POST['comentario']       ?? '');
    $monto_prom   = floatval($_POST['monto_prometido'] ?? 0);
    $fecha_prom   = $_POST['fecha_prometida']       ?? '';
    $monto_pagado = floatval($_POST['monto_pagado'] ?? 0);

    $resultados_validos = ['PAGO','NO_PAGO','PAGO_PARCIAL','PROMESA_PAGO','NO_ENCONTRADO'];
    $motivos_validos    = ['SIN_DINERO','NO_ESTABA_EN_CASA','ENFERMEDAD','PROBLEMA_FAMILIAR',
                           'DESACUERDO_MONTO','PROMESA_POSTERIOR','OTRO',''];

    if ($id_prestamo && in_array($resultado, $resultados_validos) && in_array($motivo, $motivos_validos)) {
        $res  = $conexion->real_escape_string($resultado);
        $mot  = $motivo       ? "'".$conexion->real_escape_string($motivo)."'"     : 'NULL';
        $com  = $comentario   ? "'".$conexion->real_escape_string($comentario)."'" : 'NULL';
        $fp   = $fecha_prom   ? "'".$conexion->real_escape_string($fecha_prom)."'" : 'NULL';
        $mprom = $monto_prom > 0 ? $monto_prom : 'NULL';

        $conexion->query("
            INSERT INTO historial_visitas
                (id_prestamo, id_cliente, id_empleado, fecha_visita,
                 resultado, monto_pagado, monto_prometido, fecha_prometida, motivo, comentario)
            VALUES
                ($id_prestamo, $id_cliente, $id_emp, CURDATE(),
                 '$res', $monto_pagado, $mprom, $fp, $mot, $com)
        ");

        $delta = match($resultado) {
            'PAGO'          =>  2,
            'PAGO_PARCIAL'  => -1,
            'PROMESA_PAGO'  => -1,
            'NO_ENCONTRADO' => -1,
            'NO_PAGO'       => -3,
            default         =>  0
        };
        if ($delta !== 0) {
            $op = $delta > 0
                ? "LEAST(score_crediticio + $delta, 100)"
                : "GREATEST(score_crediticio + $delta, 0)";
            $conexion->query("UPDATE clientes SET score_crediticio = $op WHERE id_cliente = $id_cliente");
        }

        $msg = 'Visita registrada correctamente.'; $msg_tipo = 'exito';
        $cliente = $conexion->query("
            SELECT c.*, e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
            FROM clientes c LEFT JOIN empleados e ON e.id_empleado = c.id_asesor
            WHERE c.id_cliente = $id_cliente
        ")->fetch_assoc();
    } else {
        $msg = 'Datos incompletos o inválidos.'; $msg_tipo = 'error';
    }
}

/* ── GUARDAR TARJETA DE PAGOS (solo GERENTE) ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'guardar_pagos') {
    if (!$es_gerente) {
        $msg = 'Solo el GERENTE puede modificar los pagos de la tarjeta.'; $msg_tipo = 'error';
    } else {
        $id_prestamo = intval($_POST['id_prestamo']);
        $cuotas_post = $_POST['cuota'] ?? [];
        $fechas_post = $_POST['fecha'] ?? [];

        $conexion->query("DELETE FROM pagos WHERE id_prestamo = $id_prestamo");

        $total_pagado_nuevo = 0;
        foreach ($cuotas_post as $num => $monto) {
            $num   = intval($num);
            $monto = floatval(str_replace(',', '', $monto));
            $fecha = $fechas_post[$num] ?? date('Y-m-d');
            $fecha = $conexion->real_escape_string($fecha);
            if ($monto > 0 && $num > 0) {
                $conexion->query("
                    INSERT INTO pagos (id_prestamo, fecha_pago, monto_pagado, cuota_numero, tipo_pago, interes)
                    VALUES ($id_prestamo, '$fecha 00:00:00', $monto, $num, 'TARJETA', 0)
                ");
                $total_pagado_nuevo += $monto;
            }
        }

        $row_p = $conexion->query("SELECT total_pagar, estado FROM prestamos WHERE id_prestamo = $id_prestamo")->fetch_assoc();
        $total_pagar = floatval($row_p['total_pagar'] ?? 0);
        $saldo_nuevo = max(0, $total_pagar - $total_pagado_nuevo);
        $marcar_pagado = ($saldo_nuevo <= 0 && $total_pagar > 0 && $row_p['estado'] !== 'PAGADO');

        if ($marcar_pagado) {
            $conexion->query("
                UPDATE prestamos
                SET total_pagado = $total_pagado_nuevo,
                    saldo_actual = $saldo_nuevo,
                    estado = 'PAGADO',
                    fecha_liquidacion = CURDATE()
                WHERE id_prestamo = $id_prestamo
            ");
        } else {
            $conexion->query("
                UPDATE prestamos
                SET total_pagado = $total_pagado_nuevo,
                    saldo_actual = $saldo_nuevo
                WHERE id_prestamo = $id_prestamo
            ");
        }

        $u = $conexion->real_escape_string($user);
        $conexion->query("
            INSERT INTO bitacora (usuario, accion, fecha)
            VALUES ('$u', 'Modificó tarjeta de pagos del préstamo #$id_prestamo (cliente #$id_cliente). Total: $total_pagado_nuevo', NOW())
        ");

        $msg = 'Tarjeta de pagos actualizada correctamente.'; $msg_tipo = 'exito';
    }
}

/* ── PRÉSTAMOS DEL CLIENTE ── */
$prestamos = $conexion->query("
    SELECT id_prestamo, monto_prestado, total_pagar,
           COALESCE(saldo_actual, 0)   AS saldo_actual,
           COALESCE(total_pagado, 0)   AS total_pagado,
           pago_diario, plazo_semanas, estado,
           fecha_inicio, fecha_fin, dias
    FROM prestamos
    WHERE id_cliente = $id_cliente
    ORDER BY fecha_inicio DESC
");
$lista_prestamos = [];
while ($p = $prestamos->fetch_assoc()) $lista_prestamos[] = $p;

$prestamo_activo = null;
foreach ($lista_prestamos as $p) {
    if ($p['estado'] === 'ACTIVO' || $p['estado'] === 'ATRASADO') {
        $prestamo_activo = $p;
        break;
    }
}

/* ── HISTORIAL DE VISITAS ── */
$visitas = $conexion->query("
    SELECT hv.*, e.nombre AS emp_nombre, e.apellido AS emp_apellido
    FROM historial_visitas hv
    LEFT JOIN empleados e ON e.id_empleado = hv.id_empleado
    WHERE hv.id_cliente = $id_cliente
    ORDER BY hv.fecha_visita DESC, hv.created_at DESC
");
$lista_visitas = [];
while ($v = $visitas->fetch_assoc()) $lista_visitas[] = $v;

/* ── PAGOS REALES (últimos) ── */
$pagos_res = $conexion->query("
    SELECT pg.*, p.estado AS estado_prestamo
    FROM pagos pg
    INNER JOIN prestamos p ON p.id_prestamo = pg.id_prestamo
    WHERE p.id_cliente = $id_cliente
    ORDER BY pg.fecha_pago DESC
    LIMIT 30
");
$lista_pagos = [];
while ($pg = $pagos_res->fetch_assoc()) $lista_pagos[] = $pg;

/* ── ESTADÍSTICAS ── */
$total_visitas   = count($lista_visitas);
$total_pagos     = count(array_filter($lista_visitas, fn($v) => in_array($v['resultado'], ['PAGO','PAGO_PARCIAL'])));
$total_ausencias = count(array_filter($lista_visitas, fn($v) => in_array($v['resultado'], ['NO_PAGO','NO_ENCONTRADO'])));
$total_promesas  = count(array_filter($lista_visitas, fn($v) => $v['resultado'] === 'PROMESA_PAGO'));
$pct_cumplimiento = $total_visitas > 0 ? round(($total_pagos / $total_visitas) * 100) : 100;

$racha_ausencias = 0;
foreach ($lista_visitas as $v) {
    if (in_array($v['resultado'], ['NO_PAGO','NO_ENCONTRADO'])) $racha_ausencias++;
    else break;
}

$score_base  = max(0, min(100, intval($cliente['score_crediticio'] ?? 100)));

/* ── DATOS PARA TARJETA DE PAGOS ── */
$pagos_por_cuota = [];
$max_cuota_pagada = 0;
if ($prestamo_activo) {
    $idp = intval($prestamo_activo['id_prestamo']);
    $rs = $conexion->query("
        SELECT cuota_numero, fecha_pago, monto_pagado
        FROM pagos
        WHERE id_prestamo = $idp
        ORDER BY cuota_numero ASC, id_pago ASC
    ");
    while ($r = $rs->fetch_assoc()) {
        $n = intval($r['cuota_numero']);
        if ($n <= 0) continue;
        $pagos_por_cuota[$n] = [
            'fecha' => date('Y-m-d', strtotime($r['fecha_pago'])),
            'monto' => floatval($r['monto_pagado']),
        ];
        if ($n > $max_cuota_pagada) $max_cuota_pagada = $n;
    }
}

$plazo        = $prestamo_activo ? max(1, intval($prestamo_activo['plazo_semanas'] ?: $prestamo_activo['dias'] ?: 20)) : 20;
$pago_diario  = $prestamo_activo ? floatval($prestamo_activo['pago_diario']) : 0;
$total_pagar_p = $prestamo_activo ? floatval($prestamo_activo['total_pagar']) : 0;
$total_pagado_p = $prestamo_activo ? floatval($prestamo_activo['total_pagado']) : 0;
$saldo_p       = $prestamo_activo ? floatval($prestamo_activo['saldo_actual']) : 0;
$fecha_inicio_p = $prestamo_activo && $prestamo_activo['fecha_inicio'] ? $prestamo_activo['fecha_inicio'] : date('Y-m-d');

$total_filas = max($plazo, $max_cuota_pagada);
if ($max_cuota_pagada >= $total_filas) {
    $total_filas = $max_cuota_pagada + 5;
}

/* Generar fechas: cobros LUNES a SÁBADO (saltar SOLO DOMINGO) */
function calcularFechasCobro($fecha_inicio, $cantidad) {
    $fechas = [];
    $d = new DateTime($fecha_inicio);
    $i = 0;
    while ($i < $cantidad) {
        if ($d->format('w') != 0) { /* 0 = domingo */
            $fechas[] = $d->format('Y-m-d');
            $i++;
        }
        $d->modify('+1 day');
    }
    return $fechas;
}
$fechas_cuotas = $prestamo_activo ? calcularFechasCobro($fecha_inicio_p, $total_filas) : [];
$cuotas_llenadas = count(array_filter($pagos_por_cuota, fn($p) => $p['monto'] > 0));
$hoy_str = date('Y-m-d');

/* ── ATRASOS y PUNTUALIDAD (afectan el score en pantalla) ── */
$cuotas_atrasadas = 0;
$cuotas_vencidas  = 0; /* fechas <= hoy del préstamo activo */
if ($prestamo_activo) {
    foreach ($fechas_cuotas as $idx => $f) {
        $num = $idx + 1;
        if ($f <= $hoy_str) {
            $cuotas_vencidas++;
            $tiene_pago = isset($pagos_por_cuota[$num]) && $pagos_por_cuota[$num]['monto'] > 0;
            if (!$tiene_pago && $f < $hoy_str) $cuotas_atrasadas++;
        }
    }
}

/* Penalización: 3 puntos por cuota atrasada (máx 60) */
$penalizacion = min(60, $cuotas_atrasadas * 3);
$score        = max(0, $score_base - $penalizacion);
$puntualidad  = $cuotas_vencidas > 0
    ? round((($cuotas_vencidas - $cuotas_atrasadas) / $cuotas_vencidas) * 100)
    : 100;
$score_color  = $score >= 80 ? '#16a34a' : ($score >= 50 ? '#d97706' : '#dc2626');
$score_label  = $score >= 80 ? 'Excelente'   : ($score >= 50 ? 'Regular' : 'Riesgo alto');
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Historial — <?= htmlspecialchars($cliente['nombre'].' '.$cliente['apellido']) ?> — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar { width:240px; background:#0f172a; height:100vh; position:fixed; top:0; left:0; display:flex; flex-direction:column; overflow-y:auto; z-index:200; box-shadow:4px 0 20px rgba(0,0,0,.2); }
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon { width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8); border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0; }
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb { width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0; }
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a { display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s; }
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; }
.main-content { padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right   { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-icon-top { width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0; background:white; color:#64748b; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s; text-decoration:none; flex-shrink:0; }
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta { border-radius:12px; padding:14px 18px; margin-bottom:20px; display:flex; align-items:center; gap:12px; font-size:.84rem; font-weight:500; }
.alerta.exito { background:#f0fdf4; border:1.5px solid #bbf7d0; color:#14532d; }
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }
.alerta i { font-size:1.1rem; flex-shrink:0; }

/* ── HEADER CLIENTE ── */
.cliente-header { background:white; border-radius:16px; padding:22px 26px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; margin-bottom:20px; display:flex; align-items:center; gap:20px; flex-wrap:wrap; }
.cli-avatar { width:64px; height:64px; border-radius:50%; background:linear-gradient(135deg,#2563eb,#1d4ed8); display:flex; align-items:center; justify-content:center; font-size:1.4rem; font-weight:800; color:white; flex-shrink:0; }
.cli-info { flex:1; min-width:0; }
.cli-nombre { font-size:1.15rem; font-weight:800; color:#0f172a; letter-spacing:-.3px; }
.cli-meta { display:flex; gap:16px; margin-top:5px; flex-wrap:wrap; }
.cli-meta span { font-size:.78rem; color:#64748b; display:flex; align-items:center; gap:4px; }

/* Score */
.score-wrap { text-align:center; padding:12px 20px; border-radius:14px; border:2px solid; min-width:110px; }
.score-num  { font-size:2rem; font-weight:800; line-height:1; }
.score-lbl  { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; margin-top:3px; }
.score-sub  { font-size:.65rem; color:#94a3b8; margin-top:2px; }

/* Badges */
.badge { display:inline-flex; align-items:center; gap:3px; padding:3px 9px; border-radius:20px; font-size:.7rem; font-weight:700; }
.badge-activo        { background:#dcfce7; color:#15803d; }
.badge-mal_historial { background:#fef3c7; color:#92400e; }
.badge-bloqueado     { background:#fee2e2; color:#dc2626; }
.badge-atrasado      { background:#fef3c7; color:#92400e; }
.badge-pagado        { background:#f0f9ff; color:#0369a1; }
.badge-renovado      { background:#f3e8ff; color:#7c3aed; }
.badge-pago          { background:#dcfce7; color:#15803d; }
.badge-pago_parcial  { background:#e0f2fe; color:#0369a1; }
.badge-promesa_pago  { background:#fef3c7; color:#92400e; }
.badge-no_pago       { background:#fee2e2; color:#dc2626; }
.badge-no_encontrado { background:#f3e8ff; color:#7c3aed; }

/* Stats */
.stats-row { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:12px; margin-bottom:20px; }
.stat-card { background:white; border-radius:14px; padding:16px 18px; box-shadow:0 2px 6px rgba(0,0,0,.04); border:1px solid #f1f5f9; display:flex; align-items:center; gap:14px; }
.stat-icon { width:40px; height:40px; border-radius:11px; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; }
.stat-val { font-size:1.3rem; font-weight:800; color:#0f172a; }
.stat-lbl { font-size:.68rem; text-transform:uppercase; letter-spacing:.04em; color:#94a3b8; margin-top:1px; }

/* Alerta racha */
.alerta-racha { background:#fff1f2; border:1.5px solid #fecdd3; border-radius:12px; padding:12px 18px; margin-bottom:20px; display:flex; align-items:center; gap:12px; font-size:.84rem; font-weight:600; color:#9f1239; }

/* Layout */
.layout-cols { display:grid; grid-template-columns:1fr 340px; gap:20px; align-items:start; }

/* Card */
.card { background:white; border-radius:16px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; overflow:hidden; margin-bottom:20px; }
.card-head { padding:16px 20px; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; }
.card-title { font-size:.82rem; font-weight:800; color:#0f172a; display:flex; align-items:center; gap:8px; }
.card-body  { padding:20px; }

/* Timeline */
.timeline { position:relative; padding-left:28px; }
.timeline::before { content:''; position:absolute; left:10px; top:0; bottom:0; width:2px; background:#f1f5f9; }
.tl-item { position:relative; margin-bottom:18px; }
.tl-item:last-child { margin-bottom:0; }
.tl-dot { position:absolute; left:-24px; top:4px; width:14px; height:14px; border-radius:50%; border:2px solid white; box-shadow:0 0 0 2px #e2e8f0; }
.tl-dot.pago         { background:#16a34a; }
.tl-dot.pago_parcial { background:#0369a1; }
.tl-dot.promesa_pago { background:#d97706; }
.tl-dot.no_pago      { background:#dc2626; }
.tl-dot.no_encontrado { background:#7c3aed; }
.tl-fecha { font-size:.68rem; color:#94a3b8; font-weight:600; text-transform:uppercase; margin-bottom:4px; }
.tl-card  { background:#f8fafc; border-radius:10px; padding:11px 14px; border:1px solid #f1f5f9; }
.tl-card-top { display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; }
.tl-resultado  { font-size:.78rem; font-weight:700; }
.tl-asesor     { font-size:.72rem; color:#94a3b8; }
.tl-motivo     { font-size:.78rem; color:#64748b; margin-top:5px; display:flex; align-items:center; gap:4px; }
.tl-comentario { margin-top:6px; padding:7px 10px; background:white; border-radius:7px; border:1px solid #e2e8f0; font-size:.78rem; color:#374151; line-height:1.5; font-style:italic; }
.tl-promesa    { font-size:.72rem; color:#92400e; margin-top:4px; display:flex; align-items:center; gap:4px; }

/* Tabla pagos */
.tabla-pagos { width:100%; border-collapse:collapse; font-size:.82rem; }
.tabla-pagos th { text-align:left; padding:9px 12px; font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; background:#f8fafc; border-bottom:1px solid #f1f5f9; }
.tabla-pagos td { padding:10px 12px; border-bottom:1px solid #f8fafc; color:#374151; }
.tabla-pagos tr:last-child td { border-bottom:none; }
.tabla-pagos tr:hover td { background:#f8fafc; }

/* Panel visita */
.panel-visita { background:white; border-radius:16px; padding:20px 22px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9; position:sticky; top:20px; }
.panel-visita h3 { font-size:.84rem; font-weight:800; color:#0f172a; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
.field { margin-bottom:14px; }
.field label { display:block; font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#374151; margin-bottom:5px; }
.field select, .field input, .field textarea { width:100%; border:1.5px solid #e2e8f0; border-radius:9px; padding:9px 12px; font-size:.84rem; color:#1e293b; outline:none; background:#f8fafc; font-family:'Inter',sans-serif; transition:border-color .15s; resize:vertical; }
.field select:focus, .field input:focus, .field textarea:focus { border-color:#2563eb; background:white; }
.field textarea { min-height:70px; }
.bloque-extra { display:none; }
.btn-guardar-visita { width:100%; padding:11px; background:#0f172a; color:white; border:none; border-radius:10px; font-size:.86rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:background .15s; display:flex; align-items:center; justify-content:center; gap:7px; margin-top:4px; }
.btn-guardar-visita:hover { background:#1e293b; }

/* Empty */
.empty-tl { text-align:center; padding:32px; color:#94a3b8; }
.empty-tl i { font-size:2rem; display:block; margin-bottom:8px; opacity:.25; }
.empty-tl p { font-size:.82rem; }

/* ════════════════════════════════════════════ */
/* ── TARJETA DE PAGOS J.E. (compacta) ──        */
/* ════════════════════════════════════════════ */
.tarjeta-je { border-radius:14px; overflow:hidden; border:1px solid #1e3a5f; box-shadow:0 4px 16px rgba(15,31,58,.15); margin-bottom:20px; background:#0f1f3a; }
.je-bar { background:linear-gradient(135deg,#1e3a8a,#1d4ed8); padding:10px 16px; display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; }
.je-bar .je-title { display:flex; align-items:center; gap:8px; color:#fff; font-size:.84rem; font-weight:800; }
.je-bar .je-title small { font-size:.62rem; font-weight:600; color:#bfdbfe; text-transform:uppercase; letter-spacing:.04em; display:block; margin-top:1px; }
.je-bar .je-meta { font-size:.7rem; color:#bfdbfe; font-weight:600; }

.je-resumen { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:#1e3a5f; }
.je-cell { background:#0f1f3a; padding:10px 12px; }
.je-cell .lbl { font-size:.58rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; font-weight:700; margin-bottom:3px; }
.je-cell .val { font-size:.92rem; font-weight:800; color:#e2e8f0; font-variant-numeric:tabular-nums; }
.je-cell.saldo .val { color:#60a5fa; }
.je-cell.atraso .val { color:#fca5a5; }
.je-cell.pagado .val { color:#34d399; }

.je-tabla-wrap { background:#0a1628; max-height:340px; overflow-y:auto; }
.je-tabla { width:100%; border-collapse:collapse; font-size:.78rem; }
.je-tabla thead th { background:#1e3a8a; color:#fff; font-weight:700; padding:6px 8px; font-size:.65rem; text-transform:uppercase; letter-spacing:.04em; position:sticky; top:0; z-index:5; }
.je-tabla thead th.col-num { width:42px; text-align:center; border-right:1px solid #1e3a5f; }
.je-tabla thead th.col-fecha { width:78px; text-align:center; border-right:1px solid #1e3a5f; }
.je-tabla thead th.col-cuota { text-align:center; }
.je-tabla tbody td { padding:0; border-bottom:1px solid #15294a; }
.je-tabla .cell-num   { text-align:center; padding:5px 6px; color:#64748b; font-weight:600; font-size:.74rem; border-right:1px solid #15294a; background:#0a1628; }
.je-tabla .cell-fecha { text-align:center; padding:5px 6px; color:#cbd5e1; border-right:1px solid #15294a; font-size:.76rem; }
.je-tabla .cell-cuota { text-align:center; padding:0; }
.je-tabla .cell-cuota input { width:100%; height:28px; padding:3px 10px; background:transparent; border:none; color:#e2e8f0; text-align:center; font-size:.78rem; font-family:'Inter',sans-serif; outline:none; font-variant-numeric:tabular-nums; }
.je-tabla .cell-cuota input:focus { background:#1e3a8a; color:#fff; box-shadow:inset 0 0 0 2px #2563eb; }
.je-tabla .cell-cuota input:disabled { color:#cbd5e1; cursor:not-allowed; }
.je-tabla .cell-cuota input.tiene-monto { color:#34d399; font-weight:700; }

/* fila pagada */
.je-tabla tr.pagada .cell-num   { color:#34d399; }
.je-tabla tr.pagada .cell-fecha { color:#86efac; }

/* fila ATRASADA (vencida sin pago) — ROJO */
.je-tabla tr.atrasada .cell-num   { color:#fca5a5; font-weight:800; background:#3b0a0a; }
.je-tabla tr.atrasada .cell-fecha { color:#fca5a5; font-weight:700; background:#2b0808; }
.je-tabla tr.atrasada .cell-cuota { background:#1c0a0a; }
.je-tabla tr.atrasada .cell-cuota input::placeholder { color:#fca5a5; }

/* fila HOY */
.je-tabla tr.hoy .cell-num   { background:#1e3a8a; color:#fff; font-weight:800; }
.je-tabla tr.hoy .cell-fecha { background:#172554; color:#bfdbfe; font-weight:700; }

.je-footer { background:#0a1628; padding:9px 14px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px; font-size:.74rem; color:#94a3b8; border-top:1px solid #15294a; }
.je-footer .actions { display:flex; gap:6px; flex-wrap:wrap; }
.btn-mini { background:transparent; border:1.5px solid #334155; color:#cbd5e1; padding:5px 10px; border-radius:6px; font-size:.7rem; font-weight:600; cursor:pointer; font-family:'Inter',sans-serif; display:inline-flex; align-items:center; gap:5px; transition:all .15s; }
.btn-mini:hover { border-color:#2563eb; color:#fff; background:#1e3a8a; }
.btn-mini.danger:hover { border-color:#dc2626; color:#fca5a5; background:#1c0a0a; }
.btn-mini.primary { background:#2563eb; border-color:#2563eb; color:#fff; }
.btn-mini.primary:hover { background:#1d4ed8; border-color:#1d4ed8; }
.je-status-bot { background:#0f1f3a; padding:8px 14px; display:flex; justify-content:space-between; align-items:center; font-size:.72rem; color:#64748b; flex-wrap:wrap; gap:8px; border-top:1px solid #15294a; }
.je-status-bot strong { color:#cbd5e1; font-weight:700; }
.je-banner-rol { background:#451a03; color:#fbbf24; padding:6px 14px; text-align:center; font-size:.7rem; font-weight:600; border-bottom:1px solid #92400e; }

/* scrollbar */
.je-tabla-wrap::-webkit-scrollbar { width:8px; }
.je-tabla-wrap::-webkit-scrollbar-track { background:#0a1628; }
.je-tabla-wrap::-webkit-scrollbar-thumb { background:#1e3a5f; border-radius:4px; }
.je-tabla-wrap::-webkit-scrollbar-thumb:hover { background:#2563eb; }

/* Dark mode */
[data-theme="dark"] body  { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .btn-icon-top   { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .cliente-header { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .cli-nombre     { color:#f8fafc; }
[data-theme="dark"] .stat-card      { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .stat-val       { color:#f8fafc; }
[data-theme="dark"] .card           { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .card-head      { border-color:#334155; }
[data-theme="dark"] .card-title     { color:#f8fafc; }
[data-theme="dark"] .timeline::before { background:#334155; }
[data-theme="dark"] .tl-card        { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .tl-comentario  { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .tabla-pagos th { background:#0f172a; }
[data-theme="dark"] .tabla-pagos td { color:#94a3b8; border-color:#1e293b; }
[data-theme="dark"] .tabla-pagos tr:hover td { background:#0f172a; }
[data-theme="dark"] .panel-visita   { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .panel-visita h3 { color:#f8fafc; }
[data-theme="dark"] .field label    { color:#94a3b8; }
[data-theme="dark"] .field select,
[data-theme="dark"] .field input,
[data-theme="dark"] .field textarea { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .alerta-racha   { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }

/* Responsive */
@media(max-width:1024px) { .layout-cols { grid-template-columns:1fr; } .panel-visita { position:static; } }
@media(max-width:900px)  { .sidebar { display:none; } .main { margin-left:0; } .main-content { padding:16px 14px 80px; } }
@media(max-width:680px)  {
    .je-resumen { grid-template-columns:repeat(2,1fr); }
    .je-tabla thead th.col-fecha { width:64px; }
    .je-tabla .cell-fecha { font-size:.7rem; }
    .je-tabla .cell-cuota input { font-size:.76rem; height:32px; }
    .je-footer { font-size:.7rem; }
    .btn-mini { padding:7px 10px; font-size:.72rem; }
}
@media(max-width:600px)  { .stats-row { grid-template-columns:1fr 1fr; } }
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php" class="active"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if (in_array($rol_actual, ['GERENTE','SUPERVISOR'])): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="clientes.php" class="btn-icon-top" title="Regresar a clientes">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-clock-history" style="color:#2563eb;"></i> Historial del Cliente</h1>
                <p>Registro de visitas, pagos y comportamiento crediticio</p>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ALERTA -->
    <?php if ($msg): ?>
    <div class="alerta <?= $msg_tipo ?>">
        <i class="bi <?= $msg_tipo === 'exito' ? 'bi-check-circle-fill' : 'bi-x-circle-fill' ?>"></i>
        <div><?= htmlspecialchars($msg) ?></div>
    </div>
    <?php endif; ?>

    <!-- HEADER CLIENTE -->
    <div class="cliente-header">
        <div class="cli-avatar">
            <?= strtoupper(mb_substr($cliente['nombre'],0,1) . mb_substr($cliente['apellido'],0,1)) ?>
        </div>
        <div class="cli-info">
            <div class="cli-nombre">
                <?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?>
                <span class="badge badge-<?= strtolower($cliente['estatus']) ?>" style="margin-left:8px;font-size:.65rem;">
                    <?= $cliente['estatus'] ?>
                </span>
            </div>
            <div class="cli-meta">
                <?php if (!empty($cliente['telefono'])): ?>
                <span><i class="bi bi-telephone-fill"></i> <?= htmlspecialchars($cliente['telefono']) ?></span>
                <?php endif; ?>
                <?php if (!empty($cliente['negocio'])): ?>
                <span><i class="bi bi-shop"></i> <?= htmlspecialchars($cliente['negocio']) ?></span>
                <?php endif; ?>
                <?php if (!empty($cliente['colonia'])): ?>
                <span><i class="bi bi-geo-alt-fill"></i> <?= htmlspecialchars($cliente['colonia']) ?></span>
                <?php endif; ?>
                <span><i class="bi bi-person-fill"></i>
                    Asesor: <?= htmlspecialchars(($cliente['asesor_nombre'] ?? '') . ' ' . ($cliente['asesor_apellido'] ?? '')) ?>
                </span>
            </div>
        </div>
        <div class="score-wrap" style="color:<?= $score_color ?>;border-color:<?= $score_color ?>33;background:<?= $score_color ?>11;">
            <div class="score-num" style="color:<?= $score_color ?>;"><?= $score ?></div>
            <div class="score-lbl" style="color:<?= $score_color ?>;"><?= $score_label ?></div>
            <div class="score-sub">Score / 100</div>
            <?php if ($prestamo_activo && $cuotas_vencidas > 0): ?>
            <div style="font-size:.62rem;margin-top:6px;padding-top:6px;border-top:1px dashed <?= $score_color ?>44;color:#94a3b8;">
                Puntualidad: <strong style="color:<?= $score_color ?>;"><?= $puntualidad ?>%</strong>
                <?php if ($cuotas_atrasadas > 0): ?>
                <br><span style="color:#dc2626;font-weight:700;">−<?= $penalizacion ?> pts</span> · <?= $cuotas_atrasadas ?> atraso<?= $cuotas_atrasadas==1?'':'s' ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ALERTA RACHA -->
    <?php if ($racha_ausencias >= 3): ?>
    <div class="alerta-racha">
        <i class="bi bi-exclamation-triangle-fill" style="font-size:1.2rem;"></i>
        <div><strong>Atención:</strong> Este cliente lleva <strong><?= $racha_ausencias ?> ausencias consecutivas</strong>. Evalúa si continuar el crédito.</div>
    </div>
    <?php endif; ?>

    <!-- ESTADÍSTICAS -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon" style="background:#dcfce7;"><i class="bi bi-check-circle-fill" style="color:#16a34a;"></i></div>
            <div><div class="stat-val"><?= $total_pagos ?></div><div class="stat-lbl">Visitas pagadas</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background:#fee2e2;"><i class="bi bi-x-circle-fill" style="color:#dc2626;"></i></div>
            <div><div class="stat-val"><?= $total_ausencias ?></div><div class="stat-lbl">Ausencias</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background:#fef3c7;"><i class="bi bi-clock-fill" style="color:#d97706;"></i></div>
            <div><div class="stat-val"><?= $total_promesas ?></div><div class="stat-lbl">Promesas</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background:#dbeafe;"><i class="bi bi-percent" style="color:#2563eb;"></i></div>
            <div><div class="stat-val"><?= $pct_cumplimiento ?>%</div><div class="stat-lbl">Cumplimiento</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background:#f3e8ff;"><i class="bi bi-credit-card-fill" style="color:#7c3aed;"></i></div>
            <div><div class="stat-val"><?= count($lista_prestamos) ?></div><div class="stat-lbl">Créditos totales</div></div>
        </div>
        <?php if ($prestamo_activo): ?>
        <div class="stat-card">
            <div class="stat-icon" style="background:#fef3c7;"><i class="bi bi-cash-stack" style="color:#d97706;"></i></div>
            <div><div class="stat-val">$<?= number_format($prestamo_activo['saldo_actual'],0) ?></div><div class="stat-lbl">Saldo actual</div></div>
        </div>
        <?php endif; ?>
    </div>

    <!-- ════════════ TARJETA DE PAGOS J.E. (compacta y responsiva) ════════════ -->
    <?php if ($prestamo_activo): ?>
    <div class="tarjeta-je">
        <div class="je-bar">
            <div class="je-title">
                <i class="bi bi-clipboard-check"></i>
                <div>
                    Tarjeta de Pagos J.E.
                    <small>Su mejor opción en préstamos · Cobros L–S</small>
                </div>
            </div>
            <div class="je-meta">
                Inicio: <?= date('d/m/Y', strtotime($fecha_inicio_p)) ?> · <?= $total_filas ?> cuotas
            </div>
        </div>

        <?php if (!$es_gerente): ?>
        <div class="je-banner-rol">
            <i class="bi bi-shield-lock-fill"></i> Modo lectura — solo el GERENTE puede modificar los pagos
        </div>
        <?php endif; ?>

        <!-- RESUMEN -->
        <div class="je-resumen">
            <div class="je-cell">
                <div class="lbl">Cuota diaria</div>
                <div class="val">$<?= number_format($pago_diario, 2) ?></div>
            </div>
            <div class="je-cell">
                <div class="lbl">Total a pagar</div>
                <div class="val">$<?= number_format($total_pagar_p, 2) ?></div>
            </div>
            <div class="je-cell pagado">
                <div class="lbl">Abonado</div>
                <div class="val" id="je-abonado">$<?= number_format($total_pagado_p, 2) ?></div>
            </div>
            <div class="je-cell saldo">
                <div class="lbl">Saldo</div>
                <div class="val" id="je-saldo">$<?= number_format($saldo_p, 2) ?></div>
            </div>
        </div>

        <form method="POST" id="form-tarjeta-pagos">
        <input type="hidden" name="accion" value="guardar_pagos">
        <input type="hidden" name="id_prestamo" value="<?= $prestamo_activo['id_prestamo'] ?>">

        <div class="je-tabla-wrap">
            <table class="je-tabla">
                <thead>
                    <tr>
                        <th class="col-num">#</th>
                        <th class="col-fecha">Fecha</th>
                        <th class="col-cuota">Cuota ($)</th>
                    </tr>
                </thead>
                <tbody id="je-tbody">
                    <?php for ($i = 1; $i <= $total_filas; $i++):
                        $f = $fechas_cuotas[$i-1] ?? date('Y-m-d');
                        $monto_existente = $pagos_por_cuota[$i]['monto'] ?? 0;
                        $fecha_existente = $pagos_por_cuota[$i]['fecha'] ?? $f;
                        $tiene = $monto_existente > 0;
                        $es_hoy = ($f === $hoy_str);
                        /* atrasada: la fecha programada ya pasó (es anterior a hoy) y no tiene pago */
                        $atrasada = (!$tiene && $f < $hoy_str);
                        $clases = [];
                        if ($tiene)    $clases[] = 'pagada';
                        if ($atrasada) $clases[] = 'atrasada';
                        if ($es_hoy)   $clases[] = 'hoy';
                    ?>
                    <tr class="<?= implode(' ', $clases) ?>">
                        <td class="cell-num"><?= $i ?></td>
                        <td class="cell-fecha"><?= date('d/m', strtotime($fecha_existente)) ?></td>
                        <td class="cell-cuota">
                            <input
                                type="text"
                                inputmode="decimal"
                                name="cuota[<?= $i ?>]"
                                value="<?= $tiene ? number_format($monto_existente, 2, '.', '') : '' ?>"
                                placeholder="<?= $atrasada ? '⚠ atraso' : '0.00' ?>"
                                class="<?= $tiene ? 'tiene-monto' : '' ?>"
                                <?= $es_gerente ? '' : 'disabled' ?>
                                onchange="jeActualizar()"
                                onkeyup="jeActualizar()"
                            >
                            <input type="hidden" name="fecha[<?= $i ?>]" value="<?= $fecha_existente ?>">
                        </td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>

        <div class="je-footer">
            <div><i class="bi bi-graph-up-arrow" style="color:#60a5fa;"></i> Atención: 6442 22 9739</div>
            <div class="actions">
                <?php if ($es_gerente): ?>
                <button type="button" class="btn-mini" onclick="jeLlenar()"><i class="bi bi-check2-square"></i> Llenar todas</button>
                <button type="button" class="btn-mini danger" onclick="jeLimpiar()"><i class="bi bi-eraser-fill"></i> Limpiar</button>
                <button type="submit" class="btn-mini primary"><i class="bi bi-floppy-fill"></i> Guardar tarjeta</button>
                <?php else: ?>
                <span style="font-size:.68rem;color:#64748b;"><i class="bi bi-lock-fill"></i> Edición restringida al GERENTE</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="je-status-bot">
            <div>Llenadas: <strong id="je-llenas"><?= $cuotas_llenadas ?></strong>/<strong><?= $total_filas ?></strong></div>
            <div>Cobros de Lunes a Sábado · Domingo no se cobra</div>
        </div>

        </form>
    </div>
    <?php endif; ?>

    <!-- ════════════ /TARJETA J.E. ════════════ -->

    <div class="layout-cols">

        <!-- ════ COLUMNA IZQUIERDA ════ -->
        <div>

            <!-- TIMELINE VISITAS -->
            <div class="card">
                <div class="card-head">
                    <div class="card-title"><i class="bi bi-journal-text" style="color:#2563eb;"></i> Historial de visitas</div>
                    <span style="font-size:.72rem;color:#94a3b8;"><?= count($lista_visitas) ?> registros</span>
                </div>
                <div class="card-body">
                    <?php if (empty($lista_visitas)): ?>
                    <div class="empty-tl">
                        <i class="bi bi-journal-x"></i>
                        <p>Aún no hay visitas registradas para este cliente.</p>
                        <p style="margin-top:4px;font-size:.76rem;">Usa el panel derecho para agregar la primera.</p>
                    </div>
                    <?php else: ?>
                    <div class="timeline">
                    <?php foreach ($lista_visitas as $v):
                        $res_key   = strtolower($v['resultado']);
                        $res_label = match($v['resultado']) {
                            'PAGO'          => 'Pago completo',
                            'PAGO_PARCIAL'  => 'Pago parcial',
                            'PROMESA_PAGO'  => 'Prometió pagar',
                            'NO_PAGO'       => 'No abonó',
                            'NO_ENCONTRADO' => 'No estaba en casa',
                            default         => $v['resultado']
                        };
                        $mot_label = match($v['motivo'] ?? '') {
                            'SIN_DINERO'        => 'Sin dinero',
                            'NO_ESTABA_EN_CASA' => 'No estaba en casa',
                            'ENFERMEDAD'        => 'Enfermedad',
                            'PROBLEMA_FAMILIAR' => 'Problema familiar',
                            'DESACUERDO_MONTO'  => 'Desacuerdo con el monto',
                            'PROMESA_POSTERIOR' => 'Promesa en fecha posterior',
                            'OTRO'              => 'Otro motivo',
                            default             => ''
                        };
                    ?>
                    <div class="tl-item">
                        <div class="tl-dot <?= $res_key ?>"></div>
                        <div class="tl-fecha"><?= date('d/m/Y', strtotime($v['fecha_visita'])) ?></div>
                        <div class="tl-card">
                            <div class="tl-card-top">
                                <span class="badge badge-<?= $res_key ?>"><?= $res_label ?></span>
                                <?php if (floatval($v['monto_pagado']) > 0): ?>
                                <span style="font-size:.78rem;font-weight:700;color:#16a34a;">+$<?= number_format($v['monto_pagado'],2) ?></span>
                                <?php endif; ?>
                                <span class="tl-asesor"><i class="bi bi-person-fill" style="font-size:.65rem;"></i> <?= htmlspecialchars(($v['emp_nombre'] ?? '') . ' ' . ($v['emp_apellido'] ?? '')) ?></span>
                            </div>
                            <?php if ($mot_label): ?>
                            <div class="tl-motivo"><i class="bi bi-tag-fill" style="font-size:.65rem;color:#94a3b8;"></i> <?= $mot_label ?></div>
                            <?php endif; ?>
                            <?php if (!empty($v['comentario'])): ?>
                            <div class="tl-comentario"><i class="bi bi-chat-quote" style="font-size:.7rem;color:#94a3b8;margin-right:4px;"></i><?= htmlspecialchars($v['comentario']) ?></div>
                            <?php endif; ?>
                            <?php if ($v['resultado'] === 'PROMESA_PAGO' && !empty($v['fecha_prometida'])): ?>
                            <div class="tl-promesa"><i class="bi bi-calendar-event" style="font-size:.65rem;"></i> Prometió pagar el <?= date('d/m/Y', strtotime($v['fecha_prometida'])) ?><?php if (!empty($v['monto_prometido'])): ?> — $<?= number_format($v['monto_prometido'],2) ?><?php endif; ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- PAGOS REALES -->
            <?php if (!empty($lista_pagos)): ?>
            <div class="card">
                <div class="card-head">
                    <div class="card-title"><i class="bi bi-cash-coin" style="color:#16a34a;"></i> Últimos pagos registrados</div>
                    <span style="font-size:.72rem;color:#94a3b8;">últimos 30</span>
                </div>
                <div style="overflow-x:auto;">
                    <table class="tabla-pagos">
                        <thead><tr><th>Fecha</th><th>Monto</th><th>Tipo</th><th>Cuota #</th></tr></thead>
                        <tbody>
                        <?php foreach ($lista_pagos as $pg): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($pg['fecha_pago'])) ?></td>
                            <td style="font-weight:700;color:#16a34a;">$<?= number_format($pg['monto_pagado'],2) ?></td>
                            <td style="font-size:.78rem;color:#64748b;"><?= htmlspecialchars($pg['tipo_pago'] ?? '—') ?></td>
                            <td style="font-size:.78rem;color:#94a3b8;"><?= $pg['cuota_numero'] ?: '—' ?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <!-- ════ COLUMNA DERECHA ════ -->
        <div>
            <div class="panel-visita">
                <h3><i class="bi bi-plus-circle-fill" style="color:#2563eb;"></i> Registrar visita de hoy</h3>

                <?php if (!$prestamo_activo): ?>
                <div style="text-align:center;padding:20px;color:#94a3b8;font-size:.82rem;">
                    <i class="bi bi-credit-card" style="font-size:2rem;display:block;margin-bottom:8px;opacity:.3;"></i>
                    Este cliente no tiene un préstamo activo en este momento.
                </div>
                <?php else: ?>

                <div style="background:#f8fafc;border-radius:10px;padding:12px 14px;margin-bottom:16px;border:1px solid #f1f5f9;">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:.05em;color:#94a3b8;margin-bottom:5px;">Préstamo activo</div>
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                        <div>
                            <div style="font-size:.84rem;font-weight:700;color:#0f172a;">Saldo: $<?= number_format($prestamo_activo['saldo_actual'],2) ?></div>
                            <div style="font-size:.72rem;color:#64748b;">
                                Cuota: $<?= number_format($prestamo_activo['pago_diario'],2) ?>
                                <?php if (!empty($prestamo_activo['fecha_fin'])): ?> · Vence: <?= date('d/m/Y', strtotime($prestamo_activo['fecha_fin'])) ?><?php endif; ?>
                            </div>
                        </div>
                        <span class="badge badge-<?= strtolower($prestamo_activo['estado']) ?>"><?= $prestamo_activo['estado'] ?></span>
                    </div>
                </div>

                <form method="POST">
                    <input type="hidden" name="accion"      value="comentario">
                    <input type="hidden" name="id_prestamo" value="<?= $prestamo_activo['id_prestamo'] ?>">

                    <div class="field">
                        <label><i class="bi bi-clipboard-check" style="margin-right:3px;"></i> Resultado de la visita</label>
                        <select name="resultado" id="sel-resultado" onchange="manejarResultado(this.value)" required>
                            <option value="">— Selecciona —</option>
                            <option value="PAGO">Pago completo</option>
                            <option value="PAGO_PARCIAL">Pago parcial</option>
                            <option value="PROMESA_PAGO">Prometió pagar</option>
                            <option value="NO_PAGO">No abonó</option>
                            <option value="NO_ENCONTRADO">No estaba en casa</option>
                        </select>
                    </div>

                    <div class="bloque-extra" id="bloque-monto-pagado">
                        <div class="field">
                            <label><i class="bi bi-currency-dollar" style="margin-right:3px;"></i> Monto pagado ($)</label>
                            <input type="number" name="monto_pagado" step="0.01" min="0" placeholder="<?= number_format($prestamo_activo['pago_diario'],2) ?>">
                        </div>
                    </div>

                    <div class="bloque-extra" id="bloque-promesa">
                        <div class="field">
                            <label><i class="bi bi-calendar-event" style="margin-right:3px;"></i> Fecha que prometió pagar</label>
                            <input type="date" name="fecha_prometida" min="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="field">
                            <label><i class="bi bi-currency-dollar" style="margin-right:3px;"></i> Monto prometido ($)</label>
                            <input type="number" name="monto_prometido" step="0.01" min="0">
                        </div>
                    </div>

                    <div class="bloque-extra" id="bloque-motivo">
                        <div class="field">
                            <label><i class="bi bi-tag" style="margin-right:3px;"></i> Motivo</label>
                            <select name="motivo">
                                <option value="">— Selecciona —</option>
                                <option value="SIN_DINERO">Sin dinero</option>
                                <option value="NO_ESTABA_EN_CASA">No estaba en casa</option>
                                <option value="ENFERMEDAD">Enfermedad</option>
                                <option value="PROBLEMA_FAMILIAR">Problema familiar</option>
                                <option value="DESACUERDO_MONTO">Desacuerdo con el monto</option>
                                <option value="PROMESA_POSTERIOR">Promesa en fecha posterior</option>
                                <option value="OTRO">Otro</option>
                            </select>
                        </div>
                    </div>

                    <div class="field">
                        <label><i class="bi bi-chat-left-text" style="margin-right:3px;"></i> Comentario (opcional)</label>
                        <textarea name="comentario" placeholder="Escribe aquí cualquier observación importante..."></textarea>
                    </div>

                    <button type="submit" class="btn-guardar-visita"><i class="bi bi-floppy-fill"></i> Guardar visita</button>
                </form>
                <?php endif; ?>
            </div>

            <?php if (count($lista_prestamos) > 1): ?>
            <div class="card" style="margin-top:16px;">
                <div class="card-head">
                    <div class="card-title"><i class="bi bi-archive" style="color:#7c3aed;"></i> Créditos anteriores</div>
                </div>
                <div class="card-body" style="padding:12px 16px;">
                <?php foreach ($lista_prestamos as $p):
                    if ($prestamo_activo && $p['id_prestamo'] === $prestamo_activo['id_prestamo']) continue;
                ?>
                <div style="padding:10px 0;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                    <div>
                        <div style="font-size:.82rem;font-weight:700;color:#0f172a;">
                            $<?= number_format($p['monto_prestado'],2) ?>
                            <span style="font-size:.7rem;font-weight:400;color:#94a3b8;">
                                prestado
                                <?php if ($p['pago_diario'] > 0): ?> · cuota $<?= number_format($p['pago_diario'],2) ?>
                                <?php elseif ($p['plazo_semanas'] > 0): ?> · <?= $p['plazo_semanas'] ?> semanas
                                <?php endif; ?>
                            </span>
                        </div>
                        <div style="font-size:.72rem;color:#94a3b8;margin-top:2px;">
                            <?= $p['fecha_inicio'] ? date('d/m/Y', strtotime($p['fecha_inicio'])) : '—' ?>
                            <?php if (!empty($p['fecha_fin'])): ?> → <?= date('d/m/Y', strtotime($p['fecha_fin'])) ?><?php endif; ?>
                        </div>
                    </div>
                    <span class="badge badge-<?= strtolower($p['estado']) ?>"><?= $p['estado'] ?></span>
                </div>
                <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>

</div>
</main>
</div>

<script>
/* ── TEMA ── */
(function() {
    var t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    var html  = document.documentElement;
    var nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

/* ── RELOJ ── */
function actualizarReloj() {
    var n = new Date(), p = function(x){ return String(x).padStart(2,'0'); };
    var el = document.getElementById('reloj');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

/* ── PANEL DE VISITA ── */
function manejarResultado(val) {
    document.getElementById('bloque-monto-pagado').style.display = (val === 'PAGO' || val === 'PAGO_PARCIAL') ? 'block' : 'none';
    document.getElementById('bloque-promesa').style.display      = val === 'PROMESA_PAGO' ? 'block' : 'none';
    document.getElementById('bloque-motivo').style.display       = (val === 'NO_PAGO' || val === 'NO_ENCONTRADO') ? 'block' : 'none';
}

/* ── TARJETA DE PAGOS J.E. ── */
<?php if ($prestamo_activo): ?>
const JE_PAGO_DIARIO = <?= json_encode($pago_diario) ?>;
const JE_TOTAL_PAGAR = <?= json_encode($total_pagar_p) ?>;
const JE_GERENTE     = <?= $es_gerente ? 'true' : 'false' ?>;
const JE_HOY         = <?= json_encode($hoy_str) ?>;

function jeFmt(n) { return '$' + Number(n).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}); }

function jeActualizar() {
    const filas = document.querySelectorAll('#je-tbody tr');
    let total = 0, llenas = 0;
    filas.forEach(tr => {
        const inp = tr.querySelector('input[name^="cuota["]');
        const fechaH = tr.querySelector('input[name^="fecha["]');
        const v = parseFloat((inp.value || '').toString().replace(/,/g,''));
        const fechaProg = fechaH.value;
        if (!isNaN(v) && v > 0) {
            total += v;
            llenas++;
            inp.classList.add('tiene-monto');
            tr.classList.add('pagada');
            tr.classList.remove('atrasada');
        } else {
            inp.classList.remove('tiene-monto');
            tr.classList.remove('pagada');
            /* atrasada: fecha programada anterior a hoy */
            if (fechaProg && fechaProg < JE_HOY) tr.classList.add('atrasada');
            else tr.classList.remove('atrasada');
        }
    });
    const saldo = Math.max(0, JE_TOTAL_PAGAR - total);
    document.getElementById('je-llenas').textContent  = llenas;
    document.getElementById('je-abonado').textContent = jeFmt(total);
    document.getElementById('je-saldo').textContent   = jeFmt(saldo);

    /* Auto-extender filas si se llena alguna de las últimas */
    if (JE_GERENTE) {
        const todas = document.querySelectorAll('#je-tbody tr');
        const ult3  = Array.from(todas).slice(-3);
        const algunaUltConValor = ult3.some(tr => {
            const i = tr.querySelector('input[name^="cuota["]');
            const v = parseFloat((i.value || '').toString().replace(/,/g,''));
            return !isNaN(v) && v > 0;
        });
        if (algunaUltConValor) jeAgregar(5);
    }
}

function jeAgregar(cuantas) {
    const tbody = document.getElementById('je-tbody');
    const filas = tbody.querySelectorAll('tr');
    let ultNum = filas.length;
    const ultFechaH = filas[filas.length - 1].querySelector('input[name^="fecha["]');
    let fecha = new Date(ultFechaH.value + 'T00:00:00');
    for (let k = 0; k < cuantas; k++) {
        ultNum++;
        do { fecha.setDate(fecha.getDate() + 1); } while (fecha.getDay() === 0); /* salta domingo */
        const yyyy = fecha.getFullYear();
        const mm   = String(fecha.getMonth()+1).padStart(2,'0');
        const dd   = String(fecha.getDate()).padStart(2,'0');
        const iso  = `${yyyy}-${mm}-${dd}`;
        const ddmm = `${dd}/${mm}`;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="cell-num">${ultNum}</td>
            <td class="cell-fecha">${ddmm}</td>
            <td class="cell-cuota">
                <input type="text" inputmode="decimal" name="cuota[${ultNum}]" placeholder="0.00"
                       onchange="jeActualizar()" onkeyup="jeActualizar()">
                <input type="hidden" name="fecha[${ultNum}]" value="${iso}">
            </td>
        `;
        tbody.appendChild(tr);
    }
}

function jeLlenar() {
    if (!JE_GERENTE) return;
    if (!JE_PAGO_DIARIO || JE_PAGO_DIARIO <= 0) { alert('No hay cuota diaria definida en el préstamo.'); return; }
    document.querySelectorAll('#je-tbody input[name^="cuota["]').forEach(inp => {
        if (!inp.value || parseFloat(inp.value) === 0) inp.value = Number(JE_PAGO_DIARIO).toFixed(2);
    });
    jeActualizar();
}

function jeLimpiar() {
    if (!JE_GERENTE) return;
    if (!confirm('¿Limpiar todos los pagos de la tarjeta? Se aplicará al guardar.')) return;
    document.querySelectorAll('#je-tbody input[name^="cuota["]').forEach(inp => inp.value = '');
    jeActualizar();
}

document.addEventListener('input', function(e) {
    if (e.target.matches('#je-tbody input[name^="cuota["]')) {
        e.target.value = e.target.value.replace(/[^0-9.]/g, '');
    }
});

jeActualizar();
<?php endif; ?>
</script>
</body>
</html>

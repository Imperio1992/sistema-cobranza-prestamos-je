<?php
$roles_permitidos = ['GERENTE'];
include("seguridad.php");
include("conexion.php");

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: empleados.php");
    exit;
}

$id = (int) $_GET['id'];

// Reactivar empleado
$conexion->query("
    UPDATE empleados 
    SET estatus = 'ACTIVO'
    WHERE id_empleado = $id
");

// Reactivar usuario
$conexion->query("
    UPDATE usuarios
    SET estatus = 'ACTIVO'
    WHERE id_empleado = $id
");

header("Location: empleados.php");
exit;
?>
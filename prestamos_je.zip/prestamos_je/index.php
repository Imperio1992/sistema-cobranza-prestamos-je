<?php
include("seguridad.php");
include("conexion.php");

// ──────────────────────────────────────
// DATOS DE SESIÓN
// ──────────────────────────────────────
$rol  = $_SESSION['rol']        ?? 'ASESOR';
$user = $_SESSION['usuario']    ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);
$hoy  = date("Y-m-d");
$hora = date("H");

// Saludo según hora
if     ($hora < 12) $saludo = "Buenos días";
elseif ($hora < 19) $saludo = "Buenas tardes";
else                $saludo = "Buenas noches";

// ──────────────────────────────────────
// MÉTRICAS GLOBALES (para GERENTE)
// ──────────────────────────────────────
$total_activos = $conexion->query("SELECT COUNT(*) AS t FROM prestamos WHERE estado='ACTIVO'")->fetch_assoc()['t'];
$total_vencidos= $conexion->query("SELECT COUNT(*) AS t FROM prestamos WHERE estado='ATRASADO'")->fetch_assoc()['t'];

$cobrado_hoy_global = (float)$conexion->query("
    SELECT COALESCE(SUM(monto_pagado),0) AS t FROM pagos WHERE DATE(fecha_pago)=CURRENT_DATE()
")->fetch_assoc()['t'];

$nuevos_hoy = $conexion->query("
    SELECT COUNT(*) AS t FROM prestamos WHERE DATE(fecha_inicio)=CURRENT_DATE()
")->fetch_assoc()['t'];

$clientes_total = $conexion->query("SELECT COUNT(*) AS t FROM clientes")->fetch_assoc()['t'];

// ──────────────────────────────────────
// MÉTRICAS DEL ASESOR LOGUEADO
// ──────────────────────────────────────
$mis_prestamos = 0;
$mi_cobrado_hoy = 0;
$mis_vencidos = 0;
$mi_cobrado_mes = 0;

if ($id_emp > 0) {
    $mis_prestamos = $conexion->query("
        SELECT COUNT(*) AS t FROM prestamos WHERE id_empleado=$id_emp AND estado='ACTIVO'
    ")->fetch_assoc()['t'];

    $mi_cobrado_hoy = (float)$conexion->query("
        SELECT COALESCE(SUM(p.monto_pagado),0) AS t
        FROM pagos p INNER JOIN prestamos pr ON pr.id_prestamo=p.id_prestamo
        WHERE pr.id_empleado=$id_emp AND DATE(p.fecha_pago)=CURRENT_DATE()
    ")->fetch_assoc()['t'];

    $mis_vencidos = $conexion->query("
        SELECT COUNT(*) AS t FROM prestamos WHERE id_empleado=$id_emp AND estado='ATRASADO'
    ")->fetch_assoc()['t'];

    $mi_cobrado_mes = (float)$conexion->query("
        SELECT COALESCE(SUM(p.monto_pagado),0) AS t
        FROM pagos p INNER JOIN prestamos pr ON pr.id_prestamo=p.id_prestamo
        WHERE pr.id_empleado=$id_emp
        AND MONTH(p.fecha_pago)=MONTH(CURRENT_DATE()) AND YEAR(p.fecha_pago)=YEAR(CURRENT_DATE())
    ")->fetch_assoc()['t'];
}

// ──────────────────────────────────────
// ALERTAS: Vencimientos hoy y mañana
// ──────────────────────────────────────
$sql_alerta = "
    SELECT c.nombre, c.apellido, pr.total_pagar,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_fin,
           e.nombre AS asesor
    FROM prestamos pr
    INNER JOIN clientes c  ON c.id_cliente=pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado=pr.id_empleado
    WHERE pr.estado='ACTIVO'
    AND DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 1 DAY)
";
if ($rol !== 'GERENTE' && $id_emp > 0) {
    $sql_alerta .= " AND pr.id_empleado=$id_emp";
}
$sql_alerta .= " ORDER BY fecha_fin ASC LIMIT 5";
$alertas_venc = [];
$r_alerta = $conexion->query($sql_alerta);
while ($a = $r_alerta->fetch_assoc()) $alertas_venc[] = $a;

// ──────────────────────────────────────
// LISTA DE PRÉSTAMOS VENCIDOS (con nombres)
// ──────────────────────────────────────
$sql_venc = "
    SELECT c.nombre, c.apellido, pr.total_pagar,
           DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY) AS fecha_fin,
           e.nombre AS asesor,
           DATEDIFF(CURRENT_DATE(), DATE_ADD(pr.fecha_inicio, INTERVAL pr.dias DAY)) AS dias_vencido
    FROM prestamos pr
    INNER JOIN clientes c  ON c.id_cliente = pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado = pr.id_empleado
    WHERE pr.estado = 'ATRASADO'
";
if ($rol !== 'GERENTE' && $id_emp > 0) {
    $sql_venc .= " AND pr.id_empleado = $id_emp";
}
$sql_venc .= " ORDER BY dias_vencido DESC LIMIT 6";
$lista_vencidos = [];
$r_venc = $conexion->query($sql_venc);
while ($v = $r_venc->fetch_assoc()) $lista_vencidos[] = $v;

// Conteo correcto según rol
$vencidos_mostrar = ($rol === 'GERENTE') ? $total_vencidos : $mis_vencidos;

// ──────────────────────────────────────
// ÚLTIMOS 5 PAGOS DEL ASESOR (o globales para GERENTE)
// ──────────────────────────────────────
$sql_pagos = "
    SELECT p.monto_pagado, p.fecha_pago,
           c.nombre AS cn, c.apellido AS ca
    FROM pagos p
    INNER JOIN prestamos pr ON pr.id_prestamo=p.id_prestamo
    INNER JOIN clientes c   ON c.id_cliente=pr.id_cliente
";
if ($rol !== 'GERENTE' && $id_emp > 0) {
    $sql_pagos .= " WHERE pr.id_empleado=$id_emp";
}
$sql_pagos .= " ORDER BY p.fecha_pago DESC, p.id_pago DESC LIMIT 5";
$ultimos_pagos = [];
$r_pagos = $conexion->query($sql_pagos);
while ($p = $r_pagos->fetch_assoc()) $ultimos_pagos[] = $p;
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Inicio | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
/* ─── RESET ─── */
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }

/* ─── LAYOUT ─── */
.app { display:flex; min-height:100vh; }

/* ════════════════════════════════════
   SIDEBAR
════════════════════════════════════ */
.sidebar {
    width: 240px;
    background: #0f172a;
    height: 100vh;
    position: fixed;
    top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto;
    z-index:200;
    box-shadow: 4px 0 20px rgba(0,0,0,0.2);
}

.sb-brand {
    padding: 22px 20px 16px;
    border-bottom: 1px solid #1e293b;
}
.sb-brand .brand-row {
    display:flex; align-items:center; gap:12px;
}
.sb-brand .brand-icon {
    width:44px; height:44px;
    background: linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px;
    display:flex; align-items:center; justify-content:center;
    font-size:1.3rem;
    box-shadow:0 4px 14px rgba(37,99,235,0.4);
    flex-shrink:0;
}
.sb-brand .brand-name {
    font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-0.3px;
}
.sb-brand .brand-sub {
    font-size:0.65rem; color:#475569; text-transform:uppercase; letter-spacing:0.8px; margin-top:2px;
}

.sb-user {
    padding:12px 16px;
    background:#1e293b;
    border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px;
    background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:0.85rem; font-weight:700; color:#fff;
    flex-shrink:0;
}
.sb-user .u-name { font-size:0.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:0.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }

/* Reloj en sidebar */
.sb-clock {
    padding:10px 16px;
    background:#0f172a;
    border-bottom:1px solid #1e293b;
    text-align:center;
}
.sb-clock #reloj {
    font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums;
}
.sb-clock .fecha-hoy { font-size:0.68rem; color:#475569; margin-top:2px; }

.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section {
    font-size:0.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em;
    color:#475569; padding:12px 8px 4px;
}
.sb-nav a {
    display:flex; align-items:center; gap:9px;
    color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px;
    font-size:0.84rem; font-weight:500;
    margin-bottom:1px; transition:all 0.15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger { color:#f87171; }
.sb-nav a.danger:hover { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }

/* Badge alertas sidebar */
.sb-badge {
    margin-left:auto; background:#ef4444; color:white;
    font-size:0.65rem; font-weight:700; border-radius:99px;
    padding:1px 6px; min-width:18px; text-align:center;
}

.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px;
    color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px;
    font-size:0.84rem; transition:all 0.15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ════════════════════════════════════
   MAIN
════════════════════════════════════ */
.main { margin-left:240px; flex:1; padding:24px 28px 48px; }

/* ─── TOP BAR ─── */
.topbar {
    display:flex; justify-content:space-between; align-items:center;
    margin-bottom:24px; gap:12px; flex-wrap:wrap;
}
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-logo {
    height:50px; border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1); object-fit:cover;
}
.topbar-title { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-0.4px; }
.topbar-sub   { font-size:0.82rem; color:#64748b; margin-top:1px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.system-badge {
    display:inline-flex; align-items:center; gap:6px;
    background:#f0fdf4; border:1px solid #86efac; color:#15803d;
    border-radius:99px; padding:5px 14px; font-size:0.78rem; font-weight:600;
}
.system-badge .dot {
    width:7px; height:7px; background:#22c55e; border-radius:50%;
    animation:blink 2s infinite;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }

/* ─── BANNER BIENVENIDA ─── */
.welcome {
    background: linear-gradient(135deg,#0f172a 0%,#1e3a8a 55%,#1d4ed8 100%);
    border-radius:20px; padding:26px 30px;
    margin-bottom:24px;
    display:flex; align-items:center; justify-content:space-between;
    gap:16px; flex-wrap:wrap;
    box-shadow:0 8px 30px rgba(37,99,235,0.22);
    position:relative; overflow:hidden;
}
.welcome::before {
    content:''; position:absolute;
    top:-50px; right:-50px; width:220px; height:220px;
    background:rgba(255,255,255,0.04); border-radius:50%;
}
.welcome::after {
    content:''; position:absolute;
    bottom:-70px; right:100px; width:160px; height:160px;
    background:rgba(255,255,255,0.03); border-radius:50%;
}
.welcome-text { position:relative; z-index:1; }
.welcome-text h2 { font-size:1.35rem; font-weight:800; color:#fff; margin-bottom:5px; letter-spacing:-0.3px; }
.welcome-text p  { font-size:0.85rem; color:#93c5fd; max-width:380px; line-height:1.5; }
.welcome-stats {
    display:flex; gap:14px; flex-shrink:0; position:relative; z-index:1; flex-wrap:wrap;
}
.w-stat {
    background:rgba(255,255,255,0.09);
    border:1px solid rgba(255,255,255,0.13);
    border-radius:14px; padding:14px 18px;
    text-align:center; backdrop-filter:blur(4px);
    min-width:90px;
}
.w-stat strong { display:block; font-size:1.5rem; font-weight:800; color:#fff; line-height:1; margin-bottom:3px; }
.w-stat small  { font-size:0.68rem; color:#93c5fd; text-transform:uppercase; letter-spacing:.06em; }

/* ─── ALERTAS ─── */
.alertas-row {
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap:16px;
    margin-bottom:24px;
}
.alerta-box {
    border-radius:14px; padding:16px 18px;
    border:1px solid transparent;
}
.alerta-box.rojo  { background:#fff1f2; border-color:#fecaca; }
.alerta-box.ambar { background:#fffbeb; border-color:#fde68a; }
.alerta-box.verde { background:#f0fdf4; border-color:#bbf7d0; }
.alerta-header {
    display:flex; align-items:center; gap:8px;
    margin-bottom:12px;
}
.alerta-header i { font-size:1.1rem; }
.alerta-header strong { font-size:0.85rem; font-weight:700; }
.alerta-box.rojo  .alerta-header  { color:#b91c1c; }
.alerta-box.ambar .alerta-header  { color:#92400e; }
.alerta-item {
    display:flex; align-items:center; justify-content:space-between;
    padding:7px 0; border-bottom:1px solid rgba(0,0,0,0.05); font-size:0.82rem;
}
.alerta-item:last-child { border-bottom:none; }
.alerta-item .nombre   { font-weight:600; color:#1e293b; }
.alerta-item .sub-info { font-size:0.72rem; color:#64748b; margin-top:1px; }
.alerta-item .monto    { font-weight:700; color:#0f172a; white-space:nowrap; }
.alerta-vacio { color:#94a3b8; font-size:0.82rem; text-align:center; padding:8px 0; }

/* ─── PANEL MI DÍA (ASESOR) ─── */
.mi-dia {
    background:white; border-radius:16px; padding:18px 20px;
    box-shadow:0 2px 10px rgba(0,0,0,0.06);
    border:1px solid #f1f5f9;
    margin-bottom:24px;
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap:16px;
}
.mi-dia-item { text-align:center; }
.mi-dia-val  { font-size:1.6rem; font-weight:800; color:#0f172a; line-height:1; margin-bottom:3px; }
.mi-dia-lbl  { font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:.05em; font-weight:500; }
.mi-dia-item.exito .mi-dia-val { color:#16a34a; }
.mi-dia-item.peligro .mi-dia-val { color:#dc2626; }
.mi-dia-item.info .mi-dia-val { color:#2563eb; }

/* ─── SECCIÓN TÍTULO ─── */
.section-title {
    font-size:0.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em;
    color:#94a3b8; margin-bottom:14px; margin-top:4px;
    display:flex; align-items:center; gap:8px;
}
.section-title::after { content:''; flex:1; height:1px; background:#e2e8f0; }

/* ─── ACCESO RÁPIDO ─── */
.quick-grid {
    display:grid;
    grid-template-columns:repeat(auto-fill, minmax(130px, 1fr));
    gap:10px; margin-bottom:26px;
}
.qbtn {
    display:flex; flex-direction:column; align-items:center; gap:7px;
    background:white; border:1px solid #f1f5f9; border-radius:14px;
    padding:14px 10px; text-decoration:none; text-align:center;
    box-shadow:0 1px 4px rgba(0,0,0,0.04);
    transition:all 0.18s;
}
.qbtn:hover { transform:translateY(-3px); box-shadow:0 8px 20px rgba(0,0,0,0.09); border-color:#e2e8f0; }
.qbtn .qi {
    width:40px; height:40px; border-radius:11px;
    display:flex; align-items:center; justify-content:center; font-size:1.2rem;
}
.qbtn span { font-size:0.73rem; font-weight:600; color:#374151; line-height:1.3; }
.qbtn small { font-size:0.65rem; color:#94a3b8; }

/* ─── GRID MÓDULOS ─── */
.mods-grid {
    display:grid;
    grid-template-columns:repeat(auto-fill, minmax(230px, 1fr));
    gap:16px;
    margin-bottom:28px;
}
.mod {
    background:white; border-radius:16px;
    border:1px solid #f1f5f9;
    box-shadow:0 2px 8px rgba(0,0,0,0.05);
    display:flex; flex-direction:column;
    overflow:hidden;
    transition:transform 0.18s, box-shadow 0.18s;
}
.mod:hover { transform:translateY(-4px); box-shadow:0 12px 30px rgba(0,0,0,0.1); }

/* Barra de color superior */
.mod-bar { height:4px; }
.mod-bar.azul    { background:linear-gradient(90deg,#2563eb,#60a5fa); }
.mod-bar.verde   { background:linear-gradient(90deg,#16a34a,#4ade80); }
.mod-bar.naranja { background:linear-gradient(90deg,#f59e0b,#fbbf24); }
.mod-bar.rojo    { background:linear-gradient(90deg,#dc2626,#f87171); }
.mod-bar.morado  { background:linear-gradient(90deg,#7c3aed,#c4b5fd); }
.mod-bar.cyan    { background:linear-gradient(90deg,#0891b2,#67e8f9); }
.mod-bar.slate   { background:linear-gradient(90deg,#475569,#94a3b8); }
.mod-bar.rosa    { background:linear-gradient(90deg,#e11d48,#fda4af); }

.mod-top  { padding:18px 18px 12px; display:flex; align-items:flex-start; gap:12px; }
.mod-ic   { width:46px; height:46px; border-radius:13px; display:flex; align-items:center; justify-content:center; font-size:1.35rem; flex-shrink:0; }
.mod-ic.azul    { background:#eff6ff; }
.mod-ic.verde   { background:#f0fdf4; }
.mod-ic.naranja { background:#fff7ed; }
.mod-ic.rojo    { background:#fef2f2; }
.mod-ic.morado  { background:#faf5ff; }
.mod-ic.cyan    { background:#ecfeff; }
.mod-ic.slate   { background:#f8fafc; }
.mod-ic.rosa    { background:#fff1f2; }

.mod-info h3 { font-size:0.95rem; font-weight:700; color:#0f172a; margin-bottom:3px; }
.mod-info p  { font-size:0.76rem; color:#94a3b8; line-height:1.4; }

/* Notificación en mod */
.mod-notif {
    margin:0 18px 8px;
    background:#fef2f2; border:1px solid #fecaca;
    border-radius:8px; padding:6px 10px;
    font-size:0.73rem; color:#b91c1c; font-weight:600;
    display:flex; align-items:center; gap:5px;
}

.mod-actions { padding:0 14px 14px; display:flex; flex-direction:column; gap:7px; flex:1; justify-content:flex-end; }

.mbtn {
    display:block; text-align:center; text-decoration:none;
    border-radius:9px; padding:9px 12px;
    font-size:0.82rem; font-weight:600;
    transition:all 0.15s; border:none; cursor:pointer;
}
.mbtn.s-azul    { background:#2563eb; color:#fff; }
.mbtn.s-azul:hover    { background:#1d4ed8; }
.mbtn.s-verde   { background:#16a34a; color:#fff; }
.mbtn.s-verde:hover   { background:#15803d; }
.mbtn.s-naranja { background:#f59e0b; color:#fff; }
.mbtn.s-naranja:hover { background:#d97706; }
.mbtn.s-rojo    { background:#dc2626; color:#fff; }
.mbtn.s-rojo:hover    { background:#b91c1c; }
.mbtn.s-morado  { background:#7c3aed; color:#fff; }
.mbtn.s-morado:hover  { background:#6d28d9; }
.mbtn.s-cyan    { background:#0891b2; color:#fff; }
.mbtn.s-cyan:hover    { background:#0e7490; }
.mbtn.s-slate   { background:#475569; color:#fff; }
.mbtn.s-slate:hover   { background:#334155; }
.mbtn.s-rosa    { background:#e11d48; color:#fff; }
.mbtn.s-rosa:hover    { background:#be123c; }

.mbtn.o-azul    { background:transparent; color:#2563eb; border:1.5px solid #2563eb; }
.mbtn.o-azul:hover    { background:#eff6ff; }
.mbtn.o-verde   { background:transparent; color:#16a34a; border:1.5px solid #16a34a; }
.mbtn.o-verde:hover   { background:#f0fdf4; }
.mbtn.o-rojo    { background:transparent; color:#dc2626; border:1.5px solid #fecaca; }
.mbtn.o-rojo:hover    { background:#fef2f2; }
.mbtn.o-morado  { background:transparent; color:#7c3aed; border:1.5px solid #7c3aed; }
.mbtn.o-morado:hover  { background:#faf5ff; }
.mbtn.o-slate   { background:transparent; color:#64748b; border:1.5px solid #e2e8f0; }
.mbtn.o-slate:hover   { background:#f8fafc; }

/* Tarjeta especial */
.mod.especial { border:2px solid #c4b5fd; background:linear-gradient(160deg,#faf5ff,#fff); }
.mod.cobro    { border:2px solid #fda4af; background:linear-gradient(160deg,#fff1f2,#fff); }

/* ─── ÚLTIMOS PAGOS ─── */
.recientes {
    background:white; border-radius:16px;
    border:1px solid #f1f5f9; box-shadow:0 2px 8px rgba(0,0,0,0.05);
    overflow:hidden; margin-bottom:28px;
}
.recientes-header {
    padding:14px 18px; border-bottom:1px solid #f1f5f9;
    display:flex; align-items:center; gap:8px;
}
.recientes-header h6 { font-size:0.88rem; font-weight:700; color:#0f172a; margin:0; }
.pago-row {
    display:flex; align-items:center; gap:12px;
    padding:10px 18px; border-bottom:1px solid #f9fafb;
}
.pago-row:last-child { border-bottom:none; }
.pago-avatar {
    width:32px; height:32px; border-radius:9px;
    background:linear-gradient(135deg,#2563eb,#7c3aed);
    display:flex; align-items:center; justify-content:center;
    font-size:0.7rem; font-weight:700; color:white; flex-shrink:0;
}
.pago-nombre { font-size:0.83rem; font-weight:600; color:#0f172a; }
.pago-fecha  { font-size:0.7rem;  color:#94a3b8; margin-top:1px; }
.pago-monto  { margin-left:auto; font-size:0.88rem; font-weight:700; color:#16a34a; white-space:nowrap; }
.pago-vacio  { padding:16px 18px; font-size:0.83rem; color:#94a3b8; text-align:center; }

/* ─── FOOTER ─── */
.page-footer {
    text-align:center; color:#cbd5e1; font-size:0.72rem;
    padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px;
}

/* ─── ANIMACIONES ─── */
.fade { opacity:0; transform:translateY(14px); animation:fadeUp 0.4s forwards; }
@keyframes fadeUp { to{opacity:1;transform:translateY(0);} }

/* ─── RESPONSIVE ─── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 40px; }
    .alertas-row { grid-template-columns:1fr; }
    .welcome-stats { display:none; }
    .mi-dia  { grid-template-columns:repeat(2,1fr); }
}
@media(max-width:540px){
    .mods-grid  { grid-template-columns:1fr; }
    .quick-grid { grid-template-columns:repeat(3,1fr); }
    .mi-dia     { grid-template-columns:1fr 1fr; }
}

/* ════════════════════════════════════
   BOTÓN TEMA
════════════════════════════════════ */
.btn-theme {
    width: 38px; height: 38px;
    border-radius: 10px;
    border: 1.5px solid #e2e8f0;
    background: white;
    color: #64748b;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem;
    transition: all 0.2s;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.btn-theme:hover { color: #0f172a; border-color: #2563eb; }

/* ════════════════════════════════════
   MODO OSCURO
════════════════════════════════════ */
[data-theme="dark"] body { background: #0a0f1e; color: #e2e8f0; }

[data-theme="dark"] .topbar-title { color: #e2e8f0; }
[data-theme="dark"] .topbar-sub   { color: #94a3b8; }

[data-theme="dark"] .btn-theme {
    background: #111827; border-color: #1e293b; color: #94a3b8;
}
[data-theme="dark"] .btn-theme:hover { color: #e2e8f0; border-color: #3b82f6; }

[data-theme="dark"] .system-badge {
    background: #052e16; border-color: #166534; color: #4ade80;
}

[data-theme="dark"] .alerta-box.rojo  { background: #1c0a0a; border-color: #7f1d1d; }
[data-theme="dark"] .alerta-box.ambar { background: #1c1500; border-color: #78350f; }
[data-theme="dark"] .alerta-box.verde { background: #052e16; border-color: #166534; }
[data-theme="dark"] .alerta-box.rojo  .alerta-header { color: #fca5a5; }
[data-theme="dark"] .alerta-box.ambar .alerta-header { color: #fde68a; }
[data-theme="dark"] .alerta-item .nombre { color: #e2e8f0; }
[data-theme="dark"] .alerta-item .monto  { color: #e2e8f0; }
[data-theme="dark"] .alerta-item { border-bottom-color: rgba(255,255,255,0.06); }

[data-theme="dark"] .mi-dia { background: #111827; border-color: #1e293b; }
[data-theme="dark"] .mi-dia-val { color: #e2e8f0; }
[data-theme="dark"] .mi-dia-item.info.mi-dia-val { color: #60a5fa; }

[data-theme="dark"] .section-title { color: #475569; }
[data-theme="dark"] .section-title::after { background: #1e293b; }

[data-theme="dark"] .qbtn { background: #111827; border-color: #1e293b; }
[data-theme="dark"] .qbtn:hover { border-color: #334155; box-shadow: 0 8px 20px rgba(0,0,0,0.3); }
[data-theme="dark"] .qbtn span { color: #e2e8f0; }

[data-theme="dark"] .mod { background: #111827; border-color: #1e293b; }
[data-theme="dark"] .mod:hover { box-shadow: 0 12px 30px rgba(0,0,0,0.4); }
[data-theme="dark"] .mod-info h3 { color: #e2e8f0; }
[data-theme="dark"] .mod-ic.azul    { background: rgba(37,99,235,0.15); }
[data-theme="dark"] .mod-ic.verde   { background: rgba(22,163,74,0.15); }
[data-theme="dark"] .mod-ic.naranja { background: rgba(245,158,11,0.15); }
[data-theme="dark"] .mod-ic.rojo    { background: rgba(220,38,38,0.15); }
[data-theme="dark"] .mod-ic.morado  { background: rgba(124,58,237,0.15); }
[data-theme="dark"] .mod-ic.cyan    { background: rgba(8,145,178,0.15); }
[data-theme="dark"] .mod-ic.slate   { background: rgba(71,85,105,0.15); }
[data-theme="dark"] .mod-ic.rosa    { background: rgba(225,29,72,0.15); }
[data-theme="dark"] .mod-notif { background: #1c0a0a; border-color: #7f1d1d; color: #fca5a5; }
[data-theme="dark"] .mod.especial { background: #1a1030; border-color: #6d28d9; }
[data-theme="dark"] .mod.cobro    { background: #1c0a14; border-color: #be123c; }

[data-theme="dark"] .mbtn.o-azul   { border-color: #2563eb; }
[data-theme="dark"] .mbtn.o-azul:hover   { background: rgba(37,99,235,0.15); }
[data-theme="dark"] .mbtn.o-verde:hover  { background: rgba(22,163,74,0.15); }
[data-theme="dark"] .mbtn.o-rojo  { border-color: #7f1d1d; }
[data-theme="dark"] .mbtn.o-rojo:hover   { background: rgba(220,38,38,0.15); }
[data-theme="dark"] .mbtn.o-morado:hover { background: rgba(124,58,237,0.15); }
[data-theme="dark"] .mbtn.o-slate { border-color: #334155; }
[data-theme="dark"] .mbtn.o-slate:hover  { background: rgba(71,85,105,0.15); }

[data-theme="dark"] .recientes { background: #111827; border-color: #1e293b; }
[data-theme="dark"] .recientes-header { border-color: #1e293b; }
[data-theme="dark"] .recientes-header h6 { color: #e2e8f0; }
[data-theme="dark"] .pago-row { border-color: #111827; }
[data-theme="dark"] .pago-nombre { color: #e2e8f0; }
[data-theme="dark"] .pago-monto  { color: #4ade80; }

[data-theme="dark"] .page-footer { color: #334155; border-color: #1e293b; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">

    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>

    <nav class="sb-nav">

        <div class="sb-section">Principal</div>
        <a href="index.php" class="active"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>

        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-cash-coin"></i> Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="solicitud_nueva.php"><i class="bi bi-file-earmark-text"></i> Solicitud Nueva</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger">
            <i class="bi bi-calendar-check"></i> Cobro Diario
            <?php if ($mis_vencidos > 0): ?>
            <span class="sb-badge"><?= $mis_vencidos ?></span>
            <?php endif; ?>
        </a>

        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>

        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>

    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>

</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOP BAR -->
    <div class="topbar fade" style="animation-delay:.0s">
        <div class="topbar-left">
            <img src="img/logo.jpeg" class="topbar-logo" alt="J.E." onerror="this.style.display='none'">
            <div>
                <div class="topbar-title">Préstamos J.E.</div>
                <div class="topbar-sub">Panel de Control — <?= date('d/m/Y') ?></div>
            </div>
        </div>
        <div class="topbar-right">
            <!-- BOTÓN TEMA CLARO/OSCURO -->
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
            <div class="system-badge">
                <span class="dot"></span> Sistema activo
            </div>
        </div>
    </div>

    <!-- BANNER BIENVENIDA -->
    <div class="welcome fade" style="animation-delay:.05s">
        <div class="welcome-text">
            <h2><?= $saludo ?>, <?= htmlspecialchars($user) ?> 👋</h2>
            <p>
                Accediste como <strong style="color:#fff;"><?= htmlspecialchars($rol) ?></strong>.
                <?php if ($rol === 'GERENTE'): ?>
                Hoy hay <strong style="color:#fff;"><?= $total_activos ?></strong> préstamos activos
                y se han cobrado <strong style="color:#fff;">$<?= number_format($cobrado_hoy_global,2) ?></strong>.
                <?php else: ?>
                Tienes <strong style="color:#fff;"><?= $mis_prestamos ?></strong> préstamos activos.
                Hoy llevas cobrado <strong style="color:#fff;">$<?= number_format($mi_cobrado_hoy,2) ?></strong>.
                <?php endif; ?>
            </p>
        </div>
        <div class="welcome-stats">
            <?php if ($rol === 'GERENTE'): ?>
            <div class="w-stat">
                <strong><?= $total_activos ?></strong>
                <small>Activos</small>
            </div>
            <div class="w-stat">
                <strong><?= $nuevos_hoy ?></strong>
                <small>Nuevos hoy</small>
            </div>
            <div class="w-stat">
                <strong><?= $clientes_total ?></strong>
                <small>Clientes</small>
            </div>
            <?php else: ?>
            <div class="w-stat">
                <strong><?= $mis_prestamos ?></strong>
                <small>Mis Préstamos</small>
            </div>
            <div class="w-stat">
                <strong>$<?= number_format($mi_cobrado_hoy,0) ?></strong>
                <small>Cobrado Hoy</small>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- MI DÍA (estadísticas del asesor) -->
    <?php if ($id_emp > 0): ?>
    <div class="mi-dia fade" style="animation-delay:.08s">
        <div class="mi-dia-item info">
            <div class="mi-dia-val"><?= $mis_prestamos ?></div>
            <div class="mi-dia-lbl">Préstamos activos</div>
        </div>
        <div class="mi-dia-item exito">
            <div class="mi-dia-val">$<?= number_format($mi_cobrado_hoy,2) ?></div>
            <div class="mi-dia-lbl">Cobrado hoy</div>
        </div>
        <div class="mi-dia-item <?= $mis_vencidos > 0 ? 'peligro' : 'exito' ?>">
            <div class="mi-dia-val"><?= $mis_vencidos ?></div>
            <div class="mi-dia-lbl">Vencidos</div>
        </div>
        <div class="mi-dia-item info">
            <div class="mi-dia-val">$<?= number_format($mi_cobrado_mes,2) ?></div>
            <div class="mi-dia-lbl">Cobrado este mes</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ALERTAS: Vencimientos hoy/mañana + Préstamos vencidos (siempre visible) -->
    <div class="alertas-row fade" style="animation-delay:.1s">

        <!-- Vencimientos hoy/mañana -->
        <?php if (!empty($alertas_venc)): ?>
        <div class="alerta-box ambar">
            <div class="alerta-header">
                <i class="bi bi-alarm-fill"></i>
                <strong>Vencimientos hoy / mañana (<?= count($alertas_venc) ?>)</strong>
            </div>
            <?php foreach ($alertas_venc as $av):
                $dias = (int)ceil((strtotime($av['fecha_fin']) - strtotime($hoy)) / 86400);
                $tag  = $dias <= 0 ? '🔴 HOY' : '🟡 Mañana';
            ?>
            <div class="alerta-item">
                <div>
                    <div class="nombre"><?= htmlspecialchars($av['nombre'].' '.$av['apellido']) ?></div>
                    <div class="sub-info"><?= $tag ?><?= $rol === 'GERENTE' ? ' — '.htmlspecialchars($av['asesor']) : '' ?></div>
                </div>
                <div class="monto">$<?= number_format($av['total_pagar'],2) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="alerta-box verde">
            <div class="alerta-header">
                <i class="bi bi-check-circle-fill"></i>
                <strong style="color:#15803d;">Sin vencimientos hoy ni mañana</strong>
            </div>
            <div class="alerta-vacio">¡Todo al corriente! 🎉</div>
        </div>
        <?php endif; ?>

        <!-- Préstamos vencidos con lista real -->
        <div class="alerta-box <?= $vencidos_mostrar > 0 ? 'rojo' : 'verde' ?>">
            <div class="alerta-header">
                <i class="bi bi-<?= $vencidos_mostrar > 0 ? 'exclamation-triangle-fill' : 'shield-check-fill' ?>"></i>
                <strong>
                    <?= $vencidos_mostrar > 0
                        ? "$vencidos_mostrar préstamo" . ($vencidos_mostrar > 1 ? 's' : '') . " vencido" . ($vencidos_mostrar > 1 ? 's' : '')
                        : "Sin préstamos vencidos" ?>
                </strong>
                <?php if ($vencidos_mostrar > 0 && $vencidos_mostrar > count($lista_vencidos)): ?>
                <span style="margin-left:auto;font-size:.7rem;color:#94a3b8;font-weight:500;">mostrando <?= count($lista_vencidos) ?></span>
                <?php endif; ?>
            </div>
            <?php if (!empty($lista_vencidos)): ?>
                <?php foreach ($lista_vencidos as $lv): ?>
                <div class="alerta-item">
                    <div>
                        <div class="nombre"><?= htmlspecialchars($lv['nombre'].' '.$lv['apellido']) ?></div>
                        <div class="sub-info">
                            <?php if ($rol === 'GERENTE'): ?>
                            <?= htmlspecialchars($lv['asesor']) ?> &middot;
                            <?php endif; ?>
                            <span style="color:#dc2626;font-weight:600;"><?= intval($lv['dias_vencido']) ?> día<?= $lv['dias_vencido'] != 1 ? 's' : '' ?> vencido</span>
                        </div>
                    </div>
                    <div class="monto" style="color:#dc2626;">$<?= number_format($lv['total_pagar'],2) ?></div>
                </div>
                <?php endforeach; ?>
                <a href="clientes_atrasados.php" style="display:block;background:#dc2626;color:white;border-radius:9px;padding:8px;text-align:center;text-decoration:none;font-size:0.78rem;font-weight:600;margin-top:10px;">
                    <i class="bi bi-arrow-right-circle"></i> Ver todos los atrasados
                </a>
            <?php else: ?>
                <div class="alerta-vacio" style="color:#15803d;">Cartera saludable ✓</div>
            <?php endif; ?>
        </div>

    </div>

    <!-- ACCESO RÁPIDO -->
    <div class="section-title fade" style="animation-delay:.13s">Acceso Rápido</div>
    <div class="quick-grid fade" style="animation-delay:.15s">
        <a href="nuevo_prestamo.php" class="qbtn">
            <div class="qi" style="background:#dbeafe;"><i class="bi bi-file-earmark-plus" style="color:#2563eb;"></i></div>
            <span>Nuevo Préstamo</span>
        </a>
        <a href="cobranza_diaria.php" class="qbtn">
            <div class="qi" style="background:#dcfce7;"><i class="bi bi-credit-card" style="color:#16a34a;"></i></div>
            <span>Cobranza</span>
        </a>
        <a href="cobro_diario/cobro_diario.php" class="qbtn">
            <div class="qi" style="background:#fecaca;"><i class="bi bi-calendar-check" style="color:#dc2626;"></i></div>
            <span>Cobro Diario</span>
            <?php if ($mis_vencidos > 0): ?>
            <small style="color:#dc2626;font-weight:700;"><?= $mis_vencidos ?> atrasados</small>
            <?php endif; ?>
        </a>
        <a href="registrar_cliente.php" class="qbtn">
            <div class="qi" style="background:#ede9fe;"><i class="bi bi-person-plus" style="color:#7c3aed;"></i></div>
            <span>Nuevo Cliente</span>
        </a>
        <a href="buscar_cliente.php" class="qbtn">
            <div class="qi" style="background:#f0f9ff;"><i class="bi bi-search" style="color:#0891b2;"></i></div>
            <span>Buscar Cliente</span>
        </a>
        <a href="programacion_prestamo.php" class="qbtn">
            <div class="qi" style="background:#ecfdf5;"><i class="bi bi-calendar3-range" style="color:#059669;"></i></div>
            <span>Programación</span>
        </a>
        <a href="dashboard.php" class="qbtn">
            <div class="qi" style="background:#e0f2fe;"><i class="bi bi-speedometer2" style="color:#0284c7;"></i></div>
            <span>Dashboard</span>
        </a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="caja.php" class="qbtn">
            <div class="qi" style="background:#fef9c3;"><i class="bi bi-safe" style="color:#ca8a04;"></i></div>
            <span>Caja</span>
        </a>
        <?php endif; ?>
    </div>

    <!-- MÓDULOS DEL SISTEMA -->
    <div class="section-title fade" style="animation-delay:.18s">Módulos del Sistema</div>
    <div class="mods-grid">

        <?php if ($rol === 'GERENTE'): ?>
        <!-- CAJA -->
        <div class="mod fade" style="animation-delay:.2s">
            <div class="mod-bar verde"></div>
            <div class="mod-top">
                <div class="mod-ic verde"><i class="bi bi-safe" style="color:#16a34a;"></i></div>
                <div class="mod-info">
                    <h3>Caja</h3>
                    <p>Control de entradas y salidas de efectivo del día</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="caja.php"          class="mbtn s-verde">Administrar Caja</a>
                <a href="historial_caja.php" class="mbtn o-verde">Ver Historial</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- CLIENTES -->
        <div class="mod fade" style="animation-delay:.22s">
            <div class="mod-bar azul"></div>
            <div class="mod-top">
                <div class="mod-ic azul"><i class="bi bi-people-fill" style="color:#2563eb;"></i></div>
                <div class="mod-info">
                    <h3>Clientes</h3>
                    <p>Registro, búsqueda y consulta de clientes</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="registrar_cliente.php" class="mbtn s-azul">Nuevo Cliente</a>
                <a href="buscar_cliente.php"    class="mbtn o-azul">Buscar</a>
                <a href="clientes.php"          class="mbtn o-azul">Ver Todos</a>
            </div>
        </div>

        <!-- PRÉSTAMOS -->
        <div class="mod fade" style="animation-delay:.24s">
            <div class="mod-bar verde"></div>
            <div class="mod-top">
                <div class="mod-ic verde"><i class="bi bi-cash-coin" style="color:#16a34a;"></i></div>
                <div class="mod-info">
                    <h3>Préstamos</h3>
                    <p>Creación y seguimiento de créditos activos</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="nuevo_prestamo.php"    class="mbtn s-verde">Nuevo Préstamo</a>
                <a href="historial_cliente.php" class="mbtn o-verde">Ver Historial</a>
            </div>
        </div>

        <!-- COBRANZA -->
        <div class="mod fade" style="animation-delay:.26s">
            <div class="mod-bar naranja"></div>
            <?php if ($mis_vencidos > 0): ?>
            <div class="mod-notif"><i class="bi bi-exclamation-triangle-fill"></i> <?= $mis_vencidos ?> cliente<?= $mis_vencidos > 1 ? 's' : '' ?> con atraso</div>
            <?php endif; ?>
            <div class="mod-top">
                <div class="mod-ic naranja"><i class="bi bi-credit-card-fill" style="color:#f59e0b;"></i></div>
                <div class="mod-info">
                    <h3>Cobranza</h3>
                    <p>Registro de pagos y control de clientes</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="cobranza_diaria.php"    class="mbtn s-naranja">Cobrar Ahora</a>
                <a href="clientes_atrasados.php" class="mbtn o-rojo">Ver Atrasos</a>
            </div>
        </div>

        <!-- COBRO DIARIO -->
        <div class="mod cobro fade" style="animation-delay:.28s">
            <div class="mod-bar rosa"></div>
            <div class="mod-top">
                <div class="mod-ic rosa"><i class="bi bi-calendar-check-fill" style="color:#e11d48;"></i></div>
                <div class="mod-info">
                    <h3>Cobro Diario</h3>
                    <p>Lista de cobro por asesor y ruta del día</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="cobro_diario/cobro_diario.php" class="mbtn s-rosa">Ir a Cobro Diario</a>
                <a href="cobro_diario/cobro_buscar.php" class="mbtn o-rojo">Buscar Cliente</a>
            </div>
        </div>

        <!-- PROGRAMACIÓN -->
        <div class="mod fade" style="animation-delay:.30s">
            <div class="mod-bar cyan"></div>
            <div class="mod-top">
                <div class="mod-ic cyan"><i class="bi bi-calendar3-range" style="color:#0891b2;"></i></div>
                <div class="mod-info">
                    <h3>Programación</h3>
                    <p>Calendario de vencimientos y renovaciones</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="programacion_prestamo.php" class="mbtn s-cyan">Ver Calendario</a>
            </div>
        </div>

        <!-- REPORTES -->
        <div class="mod fade" style="animation-delay:.32s">
            <div class="mod-bar azul"></div>
            <div class="mod-top">
                <div class="mod-ic azul"><i class="bi bi-bar-chart-line-fill" style="color:#2563eb;"></i></div>
                <div class="mod-info">
                    <h3>Reportes</h3>
                    <p>Exportaciones y resúmenes financieros</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="reporte_diario.php" class="mbtn s-azul">Ver Reportes</a>
            </div>
        </div>

        <!-- DASHBOARD -->
        <div class="mod fade" style="animation-delay:.34s">
            <div class="mod-bar morado"></div>
            <div class="mod-top">
                <div class="mod-ic morado"><i class="bi bi-speedometer2" style="color:#7c3aed;"></i></div>
                <div class="mod-info">
                    <h3>Dashboard</h3>
                    <p>Métricas clave, gráficas y KPIs en tiempo real</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="dashboard.php" class="mbtn s-morado">Ver Dashboard</a>
            </div>
        </div>

        <?php if ($rol === 'GERENTE'): ?>
        <!-- EMPLEADOS -->
        <div class="mod fade" style="animation-delay:.36s">
            <div class="mod-bar slate"></div>
            <div class="mod-top">
                <div class="mod-ic slate"><i class="bi bi-person-badge-fill" style="color:#475569;"></i></div>
                <div class="mod-info">
                    <h3>Empleados</h3>
                    <p>Gestión del equipo de asesores</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="empleados.php"        class="mbtn s-slate">Administrar</a>
                <a href="nuevo_empleado.php"   class="mbtn o-slate">Nuevo Empleado</a>
                <a href="estatus_empleado.php" class="mbtn o-slate">Estatus</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- MIGRACIÓN ESPECIAL -->
        <div class="mod especial fade" style="animation-delay:.38s">
            <div class="mod-bar morado"></div>
            <div class="mod-top">
                <div class="mod-ic morado"><i class="bi bi-stars" style="color:#7c3aed;"></i></div>
                <div class="mod-info">
                    <h3>Préstamo Migración</h3>
                    <p>Registro especial con historial de cuotas para migración de clientes</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="nuevo_prestamo_especial.php" class="mbtn s-morado">Abrir Migración</a>
            </div>
        </div>

        <!-- CERRAR SESIÓN -->
        <div class="mod fade" style="animation-delay:.40s">
            <div class="mod-bar rojo"></div>
            <div class="mod-top">
                <div class="mod-ic rojo"><i class="bi bi-box-arrow-right" style="color:#dc2626;"></i></div>
                <div class="mod-info">
                    <h3>Sesión</h3>
                    <p>Salir del sistema de forma segura</p>
                </div>
            </div>
            <div class="mod-actions">
                <a href="logout.php" class="mbtn s-rojo">Cerrar Sesión</a>
            </div>
        </div>

    </div>

    <!-- ÚLTIMOS PAGOS -->
    <?php if (!empty($ultimos_pagos)): ?>
    <div class="section-title fade" style="animation-delay:.42s">Últimos pagos registrados</div>
    <div class="recientes fade" style="animation-delay:.44s">
        <div class="recientes-header">
            <i class="bi bi-clock-history" style="color:#2563eb;"></i>
            <h6><?= $rol === 'GERENTE' ? 'Últimos pagos — todos los asesores' : 'Mis últimos pagos registrados' ?></h6>
        </div>
        <?php foreach ($ultimos_pagos as $lp):
            $ini = strtoupper(substr($lp['cn'],0,1).substr($lp['ca'],0,1));
        ?>
        <div class="pago-row">
            <div class="pago-avatar"><?= $ini ?></div>
            <div>
                <div class="pago-nombre"><?= htmlspecialchars($lp['cn'].' '.$lp['ca']) ?></div>
                <div class="pago-fecha"><?= date('d/m/Y', strtotime($lp['fecha_pago'])) ?></div>
            </div>
            <div class="pago-monto">+$<?= number_format($lp['monto_pagado'],2) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Sistema Financiero Interno &nbsp;|&nbsp; <?= date('d/m/Y H:i') ?>
    </div>

</main>
</div>

<script>
// ── TEMA CLARO / OSCURO ──
const THEME_KEY = 'pje_theme';

function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
// Aplicar tema guardado al cargar
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

// ── RELOJ ──
function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);
</script>
</body>
</html>

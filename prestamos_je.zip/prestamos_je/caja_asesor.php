<?php
$roles_permitidos = ['GERENTE','SUPERVISOR','ASESOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual  = $_SESSION['rol'];
$id_yo       = intval($_SESSION['id_empleado']);
$nombre_yo   = htmlspecialchars($_SESSION['nombre'] ?? '');
$usuario_yo  = $_SESSION['usuario'] ?? 'Sistema';

if ($rol_actual === 'ASESOR') {
    $id_ver = $id_yo;
} else {
    $id_ver = isset($_GET['id']) ? intval($_GET['id']) : $id_yo;
}

/* ── PROCESAR INVERSIÓN DE CAPITAL ── */
$msg_ok    = '';
$msg_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'cargar_fondos') {
    if (in_array($rol_actual, ['GERENTE', 'SUPERVISOR'])) {
        $monto_cargo = floatval($_POST['monto_cargo'] ?? 0);
        $medio_cargo = in_array($_POST['medio_cargo'] ?? '', ['EFECTIVO','BANCO']) ? $_POST['medio_cargo'] : 'EFECTIVO';
        $nota_cargo  = trim($_POST['nota_cargo'] ?? '');
        $id_destino  = intval($_POST['id_destino'] ?? $id_ver);

        if ($monto_cargo > 0 && $id_destino > 0) {
            $concepto_inv = 'INVERSIÓN DE CAPITAL · Registrado por: ' . strtoupper($usuario_yo);
            if ($nota_cargo) $concepto_inv .= ' · ' . $nota_cargo;

            $stmt = $conexion->prepare("
                INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, fecha, tipo_movimiento)
                VALUES ('ENTRADA', ?, ?, ?, ?, NOW(), 'INVERSION')
            ");
            $stmt->bind_param("ssdi", $concepto_inv, $medio_cargo, $monto_cargo, $id_destino);
            $stmt->execute();
            $stmt->close();

            $id_ver  = $id_destino;
            $msg_ok  = 'Inversión de $' . number_format($monto_cargo, 2) . ' registrada correctamente en la caja del asesor.';
        } else {
            $msg_error = 'El monto debe ser mayor a $0.00 y el asesor debe estar seleccionado.';
        }
    }
}

/* ── Datos del asesor visto ── */
$info = $conexion->query("
    SELECT nombre, apellido, ruta_tipo FROM empleados WHERE id_empleado=$id_ver
")->fetch_assoc();
$nombre_asesor = $info ? htmlspecialchars($info['nombre'].' '.$info['apellido']) : 'Asesor';
$ruta_asesor   = $info ? htmlspecialchars($info['ruta_tipo'] ?? '') : '';

/* ── Saldos ── */
$saldo_personal = $conexion->query("
    SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total
    FROM caja WHERE id_empleado=$id_ver
")->fetch_assoc()['total'] ?? 0;

$saldo_efectivo = $conexion->query("
    SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total
    FROM caja WHERE id_empleado=$id_ver AND medio='EFECTIVO'
")->fetch_assoc()['total'] ?? 0;

$saldo_banco = $conexion->query("
    SELECT SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END) total
    FROM caja WHERE id_empleado=$id_ver AND medio='BANCO'
")->fetch_assoc()['total'] ?? 0;

/* ── Inversiones totales ── */
$total_inversiones = $conexion->query("
    SELECT SUM(monto) total FROM caja
    WHERE id_empleado=$id_ver AND tipo_movimiento='INVERSION'
")->fetch_assoc()['total'] ?? 0;

/* ── Movimientos hoy ── */
$cobrado_hoy          = $conexion->query("SELECT SUM(monto) total FROM caja WHERE id_empleado=$id_ver AND tipo_movimiento='COBRO' AND DATE(fecha)=CURDATE()")->fetch_assoc()['total'] ?? 0;
$cobrado_efectivo_hoy = $conexion->query("SELECT SUM(monto) total FROM caja WHERE id_empleado=$id_ver AND tipo_movimiento='COBRO' AND medio='EFECTIVO' AND DATE(fecha)=CURDATE()")->fetch_assoc()['total'] ?? 0;
$cobrado_banco_hoy    = $conexion->query("SELECT SUM(monto) total FROM caja WHERE id_empleado=$id_ver AND tipo_movimiento='COBRO' AND medio='BANCO' AND DATE(fecha)=CURDATE()")->fetch_assoc()['total'] ?? 0;
$retiros_hoy          = $conexion->query("SELECT SUM(monto) total FROM caja WHERE id_empleado=$id_ver AND tipo_movimiento='RETIRO' AND DATE(fecha)=CURDATE()")->fetch_assoc()['total'] ?? 0;
$gastos_hoy           = $conexion->query("SELECT SUM(monto) total FROM caja WHERE id_empleado=$id_ver AND tipo_movimiento='GASTO' AND tipo='SALIDA' AND DATE(fecha)=CURDATE()")->fetch_assoc()['total'] ?? 0;

$en_mano = $conexion->query("
    SELECT
        SUM(CASE WHEN tipo='SALIDA' AND tipo_movimiento='RETIRO' THEN monto ELSE 0 END) -
        SUM(CASE WHEN tipo='ENTRADA' AND tipo_movimiento='COBRO' AND medio='EFECTIVO' THEN monto ELSE 0 END) AS en_mano
    FROM caja WHERE id_empleado=$id_ver
")->fetch_assoc()['en_mano'] ?? 0;

/* ── Filtro fechas ── */
$fecha_inicio = $_GET['inicio'] ?? '';
$fecha_fin    = $_GET['fin']    ?? '';
if (!$fecha_inicio && !$fecha_fin) {
    $dia_semana   = date("N");
    $lunes        = date("Y-m-d", strtotime("-".($dia_semana-1)." days"));
    $domingo      = date("Y-m-d", strtotime($lunes." +6 days"));
    $fecha_inicio = $lunes;
    $fecha_fin    = $domingo;
}
$filtro_fecha = ($fecha_inicio && $fecha_fin)
    ? "AND DATE(fecha) BETWEEN '$fecha_inicio' AND '$fecha_fin'"
    : '';

/* ── Movimientos tabla ── */
$movimientos = $conexion->query("
    SELECT * FROM caja WHERE id_empleado=$id_ver $filtro_fecha ORDER BY fecha DESC
");

/* ── Lista asesores para selector y panel inversión ── */
$lista_asesores = null;
if ($rol_actual !== 'ASESOR') {
    $lista_asesores = $conexion->query("
        SELECT id_empleado, nombre, apellido, ruta_tipo
        FROM empleados WHERE rol='ASESOR' AND estatus='ACTIVO'
        ORDER BY apellido, nombre
    ");
    $asesores_array = [];
    while ($a = $lista_asesores->fetch_assoc()) $asesores_array[] = $a;
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Caja Asesor — <?= $nombre_asesor ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
[data-theme="dark"] body { background:#0f172a; color:#e2e8f0; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#16a34a,#15803d);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(22,163,74,.15); color:#86efac; border:1px solid rgba(22,163,74,.2); }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; flex:1; }
.main-content { padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.3rem; font-weight:800; color:#0f172a; letter-spacing:-.3px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right   { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-accion {
    display:inline-flex; align-items:center; gap:6px;
    padding:9px 16px; border-radius:10px; font-size:.82rem; font-weight:700;
    text-decoration:none; border:none; cursor:pointer; font-family:'Inter',sans-serif; transition:all .15s;
}
.btn-verde  { background:#16a34a; color:white; }
.btn-verde:hover  { background:#15803d; }
.btn-rojo   { background:#dc2626; color:white; }
.btn-rojo:hover   { background:#b91c1c; }
.btn-icon-top {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s;
}
.btn-icon-top:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta {
    border-radius:12px; padding:13px 16px; margin-bottom:18px;
    display:flex; align-items:center; gap:10px; font-size:.85rem; font-weight:600;
}
.alerta.ok    { background:#f0fdf4; border:1.5px solid #bbf7d0; color:#14532d; }
.alerta.error { background:#fff1f2; border:1.5px solid #fecdd3; color:#9f1239; }

/* ── SELECTOR ASESOR ── */
.selector-card {
    background:white; border-radius:14px; padding:16px 20px;
    margin-bottom:18px; display:flex; align-items:center; gap:14px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9; flex-wrap:wrap;
}
.selector-card label { font-size:.72rem; font-weight:700; color:#374151; text-transform:uppercase; letter-spacing:.04em; }
.selector-card select {
    padding:8px 14px; border:1.5px solid #e2e8f0; border-radius:10px;
    font-size:.88rem; color:#1e293b; background:white; outline:none; min-width:240px; font-family:'Inter',sans-serif;
}
.selector-card select:focus { border-color:#2563eb; }
.selector-card button {
    padding:8px 16px; background:#0f172a; color:white; border:none;
    border-radius:10px; font-size:.82rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif;
}

/* ── CHIP ASESOR ── */
.asesor-chip {
    display:inline-flex; align-items:center; gap:8px;
    background:#0f172a; color:white;
    padding:7px 16px; border-radius:20px; font-size:.82rem; font-weight:700; margin-bottom:18px;
}
.asesor-chip span { color:#64748b; font-weight:400; }

/* ── CALLOUT EN MANO ── */
.en-mano-callout {
    background:#fffbeb; border:1.5px solid #fde68a; border-radius:14px;
    padding:16px 20px; margin-bottom:20px;
    display:flex; align-items:center; gap:16px;
}
.em-icon { font-size:1.8rem; flex-shrink:0; }
.em-label { font-size:.7rem; font-weight:700; color:#92400e; text-transform:uppercase; letter-spacing:.06em; }
.em-val   { font-size:1.7rem; font-weight:800; color:#78350f; margin-top:2px; }
.em-desc  { font-size:.72rem; color:#a16207; margin-top:2px; }

/* ── SECCIÓN TÍTULO ── */
.seccion-titulo {
    font-size:.68rem; font-weight:700; color:#64748b;
    text-transform:uppercase; letter-spacing:.1em; margin:20px 0 10px;
    display:flex; align-items:center; gap:6px;
}

/* ── CARDS GRID ── */
.cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; margin-bottom:8px; }
.card-stat {
    background:white; border-radius:14px; padding:18px 16px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); text-align:center; border:1px solid #f1f5f9;
}
.card-stat .cs-label { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#64748b; }
.card-stat .cs-val   { font-size:1.3rem; font-weight:800; color:#0f172a; margin-top:6px; }
.card-stat.verde  { background:#16a34a; border-color:#16a34a; }
.card-stat.verde  .cs-label, .card-stat.verde  .cs-val { color:white; }
.card-stat.azul   { background:#2563eb; border-color:#2563eb; }
.card-stat.azul   .cs-label, .card-stat.azul   .cs-val { color:white; }
.card-stat.oscuro { background:#0f172a; border-color:#0f172a; }
.card-stat.oscuro .cs-label, .card-stat.oscuro .cs-val { color:white; }
.card-stat.naranja { background:#ea580c; border-color:#ea580c; }
.card-stat.naranja .cs-label, .card-stat.naranja .cs-val { color:white; }
.card-stat.rojo   { background:#dc2626; border-color:#dc2626; }
.card-stat.rojo   .cs-label, .card-stat.rojo   .cs-val { color:white; }
.card-stat.morado { background:#7c3aed; border-color:#7c3aed; }
.card-stat.morado .cs-label, .card-stat.morado .cs-val { color:white; }

/* ── PANEL INVERSIÓN ── */
.panel-inversion {
    background:white; border-radius:16px;
    border:2px solid #7c3aed; margin-bottom:24px;
    box-shadow:0 4px 20px rgba(124,58,237,.1); overflow:hidden;
}
.panel-inv-header {
    background:linear-gradient(135deg,#7c3aed,#5b21b6);
    padding:16px 22px; display:flex; align-items:center; gap:12px;
}
.panel-inv-header .inv-icon {
    width:40px; height:40px; background:rgba(255,255,255,.15);
    border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0;
}
.panel-inv-header h3 { font-size:1rem; font-weight:800; color:white; }
.panel-inv-header p  { font-size:.78rem; color:#ddd6fe; margin-top:2px; }
.panel-inv-body { padding:20px 22px; }
.inv-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; margin-bottom:16px; }
.inv-field label {
    display:block; font-size:.72rem; font-weight:700; color:#374151;
    text-transform:uppercase; letter-spacing:.04em; margin-bottom:6px;
}
.inv-field input, .inv-field select {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.9rem; color:#1e293b; background:#f8fafc;
    outline:none; font-family:'Inter',sans-serif; transition:border-color .15s;
}
.inv-field input:focus, .inv-field select:focus { border-color:#7c3aed; background:white; box-shadow:0 0 0 3px rgba(124,58,237,.08); }
.inv-nota { margin-bottom:16px; }
.inv-nota label { display:block; font-size:.72rem; font-weight:700; color:#374151; text-transform:uppercase; letter-spacing:.04em; margin-bottom:6px; }
.inv-nota input {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 14px; font-size:.88rem; color:#1e293b; background:#f8fafc;
    outline:none; font-family:'Inter',sans-serif; transition:border-color .15s;
}
.inv-nota input:focus { border-color:#7c3aed; background:white; }
.inv-who {
    display:flex; align-items:center; gap:8px; padding:10px 14px;
    background:#f5f3ff; border:1px solid #ddd6fe; border-radius:10px; margin-bottom:16px;
    font-size:.8rem; color:#5b21b6;
}
.inv-who i { font-size:.9rem; }
.btn-inv {
    display:flex; align-items:center; justify-content:center; gap:8px;
    width:100%; padding:13px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    color:white; border:none; border-radius:12px; font-size:.92rem; font-weight:700;
    cursor:pointer; font-family:'Inter',sans-serif; transition:opacity .15s;
    box-shadow:0 4px 14px rgba(124,58,237,.3);
}
.btn-inv:hover { opacity:.92; }

/* ── FILTRO FECHAS ── */
.filtro-form {
    background:white; padding:14px 18px; border-radius:12px; margin:16px 0;
    display:flex; gap:10px; align-items:center; flex-wrap:wrap;
    box-shadow:0 2px 6px rgba(0,0,0,.05); font-size:.85rem; border:1px solid #f1f5f9;
}
.filtro-form label { font-size:.75rem; font-weight:700; color:#374151; }
.filtro-form input {
    padding:7px 12px; border:1.5px solid #e2e8f0; border-radius:8px;
    font-size:.85rem; font-family:'Inter',sans-serif; color:#1e293b; outline:none;
}
.filtro-form input:focus { border-color:#2563eb; }
.filtro-form button {
    padding:7px 16px; background:#0f172a; color:white; border:none;
    border-radius:8px; font-size:.82rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif;
}

/* ── TABLA ── */
.tabla-wrap {
    background:white; border-radius:14px; overflow:hidden;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
}
table { width:100%; border-collapse:collapse; }
th {
    background:#0f172a; color:white; padding:11px 14px;
    font-size:.72rem; text-align:center; font-weight:700; letter-spacing:.04em;
}
td { padding:10px 14px; border-bottom:1px solid #f1f5f9; font-size:.82rem; text-align:center; }
tr:last-child td { border-bottom:none; }
tr:hover td { background:#f8fafc; }
.tipo-entrada { color:#16a34a; font-weight:700; }
.tipo-salida  { color:#dc2626; font-weight:700; }
.badge {
    display:inline-flex; align-items:center; gap:3px;
    padding:3px 10px; border-radius:20px; font-size:.7rem; font-weight:700;
}
.badge-cobro    { background:#dcfce7; color:#16a34a; }
.badge-retiro   { background:#fee2e2; color:#dc2626; }
.badge-prestamo { background:#dbeafe; color:#2563eb; }
.badge-gasto    { background:#fef3c7; color:#d97706; }
.badge-bono     { background:#f3e8ff; color:#9333ea; }
.badge-ajuste   { background:#f1f5f9; color:#64748b; }
.badge-inversion { background:#ede9fe; color:#7c3aed; }
.badge-efectivo { background:#f0fdf4; color:#15803d; border:1px solid #86efac; }
.badge-banco    { background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; }
.sin-registros  { text-align:center; padding:40px; color:#94a3b8; font-size:.85rem; }

/* ── DARK MODE ── */
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .selector-card  { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .selector-card select { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .asesor-chip    { background:#1e293b; }
[data-theme="dark"] .en-mano-callout { background:#1c1600; border-color:#92400e; }
[data-theme="dark"] .em-label       { color:#fde68a; }
[data-theme="dark"] .em-val         { color:#fef3c7; }
[data-theme="dark"] .em-desc        { color:#d97706; }
[data-theme="dark"] .card-stat      { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .card-stat .cs-label,
[data-theme="dark"] .card-stat .cs-val { color:#e2e8f0; }
[data-theme="dark"] .card-stat.verde .cs-label,  [data-theme="dark"] .card-stat.verde .cs-val,
[data-theme="dark"] .card-stat.azul .cs-label,   [data-theme="dark"] .card-stat.azul .cs-val,
[data-theme="dark"] .card-stat.oscuro .cs-label, [data-theme="dark"] .card-stat.oscuro .cs-val,
[data-theme="dark"] .card-stat.naranja .cs-label,[data-theme="dark"] .card-stat.naranja .cs-val,
[data-theme="dark"] .card-stat.rojo .cs-label,   [data-theme="dark"] .card-stat.rojo .cs-val,
[data-theme="dark"] .card-stat.morado .cs-label, [data-theme="dark"] .card-stat.morado .cs-val { color:white; }
[data-theme="dark"] .panel-inversion { background:#1e293b; border-color:#7c3aed; }
[data-theme="dark"] .inv-field label, [data-theme="dark"] .inv-nota label { color:#94a3b8; }
[data-theme="dark"] .inv-field input, [data-theme="dark"] .inv-field select,
[data-theme="dark"] .inv-nota input { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .inv-who { background:#2e1065; border-color:#5b21b6; color:#c4b5fd; }
[data-theme="dark"] .filtro-form { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .filtro-form label { color:#94a3b8; }
[data-theme="dark"] .filtro-form input { background:#0f172a; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .tabla-wrap { background:#1e293b; border-color:#334155; }
[data-theme="dark"] td { border-color:#334155; }
[data-theme="dark"] tr:hover td { background:#253347; }
[data-theme="dark"] .btn-icon-top { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-icon-top:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .alerta.ok    { background:#071f12; border-color:#14532d; color:#86efac; }
[data-theme="dark"] .alerta.error { background:#1c0a0a; border-color:#7f1d1d; color:#fca5a5; }

/* ── RESPONSIVE ── */
@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; }
    .main-content { padding:16px 14px 80px; }
    .inv-grid { grid-template-columns:1fr; }
    .cards    { grid-template-columns:repeat(2,1fr); }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>

    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($usuario_yo, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($usuario_yo) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>

    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>

        <div class="sb-section">Clientes</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>

        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja General</a>
        <a href="caja_asesor.php" class="active"><i class="bi bi-wallet2"></i> Caja Asesor</a>
        <a href="caja_asesores.php"><i class="bi bi-people-fill"></i> Resumen Asesores</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial</a>

        <?php if ($rol_actual !== 'ASESOR'): ?>
        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
        <?php endif; ?>
    </nav>

    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="bi bi-wallet2" style="color:#16a34a;"></i> Mi Caja Personal</h1>
            <p>Responsabilidad individual &nbsp;·&nbsp; Dinero a tu cargo</p>
        </div>
        <div class="topbar-right">
            <?php
            $p_ing = 'ingreso_caja.php' . ($rol_actual !== 'ASESOR' ? '?id='.$id_ver : '');
            $p_egr = 'egreso_caja.php'  . ($rol_actual !== 'ASESOR' ? '?id='.$id_ver : '');
            ?>
            <a href="<?= $p_ing ?>" class="btn-accion btn-verde">
                <i class="bi bi-plus-circle-fill"></i> Ingreso
            </a>
            <a href="<?= $p_egr ?>" class="btn-accion btn-rojo">
                <i class="bi bi-dash-circle-fill"></i> Retiro / Gasto
            </a>
            <button class="btn-icon-top" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- ALERTAS -->
    <?php if ($msg_ok): ?>
    <div class="alerta ok">
        <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($msg_ok) ?>
    </div>
    <?php endif; ?>
    <?php if ($msg_error): ?>
    <div class="alerta error">
        <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($msg_error) ?>
    </div>
    <?php endif; ?>

    <!-- SELECTOR ASESOR (GERENTE/SUPERVISOR) -->
    <?php if ($rol_actual !== 'ASESOR' && !empty($asesores_array)): ?>
    <form method="GET" class="selector-card">
        <i class="bi bi-person-fill" style="color:#2563eb;font-size:1.1rem;"></i>
        <label>Ver caja de:</label>
        <select name="id">
            <?php foreach ($asesores_array as $e): ?>
            <option value="<?= $e['id_empleado'] ?>" <?= $e['id_empleado'] == $id_ver ? 'selected' : '' ?>>
                <?= htmlspecialchars($e['nombre'].' '.$e['apellido']) ?> — <?= htmlspecialchars($e['ruta_tipo']) ?>
            </option>
            <?php endforeach; ?>
        </select>
        <?php if ($fecha_inicio): ?>
        <input type="hidden" name="inicio" value="<?= $fecha_inicio ?>">
        <input type="hidden" name="fin"    value="<?= $fecha_fin ?>">
        <?php endif; ?>
        <button type="submit"><i class="bi bi-eye"></i> Ver</button>
    </form>
    <?php endif; ?>

    <!-- CHIP ASESOR -->
    <div class="asesor-chip">
        <i class="bi bi-person-circle"></i>
        <?= $nombre_asesor ?>
        <?php if ($ruta_asesor): ?>
        <span>· <?= $ruta_asesor ?></span>
        <?php endif; ?>
    </div>

    <!-- EFECTIVO EN MANO -->
    <div class="en-mano-callout">
        <i class="bi bi-cash-stack em-icon" style="color:#d97706;"></i>
        <div>
            <div class="em-label">Efectivo en poder del asesor ahora</div>
            <div class="em-val">$<?= number_format(max(0, floatval($en_mano)), 2) ?></div>
            <div class="em-desc">Retiros recibidos menos cobros de efectivo entregados a caja</div>
        </div>
    </div>

    <!-- SALDO HISTÓRICO -->
    <div class="seccion-titulo">
        <i class="bi bi-archive"></i> Saldo histórico (todo el tiempo)
    </div>
    <div class="cards">
        <div class="card-stat oscuro">
            <div class="cs-label">Saldo Total</div>
            <div class="cs-val">$<?= number_format($saldo_personal, 2) ?></div>
        </div>
        <div class="card-stat">
            <div class="cs-label">Efectivo</div>
            <div class="cs-val">$<?= number_format($saldo_efectivo, 2) ?></div>
        </div>
        <div class="card-stat azul">
            <div class="cs-label">Banco / Trans.</div>
            <div class="cs-val">$<?= number_format($saldo_banco, 2) ?></div>
        </div>
        <div class="card-stat morado">
            <div class="cs-label">Total Invertido</div>
            <div class="cs-val">$<?= number_format($total_inversiones, 2) ?></div>
        </div>
    </div>

    <!-- MOVIMIENTOS HOY -->
    <div class="seccion-titulo">
        <i class="bi bi-calendar-day"></i> Movimientos de hoy
    </div>
    <div class="cards">
        <div class="card-stat verde">
            <div class="cs-label">Total Cobrado</div>
            <div class="cs-val">$<?= number_format($cobrado_hoy, 2) ?></div>
        </div>
        <div class="card-stat">
            <div class="cs-label">Cobros Efectivo</div>
            <div class="cs-val">$<?= number_format($cobrado_efectivo_hoy, 2) ?></div>
        </div>
        <div class="card-stat azul">
            <div class="cs-label">Cobros Banco</div>
            <div class="cs-val">$<?= number_format($cobrado_banco_hoy, 2) ?></div>
        </div>
        <div class="card-stat naranja">
            <div class="cs-label">Retiro Hoy</div>
            <div class="cs-val">$<?= number_format($retiros_hoy, 2) ?></div>
        </div>
        <div class="card-stat rojo">
            <div class="cs-label">Gastos Hoy</div>
            <div class="cs-val">$<?= number_format($gastos_hoy, 2) ?></div>
        </div>
    </div>

    <!-- ════ PANEL INVERSIÓN DE CAPITAL (solo GERENTE/SUPERVISOR) ════ -->
    <?php if (in_array($rol_actual, ['GERENTE','SUPERVISOR']) && !empty($asesores_array)): ?>
    <div class="panel-inversion">
        <div class="panel-inv-header">
            <div class="inv-icon"><i class="bi bi-bank2" style="color:white;"></i></div>
            <div>
                <h3>Inversión de Capital</h3>
                <p>Cargar fondos a la caja de un asesor — queda registrado con tu usuario</p>
            </div>
        </div>
        <div class="panel-inv-body">
            <form method="POST">
                <input type="hidden" name="accion" value="cargar_fondos">

                <div class="inv-who">
                    <i class="bi bi-shield-lock-fill"></i>
                    <span>Registrando como: <strong><?= htmlspecialchars(strtoupper($usuario_yo)) ?></strong>
                    &nbsp;·&nbsp; <?= htmlspecialchars($rol_actual) ?></span>
                </div>

                <div class="inv-grid">
                    <div class="inv-field">
                        <label><i class="bi bi-person-fill"></i> Asesor destino</label>
                        <select name="id_destino">
                            <?php foreach ($asesores_array as $a): ?>
                            <option value="<?= $a['id_empleado'] ?>" <?= $a['id_empleado'] == $id_ver ? 'selected' : '' ?>>
                                <?= htmlspecialchars($a['nombre'].' '.$a['apellido']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="inv-field">
                        <label><i class="bi bi-currency-dollar"></i> Monto a cargar *</label>
                        <input type="number" name="monto_cargo" step="0.01" min="0.01"
                               placeholder="Ej: 5000.00" required>
                    </div>
                    <div class="inv-field">
                        <label><i class="bi bi-credit-card"></i> Medio</label>
                        <select name="medio_cargo">
                            <option value="EFECTIVO">💵 Efectivo</option>
                            <option value="BANCO">🏦 Banco / Transferencia</option>
                        </select>
                    </div>
                </div>

                <div class="inv-nota">
                    <label><i class="bi bi-chat-left-text"></i> Nota u observación <span style="font-weight:400;color:#94a3b8;">(opcional)</span></label>
                    <input type="text" name="nota_cargo" placeholder="Ej: Capital para inicio de semana, fondo especial...">
                </div>

                <button type="submit" class="btn-inv"
                        onclick="return confirm('¿Confirmas registrar esta inversión de capital?')">
                    <i class="bi bi-bank2"></i> Registrar Inversión de Capital
                </button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- FILTRO FECHAS -->
    <form method="GET" class="filtro-form">
        <?php if ($rol_actual !== 'ASESOR'): ?>
        <input type="hidden" name="id" value="<?= $id_ver ?>">
        <?php endif; ?>
        <i class="bi bi-funnel" style="color:#64748b;"></i>
        <label>Desde:</label>
        <input type="date" name="inicio" value="<?= $fecha_inicio ?>">
        <label>Hasta:</label>
        <input type="date" name="fin" value="<?= $fecha_fin ?>">
        <button type="submit"><i class="bi bi-search"></i> Filtrar</button>
    </form>

    <!-- TABLA MOVIMIENTOS -->
    <div class="tabla-wrap">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Tipo</th>
                <th>Dirección</th>
                <th>Monto</th>
                <th>Medio</th>
                <th>Concepto</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $hubo = false;
        $badge_map = [
            'COBRO'    => 'badge-cobro',
            'RETIRO'   => 'badge-retiro',
            'PRESTAMO' => 'badge-prestamo',
            'GASTO'    => 'badge-gasto',
            'BONO'     => 'badge-bono',
            'AJUSTE'   => 'badge-ajuste',
            'INVERSION'=> 'badge-inversion',
        ];
        while ($m = $movimientos->fetch_assoc()):
            $hubo = true;
            $bc = $badge_map[$m['tipo_movimiento']] ?? 'badge-ajuste';
            $mc = $m['medio'] === 'BANCO' ? 'badge-banco' : 'badge-efectivo';
            $dc = $m['tipo'] === 'ENTRADA' ? 'tipo-entrada' : 'tipo-salida';
        ?>
        <tr>
            <td style="color:#94a3b8;font-size:.75rem;"><?= $m['id_caja'] ?></td>
            <td><span class="badge <?= $bc ?>"><?= htmlspecialchars($m['tipo_movimiento']) ?></span></td>
            <td class="<?= $dc ?>">
                <i class="bi bi-arrow-<?= $m['tipo']==='ENTRADA'?'down':'up' ?>-circle-fill"></i>
                <?= $m['tipo'] ?>
            </td>
            <td style="font-weight:700;">$<?= number_format($m['monto'], 2) ?></td>
            <td><span class="badge <?= $mc ?>"><?= htmlspecialchars($m['medio']) ?></span></td>
            <td style="text-align:left;max-width:240px;font-size:.78rem;color:#64748b;"><?= htmlspecialchars($m['concepto'] ?? '') ?></td>
            <td style="font-size:.78rem;color:#64748b;"><?= $m['fecha'] ?></td>
        </tr>
        <?php endwhile; ?>
        <?php if (!$hubo): ?>
        <tr>
            <td colspan="7" class="sin-registros">
                <i class="bi bi-inbox" style="font-size:1.5rem;display:block;margin-bottom:6px;"></i>
                No hay movimientos en el rango de fechas seleccionado.
            </td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>

</div>
</main>
</div>

<script>
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function actualizarReloj() {
    const n = new Date(), pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj(); setInterval(actualizarReloj, 1000);
</script>
</body>
</html>

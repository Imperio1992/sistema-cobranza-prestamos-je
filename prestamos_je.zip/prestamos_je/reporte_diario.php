<?php
$roles_permitidos = ['GERENTE'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$fecha = date('Y-m-d', strtotime($_GET['fecha'] ?? date('Y-m-d')));
$rol   = $_SESSION['rol']     ?? 'GERENTE';
$user  = $_SESSION['usuario'] ?? 'Usuario';
$hoy   = date('Y-m-d');

/* ══ EXPORTAR EXCEL ══ */
if (isset($_GET['excel'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=reporte_asesores_$fecha.xls");
    echo "REPORTE DE ASESORES\tFecha: $fecha\n";
    echo "-----------------------------------------------------------\n";
    echo "Asesor\tCobrado Hoy\tSemana\t2 Semanas\t3 Semanas\tMes\tGastos\tGanancia Neta\tEstado\n";
    $asesores_xls = $conexion->query("SELECT id_empleado, nombre, apellido FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
    while ($a = $asesores_xls->fetch_assoc()) {
        $id = (int)$a['id_empleado'];
        $cobrado_hoy  = $conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago)='$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t'];
        $cobrado_sem  = $conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE YEARWEEK(pa.fecha_pago,1)=YEARWEEK('$fecha',1) AND pr.id_empleado=$id")->fetch_assoc()['t'];
        $cobrado_2sem = $conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago) BETWEEN DATE_SUB('$fecha',INTERVAL 2 WEEK) AND '$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t'];
        $cobrado_3sem = $conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago) BETWEEN DATE_SUB('$fecha',INTERVAL 3 WEEK) AND '$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t'];
        $cobrado_mes  = $conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE MONTH(pa.fecha_pago)=MONTH('$fecha') AND YEAR(pa.fecha_pago)=YEAR('$fecha') AND pr.id_empleado=$id")->fetch_assoc()['t'];
        $gasto_total  = $conexion->query("SELECT IFNULL(SUM(monto),0) t FROM caja WHERE id_empleado=$id AND tipo='SALIDA' AND DATE(fecha)='$fecha'")->fetch_assoc()['t'];
        $ganancia     = $conexion->query("SELECT SUM(CASE WHEN pago_diario>0 THEN total_pagar*0.20 WHEN plazo_semanas=4 THEN total_pagar*0.20 WHEN plazo_semanas=6 THEN total_pagar*0.30 WHEN plazo_semanas=8 THEN total_pagar*0.40 ELSE 0 END) g FROM prestamos WHERE estado='ACTIVO' AND id_empleado=$id")->fetch_assoc()['g'];
        $ganancia_neta = $ganancia - $gasto_total;
        $estado = $ganancia_neta >= 0 ? 'RENTABLE' : ($ganancia_neta > -500 ? 'EN RIESGO' : 'NO RENTABLE');
        echo "{$a['nombre']} {$a['apellido']}\t$cobrado_hoy\t$cobrado_sem\t$cobrado_2sem\t$cobrado_3sem\t$cobrado_mes\t$gasto_total\t$ganancia_neta\t$estado\n";
    }
    exit;
}

/* ══ DATOS GENERALES ══ */
$resumen = $conexion->query("
    SELECT
        (SELECT IFNULL(SUM(pa.monto_pagado),0)
         FROM pagos pa JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo
         WHERE DATE(pa.fecha_pago)='$fecha') AS total_cobrado,
        (SELECT IFNULL(SUM(monto),0) FROM caja WHERE tipo='SALIDA' AND DATE(fecha)='$fecha') AS total_gastos,
        (SELECT IFNULL(SUM(CASE WHEN pago_diario>0 THEN total_pagar*0.20
                 WHEN plazo_semanas=4 THEN total_pagar*0.20
                 WHEN plazo_semanas=6 THEN total_pagar*0.30
                 WHEN plazo_semanas=8 THEN total_pagar*0.40
                 ELSE 0 END),0) FROM prestamos WHERE estado='ACTIVO') AS total_ganancia,
        (SELECT COUNT(*) FROM empleados WHERE estatus='ACTIVO') AS total_asesores,
        (SELECT COUNT(DISTINCT pa.id_prestamo) FROM pagos pa WHERE DATE(pa.fecha_pago)='$fecha') AS prestamos_cobrados_hoy
")->fetch_assoc();

$resumen_neto = $resumen['total_ganancia'] - $resumen['total_gastos'];

/* Mejor y peor: solo entre quienes SÍ cobraron algo hoy */
$top_asesor = $conexion->query("
    SELECT e.nombre, e.apellido, IFNULL(SUM(pa.monto_pagado),0) AS cobrado
    FROM empleados e
    INNER JOIN prestamos pr ON e.id_empleado = pr.id_empleado
    INNER JOIN pagos pa     ON pa.id_prestamo = pr.id_prestamo AND DATE(pa.fecha_pago) = '$fecha'
    WHERE e.estatus = 'ACTIVO'
    GROUP BY e.id_empleado
    HAVING cobrado > 0
    ORDER BY cobrado DESC LIMIT 1
")->fetch_assoc();

$peor_asesor = $conexion->query("
    SELECT e.nombre, e.apellido, IFNULL(SUM(pa.monto_pagado),0) AS cobrado
    FROM empleados e
    INNER JOIN prestamos pr ON e.id_empleado = pr.id_empleado
    INNER JOIN pagos pa     ON pa.id_prestamo = pr.id_prestamo AND DATE(pa.fecha_pago) = '$fecha'
    WHERE e.estatus = 'ACTIVO'
    GROUP BY e.id_empleado
    HAVING cobrado > 0
    ORDER BY cobrado ASC LIMIT 1
")->fetch_assoc();

/* Ranking: TODOS los asesores activos, cobrado=0 si no trabajaron hoy */
$ranking = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido,
           IFNULL(SUM(pa.monto_pagado), 0) AS cobrado
    FROM empleados e
    LEFT JOIN prestamos pr ON e.id_empleado = pr.id_empleado
    LEFT JOIN pagos pa     ON pa.id_prestamo = pr.id_prestamo AND DATE(pa.fecha_pago) = '$fecha'
    WHERE e.estatus = 'ACTIVO'
    GROUP BY e.id_empleado
    ORDER BY cobrado DESC
");
$ranking_rows = [];
while ($r = $ranking->fetch_assoc()) $ranking_rows[] = $r;
$max_cobrado = max(1, $ranking_rows[0]['cobrado'] ?? 1);

$asesores = $conexion->query("
    SELECT id_empleado, nombre, apellido, IFNULL(ruta_tipo,'SIN RUTA') AS ruta_tipo
    FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre
");

$dias_es  = ['Sunday'=>'Domingo','Monday'=>'Lunes','Tuesday'=>'Martes',
             'Wednesday'=>'Miércoles','Thursday'=>'Jueves','Friday'=>'Viernes','Saturday'=>'Sábado'];
$meses_es = ['January'=>'enero','February'=>'febrero','March'=>'marzo','April'=>'abril',
             'May'=>'mayo','June'=>'junio','July'=>'julio','August'=>'agosto',
             'September'=>'septiembre','October'=>'octubre','November'=>'noviembre','December'=>'diciembre'];
$ts            = strtotime($fecha);
$dia_nombre    = $dias_es[date('l', $ts)];
$mes_nombre    = $meses_es[date('F', $ts)];
$fecha_legible = "$dia_nombre, " . date('j', $ts) . " de $mes_nombre de " . date('Y', $ts);

$prev = date('Y-m-d', strtotime($fecha.' -1 day'));
$next = date('Y-m-d', strtotime($fecha.' +1 day'));
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Reporte Diario — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 80px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:12px; }
.topbar-left h1 { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:3px; }
.topbar-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.btn-icon {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06); text-decoration:none;
}
.btn-icon:hover { color:#0f172a; border-color:#2563eb; }

/* ── FILTROS ── */
.filtros-card {
    background:white; border-radius:14px; padding:14px 18px;
    box-shadow:0 2px 6px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    margin-bottom:20px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;
}
.f-date {
    border:1.5px solid #e2e8f0; border-radius:9px; padding:8px 12px;
    font-size:.84rem; font-family:'Inter',sans-serif; color:#1e293b;
    background:#f8fafc; outline:none; transition:border-color .15s;
}
.f-date:focus { border-color:#2563eb; background:white; }
.btn-act {
    display:inline-flex; align-items:center; gap:6px;
    padding:8px 16px; border-radius:9px; font-size:.82rem; font-weight:700;
    border:none; cursor:pointer; font-family:'Inter',sans-serif; transition:all .15s;
    text-decoration:none;
}
.btn-act.primary { background:#0f172a; color:white; }
.btn-act.primary:hover { background:#1e293b; }
.btn-act.green   { background:#16a34a; color:white; }
.btn-act.green:hover { background:#15803d; }
.btn-act.slate   { background:#f1f5f9; color:#475569; border:1.5px solid #e2e8f0; }
.btn-act.slate:hover { border-color:#2563eb; color:#2563eb; }
.nav-fechas { display:flex; gap:6px; margin-left:auto; }
.btn-nav-f {
    display:inline-flex; align-items:center; gap:5px;
    background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:8px;
    padding:6px 12px; font-size:.76rem; font-weight:600; color:#475569;
    text-decoration:none; transition:all .15s;
}
.btn-nav-f:hover { border-color:#2563eb; color:#2563eb; background:#eff6ff; }

/* ── KPI GRID ── */
.kpi-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:12px; margin-bottom:18px; }
.kpi-card {
    background:white; border-radius:14px; padding:16px 18px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
    border-left:4px solid transparent; position:relative; overflow:hidden;
    transition:transform .2s, box-shadow .2s;
}
.kpi-card:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,.08); }
.kpi-card.azul    { border-left-color:#2563eb; }
.kpi-card.rojo    { border-left-color:#dc2626; }
.kpi-card.verde   { border-left-color:#16a34a; }
.kpi-card.morado  { border-left-color:#7c3aed; }
.kpi-card.amarillo{ border-left-color:#d97706; }
.kpi-lbl { font-size:.67rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:5px; }
.kpi-val { font-size:1.5rem; font-weight:800; line-height:1; color:#0f172a; }
.kpi-sub { font-size:.72rem; color:#94a3b8; margin-top:4px; }
.kpi-bg  { position:absolute; right:14px; top:12px; font-size:1.8rem; opacity:.07; }

/* ── DESTACADOS ── */
.dest-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:20px; }
.dest-card {
    border-radius:14px; padding:16px 20px;
    display:flex; align-items:center; gap:14px;
    border:1.5px solid transparent;
}
.dest-card.gold { background:#fffbeb; border-color:#fde68a; }
.dest-card.gray { background:#f8fafc; border-color:#e2e8f0; }
.dest-ico   { font-size:2rem; flex-shrink:0; }
.dest-lbl   { font-size:.68rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:2px; }
.dest-name  { font-weight:700; font-size:.95rem; color:#0f172a; margin-bottom:2px; }
.dest-monto { font-size:1.15rem; font-weight:800; }
.dest-card.gold .dest-monto { color:#d97706; }
.dest-card.gray .dest-monto { color:#64748b; }

/* ── LAYOUT 2 COLS ── */
.content-layout { display:grid; grid-template-columns:1fr 290px; gap:20px; align-items:start; }

/* ── CARD ASESOR ── */
.asesor-card {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 8px rgba(0,0,0,.05); margin-bottom:18px; overflow:hidden;
}
.asesor-header {
    padding:16px 20px; display:flex; align-items:center; gap:14px;
    border-bottom:1px solid #f1f5f9;
}
.asesor-avatar {
    width:46px; height:46px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:.95rem; font-weight:800; color:white; flex-shrink:0;
}
.av-rentable { background:linear-gradient(135deg,#16a34a,#15803d); }
.av-riesgo   { background:linear-gradient(135deg,#d97706,#b45309); }
.av-norenta  { background:linear-gradient(135deg,#dc2626,#b91c1c); }
.asesor-nombre { font-size:.98rem; font-weight:800; color:#0f172a; }
.asesor-ruta   { font-size:.75rem; color:#94a3b8; margin-top:2px; }
.badge-est {
    display:inline-flex; align-items:center; gap:4px;
    padding:4px 12px; border-radius:20px; font-size:.72rem; font-weight:700; white-space:nowrap;
}
.badge-rentable { background:#dcfce7; color:#15803d; }
.badge-riesgo   { background:#fef3c7; color:#92400e; }
.badge-norenta  { background:#fee2e2; color:#dc2626; }
.asesor-body { padding:18px 20px; }

/* Caja strip */
.caja-strip { display:flex; gap:10px; margin-bottom:14px; flex-wrap:wrap; }
.caja-pill  { flex:1; min-width:120px; border-radius:10px; padding:11px 14px; }
.cp-ef  { background:#f0fdf4; border:1px solid #bbf7d0; }
.cp-bco { background:#eff6ff; border:1px solid #bfdbfe; }
.cp-lbl { font-size:.68rem; text-transform:uppercase; letter-spacing:.04em; color:#64748b; font-weight:700; margin-bottom:3px; display:flex; align-items:center; gap:4px; }
.cp-val { font-size:1.05rem; font-weight:800; color:#0f172a; }

/* Meta bar */
.meta-wrap   { margin-bottom:14px; }
.meta-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:5px; }
.meta-lbl    { font-size:.78rem; font-weight:600; color:#374151; display:flex; align-items:center; gap:5px; }
.meta-pct    { font-size:.78rem; font-weight:800; }
.meta-bar    { height:7px; background:#f1f5f9; border-radius:4px; overflow:hidden; }
.meta-fill   { height:100%; border-radius:4px; transition:width .6s; }

/* Cobranza períodos */
.sub-titulo { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#94a3b8; margin-bottom:8px; margin-top:4px; display:flex; align-items:center; gap:5px; }
.cobr-grid  { display:grid; grid-template-columns:repeat(5,1fr); gap:8px; margin-bottom:14px; }
.cobr-cell  { background:#f8fafc; border-radius:10px; padding:10px 8px; text-align:center; }
.cobr-periodo { font-size:.65rem; text-transform:uppercase; letter-spacing:.04em; color:#94a3b8; font-weight:700; margin-bottom:3px; }
.cobr-monto   { font-size:.9rem; font-weight:800; color:#0f172a; }
.cobr-cell.cobr-hoy { background:#eff6ff; border:1.5px solid #bfdbfe; }
.cobr-cell.cobr-hoy .cobr-monto { color:#1d4ed8; }

/* Mini table */
.mini-table { width:100%; border-collapse:collapse; font-size:.82rem; margin-bottom:12px; }
.mini-table thead th {
    background:#f8fafc; color:#64748b; font-size:.68rem; font-weight:700;
    text-transform:uppercase; letter-spacing:.04em; padding:8px 12px;
    text-align:left; border-bottom:1px solid #f1f5f9;
}
.mini-table tbody td { padding:8px 12px; border-bottom:1px solid #f8fafc; }
.mini-table tbody tr:last-child td { border-bottom:none; }
.mini-table tbody tr:hover { background:#fafafa; }
.mini-table tfoot td { padding:8px 12px; font-weight:700; background:#f8fafc; border-top:2px solid #e2e8f0; font-size:.82rem; }
.sin-gastos { font-size:.82rem; color:#94a3b8; padding:10px 12px; background:#f8fafc; border-radius:8px; margin-bottom:12px; }

/* Ganancia strip */
.ganancia-strip { display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; }
.g-cell { border-radius:10px; padding:12px 10px; text-align:center; }
.g-cell.bruta    { background:#f8fafc; border:1px solid #e2e8f0; }
.g-cell.gastos   { background:#fff1f2; border:1px solid #fecdd3; }
.g-cell.neta-pos { background:#f0fdf4; border:1px solid #bbf7d0; }
.g-cell.neta-neg { background:#fff1f2; border:1px solid #fecdd3; }
.g-cell.neta-mid { background:#fffbeb; border:1px solid #fde68a; }
.g-lbl { font-size:.65rem; text-transform:uppercase; letter-spacing:.05em; color:#94a3b8; font-weight:700; margin-bottom:4px; }
.g-val { font-size:1.05rem; font-weight:800; }
.g-cell.bruta    .g-val { color:#1e293b; }
.g-cell.gastos   .g-val { color:#dc2626; }
.g-cell.neta-pos .g-val { color:#16a34a; }
.g-cell.neta-neg .g-val { color:#dc2626; }
.g-cell.neta-mid .g-val { color:#d97706; }

/* ── COLUMNA DERECHA ── */
.side-card {
    background:white; border-radius:14px; padding:18px 20px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05); margin-bottom:16px;
}
.side-card h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#64748b; margin-bottom:14px; display:flex; align-items:center; gap:7px; }
.side-card-dark {
    background:#0f172a; border-radius:14px; padding:18px 20px; margin-bottom:16px;
}
.side-card-dark h3 { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#475569; margin-bottom:14px; display:flex; align-items:center; gap:7px; }

/* Ranking */
.ranking-item { display:flex; align-items:center; gap:10px; padding:9px 0; border-bottom:1px solid #f1f5f9; }
.ranking-item:last-child { border-bottom:none; }
.rank-pos {
    width:26px; height:26px; border-radius:50%;
    background:#f1f5f9; color:#64748b;
    display:flex; align-items:center; justify-content:center;
    font-size:.7rem; font-weight:800; flex-shrink:0;
}
.rank-pos.r1 { background:#fbbf24; color:white; }
.rank-pos.r2 { background:#94a3b8; color:white; }
.rank-pos.r3 { background:#d97706; color:white; }
.rank-nombre { flex:1; font-size:.82rem; font-weight:600; color:#1e293b; }
.rank-monto  { font-size:.82rem; font-weight:800; color:#0f172a; }
.rank-bar    { width:100%; height:4px; background:#f1f5f9; border-radius:2px; margin-top:3px; overflow:hidden; }
.rank-fill   { height:100%; border-radius:2px; background:#2563eb; }

/* Resumen ejecutivo */
.exec-item { display:flex; align-items:flex-start; gap:10px; padding:10px 0; border-bottom:1px solid #1e293b; }
.exec-item:last-child { border-bottom:none; padding-bottom:0; }
.exec-ico   { font-size:1.1rem; color:#60a5fa; flex-shrink:0; margin-top:1px; }
.exec-title { font-weight:700; color:#f1f5f9; font-size:.85rem; margin-bottom:2px; }
.exec-desc  { color:#64748b; font-size:.72rem; }

/* Acceso rápido */
.acceso-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
.acceso-btn {
    display:flex; flex-direction:column; align-items:center; gap:5px;
    padding:12px 8px; background:#f8fafc; border-radius:10px;
    border:1.5px solid #e2e8f0; text-decoration:none; color:#475569;
    font-size:.72rem; font-weight:700; transition:all .15s; text-align:center;
}
.acceso-btn i { font-size:1.2rem; }
.acceso-btn:hover { background:#eff6ff; border-color:#2563eb; color:#2563eb; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:16px 14px 80px; }
    .kpi-grid { grid-template-columns:repeat(2,1fr); }
    .content-layout { grid-template-columns:1fr; }
    .cobr-grid { grid-template-columns:repeat(2,1fr); }
    .dest-grid { grid-template-columns:1fr; }
}
@media(max-width:600px){
    .ganancia-strip { grid-template-columns:1fr; }
    .kpi-grid { grid-template-columns:repeat(2,1fr); }
}
@media print {
    .sidebar, .filtros-card, .no-print { display:none !important; }
    .main { margin-left:0 !important; }
    body  { background:white !important; }
    .asesor-card { break-inside:avoid; box-shadow:none; border:1.5px solid #e2e8f0; }
    .kpi-grid { grid-template-columns:repeat(5,1fr) !important; }
    .content-layout { grid-template-columns:1fr !important; }
    .cobr-grid { grid-template-columns:repeat(5,1fr) !important; }
}

/* ── MODO OSCURO ── */
[data-theme="dark"] body          { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#f8fafc; }
[data-theme="dark"] .topbar-left p  { color:#64748b; }
[data-theme="dark"] .btn-icon     { background:#111827; color:#94a3b8; border-color:#1e293b; }
[data-theme="dark"] .btn-icon:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .filtros-card { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .f-date       { background:#1e293b; color:#e2e8f0; border-color:#334155; }
[data-theme="dark"] .btn-act.slate{ background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-nav-f    { background:#1e293b; border-color:#334155; color:#64748b; }
[data-theme="dark"] .kpi-card     { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .kpi-val      { color:#f8fafc; }
[data-theme="dark"] .kpi-lbl      { color:#64748b; }
[data-theme="dark"] .dest-card.gold{ background:#1c1a0f; border-color:#92400e; }
[data-theme="dark"] .dest-card.gray{ background:#111827; border-color:#334155; }
[data-theme="dark"] .dest-name    { color:#f8fafc; }
[data-theme="dark"] .asesor-card  { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .asesor-header{ border-color:#334155; }
[data-theme="dark"] .asesor-nombre{ color:#f8fafc; }
[data-theme="dark"] .side-card    { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .cobr-cell    { background:#0f172a; }
[data-theme="dark"] .cobr-cell.cobr-hoy { background:#1e3a6e; border-color:#3b82f6; }
[data-theme="dark"] .cobr-monto   { color:#e2e8f0; }
[data-theme="dark"] .mini-table thead th { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .mini-table tbody td { border-color:#1e293b; }
[data-theme="dark"] .mini-table tbody tr:hover { background:#0f172a; }
[data-theme="dark"] .mini-table tfoot td { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .sin-gastos   { background:#0f172a; }
[data-theme="dark"] .caja-pill.cp-ef  { background:#0c1f12; border-color:#16a34a44; }
[data-theme="dark"] .caja-pill.cp-bco { background:#0c1930; border-color:#2563eb44; }
[data-theme="dark"] .cp-val, [data-theme="dark"] .g-val { color:#f8fafc; }
[data-theme="dark"] .meta-bar     { background:#334155; }
[data-theme="dark"] .rank-bar     { background:#334155; }
[data-theme="dark"] .ranking-item { border-color:#334155; }
[data-theme="dark"] .rank-nombre  { color:#e2e8f0; }
[data-theme="dark"] .rank-monto   { color:#f8fafc; }
[data-theme="dark"] .rank-pos     { background:#334155; color:#94a3b8; }
[data-theme="dark"] .acceso-btn   { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .acceso-btn:hover { background:#1e3a6e; border-color:#3b82f6; color:#93c5fd; }
[data-theme="dark"] .g-cell.bruta { background:#1e293b; border-color:#334155; }
</style>
</head>
<body>
<div class="app">

<!-- ── SIDEBAR ── -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php" class="active"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ── MAIN ── -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="index.php" class="btn-icon" title="Regresar al inicio">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h1><i class="bi bi-bar-chart-line" style="color:#2563eb;"></i> Reporte Diario</h1>
                <p><?= $fecha_legible ?> &nbsp;·&nbsp; Solo Gerente</p>
            </div>
        </div>
        <div class="topbar-right no-print">
            <a href="?fecha=<?= $fecha ?>&excel=1" class="btn-icon" title="Exportar Excel">
                <i class="bi bi-file-earmark-excel" style="color:#16a34a;"></i>
            </a>
            <button onclick="window.print()" class="btn-icon" title="Imprimir">
                <i class="bi bi-printer"></i>
            </button>
            <button class="btn-icon" id="btnTema" title="Cambiar tema" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- FILTROS + NAV FECHAS -->
    <form method="GET" class="filtros-card no-print">
        <i class="bi bi-calendar3" style="color:#2563eb;font-size:1rem;"></i>
        <label style="font-size:.82rem;font-weight:700;color:#374151;">Fecha:</label>
        <input type="date" name="fecha" class="f-date" value="<?= $fecha ?>">
        <button type="submit" class="btn-act primary">
            <i class="bi bi-eye"></i> Ver reporte
        </button>
        <div class="nav-fechas">
            <a href="?fecha=<?= $prev ?>" class="btn-nav-f">
                <i class="bi bi-chevron-left"></i> Anterior
            </a>
            <a href="reporte_diario.php" class="btn-nav-f"
               style="<?= $fecha===$hoy ? 'border-color:#2563eb;color:#2563eb;' : '' ?>">
                <i class="bi bi-calendar-check"></i> Hoy
            </a>
            <?php if ($next <= $hoy): ?>
            <a href="?fecha=<?= $next ?>" class="btn-nav-f">
                Siguiente <i class="bi bi-chevron-right"></i>
            </a>
            <?php endif; ?>
        </div>
        <span style="font-size:.8rem;color:#64748b;font-weight:600;margin-left:8px;">
            <?= $resumen['total_asesores'] ?> asesor<?= $resumen['total_asesores'] != 1 ? 'es' : '' ?> activos
        </span>
    </form>

    <!-- KPIs -->
    <div class="kpi-grid">
        <div class="kpi-card azul">
            <i class="bi bi-cash-coin kpi-bg"></i>
            <div class="kpi-lbl">Total cobrado</div>
            <div class="kpi-val" style="font-size:1.2rem;">$<?= number_format($resumen['total_cobrado'], 2) ?></div>
            <div class="kpi-sub">en <?= date('d/m/Y', $ts) ?></div>
        </div>
        <div class="kpi-card rojo">
            <i class="bi bi-graph-down-arrow kpi-bg"></i>
            <div class="kpi-lbl">Total gastos</div>
            <div class="kpi-val" style="font-size:1.2rem;">$<?= number_format($resumen['total_gastos'], 2) ?></div>
            <div class="kpi-sub">egresos del día</div>
        </div>
        <div class="kpi-card verde">
            <i class="bi bi-currency-dollar kpi-bg"></i>
            <div class="kpi-lbl">Ganancia neta</div>
            <div class="kpi-val" style="font-size:1.2rem;color:<?= $resumen_neto >= 0 ? '#16a34a' : '#dc2626' ?>">
                $<?= number_format($resumen_neto, 2) ?>
            </div>
            <div class="kpi-sub"><?= $resumen_neto >= 0 ? 'día rentable ✓' : 'día con pérdida' ?></div>
        </div>
        <div class="kpi-card morado">
            <i class="bi bi-people kpi-bg"></i>
            <div class="kpi-lbl">Asesores activos</div>
            <div class="kpi-val"><?= $resumen['total_asesores'] ?></div>
            <div class="kpi-sub">en campo hoy</div>
        </div>
        <div class="kpi-card amarillo">
            <i class="bi bi-clipboard-check kpi-bg"></i>
            <div class="kpi-lbl">Préstamos cobrados</div>
            <div class="kpi-val"><?= $resumen['prestamos_cobrados_hoy'] ?></div>
            <div class="kpi-sub">pagos registrados</div>
        </div>
    </div>

    <!-- DESTACADOS: solo si alguien cobró ese día -->
    <?php if ($top_asesor): ?>
    <div class="dest-grid no-print">
        <div class="dest-card gold">
            <i class="bi bi-trophy-fill dest-ico" style="color:#d97706;"></i>
            <div>
                <div class="dest-lbl">Mejor asesor del día</div>
                <div class="dest-name"><?= htmlspecialchars($top_asesor['nombre'] . ' ' . $top_asesor['apellido']) ?></div>
                <div class="dest-monto">$<?= number_format($top_asesor['cobrado'], 2) ?></div>
            </div>
        </div>
        <div class="dest-card gray">
            <i class="bi bi-pin-angle-fill dest-ico" style="color:#94a3b8;"></i>
            <div>
                <div class="dest-lbl">Menor cobranza del día</div>
                <div class="dest-name"><?= htmlspecialchars(($peor_asesor['nombre'] ?? $top_asesor['nombre']) . ' ' . ($peor_asesor['apellido'] ?? $top_asesor['apellido'])) ?></div>
                <div class="dest-monto">$<?= number_format($peor_asesor['cobrado'] ?? 0, 2) ?></div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="no-print" style="background:#f8fafc;border:1.5px dashed #e2e8f0;border-radius:14px;padding:16px 24px;margin-bottom:20px;display:flex;align-items:center;gap:12px;color:#94a3b8;font-size:.85rem;">
        <i class="bi bi-clock" style="font-size:1.4rem;color:#cbd5e1;flex-shrink:0;"></i>
        <span>Sin cobros registrados aún para esta fecha. Los <strong>destacados</strong> aparecerán en cuanto se registre el primer pago del día.</span>
    </div>
    <?php endif; ?>

    <!-- LAYOUT 2 COLS -->
    <div class="content-layout">

        <!-- DETALLE ASESORES -->
        <div>
        <?php while ($a = $asesores->fetch_assoc()):
            $id = (int)$a['id_empleado'];

            $caja_efectivo = floatval($conexion->query("SELECT IFNULL(SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END),0) t FROM caja WHERE id_empleado=$id AND medio='EFECTIVO'")->fetch_assoc()['t']);
            $caja_banco    = floatval($conexion->query("SELECT IFNULL(SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE -monto END),0) t FROM caja WHERE id_empleado=$id AND medio='BANCO'")->fetch_assoc()['t']);

            $cobrado_hoy  = floatval($conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago)='$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t']);
            $cobrado_sem  = floatval($conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE YEARWEEK(pa.fecha_pago,1)=YEARWEEK('$fecha',1) AND pr.id_empleado=$id")->fetch_assoc()['t']);
            $cobrado_2sem = floatval($conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago) BETWEEN DATE_SUB('$fecha',INTERVAL 2 WEEK) AND '$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t']);
            $cobrado_3sem = floatval($conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE DATE(pa.fecha_pago) BETWEEN DATE_SUB('$fecha',INTERVAL 3 WEEK) AND '$fecha' AND pr.id_empleado=$id")->fetch_assoc()['t']);
            $cobrado_mes  = floatval($conexion->query("SELECT IFNULL(SUM(pa.monto_pagado),0) t FROM pagos pa INNER JOIN prestamos pr ON pa.id_prestamo=pr.id_prestamo WHERE MONTH(pa.fecha_pago)=MONTH('$fecha') AND YEAR(pa.fecha_pago)=YEAR('$fecha') AND pr.id_empleado=$id")->fetch_assoc()['t']);

            $gastos_res  = $conexion->query("SELECT concepto, SUM(monto) total FROM caja WHERE id_empleado=$id AND tipo='SALIDA' AND DATE(fecha)='$fecha' GROUP BY concepto");
            $gasto_total = floatval($conexion->query("SELECT IFNULL(SUM(monto),0) t FROM caja WHERE id_empleado=$id AND tipo='SALIDA' AND DATE(fecha)='$fecha'")->fetch_assoc()['t']);

            $ganancia = floatval($conexion->query("
                SELECT IFNULL(SUM(CASE WHEN pago_diario>0 THEN total_pagar*0.20
                                       WHEN plazo_semanas=4 THEN total_pagar*0.20
                                       WHEN plazo_semanas=6 THEN total_pagar*0.30
                                       WHEN plazo_semanas=8 THEN total_pagar*0.40
                                       ELSE 0 END),0) g
                FROM prestamos WHERE estado='ACTIVO' AND id_empleado=$id
            ")->fetch_assoc()['g']);
            $ganancia_neta = $ganancia - $gasto_total;

            $total_prestamos_asesor = intval($conexion->query("SELECT COUNT(*) c FROM prestamos WHERE estado='ACTIVO' AND id_empleado=$id")->fetch_assoc()['c']);

            if ($ganancia_neta >= 0) {
                $badge_class = 'badge-rentable'; $badge_txt = 'RENTABLE';    $badge_icon = 'bi-check-circle-fill';        $av_class = 'av-rentable';
            } elseif ($ganancia_neta > -500) {
                $badge_class = 'badge-riesgo';   $badge_txt = 'EN RIESGO';   $badge_icon = 'bi-exclamation-triangle-fill'; $av_class = 'av-riesgo';
            } else {
                $badge_class = 'badge-norenta';  $badge_txt = 'NO RENTABLE'; $badge_icon = 'bi-x-circle-fill';            $av_class = 'av-norenta';
            }

            $neta_class  = $ganancia_neta >= 0 ? 'neta-pos' : ($ganancia_neta > -500 ? 'neta-mid' : 'neta-neg');
            $ini         = strtoupper(mb_substr($a['nombre'],0,1) . mb_substr($a['apellido'],0,1));
            $meta_diaria = 5000;
            $pct_meta    = min(100, $meta_diaria > 0 ? round($cobrado_hoy / $meta_diaria * 100) : 0);
            $meta_color  = $pct_meta >= 80 ? '#16a34a' : ($pct_meta >= 40 ? '#d97706' : '#dc2626');
        ?>
        <div class="asesor-card">
            <div class="asesor-header">
                <div class="asesor-avatar <?= $av_class ?>"><?= $ini ?></div>
                <div style="flex:1;">
                    <div class="asesor-nombre"><?= htmlspecialchars($a['nombre'] . ' ' . $a['apellido']) ?></div>
                    <div class="asesor-ruta">
                        <i class="bi bi-geo-alt-fill" style="font-size:.7rem;"></i>
                        <?= htmlspecialchars($a['ruta_tipo']) ?>
                        &nbsp;·&nbsp;
                        <i class="bi bi-file-earmark-text" style="font-size:.7rem;"></i>
                        <?= $total_prestamos_asesor ?> préstamos activos
                    </div>
                </div>
                <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;">
                    <span class="badge-est <?= $badge_class ?>">
                        <i class="bi <?= $badge_icon ?>" style="font-size:.7rem;"></i> <?= $badge_txt ?>
                    </span>
                    <div style="display:flex;gap:8px;">
                        <a href="cobranza_diaria.php?asesor=<?= $id ?>&fecha=<?= $fecha ?>"
                           style="font-size:.7rem;color:#2563eb;text-decoration:none;display:flex;align-items:center;gap:3px;background:#eff6ff;padding:3px 8px;border-radius:6px;border:1px solid #bfdbfe;">
                            <i class="bi bi-credit-card"></i> Cobranza
                        </a>
                        <a href="cobro_diario/cobro_diario.php?id_empleado=<?= $id ?>"
                           style="font-size:.7rem;color:#dc2626;text-decoration:none;display:flex;align-items:center;gap:3px;background:#fff1f2;padding:3px 8px;border-radius:6px;border:1px solid #fecdd3;">
                            <i class="bi bi-calendar-check"></i> Cobro Diario
                        </a>
                    </div>
                </div>
            </div>

            <div class="asesor-body">

                <!-- Caja saldo -->
                <div class="caja-strip">
                    <div class="caja-pill cp-ef">
                        <div class="cp-lbl"><i class="bi bi-cash"></i> Efectivo en caja</div>
                        <div class="cp-val">$<?= number_format($caja_efectivo, 2) ?></div>
                    </div>
                    <div class="caja-pill cp-bco">
                        <div class="cp-lbl"><i class="bi bi-bank"></i> Saldo banco</div>
                        <div class="cp-val">$<?= number_format($caja_banco, 2) ?></div>
                    </div>
                </div>

                <!-- Meta del día -->
                <div class="meta-wrap">
                    <div class="meta-header">
                        <span class="meta-lbl"><i class="bi bi-bullseye"></i> Avance vs Meta ($<?= number_format($meta_diaria, 0) ?>)</span>
                        <span class="meta-pct" style="color:<?= $meta_color ?>"><?= $pct_meta ?>%</span>
                    </div>
                    <div class="meta-bar">
                        <div class="meta-fill" style="width:<?= $pct_meta ?>%;background:<?= $meta_color ?>;"></div>
                    </div>
                </div>

                <!-- Cobranza por período -->
                <div class="sub-titulo"><i class="bi bi-graph-up-arrow"></i> Cobranza por período</div>
                <div class="cobr-grid">
                    <div class="cobr-cell cobr-hoy">
                        <div class="cobr-periodo">Hoy</div>
                        <div class="cobr-monto">$<?= number_format($cobrado_hoy, 2) ?></div>
                    </div>
                    <div class="cobr-cell">
                        <div class="cobr-periodo">1 Semana</div>
                        <div class="cobr-monto">$<?= number_format($cobrado_sem, 2) ?></div>
                    </div>
                    <div class="cobr-cell">
                        <div class="cobr-periodo">2 Semanas</div>
                        <div class="cobr-monto">$<?= number_format($cobrado_2sem, 2) ?></div>
                    </div>
                    <div class="cobr-cell">
                        <div class="cobr-periodo">3 Semanas</div>
                        <div class="cobr-monto">$<?= number_format($cobrado_3sem, 2) ?></div>
                    </div>
                    <div class="cobr-cell">
                        <div class="cobr-periodo">1 Mes</div>
                        <div class="cobr-monto">$<?= number_format($cobrado_mes, 2) ?></div>
                    </div>
                </div>

                <!-- Gastos del día -->
                <div class="sub-titulo"><i class="bi bi-receipt-cutoff"></i> Gastos del día</div>
                <?php
                $gastos_filas = [];
                while ($g = $gastos_res->fetch_assoc()) $gastos_filas[] = $g;
                ?>
                <?php if (empty($gastos_filas)): ?>
                <div class="sin-gastos">
                    <i class="bi bi-check-circle" style="color:#16a34a;"></i> Sin gastos registrados hoy
                </div>
                <?php else: ?>
                <table class="mini-table">
                    <thead>
                        <tr><th>Concepto</th><th style="text-align:right;">Monto</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gastos_filas as $g): ?>
                        <tr>
                            <td><?= htmlspecialchars($g['concepto']) ?></td>
                            <td style="text-align:right;color:#dc2626;font-weight:600;">
                                -$<?= number_format($g['total'], 2) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>Total gastos</td>
                            <td style="text-align:right;color:#dc2626;">-$<?= number_format($gasto_total, 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
                <?php endif; ?>

                <!-- Resultado -->
                <div class="sub-titulo"><i class="bi bi-wallet2"></i> Resultado del asesor</div>
                <div class="ganancia-strip">
                    <div class="g-cell bruta">
                        <div class="g-lbl">Ganancia bruta</div>
                        <div class="g-val">$<?= number_format($ganancia, 2) ?></div>
                    </div>
                    <div class="g-cell gastos">
                        <div class="g-lbl">Gastos</div>
                        <div class="g-val">-$<?= number_format($gasto_total, 2) ?></div>
                    </div>
                    <div class="g-cell <?= $neta_class ?>">
                        <div class="g-lbl">Neta</div>
                        <div class="g-val">$<?= number_format($ganancia_neta, 2) ?></div>
                    </div>
                </div>

            </div>
        </div>
        <?php endwhile; ?>
        </div>

        <!-- COLUMNA DERECHA -->
        <div class="no-print">

            <!-- Ranking del día -->
            <div class="side-card">
                <h3><i class="bi bi-trophy" style="color:#d97706;"></i> Ranking del día</h3>
                <?php foreach ($ranking_rows as $i => $r):
                    $pos        = $i + 1;
                    $sin_cobro  = ($r['cobrado'] == 0);
                    $pct_rk     = (!$sin_cobro && $max_cobrado > 0) ? round($r['cobrado'] / $max_cobrado * 100) : 0;
                    if ($sin_cobro) {
                        $pos_class  = '';
                        $fill_color = '#e2e8f0';
                    } else {
                        $pos_class  = $pos === 1 ? 'r1' : ($pos === 2 ? 'r2' : ($pos === 3 ? 'r3' : ''));
                        $fill_color = $pos === 1 ? '#fbbf24' : ($pos === 2 ? '#94a3b8' : ($pos === 3 ? '#d97706' : '#2563eb'));
                    }
                ?>
                <div class="ranking-item" style="<?= $sin_cobro ? 'opacity:.5;' : '' ?>">
                    <div class="rank-pos <?= $pos_class ?>"><?= $sin_cobro ? '—' : $pos ?></div>
                    <div style="flex:1;min-width:0;">
                        <div class="rank-nombre"><?= htmlspecialchars($r['nombre'] . ' ' . $r['apellido']) ?></div>
                        <div class="rank-bar">
                            <div class="rank-fill" style="width:<?= $pct_rk ?>%;background:<?= $fill_color ?>;"></div>
                        </div>
                    </div>
                    <div class="rank-monto" style="<?= $sin_cobro ? 'color:#94a3b8;' : '' ?>">
                        <?= $sin_cobro ? 'sin cobros' : '$' . number_format($r['cobrado'], 0) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Resumen ejecutivo -->
            <div class="side-card-dark">
                <h3><i class="bi bi-clipboard-data" style="color:#60a5fa;"></i> Resumen ejecutivo</h3>
                <div class="exec-item">
                    <i class="bi bi-cash-coin exec-ico"></i>
                    <div>
                        <div class="exec-title">$<?= number_format($resumen['total_cobrado'], 2) ?></div>
                        <div class="exec-desc">total cobrado hoy</div>
                    </div>
                </div>
                <div class="exec-item">
                    <i class="bi bi-graph-down-arrow exec-ico" style="color:#f87171;"></i>
                    <div>
                        <div class="exec-title">$<?= number_format($resumen['total_gastos'], 2) ?></div>
                        <div class="exec-desc">total gastos del día</div>
                    </div>
                </div>
                <div class="exec-item">
                    <i class="bi bi-<?= $resumen_neto >= 0 ? 'check-circle-fill' : 'exclamation-triangle-fill' ?> exec-ico"
                       style="color:<?= $resumen_neto >= 0 ? '#4ade80' : '#f87171' ?>;"></i>
                    <div>
                        <div class="exec-title" style="color:<?= $resumen_neto >= 0 ? '#4ade80' : '#f87171' ?>">
                            $<?= number_format($resumen_neto, 2) ?>
                        </div>
                        <div class="exec-desc">ganancia neta general</div>
                    </div>
                </div>
                <div class="exec-item">
                    <i class="bi bi-people exec-ico"></i>
                    <div>
                        <div class="exec-title"><?= $resumen['total_asesores'] ?> asesores</div>
                        <div class="exec-desc">en campo hoy</div>
                    </div>
                </div>
                <div class="exec-item">
                    <i class="bi bi-clipboard-check exec-ico" style="color:#fbbf24;"></i>
                    <div>
                        <div class="exec-title"><?= $resumen['prestamos_cobrados_hoy'] ?> cobros</div>
                        <div class="exec-desc">pagos registrados hoy</div>
                    </div>
                </div>
            </div>

            <!-- Acceso rápido -->
            <div class="side-card">
                <h3><i class="bi bi-lightning-charge-fill" style="color:#d97706;"></i> Acceso rápido</h3>
                <div class="acceso-grid">
                    <a href="cobranza_diaria.php" class="acceso-btn">
                        <i class="bi bi-credit-card-fill" style="color:#2563eb;"></i>
                        Cobranza
                    </a>
                    <a href="clientes.php" class="acceso-btn">
                        <i class="bi bi-people-fill" style="color:#7c3aed;"></i>
                        Clientes
                    </a>
                    <a href="empleados.php" class="acceso-btn">
                        <i class="bi bi-person-badge-fill" style="color:#16a34a;"></i>
                        Empleados
                    </a>
                    <a href="caja.php" class="acceso-btn">
                        <i class="bi bi-safe-fill" style="color:#d97706;"></i>
                        Caja
                    </a>
                    <a href="clientes_atrasados.php" class="acceso-btn">
                        <i class="bi bi-exclamation-triangle-fill" style="color:#dc2626;"></i>
                        Atrasados
                    </a>
                    <a href="nuevo_prestamo.php" class="acceso-btn">
                        <i class="bi bi-file-earmark-plus-fill" style="color:#0891b2;"></i>
                        Nuevo Préstamo
                    </a>
                </div>
            </div>

        </div>
    </div>

    <div style="text-align:center;color:#cbd5e1;font-size:.72rem;padding:12px 0;border-top:1px solid #e2e8f0;margin-top:8px;" class="no-print">
        Préstamos J.E. &copy; <?= date('Y') ?> — Reporte Diario · Solo Gerente
    </div>

</main>
</div>

<script>
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();

function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

function actualizarReloj() {
    const n  = new Date();
    const h  = String(n.getHours()).padStart(2, '0');
    const m  = String(n.getMinutes()).padStart(2, '0');
    const s  = String(n.getSeconds()).padStart(2, '0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

window.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.meta-fill, .rank-fill').forEach(b => {
        const w = b.style.width;
        b.style.width = '0';
        setTimeout(() => { b.style.width = w; }, 200);
    });
});
</script>
</body>
</html>

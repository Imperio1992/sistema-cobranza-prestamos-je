<?php
$roles_permitidos = ['GERENTE', 'ASESOR', 'SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol    = $_SESSION['rol']     ?? 'ASESOR';
$user   = $_SESSION['usuario'] ?? 'Usuario';

$condiciones = [];
if ($rol === 'ASESOR') {
    $condiciones[] = "c.id_asesor = " . intval($_SESSION['id_empleado']);
}

$buscar = trim($_GET['buscar'] ?? '');
if ($buscar !== '') {
    $bs = $conexion->real_escape_string($buscar);
    $condiciones[] = "(c.nombre LIKE '%$bs%' OR c.apellido LIKE '%$bs%' OR c.telefono LIKE '%$bs%' OR c.colonia LIKE '%$bs%')";
}

$estatus_filtro = $_GET['estatus'] ?? '';
if ($estatus_filtro !== '') {
    $es = $conexion->real_escape_string($estatus_filtro);
    $condiciones[] = "c.estatus = '$es'";
}

$where = count($condiciones) ? "WHERE " . implode(" AND ", $condiciones) : "";

$clientes = $conexion->query("
    SELECT c.id_cliente, c.nombre, c.apellido, c.telefono, c.colonia,
           c.fecha_registro, c.estatus, c.fecha_desbloqueo,
           e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
    FROM clientes c
    INNER JOIN empleados e ON c.id_asesor = e.id_empleado
    $where
    ORDER BY c.fecha_registro DESC
");

$total      = $conexion->query("SELECT COUNT(*) t FROM clientes c $where")->fetch_assoc()['t'] ?? 0;
$activos    = $conexion->query("SELECT COUNT(*) t FROM clientes WHERE estatus='ACTIVO'")->fetch_assoc()['t'] ?? 0;
$bloqueados = $conexion->query("SELECT COUNT(*) t FROM clientes WHERE estatus='BLOQUEADO'")->fetch_assoc()['t'] ?? 0;
$mal        = $conexion->query("SELECT COUNT(*) t FROM clientes WHERE estatus='MAL_HISTORIAL'")->fetch_assoc()['t'] ?? 0;
$total_all  = $conexion->query("SELECT COUNT(*) t FROM clientes")->fetch_assoc()['t'] ?? 0;

$hoy = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Clientes — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user {
    padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:2px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-nuevo {
    display:inline-flex; align-items:center; gap:8px;
    background:#2563eb; color:white; border:none; border-radius:10px;
    padding:10px 18px; font-size:.86rem; font-weight:700;
    text-decoration:none; transition:all .15s; cursor:pointer;
    box-shadow:0 4px 12px rgba(37,99,235,.3);
}
.btn-nuevo:hover { background:#1d4ed8; transform:translateY(-1px); }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTAS ── */
.alerta {
    display:flex; align-items:center; gap:10px;
    padding:12px 16px; border-radius:12px; font-size:.85rem; font-weight:600;
    margin-bottom:18px; border:1px solid transparent;
}
.alerta-ok    { background:#dcfce7; color:#166534; border-color:#86efac; }
.alerta-error { background:#fef2f2; color:#991b1b; border-color:#fca5a5; }

/* ── STATS ── */
.stats-grid {
    display:grid; grid-template-columns:repeat(4,1fr);
    gap:14px; margin-bottom:22px;
}
.stat-card {
    background:white; border-radius:14px; padding:18px 20px;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9;
    border-left:4px solid transparent; cursor:pointer;
    text-decoration:none; display:block; transition:all .15s;
}
.stat-card:hover { transform:translateY(-2px); box-shadow:0 4px 14px rgba(0,0,0,.1); }
.stat-card.total   { border-left-color:#2563eb; }
.stat-card.activo  { border-left-color:#16a34a; }
.stat-card.bloq    { border-left-color:#dc2626; }
.stat-card.mal     { border-left-color:#d97706; }
.stat-card .s-icon { font-size:1.4rem; margin-bottom:8px; }
.stat-card .s-lbl  { font-size:.7rem; color:#64748b; text-transform:uppercase; letter-spacing:.05em; font-weight:700; }
.stat-card .s-val  { font-size:2rem; font-weight:800; line-height:1.1; margin-top:2px; }
.stat-card.total  .s-val { color:#2563eb; }
.stat-card.activo .s-val { color:#16a34a; }
.stat-card.bloq   .s-val { color:#dc2626; }
.stat-card.mal    .s-val { color:#d97706; }
.stat-card .s-sub { font-size:.72rem; color:#94a3b8; margin-top:3px; }

/* ── FILTROS ── */
.filter-bar {
    background:white; border-radius:14px; padding:14px 18px; margin-bottom:18px;
    display:flex; gap:10px; align-items:center; flex-wrap:wrap;
    box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid #f1f5f9;
}
.fi { position:relative; display:flex; align-items:center; }
.fi i { position:absolute; left:12px; color:#94a3b8; font-size:.9rem; pointer-events:none; }
.fi input, .fi select {
    border:1.5px solid #e2e8f0; border-radius:10px; padding:9px 12px 9px 34px;
    font-size:.84rem; color:#1e293b; font-family:'Inter',sans-serif;
    background:#f8fafc; outline:none; transition:border-color .15s;
}
.fi input  { min-width:240px; }
.fi select { min-width:170px; }
.fi input:focus, .fi select:focus { border-color:#2563eb; background:white; }
.btn-filtrar {
    display:inline-flex; align-items:center; gap:6px;
    background:#0f172a; color:white; border:none; border-radius:10px;
    padding:9px 16px; font-size:.84rem; font-weight:600; cursor:pointer; font-family:'Inter',sans-serif;
}
.btn-filtrar:hover { background:#1e293b; }
.btn-limpiar {
    display:inline-flex; align-items:center; gap:5px;
    background:#f8fafc; color:#64748b; text-decoration:none;
    border:1.5px solid #e2e8f0; border-radius:10px;
    padding:9px 14px; font-size:.83rem; font-weight:600; transition:all .15s;
}
.btn-limpiar:hover { background:#f1f5f9; color:#0f172a; }
.filtro-activo {
    display:inline-flex; align-items:center; gap:5px; margin-left:auto;
    font-size:.75rem; color:#2563eb; background:#eff6ff;
    padding:4px 10px; border-radius:99px; font-weight:600;
}

/* ── TABLA ── */
.tabla-wrap {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06); overflow:hidden;
}
.tabla-head {
    display:flex; justify-content:space-between; align-items:center;
    padding:14px 20px; border-bottom:1px solid #f8fafc;
}
.tabla-head-title { font-size:.9rem; font-weight:700; color:#0f172a; }
.tabla-head-count { font-size:.75rem; background:#eff6ff; color:#2563eb; padding:3px 10px; border-radius:99px; font-weight:600; }
.tabla-busqueda {
    padding:10px 16px; border-bottom:1px solid #f8fafc;
    position:relative; display:flex; align-items:center;
}
.tabla-busqueda i { position:absolute; left:28px; color:#94a3b8; font-size:.9rem; }
.tabla-busqueda input {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 12px 8px 34px; font-size:.84rem; font-family:'Inter',sans-serif;
    background:#f8fafc; color:#1e293b; outline:none;
}
.tabla-busqueda input:focus { border-color:#2563eb; background:white; }

table { width:100%; border-collapse:collapse; }
thead th {
    background:#0f172a; color:#94a3b8; font-size:.68rem;
    text-transform:uppercase; letter-spacing:.08em;
    padding:12px 16px; font-weight:700; text-align:left;
}
tbody td { padding:12px 16px; border-bottom:1px solid #f8fafc; font-size:.84rem; vertical-align:middle; }
tbody tr:last-child td { border-bottom:none; }
tbody tr:hover { background:#f8fafc; }
.td-nombre strong { font-size:.88rem; color:#0f172a; }
.td-nombre .td-sub { font-size:.72rem; color:#94a3b8; margin-top:1px; }

/* ── BADGES ── */
.badge {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 9px; border-radius:99px; font-size:.7rem; font-weight:700;
}
.badge-id       { background:#f1f5f9; color:#475569; font-size:.72rem; }
.badge-activo   { background:#dcfce7; color:#166534; }
.badge-bloqueado{ background:#fee2e2; color:#991b1b; }
.badge-mal      { background:#fef3c7; color:#92400e; }
.badge-espera   { background:#e0f2fe; color:#0369a1; }

/* ── ACCIONES ── */
.acciones { display:flex; gap:5px; align-items:center; flex-wrap:wrap; }
.btn-ac {
    display:inline-flex; align-items:center; justify-content:center;
    width:32px; height:32px; border-radius:8px; border:none;
    cursor:pointer; text-decoration:none; font-size:.9rem;
    transition:all .15s; position:relative;
}
.btn-ac:hover .tt { display:block; }
.tt {
    display:none; position:absolute; bottom:calc(100% + 5px); left:50%;
    transform:translateX(-50%); background:#0f172a; color:#fff;
    font-size:.68rem; padding:4px 8px; border-radius:6px;
    white-space:nowrap; z-index:50; pointer-events:none;
}
.btn-ac.hist   { background:#f5f3ff; color:#7c3aed; }
.btn-ac.hist:hover   { background:#7c3aed; color:#fff; }
.btn-ac.edit   { background:#eff6ff; color:#2563eb; }
.btn-ac.edit:hover   { background:#2563eb; color:#fff; }
.btn-ac.move   { background:#fefce8; color:#ca8a04; }
.btn-ac.move:hover   { background:#ca8a04; color:#fff; }
.btn-ac.block  { background:#fef2f2; color:#dc2626; }
.btn-ac.block:hover  { background:#dc2626; color:#fff; }
.btn-ac.unlock { background:#f0fdf4; color:#16a34a; }
.btn-ac.unlock:hover { background:#16a34a; color:#fff; }

.chip-fecha { font-size:.72rem; color:#64748b; }

/* ── VACÍO ── */
.empty-state { text-align:center; padding:56px 20px; color:#94a3b8; }
.empty-state i { font-size:3rem; display:block; margin-bottom:14px; opacity:.3; }
.empty-state p { font-size:.88rem; }

/* ── FOOTER ── */
.page-footer { text-align:center; color:#cbd5e1; font-size:.72rem; padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .stats-grid { grid-template-columns:1fr 1fr; }
    .fi input { min-width:160px; }
    table thead th:nth-child(4),
    table tbody td:nth-child(4) { display:none; }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#e2e8f0; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .btn-theme:hover { color:#e2e8f0; border-color:#3b82f6; }
[data-theme="dark"] .btn-nuevo { box-shadow:0 4px 12px rgba(37,99,235,.15); }
[data-theme="dark"] .alerta-ok    { background:rgba(22,163,74,0.1); color:#4ade80; border-color:rgba(74,222,128,0.3); }
[data-theme="dark"] .alerta-error { background:rgba(153,27,27,0.15); color:#fca5a5; border-color:rgba(252,165,165,0.3); }
[data-theme="dark"] .stat-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .stat-card .s-lbl { color:#64748b; }
[data-theme="dark"] .stat-card .s-sub { color:#475569; }
[data-theme="dark"] .filter-bar { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .fi input,
[data-theme="dark"] .fi select { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .btn-limpiar { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .tabla-wrap { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .tabla-head { border-color:#1e293b; }
[data-theme="dark"] .tabla-head-title { color:#e2e8f0; }
[data-theme="dark"] .tabla-busqueda { border-color:#1e293b; }
[data-theme="dark"] .tabla-busqueda input { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] thead th { background:#0a0f1e; color:#475569; }
[data-theme="dark"] tbody td { border-color:#1e293b; }
[data-theme="dark"] tbody tr:hover { background:#1a2235; }
[data-theme="dark"] .td-nombre strong { color:#e2e8f0; }
[data-theme="dark"] .badge-id { background:#1e293b; color:#64748b; }
[data-theme="dark"] .badge-activo   { background:rgba(22,163,74,0.15); color:#4ade80; }
[data-theme="dark"] .badge-bloqueado{ background:rgba(220,38,38,0.15); color:#f87171; }
[data-theme="dark"] .badge-mal      { background:rgba(217,119,6,0.15); color:#fcd34d; }
[data-theme="dark"] .badge-espera   { background:rgba(3,105,161,0.15); color:#7dd3fc; }
[data-theme="dark"] .btn-ac.hist   { background:rgba(124,58,237,0.15); color:#c4b5fd; }
[data-theme="dark"] .btn-ac.edit   { background:rgba(37,99,235,0.15); color:#93c5fd; }
[data-theme="dark"] .btn-ac.move   { background:rgba(202,138,4,0.15); color:#fde047; }
[data-theme="dark"] .btn-ac.block  { background:rgba(220,38,38,0.15); color:#f87171; }
[data-theme="dark"] .btn-ac.unlock { background:rgba(22,163,74,0.15); color:#4ade80; }
[data-theme="dark"] .page-footer { color:#334155; border-color:#1e293b; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php" class="active"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <h1>Clientes</h1>
            <p>Gestión y control de clientes registrados</p>
        </div>
<div class="topbar-right">
<a href="index.php" class="btn-theme" title="Regresar al inicio">
    <i class="bi bi-arrow-left"></i>
</a>
    <a href="registrar_cliente.php" class="btn-nuevo">
        <i class="bi bi-person-plus-fill"></i> Nuevo Cliente
    </a>
    <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
        <i class="bi bi-moon-fill" id="themeIcon"></i>
    </button>
</div>
    </div>

    <!-- ALERTAS -->
    <?php if (isset($_GET['ok'])): ?>
    <div class="alerta alerta-ok"><i class="bi bi-check-circle-fill"></i> Cliente registrado correctamente.</div>
    <?php endif; ?>
    <?php if (isset($_GET['bloqueado'])): ?>
    <div class="alerta alerta-ok"><i class="bi bi-slash-circle-fill"></i> Cliente bloqueado correctamente.</div>
    <?php endif; ?>
    <?php if (isset($_GET['desbloqueado'])): ?>
    <div class="alerta alerta-ok"><i class="bi bi-unlock-fill"></i> Cliente desbloqueado correctamente.</div>
    <?php endif; ?>

    <!-- STATS — clic en card filtra por estatus -->
    <div class="stats-grid">
        <a href="clientes.php" class="stat-card total" style="text-decoration:none;">
            <div class="s-icon"><i class="bi bi-people-fill" style="color:#2563eb;"></i></div>
            <div class="s-lbl">Total clientes</div>
            <div class="s-val"><?= $total_all ?></div>
            <div class="s-sub">En el sistema</div>
        </a>
        <a href="clientes.php?estatus=ACTIVO" class="stat-card activo" style="text-decoration:none;">
            <div class="s-icon"><i class="bi bi-person-check-fill" style="color:#16a34a;"></i></div>
            <div class="s-lbl">Activos</div>
            <div class="s-val"><?= $activos ?></div>
            <div class="s-sub"><?= $total_all > 0 ? round($activos/$total_all*100) : 0 ?>% del total</div>
        </a>
        <a href="clientes.php?estatus=BLOQUEADO" class="stat-card bloq" style="text-decoration:none;">
            <div class="s-icon"><i class="bi bi-person-slash" style="color:#dc2626;"></i></div>
            <div class="s-lbl">Bloqueados</div>
            <div class="s-val"><?= $bloqueados ?></div>
            <div class="s-sub">Sin acceso a crédito</div>
        </a>
        <a href="clientes.php?estatus=MAL_HISTORIAL" class="stat-card mal" style="text-decoration:none;">
            <div class="s-icon"><i class="bi bi-exclamation-triangle-fill" style="color:#d97706;"></i></div>
            <div class="s-lbl">Mal historial</div>
            <div class="s-val"><?= $mal ?></div>
            <div class="s-sub">Requieren revisión</div>
        </a>
    </div>

    <!-- FILTROS -->
    <form method="GET" class="filter-bar">
        <div class="fi">
            <i class="bi bi-search"></i>
            <input type="text" name="buscar" id="buscarInput"
                   placeholder="Nombre, apellido, teléfono, colonia..."
                   value="<?= htmlspecialchars($buscar) ?>" autocomplete="off">
        </div>
        <div class="fi">
            <i class="bi bi-funnel"></i>
            <select name="estatus">
                <option value="">Todos los estatus</option>
                <option value="ACTIVO"        <?= $estatus_filtro==='ACTIVO'       ?'selected':'' ?>>Activos</option>
                <option value="BLOQUEADO"     <?= $estatus_filtro==='BLOQUEADO'    ?'selected':'' ?>>Bloqueados</option>
                <option value="MAL_HISTORIAL" <?= $estatus_filtro==='MAL_HISTORIAL'?'selected':'' ?>>Mal historial</option>
            </select>
        </div>
        <button type="submit" class="btn-filtrar">
            <i class="bi bi-funnel-fill"></i> Filtrar
        </button>
        <?php if ($buscar || $estatus_filtro): ?>
        <a href="clientes.php" class="btn-limpiar">
            <i class="bi bi-x-circle"></i> Limpiar
        </a>
        <span class="filtro-activo">
            <i class="bi bi-info-circle"></i>
            <?= $total ?> resultado<?= $total!=1?'s':'' ?> encontrado<?= $total!=1?'s':'' ?>
        </span>
        <?php endif; ?>
    </form>

    <!-- TABLA -->
    <div class="tabla-wrap">
        <div class="tabla-head">
            <span class="tabla-head-title"><i class="bi bi-people" style="margin-right:6px;color:#2563eb;"></i>Lista de Clientes</span>
            <span class="tabla-head-count"><?= $total ?> registro<?= $total!=1?'s':'' ?></span>
        </div>
        <!-- Filtro rápido en tabla (JS sin recargar) -->
        <div class="tabla-busqueda">
            <i class="bi bi-search"></i>
            <input type="text" id="filtroRapido" placeholder="Filtrar en esta página..." oninput="filtrarTabla(this.value)">
        </div>

        <table id="tablaClientes">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Teléfono</th>
                    <th>Asesor</th>
                    <th>Registro</th>
                    <th>Estatus</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($clientes->num_rows === 0): ?>
                <tr>
                    <td colspan="7">
                        <div class="empty-state">
                            <i class="bi bi-people"></i>
                            <p>No se encontraron clientes con los filtros aplicados.</p>
                            <a href="clientes.php" style="display:inline-block;margin-top:12px;background:#2563eb;color:white;border-radius:9px;padding:8px 16px;text-decoration:none;font-size:.82rem;font-weight:600;">
                                Ver todos
                            </a>
                        </div>
                    </td>
                </tr>
            <?php else: while ($c = $clientes->fetch_assoc()): ?>
            <tr>
                <td><span class="badge badge-id"><?= $c['id_cliente'] ?></span></td>
                <td class="td-nombre">
                    <strong><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></strong>
                    <?php if (!empty($c['colonia'])): ?>
                    <div class="td-sub"><i class="bi bi-geo-alt" style="margin-right:2px;"></i><?= htmlspecialchars($c['colonia']) ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="tel:<?= htmlspecialchars($c['telefono']) ?>"
                       style="color:inherit;text-decoration:none;display:inline-flex;align-items:center;gap:5px;">
                        <i class="bi bi-telephone" style="color:#94a3b8;"></i>
                        <?= htmlspecialchars($c['telefono'] ?? '—') ?>
                    </a>
                </td>
                <td style="font-size:.82rem;color:#475569;">
                    <?= htmlspecialchars($c['asesor_nombre'].' '.$c['asesor_apellido']) ?>
                </td>
                <td><span class="chip-fecha"><?= date("d/m/Y", strtotime($c['fecha_registro'])) ?></span></td>
                <td>
                    <?php
                    switch($c['estatus']) {
                        case 'ACTIVO':
                            echo '<span class="badge badge-activo"><i class="bi bi-circle-fill" style="font-size:.45rem;"></i> Activo</span>';
                            break;
                        case 'BLOQUEADO':
                            echo '<span class="badge badge-bloqueado"><i class="bi bi-slash-circle"></i> Bloqueado</span>';
                            break;
                        case 'MAL_HISTORIAL':
                            echo '<span class="badge badge-mal"><i class="bi bi-exclamation-triangle"></i> Mal historial</span>';
                            break;
                        default:
                            echo '<span class="badge badge-id">'.htmlspecialchars($c['estatus']).'</span>';
                    }
                    ?>
                </td>
                <td>
                    <div class="acciones">
                        <a href="historial_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ac hist">
                            <i class="bi bi-clock-history"></i>
                            <span class="tt">Historial</span>
                        </a>

                        <?php if (in_array($rol, ['GERENTE','SUPERVISOR'])): ?>
                            <?php if ($c['estatus'] !== 'BLOQUEADO'): ?>
                                <a href="editar_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ac edit">
                                    <i class="bi bi-pencil-fill"></i>
                                    <span class="tt">Editar</span>
                                </a>
                                <a href="migrar_cliente.php?id=<?= $c['id_cliente'] ?>" class="btn-ac move">
                                    <i class="bi bi-arrow-left-right"></i>
                                    <span class="tt">Cambiar asesor</span>
                                </a>
                                <a href="bloquear_cliente.php?id=<?= $c['id_cliente'] ?>"
                                   onclick="return confirm('¿Bloquear a <?= htmlspecialchars(addslashes($c['nombre'].' '.$c['apellido'])) ?>?')"
                                   class="btn-ac block">
                                    <i class="bi bi-slash-circle"></i>
                                    <span class="tt">Bloquear</span>
                                </a>
                            <?php else:
                                if (!empty($c['fecha_desbloqueo']) && $hoy >= $c['fecha_desbloqueo']): ?>
                                    <a href="desbloquear_cliente.php?id=<?= $c['id_cliente'] ?>"
                                       onclick="return confirm('¿Desbloquear a <?= htmlspecialchars(addslashes($c['nombre'].' '.$c['apellido'])) ?>?')"
                                       class="btn-ac unlock">
                                        <i class="bi bi-unlock-fill"></i>
                                        <span class="tt">Desbloquear</span>
                                    </a>
                                <?php else: ?>
                                    <span class="badge badge-espera" title="Fecha de desbloqueo">
                                        <i class="bi bi-hourglass-split"></i>
                                        <?= !empty($c['fecha_desbloqueo']) ? date("d/m/Y", strtotime($c['fecha_desbloqueo'])) : '—' ?>
                                    </span>
                                <?php endif;
                            endif; ?>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Módulo Clientes
    </div>

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

// Filtro rápido en tabla (sin recargar página)
function filtrarTabla(q) {
    const filas = document.querySelectorAll('#tablaClientes tbody tr');
    const txt   = q.toLowerCase();
    filas.forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(txt) ? '' : 'none';
    });
}

// Auto-foco en buscador si hay ?buscar en URL
window.addEventListener('DOMContentLoaded', () => {
    const url = new URLSearchParams(window.location.search);
    if (!url.has('buscar')) {
        const fi = document.getElementById('filtroRapido');
        if (fi) fi.focus();
    }
});
</script>
</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();

if (empty($_SESSION['usuario']) || empty($_SESSION['rol'])) {
    header('Location: login.php');
    exit;
}

if (!empty($roles_permitidos) && !in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: index.php?error=sin_permiso');
    exit;
}
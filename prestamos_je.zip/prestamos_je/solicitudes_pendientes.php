<?php
include("seguridad.php");
include("conexion.php");
date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';
$id_empleado_sesion = $_SESSION['id_empleado'] ?? 1;

// ── Solo supervisores y gerentes pueden aprobar/rechazar ──────────
$puede_resolver = in_array($rol, ['GERENTE','SUPERVISOR']);

// ── POST: aprobar o rechazar ──────────────────────────────────────
$msg = ''; $msg_tipo = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $puede_resolver) {
    $accion       = $_POST['accion'] ?? '';
    $id_solicitud = (int)$_POST['id_solicitud'];
    $obs          = $conexion->real_escape_string(trim($_POST['observaciones'] ?? ''));

    if ($accion === 'APROBAR') {
        // Obtener datos de la solicitud
        $sol = $conexion->query("
            SELECT s.*, c.id_cliente,
                   CONCAT(c.nombre,' ',c.apellido) AS nombre_cliente
            FROM solicitudes s
            JOIN clientes c ON c.id_cliente = s.id_cliente
            WHERE s.id_solicitud = $id_solicitud AND s.estado = 'PENDIENTE'
        ")->fetch_assoc();

        if ($sol) {
            $monto   = (float)$sol['monto_solicitado'];
            $interes = round($monto * 0.20, 2);
            $total   = $monto + $interes;
            $tipo    = $sol['tipo_plazo'];
            $plazo   = (int)$sol['plazo_valor'];

            // Calcular pago_diario y dias
            if ($tipo === 'DIARIO') {
                $pago_diario   = round($total / $plazo, 2);
                $dias          = $plazo;
                $plazo_semanas = 0;
            } else {
                $pago_diario   = round($total / $plazo, 2);
                $dias          = $plazo * 6;
                $plazo_semanas = $plazo;
            }

            $fecha_inicio = date('Y-m-d');
            $id_cli       = (int)$sol['id_cliente'];
            $id_emp       = (int)$sol['id_empleado'];

            $conexion->begin_transaction();
            try {
                // Crear el préstamo
                $conexion->query("
                    INSERT INTO prestamos
                      (id_cliente, id_empleado, monto_prestado, interes, total_pagar,
                       pago_diario, plazo_semanas, dias, fecha_inicio, estado,
                       saldo_actual, total_pagado)
                    VALUES
                      ($id_cli, $id_emp, $monto, $interes, $total,
                       $pago_diario, $plazo_semanas, $dias, '$fecha_inicio', 'ACTIVO',
                       $total, 0)
                ");
                $id_prestamo = $conexion->insert_id;

                // Actualizar la solicitud
                $conexion->query("
                    UPDATE solicitudes SET
                        estado                   = 'APROBADA',
                        fecha_resolucion         = NOW(),
                        resuelto_por             = '$user',
                        observaciones_resolucion = '$obs',
                        id_prestamo              = $id_prestamo
                    WHERE id_solicitud = $id_solicitud
                ");

                // Registrar en caja
                $concepto = $conexion->real_escape_string("PRESTAMO #{$id_prestamo} - {$sol['nombre_cliente']}");
                $conexion->query("
                    INSERT INTO caja (tipo, concepto, medio, monto, id_empleado, id_prestamo, tipo_movimiento)
                    VALUES ('SALIDA', '$concepto', 'EFECTIVO', $monto, $id_emp, $id_prestamo, 'PRESTAMO')
                ");

                // Bitácora
                $conexion->query("INSERT INTO bitacora (usuario, accion) VALUES
                    ('$user', 'Solicitud #$id_solicitud APROBADA - Préstamo #$id_prestamo creado por \$$monto')");

                $conexion->commit();
                $msg = "Solicitud #$id_solicitud aprobada. Préstamo #" . str_pad($id_prestamo,6,'0',STR_PAD_LEFT) . " creado correctamente.";
                $msg_tipo = 'ok';
            } catch (Exception $e) {
                $conexion->rollback();
                $msg = "Error al aprobar: " . $e->getMessage();
                $msg_tipo = 'error';
            }
        }

    } elseif ($accion === 'RECHAZAR') {
        $conexion->query("
            UPDATE solicitudes SET
                estado                   = 'RECHAZADA',
                fecha_resolucion         = NOW(),
                resuelto_por             = '$user',
                observaciones_resolucion = '$obs'
            WHERE id_solicitud = $id_solicitud AND estado = 'PENDIENTE'
        ");
        $conexion->query("INSERT INTO bitacora (usuario, accion) VALUES
            ('$user', 'Solicitud #$id_solicitud RECHAZADA')");
        $msg = "Solicitud #$id_solicitud rechazada.";
        $msg_tipo = 'warn';

    } elseif ($accion === 'CANCELAR') {
        $conexion->query("
            UPDATE solicitudes SET estado='CANCELADA', fecha_resolucion=NOW(), resuelto_por='$user'
            WHERE id_solicitud = $id_solicitud AND estado = 'PENDIENTE'
        ");
        $msg = "Solicitud #$id_solicitud cancelada.";
        $msg_tipo = 'warn';
    }
}
// ── Filtros ───────────────────────────────────────────────────────
$filtro_estado = $_GET['estado'] ?? 'PENDIENTE';
$filtro_buscar = $conexion->real_escape_string($_GET['buscar'] ?? '');
$filtro_fecha  = $_GET['fecha'] ?? '';

$where = "WHERE 1=1";
if ($filtro_estado && $filtro_estado !== 'TODOS') $where .= " AND s.estado = '$filtro_estado'";
if ($filtro_buscar) $where .= " AND (CONCAT(c.nombre,' ',c.apellido) LIKE '%$filtro_buscar%' OR c.telefono LIKE '%$filtro_buscar%')";
if ($filtro_fecha)  $where .= " AND DATE(s.fecha_solicitud) = '$filtro_fecha'";

$solicitudes = $conexion->query("
    SELECT s.*,
           CONCAT(c.nombre,' ',c.apellido) AS nombre_cliente,
           c.telefono, c.estatus AS estatus_cliente,
           CONCAT(e.nombre,' ',e.apellido) AS nombre_asesor
    FROM solicitudes s
    JOIN clientes  c ON c.id_cliente  = s.id_cliente
    JOIN empleados e ON e.id_empleado = s.id_empleado
    $where
    ORDER BY s.fecha_solicitud DESC
    LIMIT 100
");

// Contadores para tabs
$cnt = [];
foreach (['PENDIENTE','APROBADA','RECHAZADA','CANCELADA','TODOS'] as $est) {
    $w2 = ($est === 'TODOS') ? "WHERE 1=1" : "WHERE s.estado='$est'";
    $r  = $conexion->query("SELECT COUNT(*) AS n FROM solicitudes s JOIN clientes c ON c.id_cliente=s.id_cliente $w2")->fetch_assoc();
    $cnt[$est] = (int)$r['n'];
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Solicitudes de Préstamo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}
.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;box-shadow:0 4px 14px rgba(37,99,235,.4);flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;letter-spacing:-.3px;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-sb{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}
.main{margin-left:240px;padding:24px 28px 60px;}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.3rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.btn-icon{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;text-decoration:none;}
.btn-icon:hover{color:#0f172a;border-color:#2563eb;}
.btn-back{display:inline-flex;align-items:center;gap:7px;background:white;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 14px;color:#64748b;text-decoration:none;font-size:.82rem;font-weight:600;transition:all .15s;}
.btn-back:hover{background:#f8fafc;color:#0f172a;}
.btn-nueva{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:white;border:none;border-radius:10px;padding:10px 18px;font-size:.88rem;font-weight:700;text-decoration:none;cursor:pointer;transition:all .15s;box-shadow:0 4px 12px rgba(37,99,235,.3);}
.btn-nueva:hover{transform:translateY(-1px);}
.alerta{padding:12px 16px;border-radius:10px;font-size:.85rem;font-weight:600;display:flex;align-items:center;gap:9px;margin-bottom:16px;}
.alerta.ok{background:#f0fdf4;border:1.5px solid #86efac;color:#166534;}
.alerta.error{background:#fef2f2;border:1.5px solid #fca5a5;color:#991b1b;}
.alerta.warn{background:#fffbeb;border:1.5px solid #fcd34d;color:#92400e;}
.filtros-bar{background:white;border-radius:12px;padding:14px 16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.05);border:1px solid #f1f5f9;}
.filtros-bar input,.filtros-bar select{border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 11px;font-size:.83rem;color:#1e293b;background:white;outline:none;font-family:'Inter',sans-serif;}
.filtros-bar input:focus,.filtros-bar select:focus{border-color:#2563eb;}
.btn-filtrar{background:#2563eb;color:white;border:none;border-radius:8px;padding:8px 16px;font-size:.83rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:6px;transition:all .15s;}
.btn-filtrar:hover{background:#1d4ed8;}
.btn-limpiar-f{background:white;border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:.83rem;font-weight:600;color:#64748b;cursor:pointer;text-decoration:none;display:flex;align-items:center;gap:6px;transition:all .15s;}
.btn-limpiar-f:hover{border-color:#94a3b8;color:#0f172a;}
.tabs{display:flex;gap:4px;margin-bottom:16px;background:white;border-radius:12px;padding:6px;box-shadow:0 2px 8px rgba(0,0,0,.05);border:1px solid #f1f5f9;flex-wrap:wrap;}
.tab{padding:8px 16px;border-radius:9px;font-size:.82rem;font-weight:700;cursor:pointer;text-decoration:none;transition:all .15s;color:#64748b;display:flex;align-items:center;gap:6px;}
.tab:hover{background:#f8fafc;color:#0f172a;}
.tab.activo{background:#eff6ff;color:#1e40af;}
.tab .badge{background:#e2e8f0;color:#475569;border-radius:20px;padding:1px 8px;font-size:.72rem;font-weight:800;}
.tab.activo .badge{background:#bfdbfe;color:#1e40af;}
.tab.t-pend .badge{background:#fef9c3;color:#713f12;}
.tab.t-apro .badge{background:#dcfce7;color:#166534;}
.tab.t-rech .badge{background:#fee2e2;color:#991b1b;}
.tabla-wrap{background:white;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.07);border:1px solid #f1f5f9;}
table{width:100%;border-collapse:collapse;}
thead{background:#f8fafc;}
th{padding:11px 14px;text-align:left;font-size:.72rem;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:.06em;border-bottom:2px solid #e2e8f0;}
td{padding:12px 14px;border-bottom:1px solid #f8fafc;font-size:.84rem;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#fafbff;}
.badge-estado{display:inline-flex;align-items:center;gap:4px;padding:4px 11px;border-radius:20px;font-size:.72rem;font-weight:800;white-space:nowrap;}
.be-pend{background:#fef9c3;color:#713f12;border:1px solid #fde68a;}
.be-apro{background:#dcfce7;color:#166534;border:1px solid #86efac;}
.be-rech{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;}
.be-canc{background:#f1f5f9;color:#475569;border:1px solid #cbd5e1;}
.score-chip{display:inline-block;padding:3px 9px;border-radius:20px;font-size:.75rem;font-weight:800;}
.sc-ex{background:#dcfce7;color:#166534;}
.sc-bu{background:#dbeafe;color:#1e40af;}
.sc-re{background:#fef3c7;color:#92400e;}
.sc-ri{background:#fee2e2;color:#991b1b;}
.sc-nd{background:#f1f5f9;color:#94a3b8;}
.acciones{display:flex;gap:6px;flex-wrap:nowrap;}
.btn-aprobar{background:#16a34a;color:white;border:none;border-radius:8px;padding:7px 13px;font-size:.8rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:5px;transition:all .15s;white-space:nowrap;}
.btn-aprobar:hover{background:#15803d;}
.btn-rechazar{background:#dc2626;color:white;border:none;border-radius:8px;padding:7px 13px;font-size:.8rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:5px;transition:all .15s;white-space:nowrap;}
.btn-rechazar:hover{background:#b91c1c;}
.btn-detalle{background:white;border:1.5px solid #e2e8f0;border-radius:8px;padding:6px 11px;font-size:.8rem;font-weight:600;color:#475569;cursor:pointer;text-decoration:none;display:flex;align-items:center;gap:5px;transition:all .15s;}
.btn-detalle:hover{border-color:#2563eb;color:#2563eb;}
.sin-datos{padding:40px;text-align:center;color:#94a3b8;font-size:.88rem;}
.sin-datos i{font-size:2.5rem;display:block;margin-bottom:10px;}
.modal-overlay{position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:500;display:none;align-items:center;justify-content:center;}
.modal-overlay.open{display:flex;}
.modal-box{background:white;border-radius:16px;padding:28px;width:420px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.3);}
.modal-titulo{font-size:1rem;font-weight:800;margin-bottom:6px;}
.modal-sub{font-size:.82rem;color:#64748b;margin-bottom:16px;}
.modal-box textarea{width:100%;border:1.5px solid #e2e8f0;border-radius:9px;padding:9px 12px;font-size:.85rem;font-family:'Inter',sans-serif;resize:vertical;min-height:80px;outline:none;}
.modal-box textarea:focus{border-color:#2563eb;}
.modal-btns{display:flex;gap:10px;margin-top:14px;}
.mbtn-confirmar{flex:1;padding:11px;border:none;border-radius:9px;font-weight:700;font-size:.9rem;cursor:pointer;transition:all .15s;}
.mbtn-confirmar.apr{background:#16a34a;color:white;}
.mbtn-confirmar.apr:hover{background:#15803d;}
.mbtn-confirmar.rech{background:#dc2626;color:white;}
.mbtn-confirmar.rech:hover{background:#b91c1c;}
.mbtn-cancelar{padding:11px 18px;background:white;border:1.5px solid #e2e8f0;border-radius:9px;font-weight:600;font-size:.9rem;cursor:pointer;color:#64748b;transition:all .15s;}
.mbtn-cancelar:hover{border-color:#94a3b8;color:#0f172a;}
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .filtros-bar{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .filtros-bar input,[data-theme="dark"] .filtros-bar select{background:#1e293b;border-color:#334155;color:#e2e8f0;}
[data-theme="dark"] .tabs{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .tab:hover{background:#1e293b;color:#e2e8f0;}
[data-theme="dark"] .tab.activo{background:rgba(37,99,235,.2);color:#93c5fd;}
[data-theme="dark"] .tabla-wrap{background:#111827;border-color:#1e293b;}
[data-theme="dark"] thead{background:#1e293b;}
[data-theme="dark"] th{color:#64748b;border-color:#334155;}
[data-theme="dark"] td{border-color:#1e293b;color:#e2e8f0;}
[data-theme="dark"] tr:hover td{background:#1a2234;}
[data-theme="dark"] .modal-box{background:#111827;}
[data-theme="dark"] .modal-titulo{color:#e2e8f0;}
[data-theme="dark"] .modal-box textarea{background:#1e293b;border-color:#334155;color:#e2e8f0;}
[data-theme="dark"] .btn-back,[data-theme="dark"] .btn-icon,[data-theme="dark"] .btn-detalle,[data-theme="dark"] .btn-limpiar-f{background:#111827;border-color:#1e293b;color:#94a3b8;}
@media(max-width:900px){.sidebar{display:none;}.main{margin-left:0;padding:14px 14px 50px;}.acciones{flex-direction:column;}.th-hide,.td-hide{display:none;}}
</style>
</head>
<body>
<div class="app">
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div><div class="brand-name">Préstamos J.E.</div><div class="brand-sub">Sistema Financiero</div></div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div><div class="u-name"><?= htmlspecialchars($user) ?></div><div class="u-rol"><?= htmlspecialchars($rol) ?></div></div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Solicitudes</div>
        <a href="solicitud_nueva.php"><i class="bi bi-file-earmark-plus"></i> Nueva Solicitud</a>
        <a href="solicitudes_pendientes.php" class="active"><i class="bi bi-hourglass-split"></i> Solicitudes Pendientes</a>
        <a href="historial_solicitudes.php"><i class="bi bi-clock-history"></i> Historial Solicitudes</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="cobro_diario/cobro_diario.php"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <a href="index.php" class="btn-back"><i class="bi bi-arrow-left"></i> Inicio</a>
            <div>
                <div class="topbar-title">Solicitudes de Préstamo</div>
                <div class="topbar-sub"><?= $cnt['PENDIENTE'] ?> pendiente(s) de resolución</div>
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
            <a href="solicitud_nueva.php" class="btn-nueva"><i class="bi bi-plus-lg"></i> Nueva Solicitud</a>
            <a href="historial_solicitudes.php" class="btn-icon" title="Historial completo"><i class="bi bi-clock-history"></i></a>
            <button class="btn-icon" onclick="window.print()" title="Imprimir"><i class="bi bi-printer"></i></button>
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema"><i id="themeIcon" class="bi bi-moon-fill"></i></button>
        </div>
    </div>

    <?php if ($msg): ?>
    <div class="alerta <?= $msg_tipo ?>">
        <i class="bi bi-<?= $msg_tipo==='ok'?'check-circle-fill':($msg_tipo==='warn'?'exclamation-triangle-fill':'x-circle-fill') ?>"></i>
        <?= htmlspecialchars($msg) ?>
    </div>
    <?php endif; ?>

    <!-- TABS -->
    <div class="tabs">
        <?php
        $tabs=[['PENDIENTE','Pendientes','t-pend','hourglass-split'],['APROBADA','Aprobadas','t-apro','check-circle'],
               ['RECHAZADA','Rechazadas','t-rech','x-circle'],['CANCELADA','Canceladas','','dash-circle'],['TODOS','Todas','','list-ul']];
        foreach($tabs as $t):
            $activo=($filtro_estado===$t[0])?'activo':'';
        ?>
        <a href="?estado=<?= $t[0] ?><?= $filtro_buscar?'&buscar='.urlencode($filtro_buscar):'' ?><?= $filtro_fecha?'&fecha='.$filtro_fecha:'' ?>"
           class="tab <?= $t[2] ?> <?= $activo ?>">
            <i class="bi bi-<?= $t[3] ?>"></i> <?= $t[1] ?>
            <span class="badge"><?= $cnt[$t[0]] ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- FILTROS -->
    <form method="GET" class="filtros-bar">
        <input type="hidden" name="estado" value="<?= htmlspecialchars($filtro_estado) ?>">
        <input type="text" name="buscar" value="<?= htmlspecialchars($filtro_buscar) ?>" placeholder="Buscar cliente..." style="flex:1;min-width:160px;">
        <input type="date" name="fecha" value="<?= htmlspecialchars($filtro_fecha) ?>">
        <button type="submit" class="btn-filtrar"><i class="bi bi-search"></i> Filtrar</button>
        <a href="?estado=<?= $filtro_estado ?>" class="btn-limpiar-f"><i class="bi bi-x"></i> Limpiar</a>
    </form>

    <!-- TABLA -->
    <div class="tabla-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th class="th-hide">Asesor</th>
                    <th>Monto</th>
                    <th class="th-hide">Plazo</th>
                    <th>Score</th>
                    <th>Estado</th>
                    <th class="th-hide">Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if($solicitudes && $solicitudes->num_rows>0):
                while($s=$solicitudes->fetch_assoc()):
                    $folio=str_pad($s['id_solicitud'],5,'0',STR_PAD_LEFT);
                    $score=(float)$s['score_cliente'];
                    $be_map=['PENDIENTE'=>'be-pend','APROBADA'=>'be-apro','RECHAZADA'=>'be-rech','CANCELADA'=>'be-canc'];
                    $be_ico=['PENDIENTE'=>'hourglass-split','APROBADA'=>'check-circle-fill','RECHAZADA'=>'x-circle-fill','CANCELADA'=>'dash-circle'];
                    $sc_class=$score>=80?'sc-ex':($score>=60?'sc-bu':($score>=40?'sc-re':($score>0?'sc-ri':'sc-nd')));
            ?>
                <tr>
                    <td><strong>#<?= $folio ?></strong></td>
                    <td>
                        <div style="font-weight:700;"><?= htmlspecialchars($s['nombre_cliente']) ?></div>
                        <div style="font-size:.75rem;color:#64748b;"><?= htmlspecialchars($s['telefono']??'—') ?></div>
                    </td>
                    <td class="td-hide" style="font-size:.82rem;color:#475569;"><?= htmlspecialchars($s['nombre_asesor']) ?></td>
                    <td>
                        <strong style="color:#1d4ed8;">$<?= number_format($s['monto_solicitado'],2) ?></strong>
                        <div style="font-size:.75rem;color:#64748b;"><?= $s['tipo_plazo']==='DIARIO'?$s['plazo_valor'].' días':$s['plazo_valor'].' semanas' ?></div>
                    </td>
                    <td class="td-hide"><?= $s['tipo_plazo']==='DIARIO'?$s['plazo_valor'].' días':$s['plazo_valor'].' semanas' ?></td>
                    <td>
                        <?php if($score>0): ?>
                        <span class="score-chip <?= $sc_class ?>"><?= $score ?>/100</span>
                        <?php else: ?>
                        <span class="score-chip sc-nd">N/D</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge-estado <?= $be_map[$s['estado']]??'be-pend' ?>">
                            <i class="bi bi-<?= $be_ico[$s['estado']]??'hourglass-split' ?>"></i>
                            <?= $s['estado'] ?>
                        </span>
                        <?php if($s['resuelto_por']): ?>
                        <div style="font-size:.7rem;color:#94a3b8;margin-top:3px;">por <?= htmlspecialchars($s['resuelto_por']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="td-hide" style="font-size:.8rem;color:#64748b;">
                        <?= date('d/m/Y H:i',strtotime($s['fecha_solicitud'])) ?>
                    </td>
                    <td>
                        <div class="acciones">
                            <a href="historial_cliente.php?id=<?= $s['id_cliente'] ?>" class="btn-detalle" target="_blank">
                                <i class="bi bi-person"></i>
                            </a>
                            <?php if($s['estado']==='PENDIENTE' && $puede_resolver): ?>
                            <button type="button" class="btn-aprobar"
                                onclick="abrirModal('APROBAR',<?= $s['id_solicitud'] ?>,'<?= htmlspecialchars($s['nombre_cliente'],ENT_QUOTES) ?>',<?= $s['monto_solicitado'] ?>)">
                                <i class="bi bi-check-lg"></i> Aprobar
                            </button>
                            <button type="button" class="btn-rechazar"
                                onclick="abrirModal('RECHAZAR',<?= $s['id_solicitud'] ?>,'<?= htmlspecialchars($s['nombre_cliente'],ENT_QUOTES) ?>',<?= $s['monto_solicitado'] ?>)">
                                <i class="bi bi-x-lg"></i> Rechazar
                            </button>
                            <?php elseif($s['estado']==='PENDIENTE'): ?>
                            <button type="button" class="btn-detalle"
                                onclick="abrirModal('CANCELAR',<?= $s['id_solicitud'] ?>,'<?= htmlspecialchars($s['nombre_cliente'],ENT_QUOTES) ?>',<?= $s['monto_solicitado'] ?>)">
                                <i class="bi bi-x"></i> Cancelar
                            </button>
                            <?php elseif($s['id_prestamo']): ?>
                            <a href="estado_cuenta.php?id=<?= $s['id_cliente'] ?>" class="btn-detalle" target="_blank">
                                <i class="bi bi-eye"></i> Ver Préstamo
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php if($s['observaciones_resolucion']): ?>
                        <div style="font-size:.72rem;color:#94a3b8;margin-top:5px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                             title="<?= htmlspecialchars($s['observaciones_resolucion']) ?>">
                            <i class="bi bi-chat-left-text"></i> <?= htmlspecialchars($s['observaciones_resolucion']) ?>
                        </div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile;
            else: ?>
                <tr><td colspan="9">
                    <div class="sin-datos">
                        <i class="bi bi-inbox"></i>
                        No hay solicitudes <?= $filtro_estado!=='TODOS'?strtolower($filtro_estado).'s':'' ?> con los filtros aplicados.
                        <?php if($filtro_estado==='PENDIENTE'): ?>
                        <br><a href="solicitud_nueva.php" style="color:#2563eb;font-weight:700;text-decoration:none;">+ Crear nueva solicitud</a>
                        <?php endif; ?>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</div>

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay">
    <div class="modal-box">
        <div class="modal-titulo" id="modalTitulo">Confirmar acción</div>
        <div class="modal-sub" id="modalSub">—</div>
        <textarea id="modalObs" placeholder="Observaciones (opcional)..."></textarea>
        <div class="modal-btns">
            <button class="mbtn-confirmar" id="modalConfirmar" onclick="confirmarAccion()">Confirmar</button>
            <button class="mbtn-cancelar" onclick="cerrarModal()">Cancelar</button>
        </div>
    </div>
</div>
<form method="POST" id="formAccion" style="display:none;">
    <input type="hidden" name="accion"        id="fa_accion">
    <input type="hidden" name="id_solicitud"  id="fa_id">
    <input type="hidden" name="observaciones" id="fa_obs">
    <input type="hidden" name="estado"        value="<?= htmlspecialchars($filtro_estado) ?>">
</form>

<script>
function toggleTema(){var c=document.documentElement.getAttribute('data-theme')||'light';var n=c==='dark'?'light':'dark';localStorage.setItem('pje_tema',n);document.documentElement.setAttribute('data-theme',n);document.getElementById('themeIcon').className=n==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';}
(function(){var t=localStorage.getItem('pje_tema')||'light';document.getElementById('themeIcon').className=t==='dark'?'bi bi-sun-fill':'bi bi-moon-fill';})();
function actualizarReloj(){var n=new Date(),p=function(x){return String(x).padStart(2,'0');};var el=document.getElementById('reloj');if(el)el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());}
actualizarReloj();setInterval(actualizarReloj,1000);
var _accionActual='',_idActual=0;
function abrirModal(accion,id,nombre,monto){
    _accionActual=accion;_idActual=id;
    var overlay=document.getElementById('modalOverlay');
    var fmt='$'+parseFloat(monto).toLocaleString('es-MX',{minimumFractionDigits:2});
    if(accion==='APROBAR'){
        document.getElementById('modalTitulo').textContent='Aprobar Solicitud #'+String(id).padStart(5,'0');
        document.getElementById('modalSub').textContent='Se creará el préstamo por '+fmt+' para '+nombre+'. Esta acción no se puede deshacer.';
        document.getElementById('modalConfirmar').textContent='Aprobar y crear préstamo';
        document.getElementById('modalConfirmar').className='mbtn-confirmar apr';
    }else if(accion==='RECHAZAR'){
        document.getElementById('modalTitulo').textContent='Rechazar Solicitud #'+String(id).padStart(5,'0');
        document.getElementById('modalSub').textContent='Se rechazará la solicitud de '+nombre+' por '+fmt+'.';
        document.getElementById('modalConfirmar').textContent='Rechazar solicitud';
        document.getElementById('modalConfirmar').className='mbtn-confirmar rech';
    }else{
        document.getElementById('modalTitulo').textContent='Cancelar Solicitud #'+String(id).padStart(5,'0');
        document.getElementById('modalSub').textContent='Se cancelará la solicitud de '+nombre+'.';
        document.getElementById('modalConfirmar').textContent='Cancelar solicitud';
        document.getElementById('modalConfirmar').className='mbtn-confirmar rech';
    }
    document.getElementById('modalObs').value='';
    overlay.classList.add('open');
}
function cerrarModal(){document.getElementById('modalOverlay').classList.remove('open');}
function confirmarAccion(){
    document.getElementById('fa_accion').value=_accionActual;
    document.getElementById('fa_id').value=_idActual;
    document.getElementById('fa_obs').value=document.getElementById('modalObs').value;
    document.getElementById('formAccion').submit();
}
document.getElementById('modalOverlay').addEventListener('click',function(e){if(e.target===this)cerrarModal();});
</script>
</body>
</html>
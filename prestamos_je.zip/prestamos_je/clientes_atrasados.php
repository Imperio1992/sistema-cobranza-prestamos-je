<?php
$roles_permitidos = ['GERENTE', 'SUPERVISOR', 'ASESOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol    = $_SESSION['rol']     ?? 'ASESOR';
$user   = $_SESSION['usuario'] ?? 'Usuario';
$hoy    = date('Y-m-d');

/* ── ACCIÓN: BLOQUEAR CON COMENTARIO ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'bloquear') {
    if (!in_array($rol, ['GERENTE', 'SUPERVISOR'])) { die("No autorizado"); }

    $id_cliente  = intval($_POST['id_cliente']);
    $motivo      = $conexion->real_escape_string(trim($_POST['motivo'] ?? ''));
    $comentario  = $conexion->real_escape_string(trim($_POST['comentario'] ?? ''));
    $ahora       = date("Y-m-d H:i:s");
    $usuario_ses = $conexion->real_escape_string($user);

    // Bloquear cliente
    $conexion->query("UPDATE clientes SET estatus='BLOQUEADO' WHERE id_cliente=$id_cliente");

    // Registrar en bitácora
    $conexion->query("
        INSERT INTO bitacora (id_cliente, usuario, rol, accion, detalle, fecha)
        VALUES ($id_cliente, '$usuario_ses', '$rol',
                'BLOQUEO_MOROSO',
                CONCAT('Motivo: $motivo | Comentario: $comentario'),
                '$ahora')
    ");

    header("Location: clientes_atrasados.php?bloqueado=1");
    exit;
}

/* ── FILTRO DE DÍAS ── */
$filtro_dias = intval($_GET['min_dias'] ?? 0);

$cond = '';
if ($rol === 'ASESOR') {
    $id_emp = intval($_SESSION['id_empleado']);
    $cond   = "AND c.id_asesor = $id_emp";
}
if ($filtro_dias > 0) {
    $cond .= " AND DATEDIFF('$hoy', p.fecha_fin) >= $filtro_dias";
}

$atrasados = $conexion->query("
    SELECT
        c.id_cliente, c.nombre, c.apellido, c.telefono, c.colonia, c.estatus,
        e.nombre   AS asesor_nombre,
        e.apellido AS asesor_apellido,
        p.id_prestamo, p.monto_prestado, p.saldo_actual, p.fecha_fin,
        DATEDIFF('$hoy', p.fecha_fin) AS dias_atraso
    FROM prestamos p
    INNER JOIN clientes  c ON p.id_cliente = c.id_cliente
    INNER JOIN empleados e ON c.id_asesor  = e.id_empleado
    WHERE p.estado = 'ACTIVO'
      AND p.fecha_fin < '$hoy'
      $cond
    ORDER BY dias_atraso DESC
");

$rows               = [];
$total_atrasados    = 0;
$saldo_total        = 0;
$criticos_40        = 0;
$max_dias           = 0;

while ($r = $atrasados->fetch_assoc()) {
    $rows[] = $r;
    $total_atrasados++;
    $saldo_total += floatval($r['saldo_actual']);
    if (intval($r['dias_atraso']) >= 40) $criticos_40++;
    if (intval($r['dias_atraso']) > $max_dias) $max_dias = intval($r['dias_atraso']);
}

$promedio_dias = $total_atrasados > 0
    ? round(array_sum(array_column($rows, 'dias_atraso')) / $total_atrasados)
    : 0;
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Clientes Atrasados — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(220,38,38,.15); color:#fca5a5; border:1px solid rgba(220,38,38,.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-left h1 { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-left p  { font-size:.82rem; color:#64748b; margin-top:2px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── ALERTA ── */
.alerta {
    display:flex; align-items:center; gap:10px;
    padding:12px 16px; border-radius:12px; font-size:.84rem; font-weight:600;
    margin-bottom:18px; border:1px solid transparent;
}
.alerta-ok    { background:#dcfce7; color:#166534; border-color:#86efac; }
.alerta-critica { background:#fef2f2; color:#991b1b; border-color:#fca5a5; }

/* ── BANNER CRÍTICO (>40 días) ── */
.banner-critico {
    background:linear-gradient(135deg,#7f1d1d,#991b1b);
    border-radius:14px; padding:16px 22px; margin-bottom:22px;
    display:flex; align-items:center; gap:14px; color:white;
    box-shadow:0 4px 16px rgba(153,27,27,.3);
}
.banner-critico i { font-size:2rem; opacity:.9; flex-shrink:0; }
.banner-critico h3 { font-size:1rem; font-weight:800; }
.banner-critico p  { font-size:.8rem; opacity:.85; margin-top:2px; }
.btn-ver-criticos {
    margin-left:auto; background:white; color:#991b1b; border:none; border-radius:9px;
    padding:8px 16px; font-size:.8rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; white-space:nowrap; text-decoration:none;
    transition:all .15s;
}
.btn-ver-criticos:hover { background:#fee2e2; }

/* ── STATS ── */
.stats-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:12px; margin-bottom:22px; }
.stat-card {
    background:white; border-radius:14px; padding:16px 18px;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
    border-left:4px solid transparent;
}
.stat-card.rojo    { border-left-color:#dc2626; }
.stat-card.naranja { border-left-color:#d97706; }
.stat-card.morado  { border-left-color:#7c3aed; }
.stat-card.gris    { border-left-color:#64748b; }
.stat-card.azul    { border-left-color:#2563eb; }
.stat-card .s-lbl { font-size:.68rem; color:#64748b; text-transform:uppercase; letter-spacing:.05em; font-weight:700; }
.stat-card .s-val { font-size:1.6rem; font-weight:800; margin-top:4px; line-height:1; }
.stat-card.rojo    .s-val { color:#dc2626; }
.stat-card.naranja .s-val { color:#d97706; }
.stat-card.morado  .s-val { color:#7c3aed; }
.stat-card.gris    .s-val { color:#475569; }
.stat-card.azul    .s-val { color:#2563eb; }
.stat-card .s-sub { font-size:.7rem; color:#94a3b8; margin-top:3px; }

/* ── FILTROS ── */
.filtros-bar {
    background:white; border-radius:14px; padding:12px 18px; margin-bottom:18px;
    display:flex; align-items:center; gap:10px; flex-wrap:wrap;
    border:1px solid #f1f5f9; box-shadow:0 2px 6px rgba(0,0,0,.05);
}
.filtros-bar label { font-size:.76rem; font-weight:700; color:#475569; white-space:nowrap; }
.filtro-btn {
    display:inline-flex; align-items:center; gap:5px;
    padding:6px 14px; border-radius:99px; font-size:.76rem; font-weight:600;
    text-decoration:none; border:1.5px solid #e2e8f0; background:#f8fafc; color:#64748b;
    transition:all .15s; cursor:pointer;
}
.filtro-btn:hover { border-color:#dc2626; color:#dc2626; background:#fef2f2; }
.filtro-btn.activo { background:#fef2f2; border-color:#fca5a5; color:#dc2626; }

/* ── TABLA ── */
.tabla-wrap {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06); overflow:hidden;
}
.tabla-head {
    display:flex; justify-content:space-between; align-items:center;
    padding:14px 20px; border-bottom:1px solid #f8fafc;
}
.tabla-head-title { font-size:.9rem; font-weight:700; color:#0f172a; }
.tabla-head-count { font-size:.75rem; background:#fef2f2; color:#dc2626; padding:3px 10px; border-radius:99px; font-weight:700; }

table { width:100%; border-collapse:collapse; }
thead th {
    background:#0f172a; color:#94a3b8; font-size:.68rem;
    text-transform:uppercase; letter-spacing:.08em;
    padding:12px 16px; font-weight:700; text-align:left;
}
tbody td { padding:12px 16px; border-bottom:1px solid #f8fafc; font-size:.83rem; vertical-align:middle; }
tbody tr:last-child td { border-bottom:none; }
tbody tr:hover { background:#fff8f8; }
tbody tr.fila-critica { background:#fff8f8; border-left:3px solid #dc2626; }
tbody tr.fila-critica:hover { background:#fee2e2; }
tbody tr.fila-bloqueada { opacity:.6; }

.td-nom strong { font-size:.88rem; color:#0f172a; }
.td-nom .td-col { font-size:.72rem; color:#94a3b8; margin-top:1px; }

/* ── CHIPS DÍAS ── */
.dias-chip {
    display:inline-flex; align-items:center; gap:4px;
    padding:4px 10px; border-radius:99px; font-size:.76rem; font-weight:800;
}
.dias-critico { background:#fee2e2; color:#991b1b; }
.dias-medio   { background:#fef3c7; color:#92400e; }
.dias-leve    { background:#fef9c3; color:#713f12; }

/* ── BADGE ── */
.badge-id { background:#f1f5f9; color:#475569; font-size:.72rem; padding:3px 8px; border-radius:99px; font-weight:700; }
.badge-bloq { background:#fee2e2; color:#991b1b; font-size:.7rem; padding:2px 7px; border-radius:99px; font-weight:700; }

/* ── BOTONES ACCIÓN ── */
.acciones { display:flex; gap:5px; align-items:center; }
.btn-ac {
    display:inline-flex; align-items:center; justify-content:center;
    width:32px; height:32px; border-radius:8px; border:none;
    cursor:pointer; text-decoration:none; font-size:.88rem;
    transition:all .15s; position:relative;
}
.btn-ac:hover .tt { display:block; }
.tt {
    display:none; position:absolute; bottom:calc(100% + 5px); left:50%;
    transform:translateX(-50%); background:#0f172a; color:#fff;
    font-size:.68rem; padding:4px 8px; border-radius:6px;
    white-space:nowrap; z-index:50; pointer-events:none;
}
.btn-ac.hist   { background:#f5f3ff; color:#7c3aed; }
.btn-ac.hist:hover   { background:#7c3aed; color:#fff; }
.btn-ac.bloquear { background:#fef2f2; color:#dc2626; }
.btn-ac.bloquear:hover { background:#dc2626; color:#fff; }
.btn-ac.bloquear-text {
    width:auto; padding:0 12px; font-size:.75rem; font-weight:700;
    gap:5px; display:inline-flex;
}

/* ── VACÍO ── */
.empty-state { text-align:center; padding:60px 24px; color:#94a3b8; }
.empty-state i { font-size:3rem; display:block; margin-bottom:14px; opacity:.25; }
.empty-state h3 { font-size:1rem; font-weight:700; color:#16a34a; margin-bottom:6px; }

/* ── FOOTER ── */
.page-footer { text-align:center; color:#cbd5e1; font-size:.72rem; padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px; }

/* ── MODAL DE BLOQUEO ── */
.modal-overlay {
    display:none; position:fixed; inset:0; background:rgba(0,0,0,.55);
    z-index:1000; align-items:center; justify-content:center; padding:16px;
}
.modal-overlay.visible { display:flex; }
.modal {
    background:white; border-radius:18px; padding:28px; width:100%; max-width:480px;
    box-shadow:0 20px 60px rgba(0,0,0,.3); position:relative;
}
.modal-header { display:flex; align-items:center; gap:12px; margin-bottom:20px; }
.modal-icon {
    width:44px; height:44px; background:#fef2f2; border-radius:12px;
    display:flex; align-items:center; justify-content:center;
    color:#dc2626; font-size:1.3rem; flex-shrink:0;
}
.modal-header h3 { font-size:1rem; font-weight:800; color:#0f172a; }
.modal-header p  { font-size:.78rem; color:#64748b; margin-top:2px; }
.modal-close {
    position:absolute; top:16px; right:16px;
    background:#f1f5f9; border:none; border-radius:8px; width:30px; height:30px;
    cursor:pointer; color:#64748b; font-size:.9rem;
    display:flex; align-items:center; justify-content:center;
}
.modal-close:hover { background:#e2e8f0; color:#0f172a; }
.modal .fg { margin-bottom:16px; }
.modal .fg label { display:block; font-size:.75rem; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:.05em; margin-bottom:6px; }
.modal .fg select,
.modal .fg textarea {
    width:100%; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:10px 13px; font-size:.88rem; font-family:'Inter',sans-serif;
    color:#1e293b; background:#f8fafc; outline:none; transition:border-color .15s;
}
.modal .fg textarea { resize:vertical; min-height:90px; }
.modal .fg select:focus,
.modal .fg textarea:focus { border-color:#dc2626; background:white; }
.modal-warning {
    background:#fef2f2; border:1px solid #fca5a5; border-radius:10px;
    padding:10px 14px; font-size:.78rem; color:#991b1b; margin-bottom:18px;
    display:flex; align-items:flex-start; gap:8px; line-height:1.5;
}
.modal-actions { display:flex; gap:10px; justify-content:flex-end; }
.btn-confirmar-bloqueo {
    display:inline-flex; align-items:center; gap:7px;
    background:#dc2626; color:white; border:none; border-radius:10px;
    padding:10px 20px; font-size:.88rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:all .15s;
}
.btn-confirmar-bloqueo:hover { background:#b91c1c; }
.btn-cancelar-modal {
    display:inline-flex; align-items:center; gap:6px;
    background:#f1f5f9; color:#475569; border:1.5px solid #e2e8f0;
    border-radius:10px; padding:10px 18px; font-size:.88rem; font-weight:600;
    cursor:pointer; font-family:'Inter',sans-serif; transition:all .15s;
}
.btn-cancelar-modal:hover { background:#e2e8f0; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .stats-grid { grid-template-columns:1fr 1fr; }
    table thead th:nth-child(4),
    table tbody td:nth-child(4),
    table thead th:nth-child(5),
    table tbody td:nth-child(5) { display:none; }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-left h1 { color:#e2e8f0; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .alerta-ok { background:rgba(22,163,74,.1); color:#4ade80; border-color:rgba(74,222,128,.3); }
[data-theme="dark"] .banner-critico { background:linear-gradient(135deg,#450a0a,#7f1d1d); }
[data-theme="dark"] .stat-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .stat-card .s-lbl { color:#64748b; }
[data-theme="dark"] .filtros-bar { background:#111827; border-color:#1e293b; }
[data-theme="dark"] .filtro-btn { background:#1e293b; border-color:#334155; color:#64748b; }
[data-theme="dark"] .filtro-btn.activo { background:rgba(220,38,38,.15); border-color:rgba(252,165,165,.3); color:#f87171; }
[data-theme="dark"] .tabla-wrap { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .tabla-head { border-color:#1e293b; }
[data-theme="dark"] .tabla-head-title { color:#e2e8f0; }
[data-theme="dark"] thead th { background:#0a0f1e; color:#475569; }
[data-theme="dark"] tbody td { border-color:#1e293b; }
[data-theme="dark"] tbody tr:hover { background:rgba(220,38,38,.05); }
[data-theme="dark"] tbody tr.fila-critica { background:rgba(220,38,38,.06); }
[data-theme="dark"] tbody tr.fila-critica:hover { background:rgba(220,38,38,.1); }
[data-theme="dark"] .td-nom strong { color:#e2e8f0; }
[data-theme="dark"] .badge-id { background:#1e293b; color:#64748b; }
[data-theme="dark"] .dias-critico { background:rgba(153,27,27,.2); color:#fca5a5; }
[data-theme="dark"] .dias-medio   { background:rgba(146,64,14,.2); color:#fde68a; }
[data-theme="dark"] .dias-leve    { background:rgba(113,63,18,.2); color:#fef08a; }
[data-theme="dark"] .btn-ac.hist    { background:rgba(124,58,237,.15); color:#c4b5fd; }
[data-theme="dark"] .btn-ac.bloquear{ background:rgba(220,38,38,.15); color:#f87171; }
[data-theme="dark"] .modal { background:#111827; }
[data-theme="dark"] .modal-header h3 { color:#e2e8f0; }
[data-theme="dark"] .modal-icon { background:rgba(220,38,38,.15); }
[data-theme="dark"] .modal .fg label { color:#94a3b8; }
[data-theme="dark"] .modal .fg select,
[data-theme="dark"] .modal .fg textarea { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .modal-warning { background:rgba(153,27,27,.15); border-color:rgba(252,165,165,.2); color:#fca5a5; }
[data-theme="dark"] .modal-close { background:#1e293b; color:#64748b; }
[data-theme="dark"] .btn-cancelar-modal { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .page-footer { color:#334155; border-color:#1e293b; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <a href="clientes_atrasados.php" class="active"><i class="bi bi-exclamation-triangle-fill"></i> Atrasados</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <h1>
                <i class="bi bi-exclamation-triangle-fill" style="color:#dc2626;"></i>
                Clientes Atrasados
            </h1>
            <p>Préstamos activos cuya fecha de término ya venció — <?= date('d/m/Y') ?></p>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
        </div>
    </div>

    <!-- ALERTAS -->
    <?php if (isset($_GET['bloqueado'])): ?>
    <div class="alerta alerta-ok">
        <i class="bi bi-slash-circle-fill"></i>
        Cliente bloqueado correctamente. Ya no podrá recibir nuevos préstamos.
    </div>
    <?php endif; ?>

    <!-- BANNER CRÍTICO (solo si hay >40 días) -->
    <?php if ($criticos_40 > 0): ?>
    <div class="banner-critico">
        <i class="bi bi-exclamation-octagon-fill"></i>
        <div>
            <h3><?= $criticos_40 ?> cliente<?= $criticos_40!=1?'s':'' ?> con más de 40 días de atraso</h3>
            <p>Se recomienda bloquear estas cuentas para evitar nuevos préstamos.</p>
        </div>
        <a href="?min_dias=40" class="btn-ver-criticos">
            <i class="bi bi-eye-fill" style="margin-right:5px;"></i>Ver críticos
        </a>
    </div>
    <?php endif; ?>

    <!-- STATS -->
    <div class="stats-grid">
        <div class="stat-card rojo">
            <div class="s-lbl"><i class="bi bi-people-fill" style="margin-right:4px;"></i>Total en atraso</div>
            <div class="s-val"><?= $total_atrasados ?></div>
            <div class="s-sub">préstamos vencidos</div>
        </div>
        <div class="stat-card naranja">
            <div class="s-lbl"><i class="bi bi-cash-stack" style="margin-right:4px;"></i>Saldo pendiente</div>
            <div class="s-val" style="font-size:1.2rem;">$<?= number_format($saldo_total,0) ?></div>
            <div class="s-sub">por recuperar</div>
        </div>
        <div class="stat-card morado">
            <div class="s-lbl"><i class="bi bi-exclamation-octagon" style="margin-right:4px;"></i>Críticos (+40 días)</div>
            <div class="s-val"><?= $criticos_40 ?></div>
            <div class="s-sub">requieren bloqueo</div>
        </div>
        <div class="stat-card gris">
            <div class="s-lbl"><i class="bi bi-calendar-x" style="margin-right:4px;"></i>Promedio atraso</div>
            <div class="s-val"><?= $promedio_dias ?></div>
            <div class="s-sub">días promedio</div>
        </div>
        <div class="stat-card azul">
            <div class="s-lbl"><i class="bi bi-arrow-up-circle" style="margin-right:4px;"></i>Máximo atraso</div>
            <div class="s-val"><?= $max_dias ?></div>
            <div class="s-sub">días el más atrasado</div>
        </div>
    </div>

    <!-- FILTROS POR DÍAS -->
    <div class="filtros-bar">
        <label><i class="bi bi-funnel-fill" style="margin-right:5px;"></i>Filtrar por atraso:</label>
        <a href="clientes_atrasados.php" class="filtro-btn <?= $filtro_dias===0?'activo':'' ?>">
            <i class="bi bi-list"></i> Todos
        </a>
        <a href="?min_dias=7" class="filtro-btn <?= $filtro_dias===7?'activo':'' ?>">
            <i class="bi bi-clock"></i> +7 días
        </a>
        <a href="?min_dias=14" class="filtro-btn <?= $filtro_dias===14?'activo':'' ?>">
            <i class="bi bi-clock-history"></i> +14 días
        </a>
        <a href="?min_dias=30" class="filtro-btn <?= $filtro_dias===30?'activo':'' ?>">
            <i class="bi bi-exclamation-circle"></i> +30 días
        </a>
        <a href="?min_dias=40" class="filtro-btn <?= $filtro_dias===40?'activo':'' ?>"
           style="<?= $filtro_dias===40?'':'border-color:#fca5a5;color:#dc2626;' ?>">
            <i class="bi bi-exclamation-octagon-fill"></i> +40 días (críticos)
        </a>
        <?php if ($filtro_dias > 0): ?>
        <span style="font-size:.75rem;color:#94a3b8;margin-left:auto;">
            Mostrando <strong style="color:#dc2626;"><?= count($rows) ?></strong> con +<?= $filtro_dias ?> días
        </span>
        <?php endif; ?>
    </div>

    <!-- TABLA -->
    <div class="tabla-wrap">
        <div class="tabla-head">
            <span class="tabla-head-title">
                <i class="bi bi-exclamation-triangle" style="color:#dc2626;margin-right:6px;"></i>
                Lista de atrasos
            </span>
            <span class="tabla-head-count"><?= count($rows) ?> registro<?= count($rows)!=1?'s':'' ?></span>
        </div>
        <table>
            <thead>
                <tr>
                    <th>#Préstamo</th>
                    <th>Cliente</th>
                    <th>Teléfono</th>
                    <th>Asesor</th>
                    <th>Venció</th>
                    <th>Días de atraso</th>
                    <th>Saldo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr>
                    <td colspan="8">
                        <div class="empty-state">
                            <i class="bi bi-check-circle-fill" style="color:#16a34a;opacity:1;"></i>
                            <h3>¡Sin atrasos!</h3>
                            <p>No hay préstamos vencidos<?= $filtro_dias>0?' con más de '.$filtro_dias.' días de atraso':'' ?> en este momento.</p>
                        </div>
                    </td>
                </tr>
            <?php else: foreach ($rows as $r):
                $d = intval($r['dias_atraso']);
                $es_critico  = $d >= 40;
                $ya_bloqueado= ($r['estatus'] === 'BLOQUEADO');
                $dias_cls = $d >= 40 ? 'dias-critico' : ($d >= 14 ? 'dias-medio' : 'dias-leve');
                $fila_cls = $es_critico ? 'fila-critica' : ($ya_bloqueado ? 'fila-bloqueada' : '');
            ?>
            <tr class="<?= $fila_cls ?>">
                <td><span class="badge-id"><?= $r['id_prestamo'] ?></span></td>
                <td class="td-nom">
                    <strong><?= htmlspecialchars($r['nombre'].' '.$r['apellido']) ?></strong>
                    <?php if (!empty($r['colonia'])): ?>
                    <div class="td-col"><i class="bi bi-geo-alt" style="margin-right:2px;"></i><?= htmlspecialchars($r['colonia']) ?></div>
                    <?php endif; ?>
                    <?php if ($ya_bloqueado): ?>
                    <span class="badge-bloq"><i class="bi bi-slash-circle" style="margin-right:3px;"></i>Bloqueado</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!empty($r['telefono'])): ?>
                    <a href="tel:<?= htmlspecialchars($r['telefono']) ?>" style="color:inherit;text-decoration:none;display:flex;align-items:center;gap:4px;">
                        <i class="bi bi-telephone" style="color:#94a3b8;"></i>
                        <?= htmlspecialchars($r['telefono']) ?>
                    </a>
                    <?php else: ?>—<?php endif; ?>
                </td>
                <td style="font-size:.8rem;color:#475569;">
                    <?= htmlspecialchars($r['asesor_nombre'].' '.$r['asesor_apellido']) ?>
                </td>
                <td style="font-size:.8rem;color:<?= $es_critico ? '#dc2626' : '#64748b' ?>;font-weight:<?= $es_critico?'700':'400' ?>;">
                    <?= date('d/m/Y', strtotime($r['fecha_fin'])) ?>
                </td>
                <td>
                    <span class="dias-chip <?= $dias_cls ?>">
                        <i class="bi bi-alarm"></i>
                        <?= $d ?> día<?= $d!=1?'s':'' ?>
                        <?php if ($es_critico): ?> <i class="bi bi-exclamation-circle-fill"></i><?php endif; ?>
                    </span>
                </td>
                <td>
                    <strong style="color:#dc2626;">$<?= number_format(floatval($r['saldo_actual']),2) ?></strong>
                </td>
                <td>
                    <div class="acciones">
                        <a href="historial_cliente.php?nombre=<?= urlencode($r['nombre']) ?>"
                           class="btn-ac hist">
                            <i class="bi bi-clock-history"></i>
                            <span class="tt">Ver historial</span>
                        </a>

                        <?php if (!$ya_bloqueado && in_array($rol, ['GERENTE','SUPERVISOR'])): ?>
                        <button class="btn-ac bloquear <?= $es_critico ? 'bloquear-text' : '' ?>"
                                onclick="abrirModalBloqueo(<?= $r['id_cliente'] ?>, '<?= htmlspecialchars(addslashes($r['nombre'].' '.$r['apellido'])) ?>', <?= $d ?>)">
                            <?php if ($es_critico): ?>
                            <i class="bi bi-slash-circle-fill"></i> Bloquear
                            <?php else: ?>
                            <i class="bi bi-slash-circle"></i>
                            <span class="tt">Bloquear cuenta</span>
                            <?php endif; ?>
                        </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Módulo Clientes Atrasados
    </div>

</main>
</div>

<!-- ══════════════════════════════════════
     MODAL DE BLOQUEO
══════════════════════════════════════ -->
<div class="modal-overlay" id="modalBloqueo">
    <div class="modal">
        <button class="modal-close" onclick="cerrarModal()"><i class="bi bi-x-lg"></i></button>
        <div class="modal-header">
            <div class="modal-icon"><i class="bi bi-slash-circle-fill"></i></div>
            <div>
                <h3 id="modalNombre">Bloquear cliente</h3>
                <p id="modalDias" style="color:#dc2626;font-weight:600;"></p>
            </div>
        </div>

        <div class="modal-warning">
            <i class="bi bi-exclamation-triangle-fill" style="flex-shrink:0;margin-top:1px;"></i>
            <div>Al bloquear esta cuenta el cliente <strong>no podrá recibir nuevos préstamos</strong>.
            Esta acción quedará registrada en la bitácora del sistema.</div>
        </div>

        <form method="POST" id="formBloqueo">
            <input type="hidden" name="accion" value="bloquear">
            <input type="hidden" name="id_cliente" id="inputIdCliente">

            <div class="fg">
                <label><i class="bi bi-tag" style="margin-right:4px;"></i>Motivo del bloqueo <span style="color:#dc2626;">*</span></label>
                <select name="motivo" required>
                    <option value="">Seleccionar motivo...</option>
                    <option value="MORA_EXTENDIDA">Mora extendida (+40 días)</option>
                    <option value="INCUMPLIMIENTO">Incumplimiento reiterado de pagos</option>
                    <option value="SIN_CONTACTO">Sin contacto / No localizado</option>
                    <option value="FRAUDE">Sospecha de fraude</option>
                    <option value="SOLICITUD_CLIENTE">Solicitud del cliente</option>
                    <option value="OTRO">Otro motivo</option>
                </select>
            </div>

            <div class="fg">
                <label><i class="bi bi-chat-left-text" style="margin-right:4px;"></i>Comentario / Observaciones</label>
                <textarea name="comentario"
                          placeholder="Describe el motivo con detalle: intentos de contacto, promesas de pago, acuerdos, etc."
                          required></textarea>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn-cancelar-modal" onclick="cerrarModal()">
                    <i class="bi bi-x-circle"></i> Cancelar
                </button>
                <button type="submit" class="btn-confirmar-bloqueo"
                        onclick="return confirm('¿Confirmas bloquear esta cuenta? El cliente no podrá recibir más préstamos.')">
                    <i class="bi bi-slash-circle-fill"></i> Confirmar Bloqueo
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

function abrirModalBloqueo(idCliente, nombre, dias) {
    document.getElementById('inputIdCliente').value = idCliente;
    document.getElementById('modalNombre').textContent = 'Bloquear: ' + nombre;
    document.getElementById('modalDias').textContent = dias + ' días de atraso';
    // Pre-seleccionar motivo si es crítico
    if (dias >= 40) {
        document.querySelector('[name="motivo"]').value = 'MORA_EXTENDIDA';
    }
    document.getElementById('modalBloqueo').classList.add('visible');
}
function cerrarModal() {
    document.getElementById('modalBloqueo').classList.remove('visible');
}
// Cerrar modal al dar clic fuera
document.getElementById('modalBloqueo').addEventListener('click', function(e) {
    if (e.target === this) cerrarModal();
});
// Cerrar con ESC
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') cerrarModal();
});
</script>
</body>
</html>
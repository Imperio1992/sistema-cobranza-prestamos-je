<?php
include("seguridad.php");
include("conexion.php");

$empleado = $_POST['empleado'];
$monto = $_POST['monto'];

$usuario = $_SESSION['usuario'];

$sql = "
INSERT INTO aperturas_caja
(id_empleado,monto_apertura,fecha_apertura,creado_por)
VALUES
('$empleado','$monto',NOW(),'$usuario')
";

$conexion->query($sql);

header("Location: caja.php");
exit;
<?php
include("seguridad.php");
include("conexion.php");

$id = $_POST['id'];
$efectivo = $_POST['efectivo'];
$banca = $_POST['banca'];

$usuario = $_SESSION['usuario'];

$sql = "
INSERT INTO cortes_caja
(id_apertura,efectivo,banca,fecha_corte,realizado_por)
VALUES
('$id','$efectivo','$banca',NOW(),'$usuario')
";

$conexion->query($sql);

$conexion->query("
UPDATE aperturas_caja
SET estatus='CERRADA'
WHERE id_apertura='$id'
");

header("Location: caja.php");
exit;
<?php
include("seguridad.php");
include("conexion.php");

$roles_permitidos = ['GERENTE','SUPERVISOR','ADMIN'];
$rol    = $_SESSION['rol']        ?? 'ASESOR';
$user   = $_SESSION['usuario']    ?? 'Usuario';
$id_emp = intval($_SESSION['id_empleado'] ?? 0);

if (!in_array($rol, $roles_permitidos)) {
    header("Location: index.php"); exit;
}

$fecha = $_GET['fecha'] ?? date('Y-m-d');
// Sanitize
$fecha = preg_replace('/[^0-9\-]/', '', $fecha);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) $fecha = date('Y-m-d');

$filtro_asesor = intval($_GET['asesor'] ?? 0);

// Asesores
$asesores = [];
$ra = $conexion->query("SELECT id_empleado, nombre FROM empleados WHERE estatus='ACTIVO' ORDER BY nombre");
while ($a = $ra->fetch_assoc()) $asesores[] = $a;

// ── Movimientos de caja del día ──────────────────────────────────
$where_asesor = $filtro_asesor ? "AND c.id_empleado = $filtro_asesor" : '';

$movimientos = [];
$rq = $conexion->query("
    SELECT c.*, e.nombre AS empleado_nombre
    FROM   caja c
    LEFT JOIN empleados e ON e.id_empleado = c.id_empleado
    WHERE  DATE(c.fecha) = '$fecha'
    $where_asesor
    ORDER  BY c.fecha ASC
");
while ($m = $rq->fetch_assoc()) $movimientos[] = $m;

// ── Totales de caja ──────────────────────────────────────────────
$total_entradas    = 0; $total_salidas   = 0;
$total_efectivo_e  = 0; $total_banco_e   = 0;
$total_efectivo_s  = 0; $total_banco_s   = 0;

foreach ($movimientos as $m) {
    if ($m['tipo'] === 'ENTRADA') {
        $total_entradas += $m['monto'];
        if ($m['medio'] === 'EFECTIVO') $total_efectivo_e += $m['monto'];
        else                             $total_banco_e    += $m['monto'];
    } else {
        $total_salidas += $m['monto'];
        if ($m['medio'] === 'EFECTIVO') $total_efectivo_s += $m['monto'];
        else                             $total_banco_s    += $m['monto'];
    }
}

$saldo_neto      = $total_entradas - $total_salidas;
$saldo_efectivo  = $total_efectivo_e - $total_efectivo_s;
$saldo_banco     = $total_banco_e    - $total_banco_s;

// ── Cobros del día (pagos) ───────────────────────────────────────
$cobros = [];
$rp = $conexion->query("
    SELECT p.monto_pagado, p.fecha_pago,
           c.nombre AS c_nombre, c.apellido AS c_apellido,
           e.nombre AS asesor
    FROM   pagos p
    INNER JOIN prestamos pr ON pr.id_prestamo = p.id_prestamo
    INNER JOIN clientes  c  ON c.id_cliente   = pr.id_cliente
    INNER JOIN empleados e  ON e.id_empleado  = pr.id_empleado
    WHERE  DATE(p.fecha_pago) = '$fecha'
    ".($filtro_asesor ? "AND pr.id_empleado = $filtro_asesor" : '')."
    ORDER  BY p.fecha_pago ASC
");
while ($row = $rp->fetch_assoc()) $cobros[] = $row;

$total_cobrado = array_sum(array_column($cobros,'monto_pagado'));
$num_cobros    = count($cobros);

// ── Préstamos otorgados ese día ──────────────────────────────────
$rpr = $conexion->query("
    SELECT pr.monto_prestado, pr.total_pagar, pr.dias,
           c.nombre AS c_nombre, c.apellido AS c_apellido,
           e.nombre AS asesor
    FROM   prestamos pr
    INNER JOIN clientes  c ON c.id_cliente  = pr.id_cliente
    INNER JOIN empleados e ON e.id_empleado = pr.id_empleado
    WHERE  DATE(pr.fecha_inicio) = '$fecha'
    ".($filtro_asesor ? "AND pr.id_empleado = $filtro_asesor" : '')."
    ORDER  BY pr.id_prestamo ASC
");
$prestamos_dia = [];
while ($row = $rpr->fetch_assoc()) $prestamos_dia[] = $row;
$total_prestado_dia = array_sum(array_column($prestamos_dia,'monto_prestado'));

// Tipos de movimiento para resumen
$por_tipo = [];
foreach ($movimientos as $m) {
    $t = $m['tipo_movimiento'] ?? 'OTRO';
    if (!isset($por_tipo[$t])) $por_tipo[$t] = ['entradas'=>0,'salidas'=>0,'n'=>0];
    $por_tipo[$t]['n']++;
    if ($m['tipo']==='ENTRADA') $por_tipo[$t]['entradas'] += $m['monto'];
    else                         $por_tipo[$t]['salidas']  += $m['monto'];
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Corte de Caja | Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}

/* ── SIDEBAR ── */
.sidebar a{display:block;color:#94a3b8;text-decoration:none;padding:8px 10px;border-radius:8px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}.sidebar a:hover{background:#1e293b;color:#e2e8f0;}.sidebar a.active,.sidebar a[style*="background"]{background:rgba(37,99,235,.15)!important;color:#93c5fd!important;}.sidebar h5{padding:14px 12px 2px;color:#fff;margin:0;font-size:.95rem;}.sidebar small{padding:0 12px;display:block;margin-bottom:8px;}.sidebar hr{border-color:#1e293b;}.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,0.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;line-height:1.2;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;background:#0f172a;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-hoy{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}

/* ── MAIN ── */
.main{margin-left:240px;flex:1;padding:24px 28px 48px;}

/* ── TOPBAR ── */
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.topbar-title{font-size:1.35rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:10px;}
.btn-theme{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;}
.btn-theme:hover{color:#0f172a;border-color:#2563eb;}
.btn-print{display:inline-flex;align-items:center;gap:7px;background:#0f172a;color:white;border:none;border-radius:10px;padding:9px 18px;font-size:.84rem;font-weight:600;cursor:pointer;transition:background .15s;}
.btn-print:hover{background:#1e293b;}

/* ── FILTRO FECHA ── */
.filtros{background:white;border-radius:14px;padding:14px 20px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:20px;}
.filtros form{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;}
.f-group{display:flex;flex-direction:column;gap:4px;}
.f-group label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#64748b;}
.f-group select,.f-group input{border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 12px;font-size:.84rem;font-family:'Inter',sans-serif;color:#1e293b;background:white;outline:none;transition:border-color .15s;}
.f-group select:focus,.f-group input:focus{border-color:#2563eb;}
.btn-filtrar{background:#2563eb;color:white;border:none;border-radius:9px;padding:9px 20px;font-size:.84rem;font-weight:600;cursor:pointer;}
.btn-hoy{background:white;color:#64748b;border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 14px;font-size:.84rem;font-weight:600;text-decoration:none;display:inline-block;}

/* ── RESUMEN SALDO ── */
.saldo-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:20px;}
.saldo-card{background:white;border-radius:14px;padding:18px 20px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center;}
.saldo-card .sc-val{font-size:1.6rem;font-weight:800;color:#0f172a;line-height:1;margin-bottom:4px;}
.saldo-card .sc-lbl{font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;font-weight:600;}
.saldo-card .sc-sub{font-size:.74rem;color:#64748b;margin-top:6px;}
.saldo-card.verde .sc-val{color:#16a34a;}
.saldo-card.rojo  .sc-val{color:#dc2626;}
.saldo-card.azul  .sc-val{color:#2563eb;}

/* Resumen grande -->  tres medios */
.medios-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;}
.medio-box{background:white;border-radius:14px;padding:16px 20px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);}
.medio-box h6{font-size:.78rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;display:flex;align-items:center;gap:6px;}
.medio-row{display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid #f1f5f9;font-size:.83rem;}
.medio-row:last-child{border-bottom:none;font-weight:700;}
.medio-row .lbl{color:#475569;}
.medio-row .val-e{color:#16a34a;font-weight:600;}
.medio-row .val-s{color:#dc2626;font-weight:600;}
.medio-row .val-n{font-weight:700;color:#0f172a;}

/* ── TARJETA CARD ── */
.card{background:white;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:20px;overflow:hidden;}
.card-header{padding:14px 20px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:8px;}
.card-header h5{font-size:.9rem;font-weight:700;color:#0f172a;margin:0;}
.card-header .cnt{margin-left:auto;font-size:.78rem;color:#94a3b8;}

/* ── TABLA ── */
.tabla-scroll{overflow-x:auto;}
.tabla{width:100%;border-collapse:collapse;font-size:.82rem;}
.tabla thead th{padding:9px 14px;text-align:left;font-size:.67rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#94a3b8;border-bottom:2px solid #f1f5f9;white-space:nowrap;background:#fafbfc;}
.tabla tbody td{padding:10px 14px;border-bottom:1px solid #f9fafb;vertical-align:middle;}
.tabla tbody tr:hover{background:#fafbfc;}
.tabla tbody tr:last-child td{border-bottom:none;}
.tabla tfoot td{padding:11px 14px;font-weight:700;font-size:.84rem;border-top:2px solid #e2e8f0;background:#f8fafc;}
.tag{display:inline-flex;align-items:center;border-radius:6px;padding:3px 9px;font-size:.7rem;font-weight:700;}
.tag-e{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0;}
.tag-s{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}
.tag-ef{background:#fffbeb;color:#92400e;border:1px solid #fde68a;}
.tag-bk{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;}
.monto-e{color:#16a34a;font-weight:700;}
.monto-s{color:#dc2626;font-weight:700;}
.vacio-msg{text-align:center;padding:28px;color:#94a3b8;font-size:.84rem;}

/* ── CORTE IMPRIMIBLE ── */
.corte-header-print{
    display:none;
    background:linear-gradient(135deg,#0f172a,#1e3a8a);
    color:white;padding:24px 32px;
    border-radius:12px 12px 0 0;
    margin-bottom:0;
}
.corte-header-print h1{font-size:1.4rem;font-weight:800;margin-bottom:4px;}
.corte-header-print p{font-size:.8rem;color:#93c5fd;}

/* Firmas */
.firmas{display:grid;grid-template-columns:1fr 1fr;gap:48px;margin-top:36px;}
.firma{text-align:center;}
.firma-linea{border-top:1.5px solid #0f172a;padding-top:8px;margin-top:40px;}
.firma-nombre{font-size:.84rem;font-weight:700;color:#0f172a;}
.firma-cargo{font-size:.7rem;color:#64748b;text-transform:uppercase;margin-top:2px;}

/* ── DARK MODE ── */
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .btn-theme{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .filtros{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .f-group select,[data-theme="dark"] .f-group input{background:#0f172a;border-color:#1e293b;color:#e2e8f0;}
[data-theme="dark"] .btn-hoy{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .saldo-card,.card,[data-theme="dark"] .medio-box{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .saldo-card .sc-val{color:#e2e8f0;}
[data-theme="dark"] .card-header{border-bottom-color:#1e293b;}
[data-theme="dark"] .card-header h5{color:#e2e8f0;}
[data-theme="dark"] .tabla thead th{background:#0f172a;border-bottom-color:#1e293b;}
[data-theme="dark"] .tabla tbody td{border-bottom-color:#1a2235;color:#e2e8f0;}
[data-theme="dark"] .tabla tbody tr:hover{background:#0f172a;}
[data-theme="dark"] .tabla tfoot td{background:#0f172a;border-top-color:#1e293b;}
[data-theme="dark"] .medio-row .lbl{color:#94a3b8;}
[data-theme="dark"] .medio-row .val-n{color:#e2e8f0;}
[data-theme="dark"] .medio-row{border-bottom-color:#1e293b;}
[data-theme="dark"] .firma-linea{border-top-color:#e2e8f0;}
[data-theme="dark"] .firma-nombre{color:#e2e8f0;}

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar{display:none;}
    .main{margin-left:0;padding:14px 14px 40px;}
    .saldo-grid{grid-template-columns:1fr 1fr;}
    .medios-row{grid-template-columns:1fr;}
}
@media(max-width:540px){
    .saldo-grid{grid-template-columns:1fr 1fr;}
    .firmas{grid-template-columns:1fr;}
}

/* ── PRINT ── */
@media print{
    .sidebar,.topbar,.filtros,.btn-print,.btn-theme{display:none!important;}
    .main{margin-left:0!important;padding:0!important;}
    .app{display:block;}
    body{background:white!important;}
    .corte-header-print{display:block!important;}
    .card,.medio-box,.saldo-card{box-shadow:none!important;border:1px solid #ccc!important;break-inside:avoid;}
    .tabla tbody tr{break-inside:avoid;}
    [data-theme="dark"] .saldo-card,[data-theme="dark"] .card,[data-theme="dark"] .medio-box{background:white!important;border:1px solid #ccc!important;}
    [data-theme="dark"] .tabla thead th{background:#f8fafc!important;color:#64748b!important;}
    [data-theme="dark"] .tabla tbody td{color:#0f172a!important;}
}
</style>
</head>
<body>
<div class="app">

<!-- ══════════ SIDEBAR ══════════ -->
<?php include("sidebar.php"); ?>

<!-- ══════════ MAIN ══════════ -->
<main class="main">

    <!-- Cabecera solo en impresión -->
    <div class="corte-header-print">
        <h1>💰 Préstamos J.E. — Corte de Caja</h1>
        <p>Fecha: <?= date('d/m/Y', strtotime($fecha)) ?> · Generado: <?= date('d/m/Y H:i') ?> · Responsable: <?= htmlspecialchars($user) ?></p>
    </div>

    <div class="topbar">
        <div>
            <div class="topbar-title"><i class="bi bi-safe2-fill" style="color:#16a34a;font-size:1.1rem;"></i> Corte de Caja</div>
            <div class="topbar-sub"><?= date('d/m/Y', strtotime($fecha)) ?> — <?= count($movimientos) ?> movimiento<?= count($movimientos)!=1?'s':'' ?></div>
        </div>
        <div class="topbar-right">
            <button class="btn-print" onclick="window.print()">
                <i class="bi bi-printer-fill"></i> Imprimir / PDF
            </button>
            <button class="btn-theme" onclick="toggleTheme()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros">
        <form method="GET" action="corte_caja.php">
            <div class="f-group">
                <label>Fecha del corte</label>
                <input type="date" name="fecha" value="<?= htmlspecialchars($fecha) ?>">
            </div>
            <div class="f-group">
                <label>Asesor</label>
                <select name="asesor">
                    <option value="0">Todos</option>
                    <?php foreach ($asesores as $a): ?>
                    <option value="<?= $a['id_empleado'] ?>" <?= $filtro_asesor === intval($a['id_empleado']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a['nombre']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-filtrar"><i class="bi bi-funnel-fill"></i> Ver Corte</button>
            <a href="corte_caja.php" class="btn-hoy"><i class="bi bi-calendar-day"></i> Hoy</a>
        </form>
    </div>

    <!-- RESUMEN DE SALDO -->
    <div class="saldo-grid">
        <div class="saldo-card verde">
            <div class="sc-val">$<?= number_format($total_entradas,2) ?></div>
            <div class="sc-lbl">Total Entradas</div>
            <div class="sc-sub">Efectivo $<?= number_format($total_efectivo_e,2) ?> · Banco $<?= number_format($total_banco_e,2) ?></div>
        </div>
        <div class="saldo-card rojo">
            <div class="sc-val">$<?= number_format($total_salidas,2) ?></div>
            <div class="sc-lbl">Total Salidas</div>
            <div class="sc-sub">Efectivo $<?= number_format($total_efectivo_s,2) ?> · Banco $<?= number_format($total_banco_s,2) ?></div>
        </div>
        <div class="saldo-card <?= $saldo_neto >= 0 ? 'azul' : 'rojo' ?>">
            <div class="sc-val">$<?= number_format($saldo_neto,2) ?></div>
            <div class="sc-lbl">Saldo Neto del Día</div>
            <div class="sc-sub">Cobrado: $<?= number_format($total_cobrado,2) ?> (<?= $num_cobros ?> cobros)</div>
        </div>
    </div>

    <!-- DESGLOSE POR MEDIO -->
    <div class="medios-row">
        <!-- Efectivo -->
        <div class="medio-box">
            <h6><i class="bi bi-cash-coin" style="color:#d97706;"></i> Efectivo</h6>
            <div class="medio-row">
                <span class="lbl">Entradas efectivo</span>
                <span class="val-e">+$<?= number_format($total_efectivo_e,2) ?></span>
            </div>
            <div class="medio-row">
                <span class="lbl">Salidas efectivo</span>
                <span class="val-s">−$<?= number_format($total_efectivo_s,2) ?></span>
            </div>
            <div class="medio-row">
                <span class="lbl">Saldo efectivo</span>
                <span class="val-n <?= $saldo_efectivo >= 0 ? '' : 'val-s' ?>">$<?= number_format($saldo_efectivo,2) ?></span>
            </div>
        </div>
        <!-- Banco -->
        <div class="medio-box">
            <h6><i class="bi bi-bank2" style="color:#2563eb;"></i> Banco / Transferencia</h6>
            <div class="medio-row">
                <span class="lbl">Entradas banco</span>
                <span class="val-e">+$<?= number_format($total_banco_e,2) ?></span>
            </div>
            <div class="medio-row">
                <span class="lbl">Salidas banco</span>
                <span class="val-s">−$<?= number_format($total_banco_s,2) ?></span>
            </div>
            <div class="medio-row">
                <span class="lbl">Saldo banco</span>
                <span class="val-n <?= $saldo_banco >= 0 ? '' : 'val-s' ?>">$<?= number_format($saldo_banco,2) ?></span>
            </div>
        </div>
    </div>

    <?php if (!empty($por_tipo)): ?>
    <!-- RESUMEN POR TIPO DE MOVIMIENTO -->
    <div class="card" style="margin-bottom:20px;">
        <div class="card-header">
            <i class="bi bi-grid-3x3-gap-fill" style="color:#7c3aed;"></i>
            <h5>Resumen por Tipo de Movimiento</h5>
        </div>
        <div class="tabla-scroll">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Movimientos</th>
                        <th>Entradas</th>
                        <th>Salidas</th>
                        <th>Neto</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($por_tipo as $tipo => $datos): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($tipo) ?></strong></td>
                    <td><?= $datos['n'] ?></td>
                    <td class="monto-e">$<?= number_format($datos['entradas'],2) ?></td>
                    <td class="monto-s">$<?= number_format($datos['salidas'],2) ?></td>
                    <td style="font-weight:700;color:<?= ($datos['entradas']-$datos['salidas']) >= 0 ? '#16a34a' : '#dc2626' ?>;">
                        $<?= number_format($datos['entradas']-$datos['salidas'],2) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- MOVIMIENTOS DE CAJA -->
    <div class="card">
        <div class="card-header">
            <i class="bi bi-list-ul" style="color:#2563eb;"></i>
            <h5>Movimientos de Caja</h5>
            <span class="cnt"><?= count($movimientos) ?> registros</span>
        </div>
        <div class="tabla-scroll">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Hora</th>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th>Tipo Mov.</th>
                        <th>Medio</th>
                        <th>Empleado</th>
                        <th>Monto</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($movimientos)): ?>
                    <tr><td colspan="8" class="vacio-msg"><i class="bi bi-inbox"></i><br>Sin movimientos de caja para esta fecha</td></tr>
                <?php else: ?>
                    <?php foreach ($movimientos as $i => $m): ?>
                    <tr>
                        <td style="color:#94a3b8;font-size:.75rem;"><?= $i+1 ?></td>
                        <td><?= date('H:i', strtotime($m['fecha'])) ?></td>
                        <td><span class="tag <?= $m['tipo']==='ENTRADA' ? 'tag-e' : 'tag-s' ?>"><?= $m['tipo'] ?></span></td>
                        <td><?= htmlspecialchars($m['concepto'] ?? '—') ?></td>
                        <td style="font-size:.75rem;color:#64748b;"><?= htmlspecialchars($m['tipo_movimiento'] ?? '—') ?></td>
                        <td><span class="tag <?= $m['medio']==='EFECTIVO' ? 'tag-ef' : 'tag-bk' ?>"><?= $m['medio'] ?></span></td>
                        <td><?= htmlspecialchars($m['empleado_nombre'] ?? '—') ?></td>
                        <td class="<?= $m['tipo']==='ENTRADA' ? 'monto-e' : 'monto-s' ?>">
                            <?= $m['tipo']==='ENTRADA' ? '+' : '−' ?>$<?= number_format($m['monto'],2) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
                <?php if (!empty($movimientos)): ?>
                <tfoot>
                    <tr>
                        <td colspan="7"><strong>SALDO NETO</strong></td>
                        <td style="color:<?= $saldo_neto >= 0 ? '#16a34a' : '#dc2626' ?>;font-size:.92rem;">
                            $<?= number_format($saldo_neto,2) ?>
                        </td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <!-- COBROS DEL DÍA -->
    <?php if (!empty($cobros)): ?>
    <div class="card">
        <div class="card-header">
            <i class="bi bi-credit-card-fill" style="color:#16a34a;"></i>
            <h5>Cobros Registrados del Día</h5>
            <span class="cnt"><?= $num_cobros ?> cobro<?= $num_cobros!=1?'s':'' ?> · Total: $<?= number_format($total_cobrado,2) ?></span>
        </div>
        <div class="tabla-scroll">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Asesor</th>
                        <th>Hora</th>
                        <th>Monto Cobrado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cobros as $i => $co): ?>
                    <tr>
                        <td style="color:#94a3b8;font-size:.75rem;"><?= $i+1 ?></td>
                        <td><?= htmlspecialchars($co['c_nombre'].' '.$co['c_apellido']) ?></td>
                        <td><?= htmlspecialchars($co['asesor']) ?></td>
                        <td><?= date('H:i', strtotime($co['fecha_pago'])) ?></td>
                        <td class="monto-e">+$<?= number_format($co['monto_pagado'],2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4"><strong>TOTAL COBRADO</strong></td>
                        <td style="color:#16a34a;">$<?= number_format($total_cobrado,2) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- PRÉSTAMOS OTORGADOS -->
    <?php if (!empty($prestamos_dia)): ?>
    <div class="card">
        <div class="card-header">
            <i class="bi bi-file-earmark-plus-fill" style="color:#7c3aed;"></i>
            <h5>Préstamos Otorgados en el Día</h5>
            <span class="cnt"><?= count($prestamos_dia) ?> · Capital: $<?= number_format($total_prestado_dia,2) ?></span>
        </div>
        <div class="tabla-scroll">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Asesor</th>
                        <th>Plazo</th>
                        <th>Capital</th>
                        <th>Total a Pagar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($prestamos_dia as $pd): ?>
                    <tr>
                        <td><?= htmlspecialchars($pd['c_nombre'].' '.$pd['c_apellido']) ?></td>
                        <td><?= htmlspecialchars($pd['asesor']) ?></td>
                        <td><?= $pd['dias'] ?> días</td>
                        <td>$<?= number_format($pd['monto_prestado'],2) ?></td>
                        <td>$<?= number_format($pd['total_pagar'],2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>TOTAL PRESTADO</strong></td>
                        <td style="color:#7c3aed;">$<?= number_format($total_prestado_dia,2) ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- FIRMAS -->
    <div class="card" style="padding:24px 28px;">
        <div class="firmas">
            <div class="firma">
                <div class="firma-linea">
                    <div class="firma-nombre"><?= htmlspecialchars($user) ?></div>
                    <div class="firma-cargo">Responsable del Corte</div>
                </div>
            </div>
            <div class="firma">
                <div class="firma-linea">
                    <div class="firma-nombre">Gerencia / Supervisión</div>
                    <div class="firma-cargo">Autorizado por</div>
                </div>
            </div>
        </div>
    </div>

    <div style="text-align:center;color:#cbd5e1;font-size:.72rem;padding:12px 0;border-top:1px solid #e2e8f0;margin-top:8px;">
        Préstamos J.E. © <?= date('Y') ?> — Corte de Caja del <?= date('d/m/Y', strtotime($fecha)) ?> · Generado <?= date('d/m/Y H:i') ?>
    </div>

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const ic = document.getElementById('themeIcon');
    if (ic) ic.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();
function actualizarReloj() {
    const a = new Date();
    const el = document.getElementById('reloj');
    if (el) el.textContent = String(a.getHours()).padStart(2,'0')+':'+String(a.getMinutes()).padStart(2,'0')+':'+String(a.getSeconds()).padStart(2,'0');
}
actualizarReloj(); setInterval(actualizarReloj,1000);
</script>
</body>
</html>

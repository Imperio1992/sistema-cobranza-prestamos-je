<?php

include("conexion.php");
include("calcular_atraso.php");

$sql = "SELECT * FROM prestamos WHERE estado='ACTIVO'";
$result = mysqli_query($conexion,$sql);

while($prestamo = mysqli_fetch_assoc($result)){

    $id = $prestamo['id_prestamo'];
    $fecha_inicio = $prestamo['fecha_inicio'];
    $dias = $prestamo['dias_prestamo'];
    $total_pagado = $prestamo['total_pagado'];
    $pago_diario = $prestamo['pago_diario'];

    $dias_atraso = calcularDiasAtraso($fecha_inicio,$dias,$total_pagado,$pago_diario);

    $mora = $dias_atraso * 10;

    $update = "UPDATE prestamos 
               SET mora_acumulada='$mora'
               WHERE id_prestamo='$id'";

    mysqli_query($conexion,$update);
}

?>
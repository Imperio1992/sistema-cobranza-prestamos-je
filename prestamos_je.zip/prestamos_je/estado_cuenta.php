<?php
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol  = $_SESSION['rol']     ?? 'ASESOR';
$user = $_SESSION['usuario'] ?? 'Usuario';

// ── Validar ID ────────────────────────────────────────────────────
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de cliente invalido.");
}
$id_cliente = (int)$_GET['id'];
$modo_pdf   = isset($_GET['pdf']) && $_GET['pdf'] == '1';

// ── Datos del cliente ─────────────────────────────────────────────
$stmt = $conexion->prepare("SELECT * FROM clientes WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$cliente = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$cliente) die("Cliente no encontrado.");

// ── Prestamos del cliente ─────────────────────────────────────────
$stmt2 = $conexion->prepare("
    SELECT pr.id_prestamo,
           pr.monto_prestado,
           pr.interes,
           pr.total_pagar,
           pr.pago_diario,
           pr.plazo_semanas,
           pr.dias,
           pr.fecha_inicio,
           pr.fecha_fin,
           pr.estado,
           pr.saldo_actual,
           pr.total_pagado,
           pr.mora_acumulada,
           DATEDIFF(CURRENT_DATE(), pr.fecha_fin) AS dias_vencido,
           e.nombre AS asesor
    FROM   prestamos pr
    LEFT JOIN empleados e ON e.id_empleado = pr.id_empleado
    WHERE  pr.id_cliente = ?
    ORDER  BY pr.fecha_inicio DESC
");
$stmt2->bind_param("i", $id_cliente);
$stmt2->execute();
$prestamos_result = $stmt2->get_result();
$stmt2->close();

$prestamos = [];
while ($p = $prestamos_result->fetch_assoc()) {
    $stmt3 = $conexion->prepare("
        SELECT monto_pagado, fecha_pago FROM pagos
        WHERE  id_prestamo = ?
        ORDER  BY fecha_pago ASC, id_pago ASC
    ");
    $stmt3->bind_param("i", $p['id_prestamo']);
    $stmt3->execute();
    $res3 = $stmt3->get_result();
    $pagos_hist = [];
    while ($pg = $res3->fetch_assoc()) $pagos_hist[] = $pg;
    $stmt3->close();
    $p['pagos_hist'] = $pagos_hist;
    $prestamos[] = $p;
}

$total_a_pagar_g = 0;
$total_pagado_g  = 0;
$total_saldo_g   = 0;
foreach ($prestamos as $p) {
    $total_a_pagar_g += $p['total_pagar'];
    $total_pagado_g  += $p['total_pagado'];
    $total_saldo_g   += $p['saldo_actual'];
}

// ── SCORE GENERAL DE APROBACIÓN DE CRÉDITO ─────────────────────
$score_base    = max(0, min(100, intval($cliente['score_crediticio'] ?? 100)));
$prestamos_pagados   = 0;
$prestamos_atrasados = 0;
$prestamos_activos   = 0;
foreach ($prestamos as $pp) {
    if ($pp['estado'] === 'PAGADO')   $prestamos_pagados++;
    if ($pp['estado'] === 'ATRASADO') $prestamos_atrasados++;
    if ($pp['estado'] === 'ACTIVO' || $pp['estado'] === 'ATRASADO') $prestamos_activos++;
}
$bono_historial = min(20, $prestamos_pagados * 5);   // hasta +20 por créditos pagados
$pen_atraso     = min(40, $prestamos_atrasados * 15); // hasta -40 por créditos atrasados

// Penalización por cuotas atrasadas en préstamos activos (cobro Lun-Sáb)
$cuotas_atrasadas_total = 0;
foreach ($prestamos as $pp) {
    if ($pp['estado'] !== 'ACTIVO' && $pp['estado'] !== 'ATRASADO') continue;
    if (empty($pp['fecha_inicio']) || empty($pp['pago_diario']) || $pp['pago_diario'] <= 0) continue;
    $ini = strtotime($pp['fecha_inicio']);
    $hoy = strtotime(date('Y-m-d'));
    if ($ini > $hoy) continue;
    $cuotas_venc = 0;
    for ($d = $ini; $d <= $hoy; $d += 86400) {
        if ((int)date('w', $d) !== 0) $cuotas_venc++; // saltar domingos
    }
    $cuotas_pagadas = floor(((float)$pp['total_pagado']) / ((float)$pp['pago_diario']));
    $atrasos_pp = max(0, $cuotas_venc - $cuotas_pagadas);
    $cuotas_atrasadas_total += $atrasos_pp;
}
$pen_cuotas    = min(30, $cuotas_atrasadas_total * 2); // -2 pts por cuota, máx -30

$pct_pagado_g  = $total_a_pagar_g > 0 ? round(($total_pagado_g / $total_a_pagar_g) * 100) : 0;
$score_general = max(0, min(100, $score_base + $bono_historial - $pen_atraso - $pen_cuotas));

if ($score_general >= 80)      { $score_color='#16a34a'; $score_bg='#dcfce7'; $score_label='APROBADO';  $score_icon='bi-check-circle-fill'; }
elseif ($score_general >= 50) { $score_color='#d97706'; $score_bg='#fef3c7'; $score_label='REVISAR';   $score_icon='bi-exclamation-triangle-fill'; }
else                            { $score_color='#dc2626'; $score_bg='#fee2e2'; $score_label='RECHAZADO'; $score_icon='bi-x-circle-fill'; }

// ── PRÉSTAMO RECOMENDADO (solo si score >= 70%) ─────────────────
$prestamo_recomendado = 0;
$capital_max_previo   = 0;
foreach ($prestamos as $pp) {
    if ((float)$pp['monto_prestado'] > $capital_max_previo) $capital_max_previo = (float)$pp['monto_prestado'];
}
if ($score_general >= 70) {
    // Base: el mayor préstamo previo, o 2000 si es cliente nuevo
    $base = $capital_max_previo > 0 ? $capital_max_previo : 2000;
    if      ($score_general >= 95) $factor = 2.5;
    elseif  ($score_general >= 90) $factor = 2.0;
    elseif  ($score_general >= 85) $factor = 1.5;
    elseif  ($score_general >= 80) $factor = 1.25;
    elseif  ($score_general >= 75) $factor = 1.0;
    else                            $factor = 0.75; // 70-74
    $bruto = $base * $factor;
    // Redondeo a múltiplos de 1000 (cerrados)
    $prestamo_recomendado = max(1000, floor($bruto / 1000) * 1000);
}

// ════════════════════════════════════
// MODO PDF
// ════════════════════════════════════
if ($modo_pdf) {
    ob_start();
    require("fpdf.php");

    class PDF extends FPDF {
        function Header() {}
        function Footer() {
            $this->SetY(-12);
            $this->SetFont('Arial', 'I', 7);
            $this->SetTextColor(150, 150, 150);
            $this->Cell(0, 8, 'Prestamos J.E. - Estado de Cuenta generado el ' . date('d/m/Y H:i') . '  |  Pagina ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        }
    }

    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetMargins(12, 12, 12);
    $pdf->SetAutoPageBreak(true, 18);

    // Cabecera
    $pdf->SetFillColor(15, 23, 42);
    $pdf->Rect(0, 0, 210, 26, 'F');
    $pdf->SetY(6);
    $pdf->SetFont('Arial', 'B', 15);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->Cell(0, 8, 'PRESTAMOS J.E.', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetTextColor(147, 197, 253);
    $pdf->Cell(0, 6, 'ESTADO DE CUENTA DEL CLIENTE', 0, 1, 'C');
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetY(30);

    // Datos del cliente
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(239, 246, 255);
    $pdf->Rect(12, $pdf->GetY(), 186, 7, 'F');
    $pdf->Cell(186, 7, '  DATOS DEL CLIENTE', 0, 1, 'L');

    $lw = 25; $vw = 68;
    $col2_x = 12 + $lw + $vw + 4;
    $y = $pdf->GetY() + 2;

    $pdf->SetFont('Arial', 'B', 8); $pdf->SetXY(12, $y);  $pdf->Cell($lw, 6, 'Cliente:',   0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell($vw, 6, iconv('UTF-8','latin1', $cliente['nombre'] . ' ' . $cliente['apellido']), 0, 0);
    $pdf->SetFont('Arial', 'B', 8); $pdf->SetX($col2_x);  $pdf->Cell($lw, 6, 'Telefono:',  0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell(0,   6, $cliente['telefono'] ?? '---', 0, 1);

    $pdf->SetFont('Arial', 'B', 8); $pdf->SetX(12); $pdf->Cell($lw, 6, 'Direccion:', 0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell($vw, 6, iconv('UTF-8','latin1', substr($cliente['direccion'] ?? '---', 0, 45)), 0, 0);
    $pdf->SetFont('Arial', 'B', 8); $pdf->SetX($col2_x); $pdf->Cell($lw, 6, 'Estatus:',   0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell(0,   6, $cliente['estatus'] ?? '---', 0, 1);

    $pdf->SetFont('Arial', 'B', 8); $pdf->SetX(12); $pdf->Cell($lw, 6, 'ID Cliente:', 0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell($vw, 6, '#' . $id_cliente, 0, 0);
    $pdf->SetFont('Arial', 'B', 8); $pdf->SetX($col2_x); $pdf->Cell($lw, 6, 'Generado:',  0, 0);
    $pdf->SetFont('Arial', '',  8); $pdf->Cell(0,   6, date('d/m/Y H:i'), 0, 1);
    $pdf->Ln(4);

    // Resumen global
    $bw   = 186 / 4;
    $ybox = $pdf->GetY();
    $pdf->SetFillColor(239, 246, 255);
    $pdf->Rect(12, $ybox, $bw, 18, 'F');
    $pdf->SetFont('Arial', 'B', 12); $pdf->SetTextColor(37, 99, 235);
    $pdf->SetXY(12, $ybox + 2);  $pdf->Cell($bw, 8, count($prestamos), 0, 0, 'C');
    $pdf->SetFont('Arial', '',  7); $pdf->SetTextColor(100, 116, 139);
    $pdf->SetXY(12, $ybox + 10); $pdf->Cell($bw, 6, 'PRESTAMOS', 0, 0, 'C');

    $x2 = 12 + $bw;
    $pdf->SetFillColor(240, 253, 244);
    $pdf->Rect($x2, $ybox, $bw, 18, 'F');
    $pdf->SetFont('Arial', 'B', 10); $pdf->SetTextColor(22, 163, 74);
    $pdf->SetXY($x2, $ybox + 2);  $pdf->Cell($bw, 8, '$' . number_format($total_a_pagar_g, 2), 0, 0, 'C');
    $pdf->SetFont('Arial', '',  7); $pdf->SetTextColor(100, 116, 139);
    $pdf->SetXY($x2, $ybox + 10); $pdf->Cell($bw, 6, 'TOTAL A PAGAR', 0, 0, 'C');

    $x3 = 12 + $bw * 2;
    $pdf->SetFillColor(240, 253, 244);
    $pdf->Rect($x3, $ybox, $bw, 18, 'F');
    $pdf->SetFont('Arial', 'B', 10); $pdf->SetTextColor(22, 163, 74);
    $pdf->SetXY($x3, $ybox + 2);  $pdf->Cell($bw, 8, '$' . number_format($total_pagado_g, 2), 0, 0, 'C');
    $pdf->SetFont('Arial', '',  7); $pdf->SetTextColor(100, 116, 139);
    $pdf->SetXY($x3, $ybox + 10); $pdf->Cell($bw, 6, 'PAGADO', 0, 0, 'C');

    $x4 = 12 + $bw * 3;
    if ($total_saldo_g > 0) { $pdf->SetFillColor(254, 242, 242); $sc_r=220; $sc_g=38;  $sc_b=38; }
    else                    { $pdf->SetFillColor(240, 253, 244); $sc_r=22;  $sc_g=163; $sc_b=74; }
    $pdf->Rect($x4, $ybox, $bw, 18, 'F');
    $pdf->SetFont('Arial', 'B', 10); $pdf->SetTextColor($sc_r, $sc_g, $sc_b);
    $pdf->SetXY($x4, $ybox + 2);  $pdf->Cell($bw, 8, '$' . number_format($total_saldo_g, 2), 0, 0, 'C');
    $pdf->SetFont('Arial', '',  7); $pdf->SetTextColor(100, 116, 139);
    $pdf->SetXY($x4, $ybox + 10); $pdf->Cell($bw, 6, 'SALDO PENDIENTE', 0, 0, 'C');
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetY($ybox + 22);
    $pdf->Ln(2);

    // Detalle por prestamo
    foreach ($prestamos as $p) {
        $saldo      = max(0, (float)$p['saldo_actual']);
        $pagado     = (float)$p['total_pagado'];
        $porcentaje = $p['total_pagar'] > 0 ? min(100, ($pagado / $p['total_pagar']) * 100) : 0;
        $es_atrasado = ($p['estado'] === 'ATRASADO');
        $es_pagado   = ($p['estado'] === 'PAGADO');

        if ($pdf->GetY() > 240) $pdf->AddPage();

        if ($es_atrasado)    { $pdf->SetFillColor(254,242,242); $tc_r=185; $tc_g=28;  $tc_b=28;  }
        elseif ($es_pagado)  { $pdf->SetFillColor(240,253,244); $tc_r=22;  $tc_g=101; $tc_b=52;  }
        else                 { $pdf->SetFillColor(239,246,255); $tc_r=29;  $tc_g=78;  $tc_b=216; }
        $pdf->Rect(12, $pdf->GetY(), 186, 8, 'F');
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetTextColor($tc_r, $tc_g, $tc_b);
        $folio = str_pad($p['id_prestamo'], 6, '0', STR_PAD_LEFT);
        $pdf->Cell(60, 8, '  Prestamo #' . $folio . ' - ' . $p['estado'], 0, 0, 'L');
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(100, 116, 139);
        $pdf->Cell(60, 8, 'Asesor: ' . iconv('UTF-8', 'latin1', $p['asesor'] ?? '---'), 0, 0, 'C');
        $inicio_str = $p['fecha_inicio'] ? date('d/m/Y', strtotime($p['fecha_inicio'])) : '---';
        $fin_str    = $p['fecha_fin']    ? date('d/m/Y', strtotime($p['fecha_fin']))    : '---';
        $pdf->Cell(66, 8, 'Inicio: ' . $inicio_str . '  Fin: ' . $fin_str, 0, 1, 'R');
        $pdf->SetTextColor(0, 0, 0);

        $cw = 186 / 4;
        $yp = $pdf->GetY();
        if ($saldo > 0) { $sal_r=220; $sal_g=38;  $sal_b=38; }
        else            { $sal_r=22;  $sal_g=163; $sal_b=74; }
        $fields = [
            ['Capital',       '$' . number_format($p['monto_prestado'], 2), 37,  99,  235],
            ['Total a Pagar', '$' . number_format($p['total_pagar'],    2), 37,  99,  235],
            ['Pagado',        '$' . number_format($pagado,              2), 22,  163, 74 ],
            ['Saldo',         '$' . number_format($saldo,               2), $sal_r, $sal_g, $sal_b],
        ];
        foreach ($fields as $fi => $f) {
            $xp = 12 + $cw * $fi;
            $pdf->SetXY($xp, $yp);
            $pdf->SetFont('Arial', 'B', 7); $pdf->SetTextColor(100, 116, 139);
            $pdf->Cell($cw, 5, $f[0], 0, 0, 'C');
            $pdf->SetXY($xp, $yp + 5);
            $pdf->SetFont('Arial', 'B', 10); $pdf->SetTextColor($f[2], $f[3], $f[4]);
            $pdf->Cell($cw, 7, $f[1], 0, 0, 'C');
        }
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetY($yp + 13);

        // Barra de progreso
        $bar_x=12; $bar_y=$pdf->GetY(); $bar_w=186; $bar_h=4;
        $pdf->SetFillColor(226, 232, 240);
        $pdf->Rect($bar_x, $bar_y, $bar_w, $bar_h, 'F');
        if ($porcentaje > 0) {
            if ($es_pagado || $porcentaje >= 75) $pdf->SetFillColor(22,163,74);
            else $pdf->SetFillColor(245,158,11);
            $pdf->Rect($bar_x, $bar_y, $bar_w * ($porcentaje / 100), $bar_h, 'F');
        }
        $pdf->SetFont('Arial', '', 6); $pdf->SetTextColor(100,116,139);
        $pdf->SetXY($bar_x, $bar_y);
        $pdf->Cell($bar_w, $bar_h, number_format($porcentaje, 1) . '% pagado', 0, 1, 'C');
        $pdf->Ln(2);

        $dias_venc = intval($p['dias_vencido']);
        if ($es_atrasado && $dias_venc > 0) {
            $pdf->SetFillColor(254,242,242);
            $pdf->SetFont('Arial','B',7.5); $pdf->SetTextColor(220,38,38);
            $pdf->Cell(186, 5, '  ATRASADO: ' . $dias_venc . ' dias de atraso' . ($p['mora_acumulada'] > 0 ? '  |  Mora: $' . number_format($p['mora_acumulada'],2) : ''), 'LRB', 1, 'L', true);
            $pdf->Ln(1); $pdf->SetTextColor(0,0,0);
        }

        if (!empty($p['pagos_hist'])) {
            $pdf->SetFont('Arial','B',7.5);
            $pdf->SetFillColor(248,250,252); $pdf->SetTextColor(100,116,139);
            $pdf->Cell(10,6,'#',1,0,'C',true);
            $pdf->Cell(45,6,'Fecha de Pago',1,0,'C',true);
            $pdf->Cell(55,6,'Monto Pagado',1,0,'C',true);
            $pdf->Cell(76,6,'Saldo Acumulado Pagado',1,1,'C',true);
            $pdf->SetTextColor(0,0,0);

            $acum = 0; $fill = false;
            foreach ($p['pagos_hist'] as $pi => $pg) {
                $acum += $pg['monto_pagado'];
                $saldo_tras = max(0, $p['total_pagar'] - $acum);
                $pdf->SetFont('Arial','',7.5); $pdf->SetTextColor(0,0,0);
                $pdf->Cell(10,6,$pi+1,1,0,'C',$fill);
                $pdf->Cell(45,6,date('d/m/Y',strtotime($pg['fecha_pago'])),1,0,'C',$fill);
                $pdf->SetTextColor(22,163,74);
                $pdf->Cell(55,6,'+ $' . number_format($pg['monto_pagado'],2),1,0,'R',$fill);
                $pdf->SetTextColor($saldo_tras > 0 ? 220 : 22, $saldo_tras > 0 ? 38 : 163, $saldo_tras > 0 ? 38 : 74);
                $pdf->Cell(76,6,'Saldo restante: $' . number_format($saldo_tras,2),1,1,'R',$fill);
                $pdf->SetTextColor(0,0,0);
                $fill = !$fill;
            }
            $pdf->SetFillColor(239,246,255);
            $pdf->SetFont('Arial','B',8); $pdf->SetTextColor(37,99,235);
            $pdf->Cell(10,6,'',1,0,'C',true);
            $pdf->Cell(45,6,'TOTAL PAGADO',1,0,'C',true);
            $pdf->SetTextColor(22,163,74);
            $pdf->Cell(55,6,'$' . number_format($pagado,2),1,0,'R',true);
            $pdf->SetTextColor($saldo > 0 ? 220 : 22, $saldo > 0 ? 38 : 163, $saldo > 0 ? 38 : 74);
            $pdf->Cell(76,6,'Saldo actual: $' . number_format($saldo,2),1,1,'R',true);
            $pdf->SetTextColor(0,0,0);
        } else {
            $pdf->SetFont('Arial','I',8); $pdf->SetTextColor(148,163,184);
            $pdf->Cell(186,6,'  Sin pagos registrados para este prestamo.',0,1,'L');
            $pdf->SetTextColor(0,0,0);
        }
        $pdf->Ln(5);
    }

    // Resumen final
    if ($pdf->GetY() > 255) $pdf->AddPage();
    $pdf->Ln(3);
    $pdf->SetFillColor(15,23,42);
    $pdf->SetFont('Arial','B',9); $pdf->SetTextColor(255,255,255);
    $pdf->Cell(186,8,'  RESUMEN FINAL',0,1,'L',true);
    $pdf->SetTextColor(0,0,0);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(93,7,'Total a Pagar (todos los prestamos):',0,0,'L');
    $pdf->SetTextColor(37,99,235);
    $pdf->Cell(93,7,'$ ' . number_format($total_a_pagar_g,2),0,1,'R');
    $pdf->SetTextColor(0,0,0);
    $pdf->Cell(93,7,'Total Pagado:',0,0,'L');
    $pdf->SetTextColor(22,163,74);
    $pdf->Cell(93,7,'$ ' . number_format($total_pagado_g,2),0,1,'R');
    $pdf->SetTextColor(0,0,0);
    $pdf->SetFont('Arial','B',9);
    $pdf->Cell(93,8,'SALDO PENDIENTE TOTAL:',0,0,'L');
    $pdf->SetTextColor($total_saldo_g > 0 ? 220 : 22, $total_saldo_g > 0 ? 38 : 163, $total_saldo_g > 0 ? 38 : 74);
    $pdf->Cell(93,8,'$ ' . number_format($total_saldo_g,2),0,1,'R');
    $pdf->SetTextColor(0,0,0);
    $pdf->Ln(6);
    $pdf->SetFont('Arial','I',8); $pdf->SetTextColor(100,116,139);
    $pdf->Cell(0,6,'Gracias por su preferencia. - PRESTAMOS JE',0,1,'C');

    ob_end_clean();
    $pdf->Output('D', 'estado_cuenta_' . $id_cliente . '.pdf');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Estado de Cuenta — <?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script>(function(){ var t=localStorage.getItem('pje_tema')||'light'; document.documentElement.setAttribute('data-theme',t); })();</script>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;}
.app{display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:240px;background:#0f172a;height:100vh;position:fixed;top:0;left:0;display:flex;flex-direction:column;overflow-y:auto;z-index:200;box-shadow:4px 0 20px rgba(0,0,0,.2);}
.sb-brand{padding:22px 20px 16px;border-bottom:1px solid #1e293b;}
.sb-brand .brand-row{display:flex;align-items:center;gap:12px;}
.sb-brand .brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;box-shadow:0 4px 14px rgba(37,99,235,.4);flex-shrink:0;}
.sb-brand .brand-name{font-size:1rem;font-weight:800;color:#f8fafc;line-height:1.2;letter-spacing:-.3px;}
.sb-brand .brand-sub{font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}
.sb-user{padding:12px 16px;background:#1e293b;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}
.sb-user .avatar{width:34px;height:34px;background:linear-gradient(135deg,#7c3aed,#5b21b6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user .u-name{font-size:.82rem;font-weight:700;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-user .u-rol{font-size:.65rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:1px;}
.sb-clock{padding:10px 16px;border-bottom:1px solid #1e293b;text-align:center;}
.sb-clock #reloj{font-size:1.3rem;font-weight:700;color:#60a5fa;letter-spacing:2px;font-variant-numeric:tabular-nums;}
.sb-clock .fecha-sb{font-size:.68rem;color:#475569;margin-top:2px;}
.sb-nav{flex:1;padding:8px 10px 0;}
.sb-section{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;padding:12px 8px 4px;}
.sb-nav a{display:flex;align-items:center;gap:9px;color:#94a3b8;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;font-weight:500;margin-bottom:1px;transition:all .15s;}
.sb-nav a i{font-size:1rem;width:18px;text-align:center;}
.sb-nav a:hover{background:#1e293b;color:#e2e8f0;}
.sb-nav a.active{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2);}
.sb-nav a.danger{color:#f87171;}
.sb-nav a.danger:hover{background:#1e293b;color:#fca5a5;}
.sb-footer{padding:10px;border-top:1px solid #1e293b;}
.sb-footer a{display:flex;align-items:center;gap:8px;color:#64748b;text-decoration:none;padding:9px 10px;border-radius:10px;font-size:.84rem;transition:all .15s;}
.sb-footer a:hover{background:#1e293b;color:#f87171;}

/* MAIN */
.main{margin-left:240px;padding:24px 28px 60px;}

/* TOPBAR */
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;gap:12px;flex-wrap:wrap;}
.topbar-left{display:flex;align-items:center;gap:12px;}
.topbar-title{font-size:1.3rem;font-weight:800;color:#0f172a;letter-spacing:-.4px;}
.topbar-sub{font-size:.82rem;color:#64748b;margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:10px;}
.btn-icon{width:38px;height:38px;border-radius:10px;border:1.5px solid #e2e8f0;background:white;color:#64748b;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;text-decoration:none;}
.btn-icon:hover{color:#0f172a;border-color:#2563eb;}
.btn-back{display:inline-flex;align-items:center;gap:7px;background:white;border:1.5px solid #e2e8f0;border-radius:10px;padding:8px 14px;color:#64748b;text-decoration:none;font-size:.82rem;font-weight:600;transition:all .15s;box-shadow:0 1px 4px rgba(0,0,0,.05);}
.btn-back:hover{background:#f8fafc;color:#0f172a;border-color:#94a3b8;}
.btn-pdf{display:inline-flex;align-items:center;gap:8px;background:#dc2626;color:white;border:none;border-radius:10px;padding:10px 18px;font-size:.88rem;font-weight:700;text-decoration:none;cursor:pointer;transition:all .15s;box-shadow:0 4px 12px rgba(220,38,38,.25);}
.btn-pdf:hover{background:#b91c1c;transform:translateY(-1px);}

/* CLIENTE CARD */
.cliente-card{background:linear-gradient(135deg,#0f172a 0%,#1e3a8a 55%,#1d4ed8 100%);border-radius:16px;padding:20px 24px;margin-bottom:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;box-shadow:0 6px 24px rgba(37,99,235,.2);position:relative;overflow:hidden;}
.cliente-card::before{content:'';position:absolute;top:-40px;right:-40px;width:160px;height:160px;background:rgba(255,255,255,.04);border-radius:50%;}
.cli-avatar{width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,.15);border:2px solid rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:800;color:white;flex-shrink:0;position:relative;z-index:1;}
.cli-info{flex:1;position:relative;z-index:1;}
.cli-nombre{font-size:1.1rem;font-weight:800;color:white;}
.cli-sub{font-size:.82rem;color:#93c5fd;margin-top:4px;display:flex;flex-wrap:wrap;gap:12px;}
.cli-sub span{display:flex;align-items:center;gap:5px;}
.cli-fecha{text-align:right;position:relative;z-index:1;}
.cli-fecha .df{font-size:.8rem;color:#93c5fd;}
.badge-estatus{display:inline-block;padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700;margin-top:6px;}
.score-aprob{display:inline-flex;align-items:center;gap:7px;padding:5px 13px;border-radius:30px;font-size:.78rem;font-weight:700;line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.15);}
.score-aprob i{font-size:.95rem;}
.score-aprob strong{font-size:.85rem;font-weight:800;font-variant-numeric:tabular-nums;}
.score-aprob .sa-lbl{font-size:.65rem;letter-spacing:.06em;opacity:.85;padding-left:6px;border-left:1px solid currentColor;}
@media(max-width:520px){.score-aprob .sa-lbl{display:none;}}
.prest-reco{display:inline-flex;align-items:center;gap:7px;padding:5px 13px;border-radius:30px;font-size:.78rem;font-weight:700;line-height:1;background:rgba(255,255,255,.18);color:#fff;border:1.5px solid rgba(255,255,255,.35);box-shadow:0 2px 8px rgba(0,0,0,.15);}
.prest-reco i{font-size:.95rem;color:#fde68a;}
.prest-reco .pr-lbl{font-size:.65rem;font-weight:600;letter-spacing:.05em;text-transform:uppercase;opacity:.85;}
.prest-reco strong{font-size:.92rem;font-weight:800;color:#fde68a;font-variant-numeric:tabular-nums;padding-left:6px;border-left:1px solid rgba(255,255,255,.35);}
.prest-reco-no{background:rgba(220,38,38,.25);border-color:rgba(252,165,165,.5);}
.prest-reco-no i,.prest-reco-no strong{color:#fecaca;}
@media(max-width:520px){.prest-reco .pr-lbl{display:none;}}
.be-activo{background:rgba(34,197,94,.2);color:#4ade80;border:1px solid rgba(74,222,128,.3);}
.be-bloqueado{background:rgba(239,68,68,.2);color:#fca5a5;border:1px solid rgba(252,165,165,.3);}

/* STATS */
.stats-bar{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}
.stat-box{background:white;border-radius:12px;padding:16px 12px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border-top:3px solid #e2e8f0;}
.stat-box .num{font-size:1.5rem;font-weight:800;}
.stat-box .lbl{font-size:.72rem;color:#64748b;margin-top:3px;font-weight:500;}
.stat-box.s-azul{border-top-color:#3b82f6;} .stat-box.s-azul .num{color:#2563eb;}
.stat-box.s-verde{border-top-color:#22c55e;} .stat-box.s-verde .num{color:#16a34a;}
.stat-box.s-esmeralda{border-top-color:#10b981;} .stat-box.s-esmeralda .num{color:#059669;}
.stat-box.s-rojo{border-top-color:#ef4444;} .stat-box.s-rojo .num{color:#dc2626;}

/* PRESTAMO CARD */
.prest-card{background:white;border-radius:14px;margin-bottom:16px;box-shadow:0 2px 10px rgba(0,0,0,.07);overflow:hidden;border:1px solid #f1f5f9;}
.prest-head{padding:14px 18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;border-bottom:1px solid #f8fafc;}
.prest-head.activo{background:#eff6ff;border-left:4px solid #2563eb;}
.prest-head.atrasado{background:#fef2f2;border-left:4px solid #ef4444;}
.prest-head.pagado{background:#f0fdf4;border-left:4px solid #22c55e;}
.prest-head.renovado{background:#f5f3ff;border-left:4px solid #8b5cf6;}
.prest-folio{font-size:.95rem;font-weight:800;color:#0f172a;}
.prest-meta{font-size:.78rem;color:#64748b;margin-top:2px;}
.badge-pr{font-size:.72rem;font-weight:700;padding:4px 12px;border-radius:20px;white-space:nowrap;}
.bp-activo{background:#dbeafe;color:#1e40af;}
.bp-atrasado{background:#fee2e2;color:#991b1b;}
.bp-pagado{background:#dcfce7;color:#166534;}
.bp-renovado{background:#ede9fe;color:#5b21b6;}
.prest-datos{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:14px 18px;border-bottom:1px solid #f8fafc;}
.dato-box{background:#f8fafc;border-radius:9px;padding:10px;text-align:center;}
.dato-val{font-size:.92rem;font-weight:700;color:#1e293b;}
.dato-lbl{font-size:.68rem;color:#94a3b8;margin-top:2px;}
.dato-val.verde{color:#16a34a;} .dato-val.rojo{color:#dc2626;} .dato-val.azul{color:#2563eb;}
.progress-wrap{padding:10px 18px;border-bottom:1px solid #f8fafc;}
.progress-label{display:flex;justify-content:space-between;font-size:.78rem;color:#64748b;margin-bottom:6px;}
.progress-track{background:#e2e8f0;border-radius:20px;height:8px;overflow:hidden;}
.progress-fill{height:100%;border-radius:20px;background:linear-gradient(90deg,#22c55e,#16a34a);transition:width .5s;}
.progress-fill.warn{background:linear-gradient(90deg,#f59e0b,#d97706);}
.alerta-atraso{margin:10px 18px;background:#fef2f2;border:1px solid #fca5a5;border-radius:9px;padding:8px 14px;display:flex;align-items:center;gap:8px;font-size:.82rem;color:#991b1b;font-weight:600;}

/* TABLA PAGOS */
.pagos-section{padding:14px 18px;}
.pagos-section h4{font-size:.8rem;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;display:flex;align-items:center;gap:6px;}
.tabla-pagos{width:100%;border-collapse:collapse;font-size:.82rem;}
.tabla-pagos th{background:#f8fafc;color:#64748b;font-weight:700;padding:8px 10px;text-align:left;border-bottom:2px solid #e2e8f0;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;}
.tabla-pagos td{padding:8px 10px;border-bottom:1px solid #f1f5f9;color:#1e293b;}
.tabla-pagos tr:last-child td{border-bottom:none;}
.tabla-pagos tr.fila-par td{background:#f8fafc;}
.tabla-pagos tr.fila-total td{background:#eff6ff;font-weight:700;color:#1e40af;border-top:2px solid #bfdbfe;}
.td-monto{color:#16a34a;font-weight:700;}
.td-saldo-ok{color:#16a34a;font-weight:600;}
.td-saldo-pend{color:#dc2626;font-weight:600;}
.sin-pagos{font-size:.82rem;color:#94a3b8;font-style:italic;padding:10px 0;}

/* RESUMEN FINAL */
.resumen-final{background:white;border-radius:14px;padding:20px 22px;box-shadow:0 2px 10px rgba(0,0,0,.07);border:1px solid #f1f5f9;margin-top:8px;}
.resumen-final h3{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#0f172a;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid #f1f5f9;}
.rf-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f8fafc;font-size:.9rem;}
.rf-row:last-child{border-bottom:none;}
.rf-label{color:#64748b;font-weight:500;}
.rf-val{font-weight:700;}

/* DARK */
[data-theme="dark"] body{background:#0a0f1e;color:#e2e8f0;}
[data-theme="dark"] .topbar-title{color:#e2e8f0;}
[data-theme="dark"] .btn-back{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .btn-icon{background:#111827;border-color:#1e293b;color:#94a3b8;}
[data-theme="dark"] .stat-box{background:#111827;}
[data-theme="dark"] .prest-card{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .prest-head.activo{background:rgba(37,99,235,.1);}
[data-theme="dark"] .prest-head.atrasado{background:rgba(239,68,68,.1);}
[data-theme="dark"] .prest-head.pagado{background:rgba(34,197,94,.1);}
[data-theme="dark"] .prest-head.renovado{background:rgba(139,92,246,.1);}
[data-theme="dark"] .prest-folio{color:#e2e8f0;}
[data-theme="dark"] .prest-datos{border-color:#1e293b;}
[data-theme="dark"] .dato-box{background:#1e293b;}
[data-theme="dark"] .dato-val{color:#e2e8f0;}
[data-theme="dark"] .progress-wrap{border-color:#1e293b;}
[data-theme="dark"] .progress-track{background:#1e293b;}
[data-theme="dark"] .pagos-section h4{color:#94a3b8;}
[data-theme="dark"] .tabla-pagos th{background:#1e293b;color:#64748b;border-color:#334155;}
[data-theme="dark"] .tabla-pagos td{color:#e2e8f0;border-color:#1e293b;}
[data-theme="dark"] .tabla-pagos tr.fila-par td{background:#1a2234;}
[data-theme="dark"] .tabla-pagos tr.fila-total td{background:rgba(37,99,235,.15);color:#93c5fd;}
[data-theme="dark"] .resumen-final{background:#111827;border-color:#1e293b;}
[data-theme="dark"] .resumen-final h3{color:#e2e8f0;border-color:#1e293b;}
[data-theme="dark"] .rf-label{color:#64748b;}

@media(max-width:900px){
    .sidebar{display:none;}
    .main{margin-left:0;padding:14px 14px 50px;}
    .stats-bar{grid-template-columns:1fr 1fr;}
    .prest-datos{grid-template-columns:1fr 1fr;}
    .tabla-pagos{font-size:.75rem;}
}
</style>
</head>
<body>
<div class="app">

<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-sb"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php" class="active"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php"><i class="bi bi-search"></i> Buscar Cliente</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<main class="main">

    <div class="topbar">
        <div class="topbar-left">
            <a href="historial_cliente.php?id=<?= $id_cliente ?>" class="btn-back">
                <i class="bi bi-arrow-left"></i> Historial
            </a>
            <div>
                <div class="topbar-title">Estado de Cuenta</div>
                <div class="topbar-sub"><?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?></div>
            </div>
        </div>
        <div class="topbar-right">
            <a href="estado_cuenta.php?id=<?= $id_cliente ?>&pdf=1" class="btn-pdf" target="_blank">
                <i class="bi bi-file-pdf-fill"></i> Descargar PDF
            </a>
            <button class="btn-icon" onclick="toggleTema()" title="Cambiar tema">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <!-- BANNER CLIENTE -->
    <div class="cliente-card">
        <div class="cli-avatar"><?= strtoupper(substr($cliente['nombre'],0,1)) ?></div>
        <div class="cli-info">
            <div class="cli-nombre" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                <span><?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?></span>
                <span class="score-aprob" style="background:<?= $score_bg ?>;color:<?= $score_color ?>;border:1.5px solid <?= $score_color ?>55;">
                    <i class="bi <?= $score_icon ?>"></i>
                    <strong><?= $score_general ?>/100</strong>
                    <span class="sa-lbl"><?= $score_label ?></span>
                </span>
                <?php if ($prestamo_recomendado > 0): ?>
                <span class="prest-reco" title="Monto recomendado para nuevo préstamo según historial y score">
                    <i class="bi bi-cash-stack"></i>
                    <span class="pr-lbl">Préstamo recomendado</span>
                    <strong>$<?= number_format($prestamo_recomendado, 0) ?></strong>
                </span>
                <?php else: ?>
                <span class="prest-reco prest-reco-no" title="No se recomienda otorgar un nuevo préstamo en este momento">
                    <i class="bi bi-slash-circle"></i>
                    <span class="pr-lbl">Préstamo recomendado</span>
                    <strong>NO APROBABLE</strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="cli-sub">
                <?php if ($cliente['telefono']): ?>
                <span><i class="bi bi-telephone"></i> <?= htmlspecialchars($cliente['telefono']) ?></span>
                <?php endif; ?>
                <?php if ($cliente['direccion']): ?>
                <span><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($cliente['direccion']) ?></span>
                <?php endif; ?>
                <span><i class="bi bi-person-badge"></i> ID #<?= $id_cliente ?></span>
            </div>
            <?php
            $est = $cliente['estatus'] ?? 'ACTIVO';
            $est_class = $est === 'ACTIVO' ? 'be-activo' : 'be-bloqueado';
            ?>
            <span class="badge-estatus <?= $est_class ?>"><?= htmlspecialchars($est) ?></span>
        </div>
        <div class="cli-fecha">
            <div class="df">Generado el <?= date('d/m/Y H:i') ?></div>
        </div>
    </div>

    <!-- STATS GLOBALES -->
    <div class="stats-bar">
        <div class="stat-box s-azul">
            <div class="num"><?= count($prestamos) ?></div>
            <div class="lbl">Préstamos</div>
        </div>
        <div class="stat-box s-verde">
            <div class="num">$<?= number_format($total_a_pagar_g,2) ?></div>
            <div class="lbl">Total a pagar</div>
        </div>
        <div class="stat-box s-esmeralda">
            <div class="num">$<?= number_format($total_pagado_g,2) ?></div>
            <div class="lbl">Total pagado</div>
        </div>
        <div class="stat-box <?= $total_saldo_g > 0 ? 's-rojo' : 's-verde' ?>">
            <div class="num">$<?= number_format($total_saldo_g,2) ?></div>
            <div class="lbl">Saldo pendiente</div>
        </div>
    </div>

    <!-- DETALLE POR PRÉSTAMO -->
    <?php foreach ($prestamos as $p):
        $saldo      = max(0, (float)$p['saldo_actual']);
        $pagado     = (float)$p['total_pagado'];
        $porcentaje = $p['total_pagar'] > 0 ? min(100, ($pagado / $p['total_pagar']) * 100) : 0;
        $estado_lc  = strtolower($p['estado']);
        $folio      = str_pad($p['id_prestamo'], 6, '0', STR_PAD_LEFT);
        $inicio_str = $p['fecha_inicio'] ? date('d/m/Y', strtotime($p['fecha_inicio'])) : '---';
        $fin_str    = $p['fecha_fin']    ? date('d/m/Y', strtotime($p['fecha_fin']))    : '---';
        $dias_venc  = intval($p['dias_vencido']);
    ?>
    <div class="prest-card">
        <div class="prest-head <?= $estado_lc ?>">
            <div>
                <div class="prest-folio">Préstamo #<?= $folio ?></div>
                <div class="prest-meta">
                    Asesor: <?= htmlspecialchars($p['asesor'] ?? '---') ?>
                    &bull; Inicio: <?= $inicio_str ?>
                    <?php if ($fin_str !== '---'): ?>&bull; Fin: <?= $fin_str ?><?php endif; ?>
                </div>
            </div>
            <?php
            $bp_map = ['activo'=>'bp-activo','atrasado'=>'bp-atrasado','pagado'=>'bp-pagado','renovado'=>'bp-renovado'];
            $bp_cls = $bp_map[$estado_lc] ?? 'bp-activo';
            ?>
            <span class="badge-pr <?= $bp_cls ?>"><?= htmlspecialchars($p['estado']) ?></span>
        </div>

        <div class="prest-datos">
            <div class="dato-box">
                <div class="dato-val azul">$<?= number_format($p['monto_prestado'],2) ?></div>
                <div class="dato-lbl">Capital</div>
            </div>
            <div class="dato-box">
                <div class="dato-val azul">$<?= number_format($p['total_pagar'],2) ?></div>
                <div class="dato-lbl">Total a pagar</div>
            </div>
            <div class="dato-box">
                <div class="dato-val verde">$<?= number_format($pagado,2) ?></div>
                <div class="dato-lbl">Pagado</div>
            </div>
            <div class="dato-box">
                <div class="dato-val <?= $saldo > 0 ? 'rojo' : 'verde' ?>">$<?= number_format($saldo,2) ?></div>
                <div class="dato-lbl">Saldo restante</div>
            </div>
        </div>

        <div class="progress-wrap">
            <div class="progress-label">
                <span>Avance de pago</span>
                <span><?= number_format($porcentaje,1) ?>%</span>
            </div>
            <div class="progress-track">
                <div class="progress-fill <?= $porcentaje < 75 ? 'warn' : '' ?>" style="width:<?= $porcentaje ?>%"></div>
            </div>
        </div>

        <?php if ($p['estado'] === 'ATRASADO' && $dias_venc > 0): ?>
        <div class="alerta-atraso">
            <i class="bi bi-exclamation-triangle-fill"></i>
            ATRASADO: <?= $dias_venc ?> días de atraso
            <?php if ($p['mora_acumulada'] > 0): ?>
            &nbsp;&bull;&nbsp; Mora: $<?= number_format($p['mora_acumulada'],2) ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="pagos-section">
            <h4><i class="bi bi-list-check"></i> Historial de pagos</h4>
            <?php if (!empty($p['pagos_hist'])): ?>
            <table class="tabla-pagos">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Fecha</th>
                        <th>Monto pagado</th>
                        <th>Saldo restante</th>
                    </tr>
                </thead>
                <tbody>
                <?php $acum = 0; foreach ($p['pagos_hist'] as $pi => $pg):
                    $acum += $pg['monto_pagado'];
                    $saldo_tras = max(0, $p['total_pagar'] - $acum);
                    $fila_class = ($pi % 2 === 1) ? 'fila-par' : '';
                ?>
                    <tr class="<?= $fila_class ?>">
                        <td><?= $pi + 1 ?></td>
                        <td><?= date('d/m/Y', strtotime($pg['fecha_pago'])) ?></td>
                        <td class="td-monto">+ $<?= number_format($pg['monto_pagado'],2) ?></td>
                        <td class="<?= $saldo_tras > 0 ? 'td-saldo-pend' : 'td-saldo-ok' ?>">
                            $<?= number_format($saldo_tras,2) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                    <tr class="fila-total">
                        <td colspan="2">TOTAL PAGADO</td>
                        <td>$<?= number_format($pagado,2) ?></td>
                        <td class="<?= $saldo > 0 ? 'td-saldo-pend' : 'td-saldo-ok' ?>">
                            $<?= number_format($saldo,2) ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php else: ?>
            <p class="sin-pagos"><i class="bi bi-inbox"></i> Sin pagos registrados para este préstamo.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- RESUMEN FINAL -->
    <div class="resumen-final">
        <h3><i class="bi bi-bar-chart-fill" style="color:#2563eb;"></i> Resumen Final</h3>
        <div class="rf-row">
            <span class="rf-label">Total a pagar (todos los préstamos)</span>
            <span class="rf-val" style="color:#2563eb;">$<?= number_format($total_a_pagar_g,2) ?></span>
        </div>
        <div class="rf-row">
            <span class="rf-label">Total pagado</span>
            <span class="rf-val" style="color:#16a34a;">$<?= number_format($total_pagado_g,2) ?></span>
        </div>
        <div class="rf-row">
            <span class="rf-label" style="font-weight:700;">Saldo pendiente total</span>
            <span class="rf-val" style="color:<?= $total_saldo_g > 0 ? '#dc2626' : '#16a34a' ?>;font-size:1.05rem;">
                $<?= number_format($total_saldo_g,2) ?>
            </span>
        </div>
    </div>

</main>
</div>

<script>
function toggleTema() {
    var cur  = document.documentElement.getAttribute('data-theme') || 'light';
    var next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem('pje_tema', next);
    document.documentElement.setAttribute('data-theme', next);
    document.getElementById('themeIcon').className = next === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
(function(){
    var t = localStorage.getItem('pje_tema') || 'light';
    document.getElementById('themeIcon').className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function actualizarReloj() {
    var n=new Date(), p=function(x){return String(x).padStart(2,'0');};
    var el=document.getElementById('reloj');
    if(el) el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());
}
actualizarReloj(); setInterval(actualizarReloj, 1000);
</script>
</body>
</html>
<?php
include("conexion.php");

$prestamos = $conexion->query("
SELECT p.id_prestamo, p.total_pagar,
DATEDIFF(CURDATE(), p.fecha_inicio) AS dias,
IFNULL(SUM(pa.monto_pagado),0) AS pagado
FROM prestamos p
LEFT JOIN pagos pa ON p.id_prestamo = pa.id_prestamo
GROUP BY p.id_prestamo
");

while ($row = $prestamos->fetch_assoc()) {
    if ($row['dias'] > 20 && $row['pagado'] < $row['total_pagar']) {
        $conexion->query("
            UPDATE prestamos 
            SET estado='ATRASADO' 
            WHERE id_prestamo=".$row['id_prestamo']
        );
    }
}

echo "Atrasos verificados";
?>

<?php
include("conexion.php");

function puedePrestar($id_cliente, $monto) {
    global $conexion;

    $res = $conexion->query("
        SELECT COUNT(*) AS atrasos 
        FROM prestamos 
        WHERE id_cliente=$id_cliente 
        AND estado='ATRASADO'
    ");

    $atrasos = $res->fetch_assoc()['atrasos'];

    if ($atrasos > 0) {
        return $monto * 0.5; // solo prestar 50%
    }
    return $monto;
}
?>

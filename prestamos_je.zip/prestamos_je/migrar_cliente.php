<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol_actual = $_SESSION['rol']     ?? 'SUPERVISOR';
$usuario_yo = $_SESSION['usuario'] ?? 'Usuario';

$id_cliente = intval($_GET['id'] ?? 0);
if (!$id_cliente) { header("Location: clientes.php"); exit; }

$stmt = $conexion->prepare("
    SELECT c.id_cliente, c.nombre, c.apellido, c.id_asesor,
           e.nombre AS asesor_nombre, e.apellido AS asesor_apellido
    FROM clientes c
    INNER JOIN empleados e ON c.id_asesor = e.id_empleado
    WHERE c.id_cliente = ? LIMIT 1
");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();
if (!$c) { header("Location: clientes.php"); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo_asesor = intval($_POST['id_asesor']);
    if (!$nuevo_asesor || $nuevo_asesor === $c['id_asesor']) {
        $error = 'Selecciona un asesor diferente al actual.';
    } else {
        $upd = $conexion->prepare("UPDATE clientes SET id_asesor=? WHERE id_cliente=?");
        $upd->bind_param("ii", $nuevo_asesor, $id_cliente);
        if ($upd->execute()) {
            header("Location: clientes.php?ok=1"); exit;
        }
        $error = 'Error al migrar. Intenta de nuevo.';
    }
}

$asesores_result = $conexion->query("
    SELECT e.id_empleado, e.nombre, e.apellido, e.ruta_tipo
    FROM empleados e
    WHERE e.rol='ASESOR' AND e.estatus='ACTIVO' AND e.id_empleado != {$c['id_asesor']}
    ORDER BY e.apellido, e.nombre
");
$asesores = [];
while ($a = $asesores_result->fetch_assoc()) $asesores[] = $a;

$ini_cliente  = strtoupper(substr($c['nombre'], 0, 1));
$nombre_full  = htmlspecialchars($c['nombre'].' '.$c['apellido']);
$asesor_actual = htmlspecialchars($c['asesor_nombre'].' '.$c['asesor_apellido']);
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Cambiar Asesor — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ══ SIDEBAR ══ */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column; overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user { padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155; display:flex; align-items:center; gap:10px; }
.sb-user .avatar-sb {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500; margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,.15); color:#93c5fd; border:1px solid rgba(37,99,235,.2); }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a { display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none; padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s; }
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ══ MAIN ══ */
.main { margin-left:240px; flex:1; padding:24px 28px 80px; }
.inner { max-width:560px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; gap:12px; flex-wrap:wrap; }
.topbar-title { font-size:1.35rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; display:flex; align-items:center; gap:10px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:2px; display:flex; align-items:center; gap:6px; }
.topbar-sub a { color:#64748b; text-decoration:none; }
.topbar-sub a:hover { color:#2563eb; }
.topbar-right { display:flex; align-items:center; gap:8px; }
.btn-back {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 14px; color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,.05);
}
.btn-back:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.btn-theme {
    width:38px; height:38px; border-radius:10px; border:1.5px solid #e2e8f0;
    background:white; color:#64748b; cursor:pointer;
    display:flex; align-items:center; justify-content:center; font-size:1rem; transition:all .2s;
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── FLASH ── */
.flash { border-radius:12px; padding:12px 18px; margin-bottom:18px; font-size:.85rem; font-weight:600; display:flex; align-items:center; gap:8px; }
.flash.error { background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; }

/* ── CLIENTE CARD ── */
.cliente-card {
    background:white; border-radius:16px; padding:18px 20px; margin-bottom:16px;
    box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #f1f5f9;
    display:flex; align-items:center; gap:16px;
}
.cli-avatar {
    width:52px; height:52px; border-radius:50%;
    background:linear-gradient(135deg,#eff6ff,#dbeafe);
    color:#1d4ed8; font-size:1.3rem; font-weight:800;
    display:flex; align-items:center; justify-content:center; flex-shrink:0;
    border:2px solid #bfdbfe;
}
.cli-nombre { font-size:1rem; font-weight:800; color:#0f172a; }
.cli-id     { font-size:.75rem; color:#94a3b8; margin-top:2px; }

/* ── ASESOR ACTUAL ── */
.asesor-actual {
    background:#fffbeb; border:1.5px solid #fde68a; border-radius:12px;
    padding:14px 18px; margin-bottom:16px;
    display:flex; align-items:center; gap:12px;
}
.aa-icon { font-size:1.3rem; color:#d97706; flex-shrink:0; }
.aa-label { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:#92400e; }
.aa-nombre { font-size:.95rem; font-weight:800; color:#78350f; margin-top:2px; }
.aa-badge  { margin-left:auto; background:#fef3c7; color:#92400e; padding:4px 10px; border-radius:20px; font-size:.7rem; font-weight:700; white-space:nowrap; }

/* ── FORM CARD ── */
.form-card {
    background:white; border-radius:16px;
    box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #f1f5f9; overflow:hidden;
}
.form-card-header {
    padding:16px 22px; border-bottom:1px solid #f1f5f9;
    display:flex; align-items:center; gap:12px;
}
.fch-icon {
    width:38px; height:38px; border-radius:10px;
    display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0;
}
.fch-icon.amber { background:#fffbeb; color:#d97706; }
.fch-title { font-size:.95rem; font-weight:800; color:#0f172a; }
.fch-sub   { font-size:.75rem; color:#94a3b8; margin-top:2px; }
.form-card-body { padding:20px 22px; }

/* ── ASESOR RADIO LIST ── */
.asesor-list { display:flex; flex-direction:column; gap:8px; }
.asesor-radio {
    display:flex; align-items:center; gap:14px;
    padding:13px 16px; border:2px solid #e2e8f0; border-radius:12px;
    cursor:pointer; transition:all .15s; background:#f8fafc;
}
.asesor-radio:has(input:checked) { border-color:#d97706; background:#fffbeb; }
.asesor-radio:hover { border-color:#d97706; background:#fffbeb; }
.asesor-radio input[type=radio] { accent-color:#d97706; width:17px; height:17px; flex-shrink:0; }
.ar-avatar {
    width:36px; height:36px; border-radius:50%; flex-shrink:0;
    background:linear-gradient(135deg,#16a34a,#15803d);
    display:flex; align-items:center; justify-content:center;
    font-size:.9rem; font-weight:800; color:white;
}
.ar-avatar.semanal { background:linear-gradient(135deg,#2563eb,#1d4ed8); }
.ar-name  { font-size:.88rem; font-weight:800; color:#0f172a; }
.ar-ruta  { font-size:.72rem; color:#64748b; margin-top:2px; display:flex; align-items:center; gap:4px; }
.ar-badge { margin-left:auto; padding:3px 10px; border-radius:20px; font-size:.68rem; font-weight:700; white-space:nowrap; }
.ar-badge.diario  { background:#dcfce7; color:#15803d; }
.ar-badge.semanal { background:#dbeafe; color:#1d4ed8; }

.sin-asesores {
    text-align:center; padding:30px; color:#94a3b8;
    font-size:.88rem; display:flex; flex-direction:column; align-items:center; gap:8px;
}
.sin-asesores i { font-size:2rem; }

/* ── FORM ACTIONS ── */
.form-actions {
    display:flex; justify-content:space-between; align-items:center; gap:12px;
    padding:18px 22px; border-top:1px solid #f1f5f9; background:#fafafa;
}
.btn-move {
    display:inline-flex; align-items:center; gap:8px;
    background:#d97706; color:white; border:none; border-radius:10px;
    padding:10px 24px; font-size:.88rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:background .15s; flex:1; justify-content:center;
}
.btn-move:hover { background:#b45309; }
.btn-move:disabled { background:#94a3b8; cursor:not-allowed; }
.btn-cancel {
    display:inline-flex; align-items:center; gap:8px;
    background:#f1f5f9; color:#475569; border:none; border-radius:10px;
    padding:10px 20px; font-size:.88rem; font-weight:600; cursor:pointer;
    font-family:'Inter',sans-serif; text-decoration:none; transition:all .15s;
}
.btn-cancel:hover { background:#e2e8f0; color:#1e293b; }

/* ── CONFIRM OVERLAY ── */
.overlay {
    display:none; position:fixed; inset:0; background:rgba(15,23,42,.55);
    z-index:500; align-items:center; justify-content:center;
}
.overlay.show { display:flex; }
.modal {
    background:white; border-radius:18px; padding:28px 28px 24px;
    max-width:400px; width:90%; box-shadow:0 20px 60px rgba(0,0,0,.25);
    animation:popIn .2s ease;
}
@keyframes popIn { from{opacity:0;transform:scale(.95)} to{opacity:1;transform:scale(1)} }
.modal-icon { font-size:2.2rem; text-align:center; margin-bottom:10px; }
.modal h3 { font-size:1.05rem; font-weight:800; color:#0f172a; text-align:center; }
.modal p  { font-size:.85rem; color:#64748b; text-align:center; margin-top:8px; line-height:1.5; }
.modal-actions { display:flex; gap:10px; margin-top:20px; }
.modal-actions .btn-confirm {
    flex:1; background:#d97706; color:white; border:none; border-radius:10px;
    padding:10px; font-size:.88rem; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif;
}
.modal-actions .btn-confirm:hover { background:#b45309; }
.modal-actions .btn-dismiss {
    flex:1; background:#f1f5f9; color:#475569; border:none; border-radius:10px;
    padding:10px; font-size:.88rem; font-weight:600; cursor:pointer; font-family:'Inter',sans-serif;
}
.modal-actions .btn-dismiss:hover { background:#e2e8f0; }

/* ══ DARK MODE ══ */
[data-theme="dark"] body            { background:#0f172a; color:#e2e8f0; }
[data-theme="dark"] .topbar-title   { color:#f8fafc; }
[data-theme="dark"] .btn-back       { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .btn-theme      { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .cliente-card   { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .cli-nombre     { color:#f1f5f9; }
[data-theme="dark"] .asesor-actual  { background:rgba(217,119,6,.1); border-color:rgba(217,119,6,.3); }
[data-theme="dark"] .aa-nombre      { color:#fde68a; }
[data-theme="dark"] .aa-badge       { background:rgba(217,119,6,.2); color:#fbbf24; }
[data-theme="dark"] .form-card      { background:#1e293b; border-color:#334155; }
[data-theme="dark"] .form-card-header { border-color:#334155; }
[data-theme="dark"] .fch-title      { color:#f1f5f9; }
[data-theme="dark"] .fch-icon.amber { background:rgba(217,119,6,.15); }
[data-theme="dark"] .asesor-radio   { background:#0f172a; border-color:#334155; }
[data-theme="dark"] .asesor-radio:has(input:checked) { background:rgba(217,119,6,.08); border-color:#d97706; }
[data-theme="dark"] .asesor-radio:hover { background:rgba(217,119,6,.08); border-color:#d97706; }
[data-theme="dark"] .ar-name        { color:#e2e8f0; }
[data-theme="dark"] .form-actions   { background:#162032; border-color:#334155; }
[data-theme="dark"] .btn-cancel     { background:#0f172a; color:#94a3b8; }
[data-theme="dark"] .btn-cancel:hover { background:#334155; color:#e2e8f0; }
[data-theme="dark"] .modal          { background:#1e293b; }
[data-theme="dark"] .modal h3       { color:#f1f5f9; }
[data-theme="dark"] .modal-actions .btn-dismiss { background:#0f172a; color:#94a3b8; }

@media (max-width:900px) {
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 80px; }
}
</style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon">💰</div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema de Gestión</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar-sb"><?= strtoupper(substr($usuario_yo, 0, 1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($usuario_yo) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol_actual) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F \d\e Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door"></i> Inicio</a>
        <a href="cobranza_diaria.php"><i class="bi bi-calendar-check"></i> Cobranza Diaria</a>
        <div class="sb-section">Clientes</div>
        <a href="clientes.php" class="active"><i class="bi bi-people"></i> Clientes</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="clientes_atrasados.php"><i class="bi bi-exclamation-triangle"></i> Atrasados</a>
        <div class="sb-section">Finanzas</div>
        <a href="caja.php"><i class="bi bi-safe2"></i> Caja General</a>
        <a href="caja_asesor.php"><i class="bi bi-wallet2"></i> Caja Asesor</a>
        <a href="caja_asesores.php"><i class="bi bi-people-fill"></i> Resumen Asesores</a>
        <div class="sb-section">Administración</div>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reporte Diario</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ════ MAIN ════ -->
<main class="main">
<div class="inner">

    <div class="topbar">
        <div>
            <div class="topbar-title">
                <i class="bi bi-arrow-left-right" style="color:#d97706;"></i>
                Cambiar Asesor
            </div>
            <div class="topbar-sub">
                <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                <i class="bi bi-chevron-right"></i>
                <span><?= $nombre_full ?></span>
                <i class="bi bi-chevron-right"></i>
                <span>Cambiar Asesor</span>
            </div>
        </div>
        <div class="topbar-right">
            <a href="clientes.php" class="btn-back"><i class="bi bi-arrow-left"></i> Volver</a>
            <button class="btn-theme" onclick="toggleTema()">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="flash error"><i class="bi bi-x-circle-fill"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Cliente info -->
    <div class="cliente-card">
        <div class="cli-avatar"><?= $ini_cliente ?></div>
        <div>
            <div class="cli-nombre"><?= $nombre_full ?></div>
            <div class="cli-id">Cliente #<?= $c['id_cliente'] ?></div>
        </div>
    </div>

    <!-- Asesor actual -->
    <div class="asesor-actual">
        <i class="bi bi-person-fill-check aa-icon"></i>
        <div>
            <div class="aa-label">Asesor actual</div>
            <div class="aa-nombre"><?= $asesor_actual ?></div>
        </div>
        <span class="aa-badge"><i class="bi bi-arrow-right"></i> Será reemplazado</span>
    </div>

    <!-- Form selección -->
    <form method="POST" id="formMigrar">
        <input type="hidden" name="id_asesor" id="hidden_asesor" value="">

        <div class="form-card">
            <div class="form-card-header">
                <div class="fch-icon amber"><i class="bi bi-person-plus-fill"></i></div>
                <div>
                    <div class="fch-title">Seleccionar nuevo asesor</div>
                    <div class="fch-sub">Elige a quién se asignará este cliente</div>
                </div>
            </div>
            <div class="form-card-body">
                <?php if (empty($asesores)): ?>
                <div class="sin-asesores">
                    <i class="bi bi-person-x"></i>
                    No hay otros asesores activos disponibles.
                </div>
                <?php else: ?>
                <div class="asesor-list">
                    <?php foreach ($asesores as $a):
                        $ini_a   = strtoupper(substr($a['nombre'], 0, 1));
                        $es_sem  = strtolower($a['ruta_tipo'] ?? '') === 'semanal';
                        $av_cls  = $es_sem ? 'ar-avatar semanal' : 'ar-avatar';
                        $bg_cls  = $es_sem ? 'semanal' : 'diario';
                        $ruta_lbl = $a['ruta_tipo'] ?: 'Sin ruta';
                    ?>
                    <label class="asesor-radio">
                        <input type="radio" name="asesor_sel" value="<?= $a['id_empleado'] ?>"
                               onchange="document.getElementById('hidden_asesor').value=this.value">
                        <div class="<?= $av_cls ?>"><?= $ini_a ?></div>
                        <div>
                            <div class="ar-name"><?= htmlspecialchars($a['nombre'].' '.$a['apellido']) ?></div>
                            <div class="ar-ruta"><i class="bi bi-geo-alt-fill"></i> <?= htmlspecialchars($ruta_lbl) ?></div>
                        </div>
                        <span class="ar-badge <?= $bg_cls ?>"><?= $es_sem ? 'Semanal' : 'Diario' ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="form-actions">
                <a href="clientes.php" class="btn-cancel"><i class="bi bi-x-lg"></i> Cancelar</a>
                <?php if (!empty($asesores)): ?>
                <button type="button" class="btn-move" id="btnMover" disabled onclick="abrirConfirm()">
                    <i class="bi bi-arrow-left-right"></i> Confirmar Cambio
                </button>
                <?php endif; ?>
            </div>
        </div>
    </form>

</div>
</main>
</div>

<!-- ════ MODAL CONFIRMACIÓN ════ -->
<div class="overlay" id="overlay">
    <div class="modal">
        <div class="modal-icon">🔄</div>
        <h3>¿Confirmar cambio de asesor?</h3>
        <p id="modal_texto">El cliente <strong><?= $nombre_full ?></strong> será reasignado a <strong id="modal_asesor">—</strong>. Esta acción no se puede deshacer automáticamente.</p>
        <div class="modal-actions">
            <button class="btn-dismiss" onclick="cerrarConfirm()"><i class="bi bi-x-lg"></i> Cancelar</button>
            <button class="btn-confirm" onclick="document.getElementById('formMigrar').submit()">
                <i class="bi bi-check-lg"></i> Sí, cambiar
            </button>
        </div>
    </div>
</div>

<script>
// ── Tema ──
(function() {
    const t = localStorage.getItem('pje_tema') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
})();
function toggleTema() {
    const html  = document.documentElement;
    const nuevo = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nuevo);
    localStorage.setItem('pje_tema', nuevo);
    document.getElementById('themeIcon').className = nuevo === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}

// ── Reloj ──
function actualizarReloj() {
    const n = new Date(), pad = x => String(x).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}
actualizarReloj(); setInterval(actualizarReloj, 1000);

// ── Habilitar botón al seleccionar asesor ──
const nombres = {
    <?php foreach ($asesores as $a): ?>
    <?= $a['id_empleado'] ?>: "<?= htmlspecialchars($a['nombre'].' '.$a['apellido'], ENT_QUOTES) ?>",
    <?php endforeach; ?>
};

document.querySelectorAll('input[name="asesor_sel"]').forEach(r => {
    r.addEventListener('change', () => {
        document.getElementById('btnMover').disabled = false;
    });
});

function abrirConfirm() {
    const sel = document.querySelector('input[name="asesor_sel"]:checked');
    if (!sel) return;
    const nombre = nombres[sel.value] || '—';
    document.getElementById('modal_asesor').textContent = nombre;
    document.getElementById('overlay').classList.add('show');
}
function cerrarConfirm() {
    document.getElementById('overlay').classList.remove('show');
}
// Cerrar al hacer clic fuera del modal
document.getElementById('overlay').addEventListener('click', function(e) {
    if (e.target === this) cerrarConfirm();
});
</script>
</body>
</html>

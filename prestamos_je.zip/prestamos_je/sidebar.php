<?php
// sidebar.php — incluir en cada página con: <?php include("sidebar.php"); ?>
// Requiere que $_SESSION esté activa (seguridad.php ya iniciada)
$_rol  = $_SESSION['rol']     ?? '';
$_pag  = basename($_SERVER['PHP_SELF']);
function _sblink(string $href, string $emoji, string $label, string $pag): void {
    $active = (basename($href) === $pag) ? ' style="background:rgba(255,255,255,0.12);color:#fff;font-weight:600;"' : '';
    echo "<a href=\"{$href}\"{$active}>{$emoji} {$label}</a>\n";
}
?>
<div class="sidebar">

    <h5 class="fw-bold">💼 Préstamos JE</h5>
    <small class="text-secondary">Sistema financiero</small>

    <?php _sblink('index.php',             '🏠', 'Inicio',          $_pag) ?>
    <?php _sblink('dashboard.php',         '📊', 'Dashboard',       $_pag) ?>
    <?php _sblink('caja.php',              '💰', 'Caja',            $_pag) ?>
    <?php _sblink('registrar_cliente.php', '👥', 'Clientes',        $_pag) ?>
    <?php _sblink('nuevo_prestamo.php',    '📄', 'Préstamos',       $_pag) ?>
    <?php _sblink('cobranza_diaria.php',   '💳', 'Cobranza',        $_pag) ?>
    <?php _sblink('reporte_diario.php',    '📁', 'Reportes',        $_pag) ?>

    <?php if (in_array($_rol, ['ADMIN','GERENTE','SUPERVISOR'])): ?>
    <hr style="border-color:#475569;margin:8px 0;">
    <small style="color:#64748b;font-size:.65rem;text-transform:uppercase;letter-spacing:.08em;padding:0 4px;">Gerencia</small>
    <?php _sblink('reporte_cartera.php', '📈', 'Cartera',       $_pag) ?>
    <?php _sblink('corte_caja.php',      '🗄️', 'Corte de Caja', $_pag) ?>
    <?php endif; ?>

    <hr style="border-color:#475569;">

    <?php _sblink('logout.php', '🔒', 'Cerrar sesión', $_pag) ?>

</div>

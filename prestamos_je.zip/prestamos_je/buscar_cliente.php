<?php
$roles_permitidos = ['GERENTE', 'ASESOR', 'SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

$rol    = $_SESSION['rol']     ?? 'ASESOR';
$user   = $_SESSION['usuario'] ?? 'Usuario';

$clientes = [];
$busqueda = trim($_GET['q'] ?? $_GET['nombre'] ?? '');

if ($busqueda !== '') {
    $like = '%' . $conexion->real_escape_string($busqueda) . '%';

    // Filtro por asesor si es ASESOR
    $cond_asesor = '';
    if ($rol === 'ASESOR') {
        $id_emp = intval($_SESSION['id_empleado'] ?? 0);
        $cond_asesor = "AND c.id_asesor = $id_emp";
    }

    $stmt = $conexion->prepare("
        SELECT c.*,
               e.nombre  AS asesor_nombre,
               e.apellido AS asesor_apellido
        FROM clientes c
        LEFT JOIN empleados e ON e.id_empleado = c.id_asesor
        WHERE (c.nombre LIKE ? OR c.apellido LIKE ? OR c.telefono LIKE ? OR c.colonia LIKE ? OR c.curp_ine LIKE ?)
        $cond_asesor
        ORDER BY c.estatus ASC, c.nombre ASC
        LIMIT 60
    ");
    $stmt->bind_param('sssss', $like, $like, $like, $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $clientes[] = $row;
    $stmt->close();
}

$total_clientes = $conexion->query("SELECT COUNT(*) t FROM clientes")->fetch_assoc()['t'] ?? 0;
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Buscar Cliente — Préstamos J.E.</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Inter',sans-serif; background:#f0f4f8; color:#1e293b; min-height:100vh; }
.app { display:flex; min-height:100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width:240px; background:#0f172a; height:100vh;
    position:fixed; top:0; left:0;
    display:flex; flex-direction:column;
    overflow-y:auto; z-index:200;
    box-shadow:4px 0 20px rgba(0,0,0,0.2);
}
.sb-brand { padding:22px 20px 16px; border-bottom:1px solid #1e293b; }
.sb-brand .brand-row { display:flex; align-items:center; gap:12px; }
.sb-brand .brand-icon {
    width:44px; height:44px; background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border-radius:13px; display:flex; align-items:center; justify-content:center;
    font-size:1.3rem; box-shadow:0 4px 14px rgba(37,99,235,0.4); flex-shrink:0;
}
.sb-brand .brand-name { font-size:1rem; font-weight:800; color:#f8fafc; line-height:1.2; letter-spacing:-.3px; }
.sb-brand .brand-sub  { font-size:.65rem; color:#475569; text-transform:uppercase; letter-spacing:.8px; margin-top:2px; }
.sb-user {
    padding:12px 16px; background:#1e293b; border-bottom:1px solid #334155;
    display:flex; align-items:center; gap:10px;
}
.sb-user .avatar {
    width:34px; height:34px; background:linear-gradient(135deg,#7c3aed,#5b21b6);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    font-size:.85rem; font-weight:700; color:#fff; flex-shrink:0;
}
.sb-user .u-name { font-size:.82rem; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.sb-user .u-rol  { font-size:.65rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em; margin-top:1px; }
.sb-clock { padding:10px 16px; background:#0f172a; border-bottom:1px solid #1e293b; text-align:center; }
.sb-clock #reloj { font-size:1.3rem; font-weight:700; color:#60a5fa; letter-spacing:2px; font-variant-numeric:tabular-nums; }
.sb-clock .fecha-hoy { font-size:.68rem; color:#475569; margin-top:2px; }
.sb-nav { flex:1; padding:8px 10px 0; }
.sb-section { font-size:.62rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#475569; padding:12px 8px 4px; }
.sb-nav a {
    display:flex; align-items:center; gap:9px; color:#94a3b8; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; font-weight:500;
    margin-bottom:1px; transition:all .15s;
}
.sb-nav a i { font-size:1rem; width:18px; text-align:center; }
.sb-nav a:hover  { background:#1e293b; color:#e2e8f0; }
.sb-nav a.active { background:rgba(37,99,235,0.15); color:#93c5fd; border:1px solid rgba(37,99,235,0.2); }
.sb-nav a.danger  { color:#f87171; }
.sb-nav a.danger:hover  { background:#1e293b; color:#fca5a5; }
.sb-nav a.special { color:#c4b5fd; }
.sb-nav a.special:hover { background:#1e293b; color:#ddd6fe; }
.sb-footer { padding:10px; border-top:1px solid #1e293b; }
.sb-footer a {
    display:flex; align-items:center; gap:8px; color:#64748b; text-decoration:none;
    padding:9px 10px; border-radius:10px; font-size:.84rem; transition:all .15s;
}
.sb-footer a:hover { background:#1e293b; color:#f87171; }

/* ── MAIN ── */
.main { margin-left:240px; padding:24px 28px 60px; }

/* ── TOPBAR ── */
.topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; gap:12px; flex-wrap:wrap; }
.topbar-left { display:flex; align-items:center; gap:14px; }
.topbar-title { font-size:1.4rem; font-weight:800; color:#0f172a; letter-spacing:-.4px; }
.topbar-sub   { font-size:.82rem; color:#64748b; margin-top:1px; }
.topbar-right { display:flex; align-items:center; gap:10px; }
.back-btn {
    display:inline-flex; align-items:center; gap:7px;
    background:white; border:1.5px solid #e2e8f0; border-radius:10px;
    padding:8px 14px; color:#64748b; text-decoration:none;
    font-size:.82rem; font-weight:600; transition:all .15s;
    box-shadow:0 1px 4px rgba(0,0,0,.05);
}
.back-btn:hover { background:#f8fafc; color:#0f172a; border-color:#94a3b8; }
.btn-theme {
    width:38px; height:38px; border-radius:10px;
    border:1.5px solid #e2e8f0; background:white; color:#64748b;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    font-size:1rem; transition:all .2s; box-shadow:0 1px 4px rgba(0,0,0,.06);
}
.btn-theme:hover { color:#0f172a; border-color:#2563eb; }

/* ── CAJA DE BÚSQUEDA ── */
.search-box {
    background:white; border-radius:16px; padding:24px 28px;
    border:1px solid #f1f5f9; box-shadow:0 2px 10px rgba(0,0,0,.06);
    margin-bottom:22px;
}
.search-box h2 { font-size:1rem; font-weight:700; color:#0f172a; margin-bottom:4px; }
.search-box p  { font-size:.8rem; color:#94a3b8; margin-bottom:16px; }
.search-row {
    display:flex; gap:10px;
}
.search-wrap {
    flex:1; position:relative; display:flex; align-items:center;
}
.search-wrap i { position:absolute; left:14px; color:#94a3b8; font-size:1rem; pointer-events:none; }
.search-wrap input {
    width:100%; border:1.5px solid #e2e8f0; border-radius:12px;
    padding:12px 16px 12px 42px; font-size:.95rem; font-family:'Inter',sans-serif;
    color:#1e293b; background:#f8fafc; outline:none; transition:all .15s;
}
.search-wrap input:focus {
    border-color:#2563eb; background:white;
    box-shadow:0 0 0 4px rgba(37,99,235,0.08);
}
.btn-buscar {
    display:inline-flex; align-items:center; gap:8px;
    background:#2563eb; color:white; border:none; border-radius:12px;
    padding:12px 22px; font-size:.9rem; font-weight:700; cursor:pointer;
    font-family:'Inter',sans-serif; transition:all .15s;
    box-shadow:0 4px 12px rgba(37,99,235,.3);
}
.btn-buscar:hover { background:#1d4ed8; transform:translateY(-1px); }
.btn-limpiar {
    display:inline-flex; align-items:center; gap:6px;
    background:#f8fafc; color:#64748b; text-decoration:none;
    border:1.5px solid #e2e8f0; border-radius:12px;
    padding:12px 16px; font-size:.86rem; font-weight:600; transition:all .15s;
}
.btn-limpiar:hover { background:#f1f5f9; color:#0f172a; }
.search-tips {
    display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;
}
.tip-tag {
    font-size:.73rem; background:#f8fafc; border:1px solid #e2e8f0;
    color:#64748b; padding:3px 10px; border-radius:99px; cursor:pointer;
    transition:all .15s;
}
.tip-tag:hover { background:#eff6ff; border-color:#bfdbfe; color:#2563eb; }

/* ── BARRA DE RESULTADOS ── */
.result-bar {
    display:flex; justify-content:space-between; align-items:center;
    margin-bottom:16px; flex-wrap:wrap; gap:8px;
}
.result-info { font-size:.84rem; color:#64748b; font-weight:500; }
.result-info strong { color:#0f172a; }

/* ── CARDS DE CLIENTES ── */
.cards-grid {
    display:grid;
    grid-template-columns:repeat(auto-fill, minmax(300px, 1fr));
    gap:16px;
}
.cliente-card {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 8px rgba(0,0,0,.05); overflow:hidden;
    transition:all .2s; display:flex; flex-direction:column;
}
.cliente-card:hover { transform:translateY(-3px); box-shadow:0 8px 24px rgba(0,0,0,.1); }
.cc-head {
    padding:18px 20px 14px; display:flex; align-items:center; gap:14px;
    border-bottom:1px solid #f8fafc;
}
.cc-avatar {
    width:46px; height:46px; border-radius:13px; flex-shrink:0;
    display:flex; align-items:center; justify-content:center;
    font-size:1.1rem; font-weight:800; color:white;
}
.cc-nom  { font-size:.95rem; font-weight:800; color:#0f172a; line-height:1.3; }
.cc-badge { display:inline-flex; align-items:center; gap:4px; font-size:.7rem; font-weight:700; padding:3px 9px; border-radius:99px; margin-top:4px; }
.cc-badge.activo   { background:#dcfce7; color:#166534; }
.cc-badge.bloqueado{ background:#fee2e2; color:#991b1b; }
.cc-badge.mal      { background:#fef3c7; color:#92400e; }

.cc-body { padding:14px 20px; flex:1; }
.cc-fila {
    display:flex; align-items:center; gap:9px;
    font-size:.82rem; color:#64748b; margin-bottom:7px;
}
.cc-fila:last-child { margin-bottom:0; }
.cc-fila i { color:#94a3b8; font-size:.9rem; width:16px; flex-shrink:0; }
.cc-fila a { color:inherit; text-decoration:none; }
.cc-fila a:hover { color:#2563eb; }

.cc-footer {
    padding:12px 20px; border-top:1px solid #f8fafc;
    display:flex; gap:8px;
}
.btn-acc {
    flex:1; display:inline-flex; align-items:center; justify-content:center; gap:6px;
    padding:9px 12px; border-radius:10px; font-size:.78rem; font-weight:700;
    text-decoration:none; border:none; cursor:pointer; transition:all .15s;
    font-family:'Inter',sans-serif;
}
.btn-acc.ver   { background:#eff6ff; color:#2563eb; }
.btn-acc.ver:hover   { background:#2563eb; color:white; }
.btn-acc.prest { background:#f0fdf4; color:#16a34a; }
.btn-acc.prest:hover { background:#16a34a; color:white; }
.btn-acc.block { background:#fef2f2; color:#dc2626; }
.btn-acc.block:hover { background:#dc2626; color:white; }
.btn-acc.unlock{ background:#f0fdf4; color:#16a34a; }
.btn-acc.unlock:hover{ background:#16a34a; color:white; }
.btn-acc.icon-only { flex:0 0 auto; width:36px; padding:9px 0; }

/* ── ESTADO VACÍO ── */
.empty-state {
    background:white; border-radius:16px; border:1px solid #f1f5f9;
    box-shadow:0 2px 10px rgba(0,0,0,.06);
    text-align:center; padding:60px 24px;
    color:#94a3b8;
}
.empty-state i { font-size:3rem; display:block; margin-bottom:14px; opacity:.25; }
.empty-state h3 { font-size:.95rem; font-weight:700; color:#64748b; margin-bottom:6px; }
.empty-state p  { font-size:.82rem; }

/* ── FOOTER ── */
.page-footer { text-align:center; color:#cbd5e1; font-size:.72rem; padding:12px 0; border-top:1px solid #e2e8f0; margin-top:8px; }

/* ── RESPONSIVE ── */
@media(max-width:900px){
    .sidebar { display:none; }
    .main    { margin-left:0; padding:14px 14px 50px; }
    .search-row { flex-wrap:wrap; }
    .cards-grid { grid-template-columns:1fr; }
}

/* ══════════════════════════
   MODO OSCURO
══════════════════════════ */
[data-theme="dark"] body { background:#0a0f1e; color:#e2e8f0; }
[data-theme="dark"] .topbar-title { color:#e2e8f0; }
[data-theme="dark"] .back-btn  { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .back-btn:hover { background:#1e293b; color:#e2e8f0; }
[data-theme="dark"] .btn-theme { background:#111827; border-color:#1e293b; color:#94a3b8; }
[data-theme="dark"] .search-box { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .search-box h2 { color:#e2e8f0; }
[data-theme="dark"] .search-wrap input { background:#1e293b; border-color:#334155; color:#e2e8f0; }
[data-theme="dark"] .search-wrap input:focus { border-color:#3b82f6; background:#1e293b; }
[data-theme="dark"] .btn-limpiar { background:#1e293b; border-color:#334155; color:#94a3b8; }
[data-theme="dark"] .tip-tag { background:#1e293b; border-color:#334155; color:#64748b; }
[data-theme="dark"] .tip-tag:hover { background:rgba(37,99,235,0.15); border-color:#3b82f6; color:#93c5fd; }
[data-theme="dark"] .result-info        { color:#94a3b8; }
[data-theme="dark"] .result-info strong { color:#e2e8f0; }
[data-theme="dark"] .cliente-card { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .cliente-card:hover { box-shadow:0 8px 24px rgba(0,0,0,.4); }
[data-theme="dark"] .cc-head { border-color:#1e293b; }
[data-theme="dark"] .cc-nom  { color:#e2e8f0; }
[data-theme="dark"] .cc-badge.activo   { background:rgba(22,163,74,0.15); color:#4ade80; }
[data-theme="dark"] .cc-badge.bloqueado{ background:rgba(220,38,38,0.15); color:#f87171; }
[data-theme="dark"] .cc-badge.mal      { background:rgba(217,119,6,0.15); color:#fcd34d; }
[data-theme="dark"] .cc-fila { color:#94a3b8; }
[data-theme="dark"] .cc-footer { border-color:#1e293b; }
[data-theme="dark"] .btn-acc.ver   { background:rgba(37,99,235,0.15); color:#93c5fd; }
[data-theme="dark"] .btn-acc.prest { background:rgba(22,163,74,0.15); color:#4ade80; }
[data-theme="dark"] .btn-acc.block { background:rgba(220,38,38,0.15); color:#f87171; }
[data-theme="dark"] .btn-acc.unlock{ background:rgba(22,163,74,0.15); color:#4ade80; }
[data-theme="dark"] .empty-state { background:#111827; border-color:#1e293b; box-shadow:none; }
[data-theme="dark"] .empty-state h3 { color:#94a3b8; }
[data-theme="dark"] .page-footer { color:#334155; border-color:#1e293b; }
</style>
</head>
<body>
<div class="app">

<!-- ══════════════════════════════════════
     SIDEBAR
══════════════════════════════════════ -->
<aside class="sidebar">
    <div class="sb-brand">
        <div class="brand-row">
            <div class="brand-icon"><i class="bi bi-bank2" style="color:white;font-size:1.3rem;"></i></div>
            <div>
                <div class="brand-name">Préstamos J.E.</div>
                <div class="brand-sub">Sistema Financiero</div>
            </div>
        </div>
    </div>
    <div class="sb-user">
        <div class="avatar"><?= strtoupper(substr($user,0,1)) ?></div>
        <div>
            <div class="u-name"><?= htmlspecialchars($user) ?></div>
            <div class="u-rol"><?= htmlspecialchars($rol) ?></div>
        </div>
    </div>
    <div class="sb-clock">
        <div id="reloj">--:--:--</div>
        <div class="fecha-hoy"><?= date('d \d\e F Y') ?></div>
    </div>
    <nav class="sb-nav">
        <div class="sb-section">Principal</div>
        <a href="index.php"><i class="bi bi-house-door-fill"></i> Inicio</a>
        <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <div class="sb-section">Operaciones</div>
        <a href="caja.php"><i class="bi bi-safe"></i> Caja Diaria</a>
        <a href="historial_caja.php"><i class="bi bi-clock-history"></i> Historial Caja</a>
        <a href="registrar_cliente.php"><i class="bi bi-person-plus"></i> Nuevo Cliente</a>
        <a href="nuevo_prestamo.php"><i class="bi bi-file-earmark-plus"></i> Nuevo Préstamo</a>
        <a href="cobranza_diaria.php"><i class="bi bi-credit-card"></i> Cobranza</a>
        <a href="cobro_diario/cobro_diario.php" class="danger"><i class="bi bi-calendar-check"></i> Cobro Diario</a>
        <div class="sb-section">Gestión</div>
        <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
        <?php if ($rol === 'GERENTE'): ?>
        <a href="empleados.php"><i class="bi bi-person-badge"></i> Empleados</a>
        <?php endif; ?>
        <a href="programacion_prestamo.php"><i class="bi bi-calendar3-range"></i> Programación</a>
        <a href="reporte_diario.php"><i class="bi bi-bar-chart-line"></i> Reportes</a>
        <a href="buscar_cliente.php" class="active"><i class="bi bi-search"></i> Buscar Cliente</a>
        <div class="sb-section">Especial</div>
        <a href="nuevo_prestamo_especial.php" class="special"><i class="bi bi-stars"></i> Migración</a>
        <a href="cobro_diario/cobro_buscar.php" class="special"><i class="bi bi-search-heart"></i> Cobro Buscar</a>
    </nav>
    <div class="sb-footer">
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
</aside>

<!-- ══════════════════════════════════════
     MAIN
══════════════════════════════════════ -->
<main class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div class="topbar-left">
            <a href="clientes.php" class="back-btn">
                <i class="bi bi-arrow-left"></i> Clientes
            </a>
            <div>
                <div class="topbar-title">Buscar Cliente</div>
                <div class="topbar-sub"><?= number_format($total_clientes) ?> clientes en el sistema</div>
            </div>
        </div>
        <div class="topbar-right">
            <button class="btn-theme" onclick="toggleTheme()" title="Cambiar tema">
                <i class="bi bi-moon-fill" id="themeIcon"></i>
            </button>
        </div>
    </div>

    <!-- BUSCADOR -->
    <div class="search-box">
        <h2><i class="bi bi-search" style="color:#2563eb;margin-right:8px;"></i>Buscar Cliente</h2>
        <p>Busca por nombre, apellido, teléfono, colonia o CURP/INE</p>
        <form method="GET" autocomplete="off" id="formBuscar">
            <div class="search-row">
                <div class="search-wrap">
                    <i class="bi bi-person-search"></i>
                    <input type="text" name="q" id="campoBuscar"
                           placeholder="Ej: García, Juan, 6621234567, Col. Centro..."
                           value="<?= htmlspecialchars($busqueda) ?>"
                           autofocus>
                </div>
                <button type="submit" class="btn-buscar">
                    <i class="bi bi-search"></i> Buscar
                </button>
                <?php if ($busqueda !== ''): ?>
                <a href="buscar_cliente.php" class="btn-limpiar">
                    <i class="bi bi-x-circle"></i> Limpiar
                </a>
                <?php endif; ?>
            </div>
        </form>
        <!-- Sugerencias rápidas (solo en estado vacío) -->
        <?php if ($busqueda === ''): ?>
        <div class="search-tips" id="tipsRapidos">
            <span style="font-size:.73rem;color:#94a3b8;align-self:center;">Búsquedas recientes:</span>
            <span id="tips-container"></span>
        </div>
        <?php endif; ?>
    </div>

    <!-- RESULTADOS -->
    <?php if ($busqueda !== ''): ?>

    <div class="result-bar">
        <div class="result-info">
            <i class="bi bi-funnel" style="margin-right:4px;"></i>
            <strong><?= count($clientes) ?></strong> resultado<?= count($clientes)!=1?'s':'' ?>
            para "<strong><?= htmlspecialchars($busqueda) ?></strong>"
            <?php if (count($clientes) === 60): ?>
            <span style="color:#f59e0b;font-size:.75rem;margin-left:6px;">(límite: 60 resultados — sé más específico)</span>
            <?php endif; ?>
        </div>
        <?php if (count($clientes) > 0): ?>
        <a href="registrar_cliente.php" style="display:inline-flex;align-items:center;gap:6px;font-size:.78rem;font-weight:600;color:#2563eb;text-decoration:none;">
            <i class="bi bi-person-plus-fill"></i> Registrar nuevo
        </a>
        <?php endif; ?>
    </div>

    <?php if (empty($clientes)): ?>
    <div class="empty-state">
        <i class="bi bi-person-x"></i>
        <h3>Sin resultados</h3>
        <p>No se encontró ningún cliente con "<strong><?= htmlspecialchars($busqueda) ?></strong>"</p>
        <a href="registrar_cliente.php"
           style="display:inline-flex;align-items:center;gap:6px;margin-top:16px;background:#2563eb;color:white;border-radius:10px;padding:9px 18px;text-decoration:none;font-size:.84rem;font-weight:700;">
            <i class="bi bi-person-plus-fill"></i> Registrar como nuevo cliente
        </a>
    </div>

    <?php else: ?>
    <div class="cards-grid">
        <?php
        $colores_avatar = ['#2563eb','#7c3aed','#0891b2','#16a34a','#dc2626','#d97706','#db2777'];
        foreach ($clientes as $idx => $row):
            $nombre_completo = $row['nombre'] . ' ' . $row['apellido'];
            $iniciales = strtoupper(substr($row['nombre'],0,1).substr($row['apellido'],0,1));
            $estatus   = strtoupper($row['estatus'] ?? 'ACTIVO');
            $color_av  = $colores_avatar[$idx % count($colores_avatar)];
        ?>
        <div class="cliente-card">
            <div class="cc-head">
                <div class="cc-avatar" style="background:<?= $color_av ?>;">
                    <?= $iniciales ?>
                </div>
                <div>
                    <div class="cc-nom"><?= htmlspecialchars($nombre_completo) ?></div>
                    <?php
                    $badge_class = match($estatus) {
                        'ACTIVO'       => 'activo',
                        'BLOQUEADO'    => 'bloqueado',
                        'MAL_HISTORIAL'=> 'mal',
                        default        => 'activo'
                    };
                    $badge_icon = match($estatus) {
                        'ACTIVO'       => 'bi-check-circle-fill',
                        'BLOQUEADO'    => 'bi-slash-circle',
                        'MAL_HISTORIAL'=> 'bi-exclamation-triangle-fill',
                        default        => 'bi-circle'
                    };
                    $badge_txt = match($estatus) {
                        'ACTIVO'       => 'Activo',
                        'BLOQUEADO'    => 'Bloqueado',
                        'MAL_HISTORIAL'=> 'Mal historial',
                        default        => $estatus
                    };
                    ?>
                    <span class="cc-badge <?= $badge_class ?>">
                        <i class="bi <?= $badge_icon ?>"></i> <?= $badge_txt ?>
                    </span>
                </div>
            </div>

            <div class="cc-body">
                <?php if (!empty($row['telefono'])): ?>
                <div class="cc-fila">
                    <i class="bi bi-telephone"></i>
                    <a href="tel:<?= htmlspecialchars($row['telefono']) ?>"><?= htmlspecialchars($row['telefono']) ?></a>
                </div>
                <?php endif; ?>

                <?php if (!empty($row['direccion'])): ?>
                <div class="cc-fila">
                    <i class="bi bi-geo-alt"></i>
                    <span><?= htmlspecialchars(($row['direccion'] ?? '').($row['numero_exterior'] && $row['numero_exterior']!='S/N' ? ' #'.$row['numero_exterior'] : '').(!empty($row['colonia']) ? ', '.$row['colonia'] : '')) ?></span>
                </div>
                <?php endif; ?>

                <?php if (!empty($row['negocio'])): ?>
                <div class="cc-fila">
                    <i class="bi bi-shop"></i>
                    <span><?= htmlspecialchars($row['negocio']) ?></span>
                </div>
                <?php endif; ?>

                <?php if (!empty($row['asesor_nombre'])): ?>
                <div class="cc-fila">
                    <i class="bi bi-person-badge"></i>
                    <span><?= htmlspecialchars($row['asesor_nombre'].' '.$row['asesor_apellido']) ?></span>
                </div>
                <?php endif; ?>

                <?php if (!empty($row['fecha_registro'])): ?>
                <div class="cc-fila">
                    <i class="bi bi-calendar3"></i>
                    <span>Registrado el <?= date('d/m/Y', strtotime($row['fecha_registro'])) ?></span>
                </div>
                <?php endif; ?>
            </div>

            <div class="cc-footer">
                <a href="estado_cuenta.php?id=<?= (int)$row['id_cliente'] ?>" class="btn-acc ver" target="_blank">
                    <i class="bi bi-file-earmark-text"></i> Estado de cuenta
                </a>
                <?php if ($estatus === 'ACTIVO'): ?>
                <a href="nuevo_prestamo.php?id_cliente=<?= (int)$row['id_cliente'] ?>" class="btn-acc prest icon-only" title="Nuevo préstamo">
                    <i class="bi bi-file-earmark-plus"></i>
                </a>
                <a href="bloquear_cliente.php?id=<?= (int)$row['id_cliente'] ?>"
                   class="btn-acc block icon-only"
                   onclick="return confirm('¿Bloquear a <?= htmlspecialchars(addslashes($nombre_completo)) ?>?')"
                   title="Bloquear">
                    <i class="bi bi-slash-circle"></i>
                </a>
                <?php elseif ($estatus === 'BLOQUEADO'): ?>
                <a href="desbloquear_cliente.php?id=<?= (int)$row['id_cliente'] ?>"
                   class="btn-acc unlock icon-only"
                   onclick="return confirm('¿Desbloquear a <?= htmlspecialchars(addslashes($nombre_completo)) ?>?')"
                   title="Desbloquear">
                    <i class="bi bi-unlock-fill"></i>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <!-- ESTADO INICIAL -->
    <div class="empty-state">
        <i class="bi bi-search"></i>
        <h3>Realiza una búsqueda</h3>
        <p>Escribe el nombre, apellido, teléfono, colonia o CURP/INE del cliente</p>
    </div>
    <?php endif; ?>

    <div class="page-footer">
        Préstamos J.E. &copy; <?= date('Y') ?> — Búsqueda de Clientes
    </div>

</main>
</div>

<script>
const THEME_KEY = 'pje_tema';
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
}
function toggleTheme() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
}
(function(){ applyTheme(localStorage.getItem(THEME_KEY) || 'light'); })();

function actualizarReloj() {
    const ahora = new Date();
    const h = String(ahora.getHours()).padStart(2,'0');
    const m = String(ahora.getMinutes()).padStart(2,'0');
    const s = String(ahora.getSeconds()).padStart(2,'0');
    const el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

// Historial de búsquedas recientes (localStorage)
const HIST_KEY = 'pje_busquedas';
function getHistorial() {
    try { return JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); } catch(e) { return []; }
}
function guardarBusqueda(q) {
    if (!q.trim()) return;
    let h = getHistorial().filter(x => x !== q.trim());
    h.unshift(q.trim());
    h = h.slice(0, 6);
    localStorage.setItem(HIST_KEY, JSON.stringify(h));
}
function renderTips() {
    const cont = document.getElementById('tips-container');
    if (!cont) return;
    const hist = getHistorial();
    if (hist.length === 0) {
        document.getElementById('tipsRapidos').style.display = 'none';
        return;
    }
    cont.innerHTML = hist.map(q =>
        `<span class="tip-tag" onclick="usarTip('${q.replace(/'/g,"\\'")}')">
            <i class="bi bi-clock" style="margin-right:3px;font-size:.65rem;"></i>${q}
        </span>`
    ).join('');
}
function usarTip(q) {
    document.getElementById('campoBuscar').value = q;
    document.getElementById('formBuscar').submit();
}

// Guardar al buscar
document.getElementById('formBuscar')?.addEventListener('submit', function() {
    const q = document.getElementById('campoBuscar').value;
    guardarBusqueda(q);
});

// Buscar con Enter automático tras 500ms sin escribir
let debounceTimer;
document.getElementById('campoBuscar')?.addEventListener('input', function() {
    clearTimeout(debounceTimer);
    const q = this.value.trim();
    if (q.length >= 3) {
        debounceTimer = setTimeout(() => {
            document.getElementById('formBuscar').submit();
        }, 600);
    }
});

renderTips();
</script>
</body>
</html>
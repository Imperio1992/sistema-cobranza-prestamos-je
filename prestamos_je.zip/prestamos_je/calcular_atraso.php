<?php

function calcularAtraso($fecha_inicio,$pago_diario,$total_pagado){

date_default_timezone_set('America/Mexico_City');

$hoy = new DateTime();
$inicio = new DateTime($fecha_inicio);

$dias_transcurridos = $inicio->diff($hoy)->days;

// desde el segundo día empieza a contar
if($dias_transcurridos <= 1){
    return [
        "dias_atraso"=>0,
        "deuda"=>0
    ];
}

$pagos_debidos = $dias_transcurridos;

$monto_debido = $pagos_debidos * $pago_diario;

$deuda = $monto_debido - $total_pagado;

if($deuda < 0){
    $deuda = 0;
}

$dias_pagados = floor($total_pagado / $pago_diario);

$dias_atraso = $pagos_debidos - $dias_pagados;

if($dias_atraso < 0){
    $dias_atraso = 0;
}

return [
    "dias_atraso"=>$dias_atraso,
    "deuda"=>$deuda
];

}

?>
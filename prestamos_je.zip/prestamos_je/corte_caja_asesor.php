<?php
$roles_permitidos = ['GERENTE','SUPERVISOR'];
include("seguridad.php");
include("conexion.php");

date_default_timezone_set('America/Hermosillo');

/*********************************
 FILTROS
**********************************/

$id_empleado = $_GET['asesor'] ?? '';
$fecha_inicio = $_GET['inicio'] ?? '';
$fecha_fin = $_GET['fin'] ?? '';

/* SI NO SE SELECCIONAN FECHAS → SEMANA AUTOMÁTICA */

if(!$fecha_inicio && !$fecha_fin){

$hoy = date("Y-m-d");

$dia_semana = date("N"); //1 lunes - 7 domingo

$lunes = date("Y-m-d", strtotime("-".($dia_semana-1)." days"));
$sabado = date("Y-m-d", strtotime($lunes." +5 days"));

$fecha_inicio = $lunes;
$fecha_fin = $sabado;

}

$filtro = "WHERE 1=1";

if($id_empleado){
$filtro .= " AND c.id_empleado='$id_empleado'";
}

if($fecha_inicio && $fecha_fin){
$filtro .= " AND DATE(c.fecha) BETWEEN '$fecha_inicio' AND '$fecha_fin'";
}

/*********************************
 OBTENER ASESORES
**********************************/

$asesores = $conexion->query("
SELECT id_empleado,nombre,apellido
FROM empleados
WHERE rol='ASESOR'
AND estatus='ACTIVO'
ORDER BY apellido,nombre
");

/*********************************
 MOVIMIENTOS
**********************************/

$movimientos = $conexion->query("
SELECT c.*, e.nombre, e.apellido
FROM caja c
LEFT JOIN empleados e
ON c.id_empleado = e.id_empleado
$filtro
ORDER BY c.fecha DESC
");

/*********************************
 TOTALES
**********************************/

/*********************************
 CORTE INTELIGENTE
**********************************/

/* COBROS */
$cobros = $conexion->query("
SELECT SUM(monto) as total
FROM caja c
WHERE tipo = 'ENTRADA'
" . ($id_empleado ? " AND c.id_empleado='$id_empleado'" : "") . "
" . ($fecha_inicio && $fecha_fin ? " AND DATE(c.fecha) BETWEEN '$fecha_inicio' AND '$fecha_fin'" : "") . "
");



/* PRESTAMOS */
$prestamos = $conexion->query("
SELECT SUM(monto) as total
FROM caja c
WHERE tipo = 'SALIDA'
" . ($id_empleado ? " AND c.id_empleado='$id_empleado'" : "") . "
" . ($fecha_inicio && $fecha_fin ? " AND DATE(c.fecha) BETWEEN '$fecha_inicio' AND '$fecha_fin'" : "") . "
");

$total_cobrado = $cobros->fetch_assoc()['total'] ?? 0;
$total_prestado = $prestamos->fetch_assoc()['total'] ?? 0;


/* GANANCIA REAL */
$ganancia = $total_cobrado - $total_prestado;


/* CONFIGURABLE */
$porcentaje_asesor = 0.20; // puedes cambiarlo


/* CALCULOS */
$comision_asesor = $ganancia * $porcentaje_asesor;
$ganancia_empresa = $ganancia - $comision_asesor;

$result = $conexion->query("
SELECT 
SUM(CASE WHEN tipo='ENTRADA' THEN monto ELSE 0 END) as ingresos,
SUM(CASE WHEN tipo='SALIDA' THEN monto ELSE 0 END) as egresos,
SUM(
CASE 
WHEN tipo='ENTRADA' THEN monto
WHEN tipo='SALIDA' THEN -monto
END
) as saldo
FROM caja c
$filtro
");

$totales = $result->fetch_assoc();

$ingresos = $totales['ingresos'] ?? 0;
$egresos = $totales['egresos'] ?? 0;
$saldo = $totales['saldo'] ?? 0;

?>

<!DOCTYPE html>
<html>

<head>

<title>Corte de Caja por Asesor</title>

<style>

body{
font-family:Arial;
background:#f4f6f9;
}

.container{
width:95%;
margin:auto;
margin-top:20px;
}

.cards{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
gap:20px;
margin-top:20px;
}

.card{
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 2px 5px rgba(0,0,0,0.1);
text-align:center;
}

.card h3{
margin:0;
font-size:16px;
color:#555;
}

.card p{
font-size:22px;
font-weight:bold;
margin-top:10px;
}

table{
width:100%;
border-collapse:collapse;
background:white;
margin-top:20px;
border-radius:10px;
overflow:hidden;
}

th{
background:#343a40;
color:white;
}

th,td{
padding:10px;
text-align:center;
border-bottom:1px solid #ddd;
}

.entrada{
color:#28a745;
font-weight:bold;
}

.salida{
color:#dc3545;
font-weight:bold;
}

.btn{
padding:10px 16px;
border:none;
border-radius:6px;
cursor:pointer;
color:white;
background:#6c757d;
}

.filtro{
background:white;
padding:15px;
border-radius:10px;
margin-top:20px;
box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

</style>

</head>

<body>

<div class="container">

<h2>📊 Corte de Caja por Asesor</h2>

<button class="btn" onclick="location.href='caja.php'">
⬅ Volver a Caja
</button>

<div class="filtro">

<form method="GET">

Asesor
<select name="asesor">

<option value="">Todos</option>

<?php while($a = $asesores->fetch_assoc()){ ?>

<option value="<?php echo $a['id_empleado']; ?>" 
<?php if($id_empleado==$a['id_empleado']) echo "selected"; ?>>

<?php echo $a['nombre']." ".$a['apellido']; ?>

</option>

<?php } ?>

</select>

Fecha inicio
<input type="date" name="inicio" value="<?php echo $fecha_inicio; ?>">

Fecha fin
<input type="date" name="fin" value="<?php echo $fecha_fin; ?>">

<button class="btn">Filtrar</button>

</form>

</div>

<div class="cards">

<div class="card">
<h3>💰 Total Cobrado</h3>
<p>$<?php echo number_format($total_cobrado,2); ?></p>
</div>

<div class="card">
<h3>🏦 Total Prestado</h3>
<p>$<?php echo number_format($total_prestado,2); ?></p>
</div>

<div class="card">
<h3>📈 Ganancia</h3>
<p>$<?php echo number_format($ganancia,2); ?></p>
</div>

<div class="card">
<h3>🧍 Comisión Asesor</h3>
<p>$<?php echo number_format($comision_asesor,2); ?></p>
</div>

<div class="card">
<h3>🏢 Ganancia Empresa</h3>
<p>$<?php echo number_format($ganancia_empresa,2); ?></p>
</div>

<div class="card">
<h3>Ingresos</h3>
<p>$<?php echo number_format($ingresos,2); ?></p>
</div>

<div class="card">
<h3>Egresos</h3>
<p>$<?php echo number_format($egresos,2); ?></p>
</div>

<div class="card">
<h3>Saldo</h3>
<p>$<?php echo number_format($saldo,2); ?></p>
</div>

</div>

<table>

<tr>
<th>ID</th>
<th>Tipo</th>
<th>Monto</th>
<th>Medio</th>
<th>Asesor</th>
<th>Concepto</th>
<th>Fecha</th>
</tr>

<?php while($m = $movimientos->fetch_assoc()){ ?>

<tr>

<td><?php echo $m['id_caja']; ?></td>

<td class="<?php echo $m['tipo']=='ENTRADA'?'entrada':'salida'; ?>">
<?php echo $m['tipo']; ?>
</td>

<td>$<?php echo number_format($m['monto'],2); ?></td>

<td><?php echo $m['medio']; ?></td>

<td>
<?php echo $m['nombre']." ".$m['apellido']; ?>
</td>

<td><?php echo $m['concepto']; ?></td>

<td><?php echo $m['fecha']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>